"""Cat-ode escritorio · los controles dentro del vídeo, como los de YouTube (02/10/2026): barra con degradado sobre la imagen
con el progreso, reproducir, siguiente, volumen, tiempo y capítulo, y a la derecha subtítulos, la rueda de ajustes
(calidad, velocidad, subtítulos, temporizador, repetir, solo sonido) y pantalla completa. Aparecen al mover el ratón, se
esconden a los 2,5 s si el vídeo suena y se quedan a la vista en pausa.

Es una ventanita transparente sin marco pegada encima del vídeo (mpv pinta en su propia ventana nativa y un widget normal
no se puede dibujar encima). Recibe todo el ratón del vídeo: clic = pausa, doble clic = pantalla completa, derecho = menú,
rueda = volumen."""
import os

from PySide6.QtCore import Qt, QTimer, QPoint, QRect, QSize, QEvent
from PySide6.QtGui import QColor, QPainter, QLinearGradient, QCursor, QFont, QPixmap
from PySide6.QtWidgets import QWidget, QHBoxLayout, QVBoxLayout, QLabel, QPushButton, QMenu, QSizePolicy

from . import motor
from .iconos import icono


class VistaPrevia(QLabel):
    """La miniatura del momento al pasar el ratón por la barra, como YouTube (03/10/2026): recorte del mosaico de
    storyboard de YouTube (Reproductor.storyboard), con la hora debajo. Los mosaicos se bajan una vez y se guardan."""
    _mosaicos = {}   # url → QPixmap (compartido entre la barra de abajo y los mandos del vídeo)
    _pidiendo = set()

    def __init__(self, ventana):
        super().__init__(None, Qt.ToolTip | Qt.FramelessWindowHint | Qt.WindowDoesNotAcceptFocus)
        self.ventana = ventana
        self.setStyleSheet("background: #000; border: 2px solid #EEE; border-radius: 6px; color: white; font-size: 12px; font-weight: 600;")
        self.setAlignment(Qt.AlignHCenter | Qt.AlignBottom)
        self.setFixedSize(244, 137 + 22)
        self._clave = None
        self._hora = ""

    def text(self):   # la hora va aparte: en un QLabel, setText borra la imagen (solo se veía la hora, 04/10/2026)
        return self._hora

    def mostrar(self, rep, frac, punto):
        sb = getattr(rep, "storyboard", None)
        dur = rep.dur or getattr(rep, "_dur", 0)
        if not sb or not dur or not sb.get("mosaicos"):
            return self.hide()
        t = max(0.0, min(dur, frac * dur))
        idx = int(t / max(sb["paso"], 0.1))
        por_mosaico = sb["filas"] * sb["columnas"]
        m = min(idx // por_mosaico, len(sb["mosaicos"]) - 1)
        celda = idx % por_mosaico
        url = sb["mosaicos"][m]
        self._clave = (url, celda)
        pix = self._mosaicos.get(url)
        if pix is None:
            self._pedir(url)
            self.setPixmap(QPixmap())
        else:
            fila, col = celda // sb["columnas"], celda % sb["columnas"]
            trozo = pix.copy(col * sb["ancho"], fila * sb["alto"], sb["ancho"], sb["alto"])
            self.setPixmap(trozo.scaled(240, 135, Qt.IgnoreAspectRatio, Qt.SmoothTransformation))
        self._hora = motor.tiempo(t)
        self.update()
        self.move(punto.x() - self.width() // 2, punto.y() - self.height() - 18)
        if not self.isVisible():
            self.show()

    def _pedir(self, url):
        if url in self._pidiendo:
            return
        self._pidiendo.add(url)
        import threading
        import urllib.request
        from . import fichas

        def bajar():
            datos = b""
            try:
                datos = urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": motor.AGENTE}), timeout=15).read()
            except Exception:   # noqa: BLE001
                pass
            fichas.en_ventana(lambda _: self._llegado(url, datos), None)
        threading.Thread(target=bajar, daemon=True).start()

    def _llegado(self, url, datos):
        self._pidiendo.discard(url)
        p = QPixmap()
        if datos and p.loadFromData(datos):
            if len(self._mosaicos) > 400:
                self._mosaicos.clear()
            self._mosaicos[url] = p
            if self.isVisible() and self._clave and self._clave[0] == url:   # el ratón sigue en ese mosaico: pintarlo
                sb = getattr(self.ventana.rep, "storyboard", None)
                if sb:
                    celda = self._clave[1]
                    fila, col = celda // sb["columnas"], celda % sb["columnas"]
                    self.setPixmap(p.copy(col * sb["ancho"], fila * sb["alto"], sb["ancho"], sb["alto"])
                                   .scaled(240, 135, Qt.IgnoreAspectRatio, Qt.SmoothTransformation))

    def paintEvent(self, ev):
        from PySide6.QtGui import QPainter
        p = QPainter(self)
        p.fillRect(self.rect(), QColor("#000000"))
        if self.pixmap() and not self.pixmap().isNull():
            p.drawPixmap(2, 2, self.pixmap())
        p.setPen(QColor("#FFFFFF"))
        p.drawText(self.rect().adjusted(0, 0, 0, -3), Qt.AlignHCenter | Qt.AlignBottom, self.text())
        p.end()


class ControlesVideo(QWidget):
    rep = property(lambda self: self.ventana.rep)   # el de la pestaña activa (cada pestaña tiene el suyo)

    def __init__(self, ventana):
        super().__init__(ventana, Qt.Tool | Qt.FramelessWindowHint | Qt.WindowDoesNotAcceptFocus | Qt.NoDropShadowWindowHint)
        self.ventana = ventana
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_ShowWithoutActivating)
        self.setMouseTracking(True)
        self.visibles = True
        self._ultimo_movimiento = QPoint()
        v = QVBoxLayout(self)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(0)
        # arriba: el título (sobre todo en pantalla completa)
        self.titulo = QLabel()
        self.titulo.setStyleSheet("background: transparent; color: white; font-size: 17px; font-weight: 600; padding: 14px 18px;")
        self.titulo.setAttribute(Qt.WA_TransparentForMouseEvents)
        v.addWidget(self.titulo)
        v.addStretch(1)
        # abajo: progreso y botones
        self.abajo = QWidget()
        self.abajo.setStyleSheet("background: transparent;")
        av = QVBoxLayout(self.abajo)
        av.setContentsMargins(12, 0, 12, 6)
        av.setSpacing(2)
        from .interfaz import Deslizador
        self.posicion = Deslizador(Qt.Horizontal)
        self.posicion.setRange(0, 1000)
        self.posicion.setObjectName("progresoVideo")
        self.posicion.setMouseTracking(True)
        self.posicion.texto = lambda x: motor.tiempo(x / 1000 * self.rep.dur) if self.rep.dur else ""
        self.vista = VistaPrevia(ventana)   # 03/10/2026: la miniatura del momento al pasar por la barra
        self.posicion.pasa.connect(lambda v, p: self.vista.mostrar(self.rep, v / 1000, p))
        self.posicion.sale.connect(self.vista.hide)
        self.posicion.sliderReleased.connect(lambda: self.rep.dur and self.rep.ir_a(self.posicion.value() / 1000 * self.rep.dur))
        self.posicion.clic.connect(lambda x: self.rep.dur and self.rep.ir_a(x / 1000 * self.rep.dur))
        av.addWidget(self.posicion)
        fila = QHBoxLayout()
        fila.setSpacing(2)
        av.addLayout(fila)

        def boton(nombre, ayuda, accion, tam=26):
            b = QPushButton()
            b.setObjectName("controlVideo")
            b.setIcon(icono(nombre, "#FFFFFF"))
            b.setIconSize(QSize(tam, tam))
            b.setToolTip(ayuda)
            b.setCursor(Qt.PointingHandCursor)
            b.setFocusPolicy(Qt.NoFocus)
            b.clicked.connect(accion)
            fila.addWidget(b)
            return b
        # siempre el reproductor de la pestaña activa (03/10/2026: atados al primero, pausaban el primer vídeo)
        self.play = boton("pausa", "Pausa / seguir (k)", lambda: self.rep.alternar(), 30)
        boton("siguiente", "Siguiente (Mayús+N)", lambda: self.rep.siguiente())
        self.mute = boton("volumen", "Silenciar (m)", self._silencio)
        from .interfaz import Deslizador as D2
        self.vol = D2(Qt.Horizontal)
        self.vol.setObjectName("volumenVideo")
        self.vol.setRange(0, 130)
        self.vol.setFixedWidth(90)
        self.vol.setFocusPolicy(Qt.NoFocus)
        self.vol.setValue(ventana.ajustes.get("volumen", 80))
        self.vol.valueChanged.connect(lambda x: self.rep.volumen(x))
        fila.addWidget(self.vol)
        self.tiempo = QLabel("0:00 / 0:00")
        self.tiempo.setStyleSheet("background: transparent; color: #EEEEEE; font-size: 13px; padding-left: 10px;")
        fila.addWidget(self.tiempo)
        # en un directo, en vez del tiempo: «● EN DIRECTO» (rojo si vas al día; gris y con lo que vas por detrás si no).
        # Pulsarlo lleva al momento actual, como en YouTube
        self.vivo = QPushButton()
        self.vivo.setObjectName("enDirecto")
        self.vivo.setCursor(Qt.PointingHandCursor)
        self.vivo.setFocusPolicy(Qt.NoFocus)
        self.vivo.setToolTip("Ir al momento actual del directo")
        self.vivo.clicked.connect(lambda: self.rep.ir_al_directo())
        self.vivo.hide()
        fila.addWidget(self.vivo)
        self.capitulo = QLabel()
        self.capitulo.setStyleSheet("background: transparent; color: #DDDDDD; font-size: 13px; padding-left: 8px;")
        self.capitulo.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Preferred)
        fila.addWidget(self.capitulo, 1)
        self.cc = boton("subtitulos", "Subtítulos (c)", lambda: self.ventana._alternar_subtitulos())
        boton("ajustes", "Ajustes: calidad, velocidad, subtítulos, temporizador", self._ajustes)
        boton("pip", "Imagen en imagen (i)", self.ventana.imagen_en_imagen)   # 03/10/2026
        self.cine = boton("cine", "Modo cine (t)", self.ventana.modo_cine)   # 03/10/2026
        self.completa = boton("completa", "Pantalla completa (f)", self.ventana.pantalla_completa)
        v.addWidget(self.abajo)
        self.setStyleSheet("""
            QPushButton#controlVideo { background: transparent; border: none; padding: 6px; border-radius: 18px; }
            QPushButton#controlVideo:hover { background: rgba(255,255,255,0.15); }
            QSlider#progresoVideo::groove:horizontal { height: 4px; background: rgba(255,255,255,0.3); border-radius: 2px; }
            QSlider#progresoVideo::sub-page:horizontal { background: #FF0033; border-radius: 2px; }
            QSlider#progresoVideo::handle:horizontal { background: #FF0033; width: 13px; margin: -5px 0; border-radius: 6px; }
            QSlider#volumenVideo::groove:horizontal { height: 3px; background: rgba(255,255,255,0.3); }
            QSlider#volumenVideo::sub-page:horizontal { background: white; }
            QSlider#volumenVideo::handle:horizontal { background: white; width: 11px; margin: -4px 0; border-radius: 5px; }
            QToolTip { background: #282828; color: white; border: none; padding: 4px 8px; }
        """)
        self._esconder = QTimer(self, singleShot=True, interval=2500)
        self._esconder.timeout.connect(self._ocultar_si_toca)
        self._reloj = QTimer(self, interval=250)
        self._reloj.timeout.connect(self.refrescar)
        self._reloj.start()
        self._seguir = QTimer(self, singleShot=True, interval=30)
        self._seguir.timeout.connect(self.colocar)
        self._calidad = QTimer(self, singleShot=True, interval=1200)   # tras un cambio de tamaño, la calidad «auto»
        self._calidad.timeout.connect(self.ventana.revisar_calidad)
        ventana.installEventFilter(self)
        for z in ventana.zonas_pestana:   # cada zona de vídeo (las nuevas se apuntan en PaginaVideo.nueva_zona)
            z.installEventFilter(self)
        ventana.paginas.currentChanged.connect(lambda _: self._seguir.start())   # al salir de la página del vídeo, fuera
        # el cursor se vigila también por posición: con ventanas transparentes, Windows y X11 no siempre mandan el
        # movimiento a esta ventana (los mandos no salían al mover el ratón en ventana, 02/10/2026)
        self._cursor = QCursor.pos()
        self._vigia = QTimer(self, interval=120)
        self._vigia.timeout.connect(self._mirar_cursor)
        self._vigia.start()

    # ---- dónde y cuándo se ve ----
    def eventFilter(self, obj, ev):
        if ev.type() in (QEvent.Move, QEvent.Resize, QEvent.Show, QEvent.Hide, QEvent.WindowStateChange,
                         QEvent.WindowActivate, QEvent.WindowDeactivate, QEvent.ZOrderChange):
            self._seguir.start()
        return False

    def colocar(self):
        """Encima del vídeo, del mismo tamaño; oculto si el vídeo no está a la vista."""
        self._calidad.start()
        z = self.ventana.video.video
        debe = (not os.environ.get("CATODE_SIN_MANDOS") and self.ventana.isVisible() and not self.ventana.isMinimized() and z.isVisible()
                and self.ventana.paginas.currentWidget() is self.ventana.video and self.rep.actual is not None)
        if not debe:
            if self.isVisible():
                self.hide()
            return
        if os.name == "nt" and not getattr(self.rep, "_arrancado", True):
            # 04/10/2026 (vigía de cuelgues): mientras mpv crea su ventana de vídeo (vídeo arrancando) necesita que la de
            # Cat-ode le conteste; mover o enseñar los mandos en ese momento las dejaba esperándose la una a la otra.
            # Se colocan cuando ya ha arrancado.
            if not getattr(self, "_reintento", None):
                from PySide6.QtCore import QTimer
                self._reintento = QTimer(self, singleShot=True, interval=500)
                self._reintento.timeout.connect(self.colocar)
            self._reintento.start()
            return
        r = QRect(z.mapToGlobal(QPoint(0, 0)), z.size())
        if self.geometry() != r:
            self.setGeometry(r)
        if not self.isVisible():
            self.show()
            self.raise_()
        # 03/10/2026: antes raise_() en CADA recolocación; en Windows reordena ventanas y espera a que contesten todas,
        # también la de vídeo de mpv: si esa estaba parando, Cat-ode se colgaba (vigía de cuelgues, al cerrar pestañas).
        # Siendo ventana «Tool» de Cat-ode, ya queda siempre por encima de ella.

    def _mirar_cursor(self):
        c = QCursor.pos()
        if c == self._cursor:
            return
        movido = (c - self._cursor).manhattanLength() > 2
        self._cursor = c
        if movido and self.isVisible() and self.geometry().contains(c):
            self.mostrar()

    def _fundir(self, hacia):
        """Los mandos aparecen y se van con un fundido corto (antes, de golpe)."""
        from PySide6.QtCore import QVariantAnimation, QEasingCurve
        from PySide6.QtWidgets import QGraphicsOpacityEffect
        for w in (self.abajo, self.titulo):
            if not isinstance(w.graphicsEffect(), QGraphicsOpacityEffect):
                w.setGraphicsEffect(QGraphicsOpacityEffect(w))
        if getattr(self, "_anim", None) is None:
            self._anim = QVariantAnimation(self)
            self._anim.setEasingCurve(QEasingCurve.OutCubic)
            self._anim.valueChanged.connect(self._paso_fundido)
            self._anim.finished.connect(lambda: self._alfa <= 0.01 and (self.abajo.hide(), self.titulo.hide()))
        self._anim.stop()
        self._anim.setDuration(160 if hacia else 260)
        self._anim.setStartValue(getattr(self, "_alfa", 0.0 if hacia else 1.0))
        self._anim.setEndValue(1.0 if hacia else 0.0)
        self._anim.start()

    def _paso_fundido(self, x):
        self._alfa = x
        for w in (self.abajo, self.titulo):
            if w.graphicsEffect() is not None:
                w.graphicsEffect().setOpacity(x)
        self.update()

    def mostrar(self):
        if not self.visibles:
            self.visibles = True
            self.titulo.setVisible(self.ventana.isFullScreen())
            self.abajo.show()
            self.unsetCursor()
            self._fundir(True)
        self._esconder.start()

    def _ocultar_si_toca(self):
        from PySide6.QtWidgets import QApplication
        dentro = self.abajo.isVisible() and self.abajo.geometry().contains(self.mapFromGlobal(QCursor.pos()))
        if self.ventana.isFullScreen():   # 06/10/2026: a pantalla completa se ocultan aunque el ratón esté quieto sobre la barra
            dentro = False
        if self.rep.pausa or dentro or QApplication.activePopupWidget() is not None:
            return self._esconder.start()
        self.visibles = False
        self._fundir(False)
        if self.ventana.isFullScreen():
            self.setCursor(Qt.BlankCursor)
        self.update()

    # ---- pintar ----
    def paintEvent(self, ev):
        p = QPainter(self)
        p.fillRect(self.rect(), QColor(0, 0, 0, 1))   # casi invisible, pero recibe el ratón (en Windows, 0 lo dejaría pasar)
        alfa = getattr(self, "_alfa", 1.0 if self.visibles else 0.0)
        if alfa > 0.01:
            p.setOpacity(alfa)
            alto = min(self.height(), 160)
            g = QLinearGradient(0, self.height() - alto, 0, self.height())
            g.setColorAt(0, QColor(0, 0, 0, 0))
            g.setColorAt(0.5, QColor(0, 0, 0, 90))
            g.setColorAt(1, QColor(0, 0, 0, 200))
            p.fillRect(0, self.height() - alto, self.width(), alto, g)
            if self.ventana.isFullScreen():
                g2 = QLinearGradient(0, 0, 0, 90)
                g2.setColorAt(0, QColor(0, 0, 0, 160))
                g2.setColorAt(1, QColor(0, 0, 0, 0))
                p.fillRect(0, 0, self.width(), 90, g2)
        p.end()

    def refrescar(self):
        if not self.isVisible():
            return
        e = self.rep.actual
        if e is None:
            return
        self.titulo.setVisible(self.visibles and self.ventana.isFullScreen())
        if self.titulo.text() != e.titulo:
            self.titulo.setText(e.titulo)
        nombre = "play" if self.rep.pausa else "pausa"
        if self.play.property("icono") != nombre:
            self.play.setProperty("icono", nombre)
            self.play.setIcon(icono(nombre, "#FFFFFF"))
            if self.rep.pausa:
                self.mostrar()
        n2 = "cerrar_completa" if self.ventana.isFullScreen() else "completa"
        if self.completa.property("icono") != n2:
            self.completa.setProperty("icono", n2)
            self.completa.setIcon(icono(n2, "#FFFFFF"))
            self.completa.setToolTip("Salir de pantalla completa (Esc)" if self.ventana.isFullScreen() else "Pantalla completa (f)")
        if self.rep.dur:
            self._dur = self.rep.dur   # al recargar (cambio de calidad) mpv da 0 un momento: se guarda la última
        directo = getattr(self.rep, "directo", False)
        self.tiempo.setVisible(not directo)
        self.vivo.setVisible(directo)
        if directo:
            atras = max(0, (self.rep.dur or 0) - self.rep.pos)
            al_dia = atras < 20
            self.vivo.setText("●  EN DIRECTO" + ("" if al_dia else f"   −{motor.tiempo(atras)}"))
            self.vivo.setStyleSheet("QPushButton#enDirecto { background: transparent; border: none; font-size: 13px; font-weight: 600; "
                                    "padding: 4px 10px; color: %s; } QPushButton#enDirecto:hover { color: white; }"
                                    % ("#FF4E45" if al_dia else "#BBBBBB"))
        else:
            self.tiempo.setText(f"{motor.tiempo(self.rep.pos)} / {motor.tiempo(self.rep.dur or getattr(self, '_dur', 0))}")
        caps = self.ventana.capitulos_de(e.url)
        nombre_cap = ""
        for s, n in caps:
            if s <= self.rep.pos:
                nombre_cap = n
        self.capitulo.setText(f"·  {nombre_cap}" if nombre_cap else "")
        if not self.posicion.isSliderDown() and self.rep.dur:
            self.posicion.setValue(int(self.rep.pos / self.rep.dur * 1000))
        try:
            activo = getattr(self.rep, "_sid", None) not in (False, "no", None)
        except Exception:
            activo = False
        self.cc.setIcon(icono("subtitulos", "#FFFFFF" if activo else "#9A9A9A"))

    # ---- ratón sobre el vídeo ----
    def mouseMoveEvent(self, ev):
        if (ev.globalPosition().toPoint() - self._ultimo_movimiento).manhattanLength() > 2:
            self._ultimo_movimiento = ev.globalPosition().toPoint()
            self.mostrar()

    def mousePressEvent(self, ev):
        self.mostrar()
        if ev.button() == Qt.LeftButton:
            self.rep.alternar()
        elif ev.button() == Qt.RightButton:
            self.ventana._menu_video_reproductor()

    def mouseDoubleClickEvent(self, ev):
        if ev.button() == Qt.LeftButton:
            self.rep.alternar()   # el primer clic del doble ya pausó: se deshace
            self.ventana.pantalla_completa()

    def wheelEvent(self, ev):
        self.mostrar()
        self.vol.setValue(max(0, min(130, self.vol.value() + (5 if ev.angleDelta().y() > 0 else -5))))

    def leaveEvent(self, ev):
        if not self.rep.pausa:
            self._esconder.start(800)

    # ---- botones ----
    def _silencio(self):
        self.mute.setIcon(icono("silencio" if self.rep.silencio() else "volumen", "#FFFFFF"))

    def _ajustes(self):
        """La rueda de YouTube: calidad, velocidad, subtítulos, temporizador, repetir y solo sonido."""
        b = self.ventana.barra
        m = QMenu(self)
        c = self.ventana.ajustes.get("calidad", "auto")
        m.addMenu(b._menu_calidad()).setText(f"Calidad  ·  " + (f"Automática ({self.rep.alto_auto}p)" if c == "auto" else f"{c}p"))
        vel = getattr(self.rep.mpv, "speed", 1.0) or 1.0
        m.addMenu(b._menu_velocidad()).setText(f"Velocidad  ·  {'Normal' if vel == 1 else f'{vel:g}×'}")
        m.addMenu(b._menu_subtitulos()).setText("Subtítulos")
        m.addMenu(b._menu_apagado()).setText("Temporizador de apagado")
        r = m.addAction("Repetir este vídeo")
        r.setCheckable(True)
        r.setChecked(b.bucle.isChecked())
        r.triggered.connect(lambda si: (b.bucle.setChecked(si), self.rep.bucle(si)))
        s = m.addAction("Solo sonido (sin imagen)")
        s.setCheckable(True)
        s.setChecked(b.sonido.isChecked())
        s.triggered.connect(lambda si: (b.sonido.setChecked(si), self.rep.solo_sonido(si)))
        for a, n in zip(m.actions(), ("ajustes", "velocidad", "subtitulos", "temporizador", "repetir", "auriculares")):
            a.setIcon(icono(n))
        if os.name == "nt":   # 05/10/2026: no enviar Cat-ode al escritorio remoto (Moonlight) sin cortar la sesión; F9
            r = m.addAction("Apagar el remoto (no enviar la imagen a Moonlight)  ·  F9")
            r.setCheckable(True)
            r.setChecked(bool(self.ventana.ajustes.get("apagar_remoto")))
            r.triggered.connect(self.ventana.apagar_remoto)
        self._esconder.stop()
        boton = self.sender()
        m.exec(boton.mapToGlobal(QPoint(boton.width() - m.sizeHint().width(), -m.sizeHint().height())))
        self._esconder.start()
