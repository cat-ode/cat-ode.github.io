"""Cat-ode escritorio · los ajustes (escritorio-ajustes.json), sin Qt (06/10/2026, interfaz web).

Copia de Ventana._archivo_ajustes/_leer_ajustes/guardar_ajustes (interfaz.py 2421-2436): el mismo archivo y el mismo
formato, así la interfaz Qt y la web leen y escriben lo mismo (pestañas, geometría, volumen…). interfaz.py sigue usando
lo suyo."""
import json
import os
import threading
import time

from .datos import carpeta_datos, carpeta_propia

BASE = {"calidad": "auto", "volumen": 80, "automatica": True, "patrocinios": True, "reanudar": True}


def carpeta():
    # 18/10/2026: CATODE_CARPETA (instalación aislada de prueba) manda sobre ~/.config/catode y %LOCALAPPDATA%\Cat-ode
    d = carpeta_propia()
    if d:
        os.makedirs(d, exist_ok=True)
        return d
    return carpeta_datos() if os.name == "nt" else os.path.expanduser("~/.config/catode")


def archivo():
    return os.path.join(carpeta(), "escritorio-ajustes.json")


def leer():
    try:
        with open(archivo()) as f:
            a = {**BASE, **json.load(f)}
        if not a.get("calidad_auto_migrada"):   # antes no existía «automática»: se pasa a ella una vez
            a["calidad"], a["calidad_auto_migrada"] = "auto", True
        return a
    except Exception:   # noqa: BLE001
        return dict(BASE)


_cerrojo = threading.Lock()


def guardar(ajustes):
    """Escritura atómica y de uno en uno: con la web escriben a la vez los hilos del servidor (PUT /api/ajustes) y el de la
    ventana; abrir con «w» truncaba el archivo y, si a la vez cambiaba el dict, quedaba a medias y se perdían TODOS los
    ajustes (pestañas, geometría, interfaz). Se copia el dict bajo el cerrojo, se escribe a .tmp y se reemplaza."""
    with _cerrojo:
        try:
            texto = None
            for _ in range(5):   # otro hilo cambiando el dict justo al copiarlo: se vuelve a intentar
                try:
                    texto = json.dumps(dict(ajustes))
                    break
                except RuntimeError:
                    time.sleep(0.01)
            if texto is None:
                return False
            destino = archivo()
            os.makedirs(os.path.dirname(destino), exist_ok=True)
            tmp = destino + ".tmp"
            with open(tmp, "w") as f:
                f.write(texto)
                f.flush()
                os.fsync(f.fileno())
            for i in range(20):   # Windows: reemplazar un archivo que otro está leyendo falla un instante (Datos._guardar_ya)
                try:
                    os.replace(tmp, destino)
                    return True
                except PermissionError:
                    time.sleep(0.05 * (i + 1))
            return False
        except Exception:   # noqa: BLE001
            return False


def poner(clave, valor):
    """Cambia una clave sin perder lo demás (lee, cambia y guarda)."""
    a = leer()
    a[clave] = valor
    guardar(a)
    return a


CLAVES_DE_INTERFAZ = ("interfaz", "interfaz_remota", "web_sin_lista")


def guardar_conservando(ajustes):
    """06/10/2026: la ventana Qt guarda su dict entero al cerrar y pisaba lo que el actualizador había escrito en el
    archivo (interfaz_remota): en cada arranque «cambiaba» otra vez y la app se reiniciaba sin parar. Las claves de la
    interfaz que estén en el archivo y no en memoria se conservan."""
    try:
        disco = leer()
    except Exception:   # noqa: BLE001
        disco = {}
    for k in CLAVES_DE_INTERFAZ:
        if k in disco and k not in ajustes:
            ajustes[k] = disco[k]
    guardar(ajustes)
