"""Cat-ode escritorio · «YouTube se ha roto» (18/10/2026). Orden del autor: «la actualización de la app debe hacerse sola
desde la URL de GDrive cuando la app se inicia o cuando se detecta que youtube se ha cascado».

Cada fallo se clasifica (clasificar): «red» (sin conexión), «bloqueo» (YouTube ha marcado la IP: regla 24), «video» (ese
vídeo concreto no se puede ver: privado, borrado, región, miembros, edad) o «roto» (todo lo demás: YouTube ha cambiado
algo). Solo «roto» cuenta. Disparo: 2 vídeos distintos «roto» en 15 min, 2 fallos de análisis (búsqueda, inicio, canal,
novedades) en 15 min, o todos los clientes OK sin HLS. Entonces se llama a al_roto(motivo), que pone actualizar.empezar
(busca el arreglo YA en Drive), como mucho una vez cada 10 min. Sin Qt ni red: lo usan el servicio web, la Qt, el motor
y el resolutor."""
import re
import threading
import time

VENTANA = 15 * 60          # los fallos cuentan durante 15 min
ESPERA = 10 * 60           # una búsqueda de arreglo cada 10 min como mucho

# OJO: «confirm your age» es definitivo (ese vídeo), no un bloqueo; antes «confirm you» casaba con él (18/10/2026)
EDAD = ("confirm your age", "age-restricted", "age restricted", "inappropriate for some users", "age_check_required",
        "age_verification_required", "confirmar tu edad", "confirmar su edad", "restricción de edad")
BLOQUEOS = ("not a bot", "no eres un bot", "no eres un robot", "confirm you're not", "confirm you’re not",
            "confirm that you're not", "confirm that you’re not", "signinconfirmnotbot", "too many requests",
            "http error 429", "automated queries", "tráfico automático")
BLOQUEO_FLOJO = ("login_required",)   # también lo da un vídeo privado: va después de los motivos de vídeo
VIDEO = ("recording is not available", "live event will begin", "premieres in", "private video", "this video is private",
         "members", "removed", "video unavailable", "this video is unavailable", "not available in your country",
         "available in your country", "not made this video available", "has been terminated", "copyright",
         "live_stream_offline", "content_check_required",
         # los mismos en español (la API interna va con hl=es y servicio.clasificar ya los traduce)
         "es privado", "vídeo privado", "miembros", "ya no está en youtube", "ya no está disponible", "no está disponible en",
         "vídeo no disponible", "no disponible en tu país", "eliminado", "directo ya terminó", "aún no ha empezado")
RED = ("sin conexión", "temporary failure in name resolution", "name or service not known", "getaddrinfo failed",
       "nodename nor servname", "network is unreachable", "no route to host", "connection refused", "connection reset",
       "connection aborted", "timed out", "failed to establish a new connection", "max retries exceeded",
       "remote end closed connection", "errno 11001", "winerror 10051", "winerror 10060", "winerror 10061",
       "winerror 10065", "urlopen error", "unexpected_eof", "eof occurred in violation")
_429 = re.compile(r"(?<![\w-])429(?![\w-])")
_ID = re.compile(r"(?:v=|youtu\.be/|shorts/)([A-Za-z0-9_-]{11})")

al_roto = None             # lo pone actualizar.empezar: al_roto(motivo) → busca el arreglo YA
_cerrojo = threading.Lock()
_videos = {}               # id del vídeo → hora de su último fallo «roto»
_analisis = []             # horas de los fallos de análisis
_ultimo = 0.0              # hora del último disparo


def _texto(error):
    if isinstance(error, BaseException):
        return f"{error.__class__.__name__}: {error} {getattr(error, 'reason', '') or ''}"
    return str(error or "")


def clasificar(error):
    """«red», «bloqueo», «video» o «roto» de una excepción o de un texto de error (inglés de yt-dlp, español de la app)."""
    import socket
    import urllib.error
    t = _texto(error).lower()
    if any(k in t for k in EDAD):
        return "video"
    if any(k in t for k in BLOQUEOS) or _429.search(t):
        return "bloqueo"
    if any(k in t for k in VIDEO):
        return "video"
    if any(k in t for k in BLOQUEO_FLOJO):
        return "bloqueo"
    if isinstance(error, urllib.error.HTTPError):   # 403/400 de YouTube: roto (el 429 ya ha salido arriba)
        return "roto"
    if isinstance(error, (ConnectionError, TimeoutError, socket.timeout, urllib.error.URLError)) or any(k in t for k in RED):
        return "red"
    return "roto"


def jugabilidad(estado, motivo, hay_hls):
    """La respuesta «player» de la API interna: None si va bien; si no, su clase. OK sin HLS y UNPLAYABLE sin motivo
    concreto = «roto»; UNPLAYABLE con motivo = ese vídeo."""
    if estado == "OK":
        return None if hay_hls else "roto"
    if estado == "UNPLAYABLE":
        if not (motivo or "").strip():
            return "roto"
        c = clasificar(motivo)
        return "video" if c == "roto" else c
    return clasificar(f"{estado}: {motivo or ''}")


def _id(url):
    m = _ID.search(url or "")
    return m.group(1) if m else (url or "")


def _apunta(t):
    try:
        from .resolutor import registro
        registro("roto: " + t)
    except Exception:   # noqa: BLE001
        pass


def apuntar_video(url, error, clase=None, ahora=None):
    """Un vídeo que no ha salido. Devuelve su clase; si es «roto» y ya van 2 vídeos distintos en 15 min, dispara."""
    clase = clase or clasificar(error)
    if clase != "roto":
        return clase
    ahora = time.time() if ahora is None else ahora
    with _cerrojo:
        _videos[_id(url)] = ahora
        for k in [k for k, t in _videos.items() if ahora - t > VENTANA]:
            del _videos[k]
        n = len(_videos)
    _apunta(f"vídeo {_id(url)} roto ({_texto(error)[:120]}); {n} en 15 min")
    if n >= 2:
        _disparar(f"{n} vídeos distintos sin salir", ahora)
    return clase


def apuntar_analisis(donde, error=None, ahora=None):
    """Una página de YouTube que ya no se entiende (búsqueda, inicio, canal, novedades). error=None: llegó sin vídeos.
    Devuelve la clase; si es «roto» y van 2 en 15 min, dispara."""
    clase = "roto" if error is None else clasificar(error)
    if clase != "roto":
        return clase
    ahora = time.time() if ahora is None else ahora
    with _cerrojo:
        _analisis.append(ahora)
        _analisis[:] = [t for t in _analisis if ahora - t <= VENTANA]
        n = len(_analisis)
    _apunta(f"{donde}: no se entiende ({_texto(error)[:120] if error is not None else 'sin vídeos'}); {n} en 15 min")
    if n >= 2:
        _disparar(f"{n} fallos al leer {donde}", ahora)
    return clase


def todos_sin_hls(url, ahora=None):
    """Todos los clientes dicen OK y ninguno da HLS: YouTube ha cambiado algo seguro. Dispara ya."""
    _apunta(f"vídeo {_id(url)}: todos los clientes OK sin HLS")
    return _disparar("todos los clientes OK sin HLS", time.time() if ahora is None else ahora)


def _disparar(motivo, ahora):
    global _ultimo
    with _cerrojo:
        if ahora - _ultimo < ESPERA:
            return False
        _ultimo = ahora
        _videos.clear()
        _analisis.clear()
    _apunta(f"YouTube roto ({motivo}): se busca el arreglo ya")
    f = al_roto
    if f:
        try:
            f(motivo)
        except Exception as e:   # noqa: BLE001
            _apunta(f"al buscar el arreglo: {e!r}"[:200])
    return True


def reiniciar():
    """Para las pruebas: sin fallos apuntados ni disparos."""
    global _ultimo
    with _cerrojo:
        _videos.clear()
        _analisis.clear()
        _ultimo = 0.0
