"""Cat-ode escritorio · movimiento (02/10/2026): desplazamiento suave con la rueda, páginas que entran con un fundido,
miniaturas que aparecen poco a poco y el «modo ambiente» (los colores del vídeo, difuminados, detrás del reproductor)."""
from PySide6.QtCore import Qt, QObject, QEvent, QPropertyAnimation, QEasingCurve, QVariantAnimation, QPointF, QRectF
from PySide6.QtGui import QPainter, QImage, QPixmap, QRadialGradient, QColor
from PySide6.QtWidgets import QAbstractScrollArea, QGraphicsOpacityEffect, QProxyStyle, QStyle, QStyleFactory


class DesplazamientoSuave(QObject):
    """La rueda del ratón desliza la página en vez de saltar a golpes (como el navegador). Se acumulan los giros seguidos:
    el destino avanza y la animación lo persigue. Con el panel táctil (píxeles exactos) no se toca: ya es suave."""
    def __init__(self, area):
        super().__init__(area)
        self.area = area
        self.barra = area.verticalScrollBar()
        self.anim = QPropertyAnimation(self.barra, b"value", self)
        self.anim.setEasingCurve(QEasingCurve.OutCubic)
        self.anim.setDuration(260)
        self.destino = None
        area.viewport().installEventFilter(self)

    def eventFilter(self, obj, ev):
        if ev.type() != QEvent.Wheel or ev.modifiers() & (Qt.ControlModifier | Qt.ShiftModifier):
            return False
        if not ev.pixelDelta().isNull() or ev.angleDelta().y() == 0:
            return False
        b = self.barra
        corriendo = self.anim.state() == QPropertyAnimation.Running
        base = self.destino if (corriendo and self.destino is not None) else b.value()
        paso = -ev.angleDelta().y() / 120 * max(100, min(220, self.area.viewport().height() * 0.22))
        self.destino = int(max(b.minimum(), min(b.maximum(), base + paso)))
        self.anim.stop()
        self.anim.setStartValue(b.value())
        self.anim.setEndValue(self.destino)
        self.anim.start()
        return True


def suavizar(area):
    """Pone el desplazamiento suave a un área (una vez)."""
    if isinstance(area, QAbstractScrollArea) and not getattr(area, "_suave", None):
        area._suave = DesplazamientoSuave(area)


def fundido(w, ms=170):
    """La página que entra aparece en un fundido corto. El efecto se quita al acabar (no cuesta nada después)."""
    if w is None or w.graphicsEffect() is not None:
        return
    ef = QGraphicsOpacityEffect(w)
    ef.setOpacity(0.0)
    w.setGraphicsEffect(ef)
    a = QPropertyAnimation(ef, b"opacity", w)
    a.setDuration(ms)
    a.setStartValue(0.0)
    a.setEndValue(1.0)
    a.setEasingCurve(QEasingCurve.OutCubic)
    a.finished.connect(lambda: w.setGraphicsEffect(None))
    a.start(QPropertyAnimation.DeleteWhenStopped)


class Aparicion:
    """Para etiquetas con imagen: aparecer(pixmap) la funde desde transparente (las miniaturas al llegar de la red)."""
    def aparecer(self, p):
        self._nueva, self._opacidad = p, 0.0
        a = QVariantAnimation(self)
        a.setDuration(220)
        a.setStartValue(0.0)
        a.setEndValue(1.0)
        a.setEasingCurve(QEasingCurve.OutCubic)
        a.valueChanged.connect(self._paso)
        a.finished.connect(lambda: (self.setPixmap(p), setattr(self, "_nueva", None)))
        a.start(QVariantAnimation.DeleteWhenStopped)

    def _paso(self, x):
        self._opacidad = x
        self.update()

    def pintar_aparicion(self, p):
        """Llamar desde paintEvent: True si ha pintado la imagen que está apareciendo."""
        nueva = getattr(self, "_nueva", None)
        if nueva is None:
            return False
        p.setOpacity(self._opacidad)
        r = nueva.deviceIndependentSize()
        p.drawPixmap(int((self.width() - r.width()) / 2), int((self.height() - r.height()) / 2), nueva)
        p.setOpacity(1.0)
        return True


def difuminada(imagen, ancho=48):
    """Una versión muy borrosa de la imagen: se reduce a un puñado de píxeles y se vuelve a ampliar suavizando
    (dos pasadas). Barato y sin depender de la gráfica: sirve para el modo ambiente."""
    if isinstance(imagen, QPixmap):
        imagen = imagen.toImage()
    if imagen.isNull():
        return QImage()
    peq = imagen.scaledToWidth(ancho, Qt.SmoothTransformation).scaledToWidth(max(8, ancho // 3), Qt.SmoothTransformation)
    return peq.scaledToWidth(ancho * 4, Qt.SmoothTransformation)


class Ambiente(QObject):
    """Detrás del reproductor, los colores del vídeo difuminados y desvaneciéndose hacia el fondo (el «modo ambiente»
    de YouTube). Es una imagen fija sacada de la miniatura: no gasta nada mientras el vídeo suena. La página que lo lleva
    llama a pintar() en su paintEvent, antes que nada (queda detrás de todo)."""
    def __init__(self, duena):
        super().__init__(duena)
        self.duena = duena
        self.imagen = QImage()
        self._fuerza = 0.0
        self.anim = QVariantAnimation(self, duration=700, startValue=0.0, endValue=1.0)
        self.anim.setEasingCurve(QEasingCurve.OutCubic)
        self.anim.valueChanged.connect(lambda x: (setattr(self, "_fuerza", x), duena.update()))

    def poner(self, pixmap):
        self.imagen = difuminada(pixmap) if pixmap is not None else QImage()
        self.anim.stop()
        self._fuerza = 0.0
        if not self.imagen.isNull():
            self.anim.start()
        self.duena.update()

    def pintar(self, p, zona):
        if self.imagen.isNull() or zona is None or self._fuerza <= 0:
            return
        p.save()
        p.setRenderHint(QPainter.SmoothPixmapTransform)
        margen = max(zona.width(), zona.height()) * 0.16
        destino = zona.adjusted(-margen, -margen * 0.6, margen, margen * 1.4)
        p.setOpacity(0.5 * self._fuerza)
        p.drawImage(destino, self.imagen)
        p.setOpacity(1.0)
        # fundido elíptico: llega al color de fondo justo en el borde del rectángulo (sin franjas ni cortes rectos)
        c = destino.center()
        p.translate(c)
        p.scale(destino.width() / 2, destino.height() / 2)
        g = QRadialGradient(QPointF(0, 0), 1.0)
        g.setColorAt(0.0, QColor(15, 15, 15, 0))
        g.setColorAt(0.45, QColor(15, 15, 15, 40))
        g.setColorAt(0.8, QColor(15, 15, 15, 200))
        g.setColorAt(1.0, QColor(15, 15, 15, 255))
        p.setPen(Qt.NoPen)
        p.setBrush(g)
        p.drawRect(QRectF(-1.02, -1.02, 2.04, 2.04))
        p.restore()


class Estilo(QProxyStyle):
    """Fusion con las casillas dibujadas como interruptores de YouTube (pastilla gris; azul y bola a la derecha si está)."""
    def __init__(self):
        super().__init__(QStyleFactory.create("Fusion"))

    def pixelMetric(self, m, opt=None, w=None):
        if m == QStyle.PM_IndicatorWidth:
            return 36
        if m == QStyle.PM_IndicatorHeight:
            return 20
        return super().pixelMetric(m, opt, w)

    def drawPrimitive(self, el, opt, p, w=None):
        if el != QStyle.PE_IndicatorCheckBox:
            return super().drawPrimitive(el, opt, p, w)
        r = opt.rect
        si = bool(opt.state & QStyle.State_On)
        encima = bool(opt.state & QStyle.State_MouseOver)
        p.save()
        p.setRenderHint(QPainter.Antialiasing)
        p.setPen(Qt.NoPen)
        alto = min(r.height(), 20)
        y = r.y() + (r.height() - alto) / 2
        p.setBrush(QColor("#3EA6FF") if si else QColor("#717171" if encima else "#5A5A5A"))
        p.drawRoundedRect(QRectF(r.x(), y + 3, 36, alto - 6), (alto - 6) / 2, (alto - 6) / 2)
        p.setBrush(QColor("#FFFFFF") if si else QColor("#F1F1F1"))
        d = alto
        p.drawEllipse(QPointF(r.x() + (36 - d / 2) if si else r.x() + d / 2, y + alto / 2), d / 2, d / 2)
        p.restore()
