"""Cat-ode escritorio · graba los datos de prueba (fixtures) de la interfaz web SIN pedir nada a YouTube (06/10/2026,
DISENO_WEB.md §4, módulo M3).

Fuente: lo que ya hay en el equipo (cero llamadas nuevas): los /app/*.json que publica el recomendador del ProBook
(~/.cache/obra/catode/{parati,novedades,historial}.json), los canales del recomendador (~/Cat-ode/datos/canales.json) y la
caché de metadatos (~/.cache/catode/metadatos.json, duraciones y visualizaciones). Lo que no está (ficha, comentarios,
acerca, completo, sugerencias…) se fabrica: sintético pero creíble (títulos, canales, duraciones, ids de 11 caracteres).
Si no hay nada de lo anterior, TODO sale sintético (sinteticos()).

Uso: python -m catode.grabar_fixtures [carpeta]   (por defecto ~/Cat-ode/pruebas/fixtures). Se versionan y no se vuelven
a grabar. motor_falso usa sinteticos() en memoria si la carpeta no está (p. ej. en el mini PC)."""
import json
import os
import random
import sys
import time

AQUI = os.path.dirname(os.path.abspath(__file__))
ALFABETO = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-"
NOMBRES = ["Flavour Trip", "Ciencia de Sofá", "La Cocina de Marta", "Gatos y Más", "Historia Viva", "Ruta Norte", "Píxel Retro",
           "Música Lenta", "El Taller de Lucas", "Noticias en Corto", "Montaña Abierta", "Jardín Urbano", "Fútbol Táctico",
           "Astronomía Fácil", "Bici y Ciudad", "Cine de Barrio", "Mente Curiosa", "Viajes Baratos", "Lingüística Pop", "Arte en Casa"]
TEMAS = ["Cómo preparar un pan de masa madre en casa", "La historia oculta del metro de Madrid", "10 trucos para fotografiar de noche",
         "Ruta en bici por la Sierra de Guadarrama", "Por qué los gatos ronronean (explicado por una veterinaria)",
         "El último vuelo del Concorde", "Directo: observación de Saturno", "Reparando una radio de 1965",
         "Las 5 mejores playas del norte", "Entrevista: vivir sin coche en una gran ciudad", "Así se hace el queso manchego",
         "Música para estudiar · 2 horas", "Análisis táctico de la final", "Cómo funciona un reactor de fusión",
         "Huerto en el balcón: tomates en octubre", "El misterio de las caras de Bélmez", "Aprende acuarela en 15 minutos",
         "Tour por una casa pasiva", "La batalla de las Navas de Tolosa", "Comparativa de móviles baratos 2026"]


def _id(r):
    return "".join(r.choice(ALFABETO) for _ in range(11))


def _url(vid):
    return f"https://www.youtube.com/watch?v={vid}"


def _min(vid):
    return f"https://i.ytimg.com/vi/{vid}/mqdefault.jpg"


def _canal_url(r):
    return "https://www.youtube.com/channel/UC" + "".join(r.choice(ALFABETO) for _ in range(22))


def _video(r, titulo=None, autor=None, autor_url=None, ahora_ms=None, i=0):
    vid = _id(r)
    ahora_ms = ahora_ms or int(time.time() * 1000)
    return {"tipo": "VIDEO", "url": _url(vid), "titulo": titulo or f"{r.choice(TEMAS)} #{i + 1}", "autor": autor or r.choice(NOMBRES),
            "autorUrl": autor_url or _canal_url(r), "miniatura": _min(vid), "duracion": r.choice([95, 312, 617, 845, 1290, 2710, 3605]),
            "detalle": f"{r.randint(2, 900)} mil visualizaciones", "fecha": ahora_ms - r.randint(1, 20 * 86400) * 1000}


def sinteticos(semilla=7):
    """Todos los fixtures, fabricados (sin leer nada del disco)."""
    r = random.Random(semilla)
    ahora = int(time.time() * 1000)
    canales = [{"tipo": "CANAL", "url": _canal_url(r), "titulo": n, "autor": "", "autorUrl": "", "miniatura": "", "duracion": -1,
                "detalle": f"{r.randint(5, 900)} mil suscriptores", "fecha": 0} for n in NOMBRES]

    def videos(n, de=None):
        out = []
        for i in range(n):
            c = de or r.choice(canales)
            out.append(_video(r, f"{r.choice(TEMAS)} · parte {i + 1}", c["titulo"], c["url"], ahora, i))
        return out
    parati = videos(120)
    for v in parati[:30]:
        v["motivo"] = "Porque sigues a " + v["autor"] if r.random() < .5 else "Novedad de tus suscripciones"
    return completar({"parati": {"generado": ahora, "version": 1, "temas": NOMBRES[:8], "videos": parati},
                      "novedades": {"generado": ahora, "videos": videos(120)},
                      "historial_yt": {"generado": ahora, "videos": videos(150)},
                      "suscripciones": canales,
                      "canal_videos": videos(30, canales[0])}, r)


def completar(f, r):
    """Lo que nunca está en el disco: se fabrica a partir de lo que sí hay (mismos canales y títulos)."""
    ahora = int(time.time() * 1000)
    vids = f["parati"]["videos"] + f["novedades"]["videos"]
    canales = f["suscripciones"]
    c0 = canales[0]
    cv = f.get("canal_videos") or [v for v in vids if v.get("autorUrl") == c0["url"]][:30] or vids[:30]
    f.pop("canal_videos", None)
    f["explorar"] = {cat: r.sample(vids, min(24, len(vids))) for cat in ("Música", "Videojuegos", "Noticias", "Deportes", "Aprendizaje", "Moda y belleza")}
    busq = r.sample(vids, min(38, len(vids)))
    busq.insert(2, dict(c0))
    busq.insert(5, {"tipo": "LISTA", "url": "https://www.youtube.com/playlist?list=PL" + _id(r) + _id(r)[:5], "titulo": "Lista de prueba",
                    "autor": c0["titulo"], "autorUrl": c0["url"], "miniatura": vids[0]["miniatura"], "duracion": -1, "detalle": "25 vídeos", "fecha": 0})
    f["busqueda"] = {"elementos": busq, "cursor": "pagina2"}
    f["sugerencias"] = ["cómo hacer pan", "cómo hacer pan de masa madre", "cómo hacer pan sin horno", "gatos graciosos",
                        "música para estudiar", "ruta en bici madrid", "astronomía para principiantes", "saturno telescopio",
                        "historia de madrid", "recetas fáciles"]
    f["canal"] = {"cabecera": dict(c0, detalle=c0.get("detalle") or "120 mil suscriptores"),
                  "videos": cv, "shorts": [dict(v, duracion=r.randint(15, 59), url=v["url"].replace("watch?v=", "shorts/")) for v in cv[:12]],
                  "streams": cv[12:18], "playlists": [busq[5]],
                  "info": {"id": c0["url"].rsplit("/", 1)[-1], "nombre": c0["titulo"], "avatar": "", "suscriptores": c0.get("detalle") or "120 mil suscriptores",
                           "banner": "", "verificado": True, "handle": "@" + c0["titulo"].replace(" ", "").lower(), "etiquetas": [],
                           "descripcion": f"Canal de {c0['titulo']}: vídeos nuevos cada semana.", "cabecera": None}}
    f["acerca"] = {"vistas": 48_123_456, "alta": "12 mar 2014", "pais": "España", "enlaces": [["Web", "https://example.org"]],
                   "handle": f["canal"]["info"]["handle"], "suscriptores": f["canal"]["info"]["suscriptores"], "videos": 412}
    rel = r.sample(vids, min(20, len(vids)))
    v0 = vids[0]
    f["ficha"] = {"titulo": v0["titulo"], "autor": v0["autor"], "autorUrl": v0["autorUrl"],
                  "descripcion": "Vídeo de prueba de Cat-ode.\nCapítulos:\n0:00 Inicio\n0:08 Mitad\n0:16 Final\nMás en https://example.org",
                  "descripcionHtml": "Vídeo de prueba de Cat-ode.<br>Capítulos:<br>0:00 Inicio<br>0:08 Mitad<br>0:16 Final<br>"
                                     "Más en <a href=\"https://example.org\">https://example.org</a>",
                  "vistas": "123.456 visualizaciones", "vistasExactas": 123456, "textoFecha": "3 oct 2026", "fechaRelativa": "hace 3 días",
                  "canalSuscriptores": "120 mil suscriptores", "avatar": "", "capitulos": [[0, "Inicio"], [8, "Mitad"], [16, "Final"]],
                  "relacionados": rel}
    def fmt(clase, calidad, fps, cod, cont, tasa, tam, muestreo=-1, canales=-1):
        return {"clase": clase, "calidad": calidad, "fps": fps, "codec": cod, "contenedor": cont, "hdr": False, "tasa": tasa,
                "tamano": tam, "estimado": False, "muestreo": muestreo, "canales": canales, "pista": ""}
    f["completo"] = {"extra": {"vistas": 123456, "meGusta": 4321, "publicado": ahora - 3 * 86400000, "textoFecha": "3 oct 2026",
                               "categoria": "Ciencia y tecnología", "etiquetas": ["prueba", "cat-ode"], "licencia": "Licencia estándar de YouTube",
                               "paraNinos": False, "edad": False, "oculto": False, "privado": False, "emision": None, "filas": [],
                               "comentarios": 87, "canal": v0["autor"], "canalId": "", "canalSuscriptores": "120 mil suscriptores",
                               "canalVerificado": True, "duracion": 25, "esShort": False},
                     "formatos": {"formatos": [fmt("vídeo", "1080p", 30, "avc1.640028", "mp4", 2_500_000, 7_800_000),
                                               fmt("vídeo", "720p", 30, "avc1.4d401f", "mp4", 1_500_000, 4_700_000),
                                               fmt("audio", "", -1, "mp4a.40.2", "m4a", 128_000, 400_000, 44100, 2)],
                                  "subtitulos": ["Español"], "subtitulosAuto": ["Inglés"], "audios": [], "motivo": ""},
                     "votos": {"meGusta": 4321, "noMeGusta": 87, "valoracion": 4.9, "vistas": 123456}}
    gente = ["Ana", "Luis", "Marta", "Jorge", "Lucía", "Pablo", "Nuria", "Iker", "Sara", "Raúl"]
    f["comentarios"] = {"comentarios": [{"autor": "@" + gente[i % 10].lower() + str(i), "foto": "", "texto": t, "megusta": r.randint(0, 900),
                                         "cuando": f"hace {r.randint(1, 23)} horas", "respuestas": r.randint(0, 12)}
                                        for i, t in enumerate(["Qué buen vídeo, gracias por explicarlo tan claro.", "En el 0:08 está lo mejor.",
                                                               "Llevo años esperando algo así.", "¿Alguien sabe dónde se grabó?",
                                                               "Lo he visto tres veces seguidas.", "Muy bien documentado, como siempre.",
                                                               "Mi gato se ha quedado mirando la pantalla 😂", "Subtítulos perfectos, gracias.",
                                                               "Por más vídeos así.", "Primer comentario del día."] * 2)], "cursor": "mas"}
    f["lista_yt"] = {"titulo": "Lista de prueba", "videos": r.sample(vids, min(25, len(vids)))}
    f["nut"] = {chip: r.sample(vids, min(20, len(vids))) for chip in ("Juegos para gatos", "TV para gatos", "Música para gatos")}
    f["shorts"] = f["canal"]["shorts"] + [dict(v, duracion=r.randint(15, 59)) for v in r.sample(vids, min(12, len(vids)))]
    f["transcripcion"] = {"lineas": [[s, t] for s, t in LINEAS]}
    return f


LINEAS = [(0.5, "Hola, esto es el vídeo de prueba de Cat-ode."), (3.0, "Sirve para probar la interfaz sin red."),
          (6.0, "Ni una sola petición a YouTube."), (9.0, "Aquí empieza el capítulo de la mitad."),
          (12.5, "Los subtítulos salen de un archivo local."), (16.0, "Y este es el capítulo final."),
          (19.5, "La barra roja debería avanzar sola."), (23.0, "Fin del vídeo de prueba.")]


def vtt():
    def t(s):
        return f"00:{int(s) // 60:02d}:{s % 60:06.3f}"
    partes = ["WEBVTT", "Kind: captions", "Language: es", ""]
    for i, (s, frase) in enumerate(LINEAS):
        fin = LINEAS[i + 1][0] if i + 1 < len(LINEAS) else 25.0
        partes += [f"{t(s)} --> {t(fin)}", frase, ""]
    return "\n".join(partes)


def miniatura(ruta):
    """320×180 con un degradado naranja (la paleta de Cat-ode) y un rótulo, sin red."""
    try:
        from PIL import Image, ImageDraw
        im = Image.new("RGB", (320, 180))
        d = ImageDraw.Draw(im)
        for x in range(320):
            d.line([(x, 0), (x, 179)], fill=(255, 122 - x // 6, x // 4))
        d.rectangle([12, 140, 170, 168], fill=(15, 15, 15))
        d.text((20, 146), "Cat-ode · prueba", fill=(241, 241, 241))
        im.save(ruta, "JPEG", quality=80)
        return True
    except Exception:   # noqa: BLE001
        # sin PIL: un fotograma del vídeo de prueba con ffmpeg, si lo hay
        import shutil
        import subprocess
        video = os.path.join(os.path.dirname(os.path.dirname(AQUI)), "pruebas", "video_prueba.mp4")
        if shutil.which("ffmpeg") and os.path.exists(video):
            subprocess.run(["ffmpeg", "-v", "error", "-y", "-ss", "3", "-i", video, "-vf", "scale=320:180", "-frames:v", "1", "-f", "image2", ruta],
                           timeout=30, check=False)
            if os.path.exists(ruta) and os.path.getsize(ruta) > 500:
                return True
        # y si tampoco: una imagen mínima válida (GIF de 1×1; el navegador la reconoce por el contenido)
        import base64
        with open(ruta, "wb") as fh:
            fh.write(base64.b64decode("R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw=="))
        return False


def de_disco(r):
    """Los fixtures a partir de lo que hay en el ProBook (None si falta lo básico)."""
    obra = os.path.expanduser("~/.cache/obra/catode")
    try:
        parati = json.load(open(os.path.join(obra, "parati.json"), encoding="utf-8"))
        nov = json.load(open(os.path.join(obra, "novedades.json"), encoding="utf-8"))
    except Exception:   # noqa: BLE001
        return None
    try:
        hist = json.load(open(os.path.join(obra, "historial.json"), encoding="utf-8"))
    except Exception:   # noqa: BLE001
        hist = {"videos": []}
    try:
        cache = json.load(open(os.path.expanduser("~/.cache/catode/metadatos.json"), encoding="utf-8")).get("resumen", {})
    except Exception:   # noqa: BLE001
        cache = {}

    def limpio(v, motivo=False):
        x = {k: v.get(k, d) for k, d in (("tipo", "VIDEO"), ("url", ""), ("titulo", ""), ("autor", ""), ("autorUrl", ""), ("miniatura", ""),
                                        ("duracion", -1), ("detalle", ""), ("fecha", 0))}
        vid = x["url"].rsplit("=", 1)[-1][-11:]
        m = (cache.get(vid) or {}).get("v") or {}
        if (x["duracion"] or -1) < 0:
            x["duracion"] = m.get("duracion") or r.choice([312, 617, 845, 1290])
        if not x["detalle"] and m.get("vistas"):
            x["detalle"] = f"{m['vistas']:,} visualizaciones".replace(",", ".")
        if motivo and v.get("motivo"):
            x["motivo"] = v["motivo"]
        return x
    pv = [limpio(v, True) for v in parati.get("videos", [])[:120]]
    nv = [limpio(v) for v in nov.get("videos", [])[:120]]
    hv = [limpio(v) for v in hist.get("videos", [])[:150]] or [limpio(v) for v in r.sample(pv, min(40, len(pv)))]
    # los canales «suscritos»: los 20 que más salen en las novedades (así Suscripciones tiene vídeos)
    cuenta = {}
    for v in nv:
        if v["autorUrl"]:
            cuenta.setdefault(v["autorUrl"], [v["autor"], 0])[1] += 1
    subs = [{"tipo": "CANAL", "url": u, "titulo": a, "autor": "", "autorUrl": "", "miniatura": "", "duracion": -1, "detalle": "", "fecha": 0}
            for u, (a, n) in sorted(cuenta.items(), key=lambda kv: -kv[1][1])[:20]]
    if not subs:
        return None
    cv = [v for v in nv if v["autorUrl"] == subs[0]["url"]]
    try:   # los vídeos del primer canal, del recomendador (si está)
        canales = json.load(open(os.path.expanduser("~/Cat-ode/datos/canales.json"), encoding="utf-8"))
        c = canales.get(subs[0]["url"]) or {}
        cv = [limpio(v) for v in (c.get("videos") or [])][:30] or cv
        for s in subs:
            n = (canales.get(s["url"]) or {}).get("subs")
            if n:
                s["detalle"] = f"{n:,} suscriptores".replace(",", ".")
    except Exception:   # noqa: BLE001
        pass
    return completar({"parati": {"generado": parati.get("generado"), "version": 1, "temas": parati.get("temas", [])[:12], "videos": pv},
                      "novedades": {"generado": nov.get("generado"), "videos": nv},
                      "historial_yt": {"generado": hist.get("generado", 0), "videos": hv},
                      "suscripciones": subs, "canal_videos": cv}, r)


def grabar(carpeta=None):
    carpeta = carpeta or os.path.join(os.path.dirname(os.path.dirname(AQUI)), "pruebas", "fixtures")
    os.makedirs(carpeta, exist_ok=True)
    r = random.Random(7)
    f = de_disco(r)
    origen = "disco (ProBook)"
    if f is None:
        f, origen = sinteticos(), "sintéticos"
    for nombre, valor in f.items():
        with open(os.path.join(carpeta, nombre + ".json"), "w", encoding="utf-8") as fh:
            json.dump(valor, fh, ensure_ascii=False, indent=0 if nombre in ("ficha", "completo", "acerca", "canal") else None)
    with open(os.path.join(carpeta, "subs.vtt"), "w", encoding="utf-8") as fh:
        fh.write(vtt())
    miniatura(os.path.join(carpeta, "miniatura.jpg"))
    print(f"fixtures grabados en {carpeta} ({origen}): {', '.join(sorted(f))} + subs.vtt + miniatura.jpg")
    return carpeta


if __name__ == "__main__":
    grabar(sys.argv[1] if len(sys.argv) > 1 else None)
