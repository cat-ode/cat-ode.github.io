"""Cat-ode escritorio · trae tu YouTube (02/10/2026): con la sesión de YouTube que ya tienes abierta en el navegador
(Firefox, Chrome, Edge, Brave…), de TODAS sus cuentas de Google y canales de marca: suscripciones, historial entero,
«Me gusta», «Ver más tarde» y tus listas con sus vídeos. Solo lee; nada sale del equipo salvo las peticiones a YouTube.
Viene de importar_youtube.py e importar_historial.py (01-02/10/2026), que ya lo hacían desde Firefox.

18/10/2026 · «Traer mi YouTube» en dos sentidos (orden del autor: «la opción traer desde youtube tiene que tener una opción
de "actualizar cuenta desde youtube", por si se han suscrito nuevos canales y otra de "actualizar youtube desde cat-ode"»):
- la sesión puede venir del navegador (Firefox…) o de un diccionario de galletas (la ventana de Google DENTRO de la app en
  Windows, interfaz_web.VentanaCuenta);
- volcar_nuevo(): «Actualizar cuenta desde YouTube», SOLO LO NUEVO, con una «foto» por equipo de los canales vistos en
  YouTube (cuenta-<equipo>.json en la carpeta de configuración) para saber qué se ha seguido en YouTube desde entonces;
- plan_youtube() y aplicar(): «Actualizar YouTube desde Cat-ode» en la cuenta o canal elegido (suscribir, quitar, «Me
  gusta» y «Ver más tarde»), despacio y parando al primer freno de YouTube."""
import hashlib
import json
import os
import platform
import re
import threading
import time
import urllib.error
import urllib.request

ORIGEN = "https://www.youtube.com"
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0"
# 18/10/2026 · Chrome de escritorio SIN «Edg/»: el de la ventana de Google de la app (con la marca de Edge embebido Google
# puede negar la entrada) y el de las peticiones hechas con sus galletas
UA_CHROME = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36"
CTX = {"client": {"clientName": "WEB", "clientVersion": "2.20250930.01.00", "hl": "es", "gl": "ES"}}
NAVEGADORES = ("firefox", "chrome", "edge", "brave", "chromium", "opera", "vivaldi")
NOMBRES = {"firefox": "Firefox", "chrome": "Chrome", "edge": "Edge", "brave": "Brave", "chromium": "Chromium",
           "opera": "Opera", "vivaldi": "Vivaldi"}


def _galletas(navegador):
    from yt_dlp.cookies import extract_cookies_from_browser
    jar = extract_cookies_from_browser(navegador)
    d = {}
    for c in jar:
        dom = c.domain.lstrip(".")
        if "www.youtube.com" == dom or "www.youtube.com".endswith("." + dom):
            d[c.name] = c.value
    return d


def navegadores():
    """[(clave, nombre)] de los navegadores con la sesión de YouTube abierta (los que tienen la galleta SAPISID)."""
    r = []
    for n in NAVEGADORES:
        try:
            g = _galletas(n)
            if g.get("SAPISID") or g.get("__Secure-3PAPISID"):
                r.append((n, NOMBRES[n]))
        except Exception:   # noqa: BLE001 (ese navegador no está, o no deja leer sus galletas)
            pass
    return r


# 18/10/2026 · regla 24: un 429, un «not a bot» o un Cancelar paran la lectura ENTERA (antes leer() se tragaba los errores
# y seguía pidiendo páginas a YouTube tras un 429). El texto de _Freno lleva «429» para que servicio.clasificar lo dé por
# bloqueo y la app enseñe el aviso de la regla 24.
PAUSA_LECTURA = 0.5        # al leer, como mucho una petición cada medio segundo (como quien va bajando la página)
_RE_429 = re.compile(r"(?<![\w-])429(?![\w-])")


class _Freno(Exception):
    pass


class _Cancelado(RuntimeError):
    pass


def _cuerpo_http(e):
    """El cuerpo de un HTTPError en minúsculas (se lee una vez y se guarda: read() solo vale una vez)."""
    if not hasattr(e, "_cuerpo_catode"):
        try:
            e._cuerpo_catode = (e.read() or b"").decode("utf-8", "replace").lower()
        except Exception:   # noqa: BLE001
            e._cuerpo_catode = ""
    return e._cuerpo_catode


def _es_bloqueo(e):
    """¿YouTube nos ha frenado? (429, 403 con «not a bot»/«unusual traffic», o el texto de un freno)."""
    if isinstance(e, _Freno):
        return True
    if isinstance(e, urllib.error.HTTPError):
        if e.code == 429:
            return True
        if e.code == 403 and any(k in _cuerpo_http(e) for k in ("not a bot", "unusual traffic", "too many", "automated")):
            return True
    t = str(e).lower()
    return "not a bot" in t or "too many requests" in t or bool(_RE_429.search(t))


def _hay_que_parar(e):
    return isinstance(e, _Cancelado) or _es_bloqueo(e)


def _relanzar(e):
    """Vuelve a lanzar un Cancelar tal cual y un freno como _Freno (con «429» en el texto)."""
    if isinstance(e, (_Cancelado, _Freno)):
        raise e
    raise _Freno("YouTube ha frenado las peticiones (429): no sigo") from e


class _Sesion:
    parar = None               # 18/10/2026: función que dice si el autor ha pulsado Cancelar
    pausa = 0.0                # 18/10/2026: segundos mínimos entre dos peticiones de lectura
    _ultima = 0.0

    def __init__(self, navegador=None, galletas=None):
        """navegador: «firefox», «chrome»…; o galletas: {nombre: valor} de youtube.com (18/10/2026: las de la ventana de
        Google de la app). Un diccionario pasado como navegador también vale."""
        if isinstance(navegador, dict) and galletas is None:
            navegador, galletas = None, navegador
        self.ua = UA if galletas is None else UA_CHROME
        self.g = dict(galletas) if galletas is not None else _galletas(navegador)
        self.cab = "; ".join(f"{k}={v}" for k, v in self.g.items())

    def con_sesion(self):
        return bool(self.g.get("SAPISID") or self.g.get("__Secure-3PAPISID"))

    def _firma(self):
        ts = str(int(time.time()))
        r = []
        for esquema, nombre in (("SAPISIDHASH", "SAPISID"), ("SAPISID1PHASH", "__Secure-1PAPISID"), ("SAPISID3PHASH", "__Secure-3PAPISID")):
            v = self.g.get(nombre)
            if v:
                r.append(f"{esquema} {ts}_{hashlib.sha1(f'{ts} {v} {ORIGEN}'.encode()).hexdigest()}")
        return " ".join(r)

    def api(self, ep, cuerpo, au=0, pagina=None):
        h = {"Content-Type": "application/json", "Cookie": self.cab, "Authorization": self._firma(), "Origin": ORIGEN,
             "X-Origin": ORIGEN, "X-Goog-AuthUser": str(au), "X-Youtube-Client-Name": "1",
             "X-Youtube-Client-Version": CTX["client"]["clientVersion"], "User-Agent": self.ua}
        b = dict(cuerpo)
        b["context"] = json.loads(json.dumps(CTX))
        if pagina:
            h["X-Goog-PageId"] = pagina
            b["context"]["user"] = {"onBehalfOfUser": pagina}
        q = urllib.request.Request(f"{ORIGEN}/youtubei/v1/{ep}?prettyPrint=false", data=json.dumps(b).encode(), headers=h)
        return json.load(urllib.request.urlopen(q, timeout=40))

    def turno(self):
        """18/10/2026 · antes de cada petición de lectura: para si el autor ha pulsado Cancelar y espera lo que falte
        para la pausa mínima entre peticiones."""
        if self.parar and self.parar():
            raise _Cancelado("Cancelado")
        if self.pausa:
            falta = self._ultima + self.pausa - time.monotonic()
            if falta > 0:
                time.sleep(falta)
            if self.parar and self.parar():
                raise _Cancelado("Cancelado")
        self._ultima = time.monotonic()

    def _browse(self, cuerpo, au, pagina):
        self.turno()
        r = self.api("browse", cuerpo, au, pagina)
        if _freno_en(r):
            raise _Freno("YouTube ha frenado las peticiones (429)")
        return r

    def paginas(self, browse_id, au, pagina, tope=100000):
        """Todas las páginas de un «browse» (siguiendo las continuaciones). 18/10/2026: con pausa entre páginas, parando
        al pulsar Cancelar y al primer freno de YouTube (también si llega con 200 y un «error» dentro)."""
        r = self._browse({"browseId": browse_id}, au, pagina)
        n = 0
        while True:
            yield r
            n += 1
            tok = next((x.get("continuationEndpoint", {}).get("continuationCommand", {}).get("token")
                        for x in _recorre(r, "continuationItemRenderer")), None)
            if not tok or n >= tope:
                return
            r = self._browse({"continuation": tok}, au, pagina)


def _recorre(o, clave):
    if isinstance(o, dict):
        for k, v in o.items():
            if k == clave:
                yield v
            yield from _recorre(v, clave)
    elif isinstance(o, list):
        for v in o:
            yield from _recorre(v, clave)


def _txt(x):
    return (x or {}).get("simpleText") or "".join(r.get("text", "") for r in (x or {}).get("runs", []))


def _segundos(t):
    try:
        s = 0
        for p in (t or "").split(":"):
            s = s * 60 + int(p)
        return s if t else -1
    except ValueError:
        return -1


def _videos(r):
    """Los vídeos de una respuesta, en el formato viejo (videoRenderer / playlistVideoRenderer) o el nuevo (lockupViewModel)."""
    for clave in ("videoRenderer", "playlistVideoRenderer", "lockupViewModel"):
        for v in _recorre(r, clave):
            vid = v.get("videoId") or (v.get("contentId") if v.get("contentType", "LOCKUP_CONTENT_TYPE_VIDEO") == "LOCKUP_CONTENT_TYPE_VIDEO" else None)
            if not vid or len(vid) != 11:
                continue
            if clave == "lockupViewModel":
                md = (v.get("metadata") or {}).get("lockupMetadataViewModel") or {}
                titulo = (md.get("title") or {}).get("content", "")
                filas = md.get("metadata", {}).get("contentMetadataViewModel", {}).get("metadataRows") or [{}]
                canal = ((filas[0].get("metadataParts") or [{}])[0].get("text") or {}).get("content", "")
                cid = next((x.get("browseId") for x in _recorre(md.get("image", {}), "browseEndpoint")), None)
                dur = next((b.get("text") for b in _recorre(v.get("contentImage", {}), "thumbnailBadgeViewModel")), "")
            else:
                dueno = v.get("ownerText") or v.get("longBylineText") or v.get("shortBylineText") or {}
                canal, titulo = _txt(dueno), _txt(v.get("title"))
                cid = next((x.get("browseId") for x in _recorre(dueno, "browseEndpoint")), None)
                dur = _txt(v.get("lengthText"))
            yield {"id": vid, "titulo": titulo, "canal": canal, "canal_id": cid, "duracion": _segundos(dur)}


def _identidades(s, aviso):
    """Todas las cuentas de Google abiertas en el navegador y sus canales (personales y de marca)."""
    r_ids, vistos = [], set()
    for au in range(0, 8):
        try:
            s.turno()
            r = s.api("account/accounts_list", {"requestType": "ACCOUNTS_LIST_REQUEST_TYPE_CHANNEL_SWITCHER",
                                                "callCircumstance": "SWITCHING_USERS_FULL"}, au)
        except Exception as e:   # noqa: BLE001 (no hay más cuentas)
            if _hay_que_parar(e):   # 18/10/2026: un 429 no es «no hay más cuentas»
                _relanzar(e)
            break
        items = list(_recorre(r, "accountItemRenderer"))
        personal = next((next(_recorre(it, "obfuscatedGaiaId"), None) for it in items if not list(_recorre(it, "pageId"))), None)
        if not items or personal in vistos:
            break
        vistos.add(personal)
        for it in items:
            r_ids.append({"au": au, "pagina": next(_recorre(it, "pageId"), None),
                          "nombre": _txt(it.get("accountName")) or _txt(it.get("channelHandle"))})
    aviso(f"{len(r_ids)} cuentas y canales: " + ", ".join(i["nombre"] for i in r_ids))
    return r_ids


def _suscripciones(s, i, destino, propias=None):
    """Los canales que sigue la identidad i (FEchannels con sus continuaciones), añadidos a destino {id: canal}.
    propias (18/10/2026): un conjunto donde apuntar TODOS los ID de esta identidad (para su foto)."""
    for r in s.paginas("FEchannels", i["au"], i["pagina"]):
        for c in _recorre(r, "channelRenderer"):
            cid = c.get("channelId")
            if cid and propias is not None:
                propias.add(cid)
            if cid and cid not in destino:
                mini = (c.get("thumbnail", {}).get("thumbnails") or [{}])[-1].get("url", "")
                destino[cid] = {"id": cid, "titulo": _txt(c.get("title")),
                                "miniatura": ("https:" + mini) if mini.startswith("//") else mini}


def _nombre_origen(origen):
    if isinstance(origen, str):
        return NOMBRES.get(origen, origen)
    return "Cat-ode"


def abrir(origen):
    """18/10/2026 · la sesión de un origen: un navegador («firefox»…), un diccionario de galletas o una sesión ya hecha."""
    s = origen if isinstance(origen, _Sesion) else _Sesion(origen)
    if not s.con_sesion():
        raise RuntimeError(f"No hay sesión de YouTube abierta en {_nombre_origen(origen)}")
    return s


def clave_identidad(i):
    """«au:pageId» de una cuenta o canal de la sesión (la foto y el destino elegido se guardan con ella)."""
    return f"{int(i.get('au') or 0)}:{i.get('pagina') or ''}"


def leer_suscripciones(navegador, aviso=print):
    """Solo las suscripciones de todas las cuentas del navegador (13/10/2026: para traer en segundo plano los canales
    nuevos que se siguen en YouTube; unas pocas peticiones, sin historial ni listas). Falla si alguna cuenta falla, para
    no dar por buena una lista a medias."""
    s = abrir(navegador)
    ids = _identidades(s, aviso)
    if not ids:
        raise RuntimeError("YouTube no ha reconocido la sesión del navegador")
    out = {}
    for i in ids:
        _suscripciones(s, i, out)
        aviso(f"{i['nombre']}: {len(out)} suscripciones en total")
    return list(out.values())


def _id_video(url):
    m = re.search(r"[?&]v=([\w-]{11})", url or "")
    return m.group(1) if m else None


def _foto_valida(previa, nombre):
    """18/10/2026 · una foto (o lectura) guardada de OTRA cuenta en el mismo «au» (se cambió de cuenta en el navegador) no
    vale: sería como no tenerla."""
    return isinstance(previa, dict) and previa.get("nombre", "") in ("", nombre or "")


def _ancla(orden, foto_h):
    """18/10/2026 · posición en «orden» (ID del historial leído, lo más reciente primero) donde empieza lo ya visto en la
    lectura anterior: la primera racha de 3 ID seguidos que estaban en su foto (o tantos como tenga la foto, si son menos).
    Con racha y no con el primero, porque un vídeo viejo que se vuelve a ver sube arriba del todo. None si no aparece."""
    if not foto_h:
        return None
    en_foto, falta = set(foto_h), min(3, len(foto_h))
    racha = 0
    for n, vid in enumerate(orden):
        racha = racha + 1 if vid in en_foto else 0
        if racha >= falta:
            return n - racha + 1
    return None


CONOCIDOS_SEGUIDOS = 50    # 18/10/2026: el historial se deja de leer tras 50 vídeos seguidos que ya están en Cat-ode
FOTO_HISTORIAL = 200       # 18/10/2026: ID del principio del historial que se guardan como «foto» de cada lectura


def leer(navegador, aviso=print, parar=None, pausa=0.0, datos=None):
    """Lo de YouTube de las cuentas del navegador:
    {"suscripciones": [{id, titulo, miniatura}], "historial": [vídeo…] (lo más reciente primero),
     "megusta": [vídeo…], "despues": [vídeo…], "listas": [{id, titulo, videos: [vídeo…]}], "cuentas": [nombres],
     "por_identidad": {clave_identidad: [ID de canal]} (18/10/2026: solo las cuentas cuyas suscripciones se leyeron enteras),
     "lecturas": {clave_identidad: {"nombre", "historial": [ID], "megusta": [ID], "despues": [ID]}} (18/10/2026: lo leído
     ENTERO de cada cuenta, para la próxima vez)}
    navegador: un navegador, un diccionario de galletas o una sesión (abrir).
    18/10/2026 · regla 24 y hallazgos 4, 7 y 8 de la revisión:
    - una petición cada «pausa» segundos como mucho; «parar()» verdadero (Cancelar) o un freno de YouTube (429, «not a
      bot») paran TODO al momento y salen como excepción (nada a medias se da por bueno);
    - el historial ya no se lee entero cada vez: solo hasta lo visto en la lectura anterior (su foto, en estado_cuenta),
      hasta 50 vídeos seguidos que Cat-ode ya tiene o hasta el tope de Cat-ode; y «historial» trae solo lo anterior a lo ya
      visto, así un historial borrado en Cat-ode no vuelve entero al pulsar «Actualizar» (datos: para saber qué tiene ya
      Cat-ode y cuándo se borró su historial);
    - una lista que no se ha podido leer no se devuelve (antes llegaba vacía y vaciaba la de Cat-ode)."""
    from .datos import TOPES
    s = abrir(navegador)
    s.parar, s.pausa = parar, pausa
    ids = _identidades(s, aviso)
    if not ids:
        raise RuntimeError("YouTube no ha reconocido la sesión (vuelve a entrar en YouTube y repite)")
    est = estado_cuenta()
    lecturas_previas = est.get("lecturas") or {}
    conocidos, borrado_sin_foto = set(), False
    if datos is not None:
        conocidos = {v for v in (_id_video(c) for c, _m in datos.todas("historial")) if v}
        borrado_sin_foto = bool(getattr(datos, "borrado", 0)) and datos.borrado > (est.get("ultima_lectura") or 0)
    tope_h = TOPES.get("historial", 5000)
    out = {"suscripciones": {}, "historial": [], "megusta": [], "despues": [], "listas": [], "cuentas": [i["nombre"] for i in ids],
           "por_identidad": {}, "identidades": ids, "lecturas": {}}
    vistos = {"historial": set(), "megusta": set(), "despues": set()}
    listas_vistas = set()
    for i in ids:
        nombre, clave_i = i["nombre"], clave_identidad(i)
        previa = lecturas_previas.get(clave_i)
        foto_h = previa.get("historial") if _foto_valida(previa, nombre) and isinstance(previa.get("historial"), list) else None
        lectura = {"nombre": nombre}
        try:   # suscripciones
            propias = set()
            _suscripciones(s, i, out["suscripciones"], propias)
            out["por_identidad"][clave_i] = sorted(propias)
            aviso(f"{nombre}: {len(out['suscripciones'])} suscripciones en total")
        except Exception as e:   # noqa: BLE001
            if _hay_que_parar(e):
                _relanzar(e)
            aviso(f"{nombre}: no he podido leer las suscripciones ({e.__class__.__name__})")
        for col, bid in (("historial", "FEhistory"), ("megusta", "VLLL"), ("despues", "VLWL")):
            try:
                videos, orden, en_orden, seguidos_conocidos = [], [], set(), 0
                for r in s.paginas(bid, i["au"], i["pagina"]):
                    for v in _videos(r):
                        if v["id"] in en_orden:
                            continue
                        en_orden.add(v["id"])
                        orden.append(v["id"])
                        videos.append(v)
                        seguidos_conocidos = seguidos_conocidos + 1 if v["id"] in conocidos else 0
                    if col != "historial":
                        continue
                    if len(orden) % 1000 < 25:
                        aviso(f"{nombre}: historial, {len(orden)} vídeos…")
                    if (_ancla(orden, foto_h) is not None or seguidos_conocidos >= CONOCIDOS_SEGUIDOS or len(orden) >= tope_h
                            or (foto_h is None and borrado_sin_foto)):
                        break
                if col == "historial":
                    corte = _ancla(orden, foto_h)
                    if corte is not None:
                        videos = videos[:corte]          # solo lo visto en YouTube después de la lectura anterior
                    elif foto_h is None and borrado_sin_foto:
                        videos = []                      # historial borrado aquí y sin foto: no se trae nada, solo la foto
                    videos = videos[:tope_h]
                    lectura["historial"] = orden[:FOTO_HISTORIAL]
                else:
                    lectura[col] = orden
                for v in videos:
                    if v["id"] not in vistos[col]:
                        vistos[col].add(v["id"])
                        out[col].append(v)
                aviso(f"{nombre}: {len(videos)} {'nuevos en el historial' if col == 'historial' else 'en «Me gusta»' if col == 'megusta' else 'en «Ver más tarde»'}")
            except Exception as e:   # noqa: BLE001 (un canal de marca sin «Me gusta», por ejemplo)
                if _hay_que_parar(e):
                    _relanzar(e)
                aviso(f"{nombre}: sin {col} ({e.__class__.__name__})")
        out["lecturas"][clave_i] = lectura
        try:   # listas propias y guardadas
            for r in s.paginas("FEplaylist_aggregation", i["au"], i["pagina"]):
                for l in _recorre(r, "lockupViewModel"):
                    lid = l.get("contentId") or ""
                    if (l.get("contentType") != "LOCKUP_CONTENT_TYPE_PLAYLIST" or not lid or lid in ("LL", "WL") or lid in listas_vistas
                            or lid.startswith("RD")):   # los «Mix» los genera YouTube al vuelo: sin vídeos fijos
                        continue
                    listas_vistas.add(lid)
                    md = (l.get("metadata") or {}).get("lockupMetadataViewModel") or {}
                    titulo = (md.get("title") or {}).get("content", "") or "Lista"
                    videos = []
                    try:
                        for rr in s.paginas("VL" + lid, i["au"], i["pagina"]):
                            videos.extend(_videos(rr))
                    except Exception as e:   # noqa: BLE001
                        if _hay_que_parar(e):
                            _relanzar(e)
                        # 18/10/2026 (hallazgo 3): una lista que no se ha podido leer NO se devuelve; antes llegaba vacía y
                        # vaciaba la de Cat-ode en todos los equipos
                        aviso(f"{nombre}: no he podido leer la lista «{titulo}» ({e.__class__.__name__}): no la toco")
                        continue
                    out["listas"].append({"id": lid, "titulo": titulo, "videos": videos})
            aviso(f"{nombre}: {len(out['listas'])} listas")
        except Exception as e:   # noqa: BLE001
            if _hay_que_parar(e):
                _relanzar(e)
            aviso(f"{nombre}: sin listas ({e.__class__.__name__})")
    out["suscripciones"] = list(out["suscripciones"].values())
    return out


def volcar(datos, leido):
    """Pasa lo leído a Cat-ode (datos.Datos). Devuelve un resumen."""
    from .motor import Elemento

    def video(v):
        return Elemento("VIDEO", f"https://www.youtube.com/watch?v={v['id']}", v["titulo"], v.get("canal", ""),
                        f"https://www.youtube.com/channel/{v['canal_id']}" if v.get("canal_id") else "",
                        f"https://i.ytimg.com/vi/{v['id']}/mqdefault.jpg", v.get("duracion", -1))
    lotes = {
        "suscripciones": [(f"https://www.youtube.com/channel/{c['id']}",
                           Elemento("CANAL", f"https://www.youtube.com/channel/{c['id']}", c["titulo"], miniatura=c.get("miniatura", "")), None)
                          for c in leido["suscripciones"]],
        "historial": [(video(v).url, video(v), None) for v in leido["historial"]],
        "megusta": [(video(v).url, video(v), None) for v in leido["megusta"]],
        "despues": [(video(v).url, video(v), None) for v in leido["despues"]],
        "listas": [(f"cuenta:{l['id']}", None, {"nombre": l["titulo"], "videos": [video(v).dict() for v in l["videos"]],
                                                 "yt": f"https://www.youtube.com/playlist?list={l['id']}"})
                   for l in leido["listas"]],
    }
    datos.importar(lotes)
    return (f"{len(leido['suscripciones'])} suscripciones, {len(leido['historial'])} vídeos del historial, "
            f"{len(leido['megusta'])} «Me gusta», {len(leido['despues'])} en «Ver más tarde» y {len(leido['listas'])} listas")


# ==================================================================================================== 18/10/2026
# «Actualizar cuenta desde YouTube» (A) y «Actualizar YouTube desde Cat-ode» (B). La «foto» es, por equipo y por cuenta o
# canal de la sesión, el conjunto de canales vistos en YouTube en la última lectura y su hora: lo que está ahora en YouTube
# y no estaba en la foto se ha seguido en YouTube desde entonces; una baja hecha en Cat-ode DESPUÉS de la foto se lleva a
# YouTube. Vive en la carpeta de configuración (cuenta-<equipo>.json, con el destino elegido para B y el origen).
RE_CANAL = re.compile(r"/channel/(UC[\w-]{22})")


def _archivo_estado():
    from .datos import carpeta_config
    d = carpeta_config()
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, f"cuenta-{platform.node()}.json")


def estado_cuenta():
    """{"foto": {clave_identidad: {t, ids, nombre}}, "destino": identidad|None, "origen": str|None, …} (vacío si no hay)."""
    try:
        with open(_archivo_estado(), encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:   # noqa: BLE001 (primera vez)
        return {}


_CERROJO_ESTADO = threading.RLock()   # 18/10/2026 (hallazgo 12): leer, fundir y escribir el estado sin pisarse entre hilos
_FUNDIBLES = ("foto", "lecturas")      # por cuenta: se funden clave a clave ({} vacío = vaciarlas, al cerrar la sesión)


def guardar_estado_cuenta(cambios):
    """Funde «cambios» en el estado guardado (escritura atómica). 18/10/2026: con cerrojo, y «foto» y «lecturas» se funden
    por cuenta (cada llamador pasa solo las cuentas que cambia; un {} vacío las vacía todas)."""
    with _CERROJO_ESTADO:
        d = estado_cuenta()
        for k, v in cambios.items():
            if k in _FUNDIBLES and isinstance(v, dict) and v and isinstance(d.get(k), dict):
                d[k] = {**d[k], **v}
            else:
                d[k] = v
        ruta = _archivo_estado()
        tmp = f"{ruta}.{threading.get_ident()}.tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False)
        os.replace(tmp, ruta)
        return d


def _ahora_ms():
    return int(time.time() * 1000)


def _norma(t):
    return (t or "").strip().lower()


def _id_canal(url):
    m = RE_CANAL.search(url or "")
    return m.group(1) if m else None


def _url_canal(cid):
    return f"https://www.youtube.com/channel/{cid}"


def _fulminados(datos):
    """(ID de canal, nombres) de los canales fulminados (ocultos «canal:<url>» activos)."""
    ids, nombres = set(), set()
    for url, nombre in datos.fulminados():
        cid = _id_canal(url)
        if cid:
            ids.add(cid)
        elif nombre and nombre != url:   # 18/10/2026 (hallazgo 6): por nombre solo los que no tienen ID (otro canal puede llamarse igual)
            nombres.add(_norma(nombre))
    return ids, nombres


def _indice_subs(datos):
    """Las suscripciones de Cat-ode, activas e inactivas, por ID de canal y por nombre: {"id": {UC: [(clave, m)]},
    "nombre": {nombre: [(clave, m)]}}. Por nombre porque una suscripción hecha en Cat-ode puede tener la clave /@nombre.
    18/10/2026 (hallazgo 6): por nombre SOLO las claves sin ID de canal; si no, dos canales que se llaman igual se
    confundían (seguir uno en YouTube no entraba porque «ya estaba» el otro)."""
    por_id, por_nombre = {}, {}
    for clave, m in datos.todas("suscripciones"):
        cid = _id_canal(clave)
        if cid:
            por_id.setdefault(cid, []).append((clave, m))
            continue
        e = m.get("e")
        n = _norma(getattr(e, "titulo", ""))
        if n:
            por_nombre.setdefault(n, []).append((clave, m))
    return {"id": por_id, "nombre": por_nombre}


def _en_catode(indice, cid, titulo):
    """Las entradas de Cat-ode que son ese canal (por ID y, si no hay, por nombre)."""
    return indice["id"].get(cid) or indice["nombre"].get(_norma(titulo)) or []


def volcar_nuevo(datos, leido):
    """A · «Actualizar cuenta desde YouTube»: SOLO LO NUEVO de lo leído (leer). Añade lo que no existe en Cat-ode; nunca
    reactiva las bajas hechas en Cat-ode ni pisa lo que hay, salvo los canales seguidos en YouTube desde la foto anterior
    (si no están fulminados); renueva las listas «cuenta:<id>» activas. Nunca borra ni desactiva nada. Al acabar, foto
    nueva de las cuentas leídas enteras. Devuelve (resumen, cuentas {canales, historial, megusta, despues, listas, renovadas})."""
    from .motor import Elemento
    est = estado_cuenta()
    foto = dict(est.get("foto") or {})
    por_identidad = leido.get("por_identidad") or {}
    nombres = {clave_identidad(i): i.get("nombre", "") for i in leido.get("identidades") or []}
    seguidos = set()   # en YouTube ahora y no en la foto anterior de su cuenta
    validas, sin_subs = {}, []
    for clave_i, ids in por_identidad.items():
        previa = foto.get(clave_i)
        # una foto de OTRA cuenta en el mismo «au» (se cambió de cuenta en el navegador) no vale: sería como no tenerla
        if not (_foto_valida(previa, nombres.get(clave_i, "")) and isinstance(previa.get("ids"), list)):
            continue
        if not ids and previa["ids"]:
            # 18/10/2026 (hallazgo 5): 0 suscripciones leídas con una foto que tenía canales es casi seguro una lectura
            # fallida: ni se renueva la foto (las bajas hechas aquí volverían en la siguiente) ni cuenta para nada
            sin_subs.append(nombres.get(clave_i, "") or clave_i)
            continue
        validas[clave_i] = previa
        seguidos |= set(ids) - set(previa["ids"])
    indice = _indice_subs(datos)
    f_ids, f_nombres = _fulminados(datos)

    def video(v):
        return Elemento("VIDEO", f"https://www.youtube.com/watch?v={v['id']}", v["titulo"], v.get("canal", ""),
                        _url_canal(v["canal_id"]) if v.get("canal_id") else "",
                        f"https://i.ytimg.com/vi/{v['id']}/mqdefault.jpg", v.get("duracion", -1))
    subs, reactivar = [], {}
    for c in leido.get("suscripciones") or []:
        cid, titulo = c["id"], c.get("titulo", "")
        if cid in f_ids or _norma(titulo) in f_nombres:
            continue
        ya = _en_catode(indice, cid, titulo)
        if not ya:
            subs.append((_url_canal(cid), Elemento("CANAL", _url_canal(cid), titulo, miniatura=c.get("miniatura", "")), None))
        elif cid in seguidos and not any(m["activo"] for _, m in ya):
            clave = ya[0][0]
            reactivar[clave] = Elemento("CANAL", clave, titulo or getattr(ya[0][1].get("e"), "titulo", ""),
                                        miniatura=c.get("miniatura", "") or getattr(ya[0][1].get("e"), "miniatura", ""))
    listas = []
    for l in leido.get("listas") or []:
        clave_l = f"cuenta:{l['id']}"
        if not l["videos"]:
            # 18/10/2026 (hallazgo 3): una lista que llega vacía no vacía la que Cat-ode ya tiene con vídeos (si la lectura
            # falló a medias, la vaciaría en todos los equipos con la hora de ahora)
            ya = datos.entrada("listas", clave_l)
            x_ya = next((m.get("x") for c, m in datos.todas("listas") if c == clave_l), None) if ya else None
            if isinstance(x_ya, dict) and x_ya.get("videos"):
                continue
        listas.append((clave_l, None, {"nombre": l["titulo"], "videos": [video(v).dict() for v in l["videos"]],
                                       "yt": f"https://www.youtube.com/playlist?list={l['id']}"}))
    lotes = {
        "suscripciones": subs,
        "historial": [(video(v).url, video(v), None) for v in leido.get("historial") or []],
        "megusta": [(video(v).url, video(v), None) for v in leido.get("megusta") or []],
        "despues": [(video(v).url, video(v), None) for v in leido.get("despues") or []],
        "listas": listas,
    }
    r = datos.importar_nuevo(lotes, {"suscripciones": reactivar})
    ahora = _ahora_ms()
    # 18/10/2026 · tarea extra 1 (como Android): «t» la mueven A y B; «t_subida» se pone con la primera foto y SOLO la
    # mueve un B completo. Así una baja hecha en Cat-ode sigue llegando a YouTube aunque antes se pulse A (hallazgo 1)
    nuevas = {}
    for clave_i, ids in por_identidad.items():
        if not ids:
            continue   # 18/10/2026 (hallazgo 5): con 0 canales leídos no se hace foto (ni vacía: luego todo parecería «seguido»)
        previa = validas.get(clave_i)
        t_subida = (previa.get("t_subida") or previa.get("t") or ahora) if previa else ahora
        nuevas[clave_i] = {"t": ahora, "t_subida": t_subida, "ids": sorted(set(ids)), "nombre": nombres.get(clave_i, "")}
    lecturas = {}
    for clave_i, lec in (leido.get("lecturas") or {}).items():
        lecturas[clave_i] = {**lec, **({"historial": lec["historial"][:FOTO_HISTORIAL]} if "historial" in lec else {})}
    cambios = {"ultima_lectura": ahora}
    if nuevas:
        cambios["foto"] = nuevas
    if lecturas:
        cambios["lecturas"] = lecturas
    guardar_estado_cuenta(cambios)
    n = {"canales": r.get("suscripciones", 0) + r["reactivados"].get("suscripciones", 0), "historial": r.get("historial", 0),
         "megusta": r.get("megusta", 0), "despues": r.get("despues", 0), "listas": r.get("listas", 0), "renovadas": r["renovadas"],
         "sin_subs": sin_subs}
    return resumen_a(n), n


def resumen_a(n):
    partes = []
    if n["canales"]:
        partes.append(f"{n['canales']} canal{'es' if n['canales'] != 1 else ''} nuevo{'s' if n['canales'] != 1 else ''}")
    if n["historial"]:
        partes.append(f"{n['historial']} vídeo{'s' if n['historial'] != 1 else ''} nuevo{'s' if n['historial'] != 1 else ''} en el historial")
    if n["megusta"]:
        partes.append(f"{n['megusta']} «Me gusta» nuevo{'s' if n['megusta'] != 1 else ''}")
    if n["despues"]:
        partes.append(f"{n['despues']} nuevo{'s' if n['despues'] != 1 else ''} en «Ver más tarde»")
    if n["listas"]:
        partes.append(f"{n['listas']} lista{'s' if n['listas'] != 1 else ''} nueva{'s' if n['listas'] != 1 else ''}")
    if n["renovadas"]:
        partes.append(f"{n['renovadas']} lista{'s' if n['renovadas'] != 1 else ''} al día")
    aviso = ""
    if n.get("sin_subs"):   # 18/10/2026 (hallazgo 5)
        aviso = (f". No he podido ver las suscripciones de {', '.join(n['sin_subs'])}: no las toco")
    if not partes:
        return "Nada nuevo en tu YouTube desde la última vez" + aviso
    return ((", ".join(partes[:-1]) + " y " + partes[-1]) if len(partes) > 1 else partes[0]) + aviso


# ---------------------------------------------------------------- B · «Actualizar YouTube desde Cat-ode»
PARAMS_SUSCRIBIR, PARAMS_QUITAR = "EgIIAhgA", "CgIIAhgA"
TOPE_VIDEOS = 150          # «Me gusta» y «Ver más tarde» por pasada (el resto, en la siguiente)
PAUSA = 1.5                # una petición cada ~1,5 s


def identidades(origen, aviso=lambda _t: None):
    """Las cuentas y canales de la sesión: [{au, pagina, nombre, clave}]."""
    r = _identidades(abrir(origen), aviso)
    for i in r:
        i["clave"] = clave_identidad(i)
    return r


def elegir_destino(ids, guardada=None):
    """La identidad destino de B: la recordada si sigue en la sesión; si no, la personal de au 0."""
    if guardada:
        for i in ids:
            if clave_identidad(i) == guardada.get("clave", clave_identidad(guardada)):
                return i
    return next((i for i in ids if int(i.get("au") or 0) == 0 and not i.get("pagina")), ids[0] if ids else None)


def _videos_de(s, bid, i):
    r = []
    for pag in s.paginas(bid, i["au"], i["pagina"]):
        r.extend(v["id"] for v in _videos(pag))
    return r


def resolver_canal(s, url, i):
    """El ID UC… de una dirección /@nombre, /c/… o /user/… (navigation/resolve_url), o None si no se resuelve."""
    try:
        s.turno()   # 18/10/2026: Cancelar y la pausa también aquí (hallazgo 4)
        r = s.api("navigation/resolve_url", {"url": url}, i["au"], i["pagina"])
        if _freno_en(r):
            raise _Freno("YouTube ha frenado las peticiones (429)")
    except Exception as e:   # noqa: BLE001
        if _hay_que_parar(e):
            _relanzar(e)
        return None
    bid = next((b.get("browseId") for b in _recorre(r, "browseEndpoint")), None)
    return bid if bid and bid.startswith("UC") else None


def plan_youtube(datos, origen, destino, aviso=lambda _t: None, parar=None, pausa=0.0):
    """El plan de B para la identidad «destino» (leída de YouTube ahora): qué suscribir, qué quitar y qué «Me gusta» y
    «Ver más tarde» faltan. No toca nada. Falla si no se pueden leer las suscripciones de esa identidad.
    18/10/2026: se quitan las bajas hechas en Cat-ode después de «t_subida» (la hora del último B completo, que A ya no
    mueve: hallazgo 1); con 0 suscripciones leídas y una foto con canales no hay plan (hallazgo 5); no se vuelven a añadir
    los «Me gusta» y «Ver más tarde» quitados en YouTube desde la lectura anterior (hallazgo 10); y un freno de YouTube o
    Cancelar paran la lectura (parar, pausa: como en leer)."""
    from .motor import id_video
    hora = _ahora_ms()   # antes de leer nada: lo que se dé de baja aquí mientras dura B entra en la siguiente pasada
    s = abrir(origen)
    s.parar, s.pausa = parar, pausa
    i = destino
    nombre = i.get("nombre") or "tu cuenta"
    aviso(f"{nombre}: leyendo tus suscripciones…")
    yt = {}
    _suscripciones(s, i, yt)
    leidos = {}
    for col, bid, txt in (("megusta", "VLLL", "«Me gusta»"), ("despues", "VLWL", "«Ver más tarde»")):
        aviso(f"{nombre}: leyendo {txt}…")
        try:
            leidos[col] = set(_videos_de(s, bid, i))
        except Exception as e:   # noqa: BLE001 (un canal de marca sin «Me gusta»: esa parte no se toca)
            if _hay_que_parar(e):
                _relanzar(e)
            aviso(f"{nombre}: no he podido leer {txt} ({e.__class__.__name__}): no lo toco")
            leidos[col] = None
    est = estado_cuenta()
    foto = (est.get("foto") or {}).get(clave_identidad(i)) or {}
    if not _foto_valida(foto, i.get("nombre", "")):
        foto = {}   # foto de otra cuenta en el mismo «au»: sin foto, ninguna baja se lleva (solo los fulminados)
    if not yt and foto.get("ids"):
        raise RuntimeError(f"No he podido ver las suscripciones de {nombre} (YouTube no ha dado ninguna y antes había "
                           f"{len(foto['ids'])}): no toco nada. Prueba otra vez dentro de un rato")
    # tarea extra 1: el umbral de las bajas es «t_subida» (la mueve solo un B completo); las fotos de antes, su «t»
    foto_t = foto.get("t_subida") or foto.get("t")
    lectura = (est.get("lecturas") or {}).get(clave_identidad(i)) or {}
    if not _foto_valida(lectura, i.get("nombre", "")):
        lectura = {}
    indice = _indice_subs(datos)
    f_ids, f_nombres = _fulminados(datos)
    yt_nombres = {_norma(c["titulo"]) for c in yt.values()}
    suscribir, sin_identificar, vistos = [], [], set()
    for e in datos.suscripciones():
        cid = _id_canal(e.url)
        if cid in f_ids or _norma(e.titulo) in f_nombres:
            continue   # fulminado: nunca se sigue en YouTube
        if not cid and _norma(e.titulo) in yt_nombres:
            continue   # /@nombre que ya sigue en YouTube (por nombre): sin gastar una petición en resolverla
        if not cid:
            aviso(f"Buscando el canal «{e.titulo}»…")
            cid = resolver_canal(s, e.url, i)
            if not cid:
                sin_identificar.append(e.titulo or e.url)
                continue
        if cid in yt or cid in vistos or cid in f_ids:
            continue
        vistos.add(cid)
        suscribir.append({"id": cid, "titulo": e.titulo or cid})
    quitar = []
    for cid, c in yt.items():
        if cid in f_ids or _norma(c["titulo"]) in f_nombres:
            quitar.append({"id": cid, "titulo": c["titulo"], "motivo": "fulminado"})
            continue
        ya = _en_catode(indice, cid, c["titulo"])
        if foto_t and ya and not any(m["activo"] for _, m in ya) and max(m["t"] for _, m in ya) > foto_t:
            quitar.append({"id": cid, "titulo": c["titulo"], "motivo": "baja en Cat-ode"})
    faltan = {}
    for col in ("megusta", "despues"):
        if leidos[col] is None:
            faltan[col] = None
            continue
        # hallazgo 10: lo que estaba en YouTube en la lectura anterior y ya no está se quitó allí: no se vuelve a poner
        quitados_yt = set(lectura.get(col) or []) - leidos[col]
        faltan[col] = [id_video(e.url) for e in datos.coleccion(col)
                       if len(id_video(e.url)) == 11 and id_video(e.url) not in leidos[col]
                       and id_video(e.url) not in quitados_yt]
    return {"identidad": dict({k: i.get(k) for k in ("au", "pagina", "nombre")}, clave=clave_identidad(i)),
            "suscribir": suscribir, "quitar": quitar, "megusta": faltan["megusta"], "despues": faltan["despues"],
            "sin_identificar": sin_identificar, "yt_subs": sorted(yt), "foto_t": foto_t, "foto_t_subida": foto_t,
            "hora": hora, "lecturas": {col: (None if leidos[col] is None else sorted(leidos[col])) for col in ("megusta", "despues")},
            "n_youtube": {"suscripciones": len(yt), "megusta": None if leidos["megusta"] is None else len(leidos["megusta"]),
                          "despues": None if leidos["despues"] is None else len(leidos["despues"])}}


def numeros_plan(plan):
    """{suscribir, quitar, megusta, despues (los de esta pasada), quedan_megusta, quedan_despues, sin_identificar}."""
    mg, wl = plan.get("megusta") or [], plan.get("despues") or []
    return {"suscribir": len(plan["suscribir"]), "quitar": len(plan["quitar"]), "megusta": min(len(mg), TOPE_VIDEOS),
            "despues": min(len(wl), TOPE_VIDEOS), "quedan_megusta": max(0, len(mg) - TOPE_VIDEOS),
            "quedan_despues": max(0, len(wl) - TOPE_VIDEOS), "sin_identificar": len(plan.get("sin_identificar") or [])}


def _freno_en(r):
    """¿La respuesta trae un 429/403 o «not a bot»? (algunos errores llegan con 200 y un «error» dentro)."""
    try:
        err = (r or {}).get("error") or {}
        codigo = int(err.get("code") or 0) if isinstance(err, dict) else 0
        texto = json.dumps(err).lower() if err else ""
    except Exception:   # noqa: BLE001
        return False
    return codigo in (429, 403) or "not a bot" in texto or "too many requests" in texto


def aplicar(origen, plan, aviso=lambda _t: None, progreso=lambda _h, _t, _x: None, pausa=PAUSA, parar=lambda: False):
    """B · aplica un plan (plan_youtube): una petición cada «pausa» segundos, como mucho TOPE_VIDEOS «Me gusta» y otros
    tantos «Ver más tarde» por pasada; al primer 429/403 o a los 2 errores seguidos, para. Al acabar, foto nueva de esa
    identidad. Devuelve {hechos, fallos, parado, quedan, resumen}."""
    s = abrir(origen)
    i = plan["identidad"]
    au, pagina = i.get("au") or 0, i.get("pagina")
    tareas = ([("suscribir", c["id"], c["titulo"]) for c in plan["suscribir"]]
              + [("quitar", c["id"], c["titulo"]) for c in plan["quitar"]]
              + [("megusta", v, "") for v in (plan.get("megusta") or [])[:TOPE_VIDEOS]]
              + [("despues", v, "") for v in (plan.get("despues") or [])[:TOPE_VIDEOS]])
    hechos = {"suscribir": [], "quitar": [], "megusta": [], "despues": []}
    fallos, seguidos, parado = 0, 0, ""
    textos = {"suscribir": "Suscribiendo a «{}»", "quitar": "Quitando «{}»", "megusta": "«Me gusta» {}", "despues": "«Ver más tarde» {}"}
    for n, (que, ident, titulo) in enumerate(tareas):
        if parar():
            parado = "Cancelado"
            break
        if n:
            time.sleep(pausa)
        progreso(n, len(tareas), textos[que].format(titulo or ident))
        if que == "suscribir":
            ep, cuerpo = "subscription/subscribe", {"channelIds": [ident], "params": PARAMS_SUSCRIBIR}
        elif que == "quitar":
            ep, cuerpo = "subscription/unsubscribe", {"channelIds": [ident], "params": PARAMS_QUITAR}
        elif que == "megusta":
            ep, cuerpo = "like/like", {"target": {"videoId": ident}}
        else:
            ep, cuerpo = "browse/edit_playlist", {"playlistId": "WL", "actions": [{"action": "ACTION_ADD_VIDEO", "addedVideoId": ident}]}
        try:
            r = s.api(ep, cuerpo, au, pagina)
            if _freno_en(r):
                raise _Freno("YouTube ha frenado las peticiones")
            bien = isinstance(r, dict) and "error" not in r and (que != "despues" or r.get("status") == "STATUS_SUCCEEDED")
        except urllib.error.HTTPError as e:
            if e.code in (429, 403):
                parado = f"YouTube ha frenado las peticiones ({e.code}): paro aquí"
                break
            bien = False
        except _Freno as e:
            parado = f"{e}: paro aquí"
            break
        except Exception:   # noqa: BLE001 (red, respuesta rara…)
            bien = False
        if bien:
            hechos[que].append(ident)
            seguidos = 0
        else:
            fallos += 1
            seguidos += 1
            aviso(f"No ha salido: {textos[que].format(titulo or ident)}")
            if seguidos >= 2:
                parado = "Dos errores seguidos: paro aquí"
                break
    progreso(len(tareas) if not parado else n, len(tareas), "")
    # 18/10/2026 · foto nueva de esa identidad (hallazgo 2): la foto ANTERIOR más lo suscrito y menos lo quitado (antes,
    # lo leído en YouTube: un canal que se volvió a seguir allí entraba en la foto y A ya no lo reactivaba). Sin foto
    # anterior, lo leído en YouTube. «t» = ahora; «t_subida» (tarea extra 1) solo avanza con un B COMPLETO (sin parar y
    # con todas las bajas llevadas), hasta la hora en que empezó el plan; si no, se queda donde estaba y la próxima
    # pasada vuelve a ver las bajas pendientes
    with _CERROJO_ESTADO:
        est = estado_cuenta()
        previa = (est.get("foto") or {}).get(i["clave"])
        if _foto_valida(previa, i.get("nombre", "")) and isinstance(previa.get("ids"), list):
            base = set(previa["ids"])
        else:
            base, previa = set(plan.get("yt_subs") or []), None
        ids = (base | set(hechos["suscribir"])) - set(hechos["quitar"])
        ahora = _ahora_ms()
        completo = not parado and len(hechos["quitar"]) >= len(plan["quitar"])
        hora = plan.get("hora") or ahora
        if completo:
            t_subida = hora
        else:
            t_subida = plan.get("foto_t_subida") or plan.get("foto_t") or (previa or {}).get("t_subida") or hora
        lectura = (est.get("lecturas") or {}).get(i["clave"])
        lectura = dict(lectura) if _foto_valida(lectura, i.get("nombre", "")) else {}
        lectura["nombre"] = i.get("nombre", "")
        for col in ("megusta", "despues"):   # hallazgo 10: lo que hay ahora en YouTube, para la próxima vez
            leidos = (plan.get("lecturas") or {}).get(col)
            if leidos is not None:
                lectura[col] = sorted(set(leidos) | set(hechos[col]))
        guardar_estado_cuenta({"foto": {i["clave"]: {"t": ahora, "t_subida": t_subida, "ids": sorted(ids), "nombre": i.get("nombre", "")}},
                               "lecturas": {i["clave"]: lectura}})
    num = numeros_plan(plan)
    quedan = {"megusta": len(plan.get("megusta") or []) - len(hechos["megusta"]),
              "despues": len(plan.get("despues") or []) - len(hechos["despues"])}
    return {"hechos": {k: len(v) for k, v in hechos.items()}, "fallos": fallos, "parado": parado, "quedan": quedan,
            "resumen": resumen_b(hechos, fallos, parado, quedan, num["sin_identificar"])}


def resumen_b(hechos, fallos, parado, quedan, sin_identificar):
    n = {k: len(v) if isinstance(v, list) else v for k, v in hechos.items()}
    partes = []
    if n["suscribir"]:
        partes.append(f"suscrito a {n['suscribir']} canal{'es' if n['suscribir'] != 1 else ''}")
    if n["quitar"]:
        partes.append(f"{n['quitar']} canal{'es' if n['quitar'] != 1 else ''} quitado{'s' if n['quitar'] != 1 else ''}")
    if n["megusta"]:
        partes.append(f"{n['megusta']} «Me gusta»")
    if n["despues"]:
        partes.append(f"{n['despues']} en «Ver más tarde»")
    texto = ("En YouTube: " + ", ".join(partes)) if partes else "Nada que llevar a YouTube"
    extra = []
    if quedan.get("megusta", 0) > 0 or quedan.get("despues", 0) > 0:
        extra.append(f"quedan {max(0, quedan.get('megusta', 0))} «Me gusta» y {max(0, quedan.get('despues', 0))} «Ver más tarde» para la siguiente pasada")
    if sin_identificar:
        extra.append(f"{sin_identificar} canal{'es' if sin_identificar != 1 else ''} sin identificar")
    if fallos:
        extra.append(f"{fallos} sin poder hacer")
    if parado:
        extra.append(parado)
    if not extra:
        return texto
    resto = "; ".join(extra)
    return f"{texto}. {resto[:1].upper()}{resto[1:]}"
