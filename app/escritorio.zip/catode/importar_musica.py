"""Cat-ode escritorio · «Importar tu música» (22/10/2026, orden del autor: «quien use Catode redistributable debe poder importar en
local su biblioteca de spotify, amazon music y youtube music»). Todo en el aparato de cada usuario: sin servidor nuestro.

Vías (documentadas el 22/10/2026; la Web API de Spotify no se puede repartir: modo desarrollo con usuarios a mano y dueño con
Premium; Amazon Music no tiene API pública ni exportación oficial):
  spotify_archivo(ruta)  el ZIP (o la carpeta, o un JSON) de «Descargar tus datos» de Spotify: YourLibrary.json (canciones,
                         álbumes y artistas guardados) y Playlist*.json (sus listas con sus canciones).
  spotify_enlace(url)    una lista PÚBLICA de Spotify por su enlace (la página «embed»: como mucho 100 canciones).
  csv_archivo(ruta)      un CSV con columnas de título y artista (p. ej. el de TuneMyMusic para Amazon Music o Spotify).
  carpeta(ruta)          una carpeta con su música (p. ej. lo comprado en Amazon Music y descargado): suena desde el archivo.
  youtube_music(galletas) su biblioteca de YouTube Music con la sesión de la ventana de Google de la app («Traer mi YouTube»).
Todas devuelven {"listas": {nombre: [canción]}, "megusta": [...], "albumes": {nombre: {titulo, artista, canciones}},
"artistas": [...]}; canción = {titulo, artista, album, dur} (+ id si ya es de YouTube, + ruta si es un archivo).
guardar(datos, fuente, res) lo pone en la biblioteca de música de este Cat-ode (colección «biblioteca», origen = la fuente);
las canciones sin vídeo se buscan en YouTube al ir a sonar (musica.buscar_cancion)."""
import csv
import io
import json
import os
import re
import time
import urllib.request
import zipfile

from . import motor

AUDIO = (".mp3", ".m4a", ".flac", ".ogg", ".opus", ".wav", ".aac", ".wma")
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36"


def _c(titulo, artista="", album="", dur=-1, **mas):
    t = " ".join(str(titulo or "").split())
    return {"titulo": t, "artista": " ".join(str(artista or "").split()), "album": " ".join(str(album or "").split()),
            "dur": int(dur) if dur not in (None, "") else -1, **{k: v for k, v in mas.items() if v}} if t else None


def _vacio():
    return {"listas": {}, "megusta": [], "albumes": {}, "artistas": []}


# ---------------------------------------------------------------- Spotify: «Descargar tus datos»
def _jsons_de(ruta):
    """{nombre: contenido} de los JSON de un ZIP, una carpeta o un archivo suelto."""
    out = {}
    if os.path.isdir(ruta):
        for raiz, _, archivos in os.walk(ruta):
            for a in archivos:
                if a.lower().endswith(".json"):
                    with open(os.path.join(raiz, a), "rb") as f:
                        out[a] = f.read()
    elif zipfile.is_zipfile(ruta):
        with zipfile.ZipFile(ruta) as z:
            for n in z.namelist():
                if n.lower().endswith(".json"):
                    out[os.path.basename(n)] = z.read(n)
    else:
        with open(ruta, "rb") as f:
            out[os.path.basename(ruta)] = f.read()
    return {n: json.loads(b.decode("utf-8-sig")) for n, b in out.items() if b.strip()}


def spotify_archivo(ruta):
    """El paquete de «Descargar tus datos» de Spotify (spotify.com → Cuenta → Privacidad → «Descargar tus datos»)."""
    res = _vacio()
    for nombre, j in _jsons_de(ruta).items():
        if not isinstance(j, dict):
            continue
        if "tracks" in j and isinstance(j.get("tracks"), list):   # YourLibrary.json
            res["megusta"] += [c for c in (_c(t.get("track") or t.get("trackName"), t.get("artist") or t.get("artistName"),
                                              t.get("album") or t.get("albumName"), uri=t.get("uri")) for t in j["tracks"]) if c]
            for a in j.get("albums") or []:
                t, ar = a.get("album") or a.get("name") or "", a.get("artist") or ""
                if t:
                    res["albumes"].setdefault(f"{t} — {ar}" if ar else t, {"titulo": t, "artista": ar, "canciones": [], "uri": a.get("uri", "")})
            res["artistas"] += [{"nombre": a.get("name") or a.get("artist") or "", "uri": a.get("uri", "")} for a in j.get("artists") or []]
        for l in j.get("playlists") or []:   # Playlist1.json, Playlist2.json…
            cs = []
            for it in l.get("items") or []:
                t = it.get("track") or {}
                cs.append(_c(t.get("trackName") or t.get("name"), t.get("artistName") or t.get("artist"),
                             t.get("albumName") or t.get("album"), uri=t.get("trackUri") or t.get("uri")))
            cs = [c for c in cs if c]
            if cs:
                res["listas"][l.get("name") or "Lista de Spotify"] = cs
    return res


# ---------------------------------------------------------------- Spotify: enlace de una lista pública
def spotify_enlace(url):
    """Una lista pública de Spotify por su enlace (open.spotify.com/playlist/ID o /album/ID): la página «embed», que trae
    las 100 primeras canciones con título, artistas y duración."""
    m = re.search(r"(playlist|album)[/:]([A-Za-z0-9]{10,})", url or "")
    if not m:
        raise ValueError("No es un enlace de una lista o un álbum de Spotify")
    q = urllib.request.Request(f"https://open.spotify.com/embed/{m.group(1)}/{m.group(2)}", headers={"User-Agent": UA,
                                                                                                    "Accept-Language": "es-ES,es"})
    html = urllib.request.urlopen(q, timeout=30).read().decode("utf-8", "replace")
    d = re.search(r'<script id="__NEXT_DATA__"[^>]*>(.*?)</script>', html, re.S)
    if not d:
        raise ValueError("Spotify no ha devuelto la lista (¿es privada?)")
    ent = json.loads(d.group(1))["props"]["pageProps"]["state"]["data"]["entity"]
    cs = [_c(t.get("title"), t.get("subtitle"), "", (t.get("duration") or 0) // 1000 or -1, uri=t.get("uri"))
          for t in ent.get("trackList") or []]
    res = _vacio()
    res["listas"][ent.get("name") or ent.get("title") or "Lista de Spotify"] = [c for c in cs if c]
    return res


# ---------------------------------------------------------------- CSV (TuneMyMusic y parecidos)
def _col(cab, *claves):
    for i, h in enumerate(cab):
        h = (h or "").strip().lower()
        if any(k in h for k in claves):
            return i
    return None


def csv_archivo(ruta, lista_por_defecto="Importada"):
    """Un CSV con una fila por canción: título y artista (y si están, álbum y lista). Separador «,» o «;»."""
    texto = open(ruta, encoding="utf-8-sig", errors="replace").read()
    dialecto = csv.Sniffer().sniff(texto[:4096], delimiters=",;\t") if texto.strip() else csv.excel
    filas = list(csv.reader(io.StringIO(texto), dialecto))
    if not filas:
        return _vacio()
    cab = filas[0]
    it, ia = _col(cab, "track name", "track", "título", "titulo", "title", "song", "canción", "cancion", "name"), _col(cab, "artist", "artista")
    ial, il = _col(cab, "album", "álbum"), _col(cab, "playlist", "lista")
    if it is None:
        raise ValueError("El CSV no tiene una columna de título (track, title, título…)")
    res = _vacio()
    for f in filas[1:]:
        g = (lambda i: f[i] if i is not None and i < len(f) else "")
        c = _c(g(it), g(ia), g(ial))
        if c:
            res["listas"].setdefault(g(il).strip() or lista_por_defecto, []).append(c)
    return res


# ---------------------------------------------------------------- una carpeta de música (lo comprado en Amazon, sus discos…)
def carpeta(ruta):
    """Los archivos de música de una carpeta (y sus subcarpetas), con sus etiquetas; una lista por álbum y una con todo."""
    try:
        import mutagen
    except ImportError:   # sin mutagen: el nombre del archivo
        mutagen = None
    res, todas = _vacio(), []
    for raiz, _, archivos in os.walk(ruta):
        for a in sorted(archivos):
            if not a.lower().endswith(AUDIO):
                continue
            p = os.path.join(raiz, a)
            t, ar, al, d = os.path.splitext(a)[0], "", os.path.basename(raiz), -1
            try:
                m = mutagen.File(p, easy=True) if mutagen else None
                if m is not None:
                    t = (m.get("title") or [t])[0]
                    ar = (m.get("artist") or m.get("albumartist") or [""])[0]
                    al = (m.get("album") or [al])[0]
                    d = int(m.info.length) if getattr(m, "info", None) else -1
            except Exception:   # noqa: BLE001
                pass
            c = _c(t, ar, al, d, ruta=p)
            if c:
                todas.append(c)
                res["albumes"].setdefault(f"{al} — {ar}" if ar else al, {"titulo": al, "artista": ar, "canciones": []})["canciones"].append(c)
    if todas:
        res["listas"]["Tu carpeta de música"] = todas
    return res


# ---------------------------------------------------------------- YouTube Music (la sesión de la ventana de Google)
def youtube_music(galletas, aviso=print):
    """Su biblioteca de YouTube Music con las galletas de youtube.com de la ventana de Google de la app (o de un navegador)."""
    from . import ytmusic
    s = ytmusic.Sesion(galletas=galletas)
    if not s.con_sesion():
        raise ValueError("No hay sesión de Google: entra primero en «Traer mi YouTube»")
    r = ytmusic.leer(s, {}, aviso)
    res = _vacio()
    cv = lambda c: _c(c.get("titulo"), c.get("artista"), c.get("album"), c.get("dur", -1), id=c.get("id"))   # noqa: E731
    res["listas"] = {n: [x for x in map(cv, cs) if x] for n, cs in r["listas"].items()}
    res["megusta"] = [x for x in map(cv, r["canciones"]) if x]
    res["albumes"] = {k: {**a, "canciones": [x for x in map(cv, a["canciones"]) if x]} for k, a in r["albumes"].items()}
    res["artistas"] = r["artistas"]
    return res


# ---------------------------------------------------------------- a la biblioteca de este Cat-ode
ORIGEN = {"spotify": "spotify", "amazon": "amazon music", "youtube": "youtube music", "carpeta": "tu carpeta", "csv": "importada"}


def guardar(datos, fuente, res):
    """Lo importado a la colección «biblioteca» de este Cat-ode (y, si tiene cuenta compartida, a sus otros aparatos).
    Devuelve cuántas listas y canciones han entrado."""
    import unicodedata
    origen = ORIGEN.get(fuente, fuente)
    pon = lambda c: {k: v for k, v in {"id": c.get("id"), "titulo": c["titulo"], "autor": c.get("artista", ""), "dur": c.get("dur", -1),   # noqa: E731
                                       "album": c.get("album", ""), "ruta": c.get("ruta")}.items() if v not in (None, "")}

    def clave(n):
        n = unicodedata.normalize("NFKD", f"{origen} {n}".lower())
        return "lista:" + re.sub(r"[^a-z0-9]+", "-", "".join(c for c in n if not unicodedata.combining(c))).strip("-")[:60]
    nl = nc = 0
    grupos = [(f"Me gusta en {fuente.capitalize() if fuente != 'youtube' else 'YouTube Music'}", res.get("megusta") or [], origen)]
    grupos += [(n, cs, origen) for n, cs in (res.get("listas") or {}).items()]
    grupos += [(k, a.get("canciones") or [], origen + " · álbum") for k, a in (res.get("albumes") or {}).items()]
    for nombre, cs, org in grupos:
        cs = [pon(c) for c in cs if c and c.get("titulo")]
        if not cs:
            continue
        datos.poner("biblioteca", clave(nombre), None, {"nombre": nombre, "origen": org, "hecha": int(time.time()), "canciones": cs})
        nl, nc = nl + 1, nc + len(cs)
    for a in res.get("artistas") or []:
        if str(a.get("id", "")).startswith("UC"):
            datos.poner("biblioteca", "artista:" + a["id"], None, {"nombre": a.get("nombre", ""), "id": a["id"], "miniatura": a.get("miniatura", ""),
                                                                   "origen": "youtube music · artista", "hecha": int(time.time())})
    return nl, nc
