"""Cat-ode · el Inicio no puede ser siempre el mismo (06/10/2026, orden del autor: «el feed de Catode no puede ser siempre
el mismo y fijo»). El recomendador deja ~400 vídeos ordenados por puntuación; servidos tal cual, la primera pantalla era
idéntica hasta que se veían. Aquí se hace una mezcla nueva en cada visita: sorteo con peso por posición (los mejor
puntuados salen antes más a menudo, pero no siempre los mismos) y variedad de canales (como mucho 2 seguidos del mismo
y 3 por canal en los primeros 30). Sin Qt ni red: lo usan el servicio web, la interfaz Qt y el recomendador."""
import collections
import json
import os
import platform
import random
import threading
import time


class Ensenado:
    """24/10/2026 («catode enseña siempre los mismos vídeos… no hay rotación»; medido: con una mezcla nueva en cada visita
    y los mismos 400 del servidor, en 12 visitas salían solo 184 distintos y los de cabeza en 6 de cada 12). La memoria de
    lo que el Inicio ya ha enseñado en este aparato: cada mezcla nueva apunta los PRIMEROS que se ven y lo que ha salido
    VECES veces sin que se abra se aparta DIAS días desde la última (después cuenta de cero). Lo que se abre ya no sale
    (va al historial). Un archivo por aparato, como datos-<equipo>.json; si no se puede leer, se empieza vacía, y nunca
    deja el Inicio con menos de MINIMO (ver apartar)."""
    VECES, DIAS, PRIMEROS, MINIMO = 3, 14, 24, 40

    def __init__(self, ruta=None):
        if ruta is None:
            from .datos import carpeta_datos
            ruta = os.path.join(carpeta_datos(), f"ensenado-{platform.node()}.json")
        self.ruta, self.cerrojo = ruta, threading.Lock()
        try:
            with open(ruta, encoding="utf-8") as f:
                m = json.load(f)
        except Exception:   # noqa: BLE001 (sin archivo o roto: memoria vacía)
            m = {}
        ahora = time.time()
        self.m = {k: v for k, v in (m.items() if isinstance(m, dict) else [])
                  if isinstance(v, list) and len(v) == 2 and ahora - v[1] < self.DIAS * 86400}

    def veces(self):
        """{id: veces} de lo enseñado en los últimos DIAS días (para mezclar: lo ya visto pierde peso)."""
        with self.cerrojo:
            return {k: v[0] for k, v in self.m.items()}

    def cansados(self):
        """Los ids que ya han salido VECES veces en los últimos DIAS días."""
        with self.cerrojo:
            return {k for k, v in self.m.items() if v[0] >= self.VECES}

    def apartar(self, lista, cansados, clave):
        """La lista sin lo cansado; si quedaran menos de MINIMO, se completa con lo que hace más que salió."""
        buenos = [x for x in lista if clave(x) not in cansados]
        if len(buenos) >= self.MINIMO:
            return buenos
        with self.cerrojo:
            resto = sorted((x for x in lista if clave(x) in cansados), key=lambda x: self.m.get(clave(x), [0, 0])[1])
        return buenos + resto[:self.MINIMO - len(buenos)]

    def apuntar(self, ids):
        """Una vez enseñados (una mezcla nueva): +1 a cada uno y se guarda."""
        ahora = time.time()
        with self.cerrojo:
            for vid in ids:
                if vid:
                    self.m[vid] = [self.m.get(vid, [0, 0])[0] + 1, ahora]
            copia = dict(self.m)
        try:
            tmp = self.ruta + ".nuevo"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(copia, f)
            os.replace(tmp, self.ruta)
        except Exception:   # noqa: BLE001 (sin disco: se queda en memoria hasta cerrar)
            pass


def _canal(v):
    return (v.get("autorUrl") or v.get("autor") or "") if isinstance(v, dict) else (getattr(v, "autorUrl", "") or getattr(v, "autor", ""))


def mezclar(videos, rnd=None, seguidos=2, por_canal=3, ventana=30, media=100.0, ensenados=None):
    """Devuelve una lista nueva con los mismos elementos en otro orden. «media»: la posición original a la que el peso
    baja a la mitad. 24/10/2026 («siguen saliéndome siempre los mismos vídeos sugeridos»): 100 en vez de 40 (con 40, un
    tercio de la primera pantalla salía siempre de los 40 primeros) y «ensenados» ({id: veces}, Ensenado.veces): lo ya
    enseñado pierde peso desde la primera vez (1/3, luego 1/5…), sin esperar a apartarlo a la tercera."""
    videos = list(videos or [])
    if len(videos) < 3:
        return videos
    rnd = rnd or random.Random()
    ensenados = ensenados or {}
    if ensenados:
        from . import motor
    claves = []
    for i in range(len(videos)):
        peso = 1.0 / (1.0 + i / media)
        if ensenados:
            v = videos[i]
            peso /= 1 + 2 * ensenados.get(motor.id_video(v.get("url", "") if isinstance(v, dict) else getattr(v, "url", "")), 0)
        claves.append((rnd.random() ** (1.0 / peso), i))   # sorteo con pesos sin reposición (Efraimidis-Spirakis)
    cola = [videos[i] for _, i in sorted(claves, reverse=True)]
    final, cuenta = [], collections.Counter()
    while cola:
        elegido = 0
        for k, v in enumerate(cola[:60]):
            a = _canal(v)
            repetido = len(final) >= seguidos and all(_canal(x) == a for x in final[-seguidos:])
            if not repetido and (len(final) >= ventana or cuenta[a] < por_canal):
                elegido = k
                break
        v = cola.pop(elegido)
        cuenta[_canal(v)] += 1
        final.append(v)
    return final


def mas_para_ti(datos, ya, tema="Todo", parati=None, vistos=None, rnd=None):
    """Una tanda más para el Inicio al llegar al final (06/10/2026: «la lista de vídeos a ver es cortísima, tiene que
    autogenerarse al ir haciendo scroll» y «relacionado con mis canales y mis intereses»). De YouTube, alrededor de lo
    suyo: para «Todo», los relacionados de 3 vídeos suyos (2 del historial reciente, con más peso lo último, y 1 de sus «me
    gusta») y lo último de 2 canales a los que está suscrito; para un tema (el nombre de un canal), los vídeos de ese
    canal y los relacionados de 2 de sus vídeos; para «Novedades de tus canales», lo último de 4 suscripciones.
    «ya»: conjunto de ids mostrados (se actualiza aquí). Devuelve (elementos, motivos); ([], {}) si no sale nada nuevo.
    Hace 3-5 peticiones en paralelo; se llama en un hilo, nunca en el de la ventana."""
    from concurrent.futures import ThreadPoolExecutor
    from . import motor
    rnd = rnd or random.Random()
    parati = parati or []
    vistos = vistos or set()
    trabajos = []   # (función que devuelve Elementos, motivo)

    def de_canal(url, n=14):
        return lambda: list(motor.canal(url)[1] or [])[:n]

    def de_relacionados(url):
        return lambda: list(motor.relacionados(url) or [])

    subs = list(datos.suscripciones())
    if tema == "Novedades de tus canales":
        for c in rnd.sample(subs, min(4, len(subs))):
            trabajos.append((de_canal(c.url), "De tus suscripciones"))
    elif tema in ("Todo", "", None):
        hist = [e for e in datos.historial(60) if getattr(e, "tipo", "VIDEO") == "VIDEO"]
        semillas = []
        if hist:
            pesos = [1.0 / (1.0 + i / 15.0) for i in range(len(hist))]
            for e in rnd.choices(hist, weights=pesos, k=6):
                if e.url not in [s.url for s in semillas] and len(semillas) < 2:
                    semillas.append(e)
        megusta = [e for e in datos.coleccion("megusta", 200) if getattr(e, "tipo", "VIDEO") == "VIDEO"]
        if megusta:
            semillas.append(rnd.choice(megusta))
        elif len(hist) > 2:
            semillas.append(rnd.choice(hist))
        for e in semillas:
            trabajos.append((de_relacionados(e.url), f"Porque has visto «{(e.titulo or '')[:40]}»"))
        for c in rnd.sample(subs, min(2, len(subs))):
            trabajos.append((de_canal(c.url), "De tus suscripciones"))
    else:
        del_tema = [v for v in parati if v.get("autor") == tema]
        url = next((v.get("autorUrl") for v in del_tema if v.get("autorUrl")), None) \
            or next((c.url for c in subs if c.titulo == tema), None)
        if url:
            trabajos.append((de_canal(url, 30), f"De {tema}"))
        for v in rnd.sample(del_tema, min(2, len(del_tema))):
            trabajos.append((de_relacionados(v["url"]), f"Relacionado con {tema}"))
    if not trabajos:
        return [], {}

    def hacer(t):
        try:
            return t[0]()
        except Exception:   # noqa: BLE001 (una fuente que falla no tumba la tanda)
            return []
    with ThreadPoolExecutor(max_workers=5) as pool:
        tandas = list(pool.map(hacer, trabajos))
    ocultos = datos.ocultos()
    colas, motivos = [], {}
    for (_, motivo), lista in zip(trabajos, tandas):
        cola = []
        for e in lista:
            vid = motor.id_video(getattr(e, "url", "") or "")
            if (not vid or getattr(e, "tipo", "VIDEO") != "VIDEO" or vid in ya or vid in vistos or e.url in ocultos
                    or datos.vetado(e) or motor.programado(e)):   # 24/10/2026: sin estrenos que aún no han empezado
                continue
            ya.add(vid)
            cola.append(e)
            motivos[e.url] = motivo
        colas.append(cola)
    elementos = []
    while any(colas):   # de una fuente cada vez, para que no salgan seguidos los de la misma
        for cola in colas:
            if cola:
                elementos.append(cola.pop(0))
    return mezclar_canales(elementos), motivos


def mezclar_canales(elementos, seguidos=2):
    """El mismo orden, pero sin más de 2 seguidos del mismo canal (mirando hasta 20 por delante)."""
    cola, final = list(elementos), []
    while cola:
        elegido = 0
        for k, v in enumerate(cola[:20]):
            a = _canal(v)
            if not (len(final) >= seguidos and all(_canal(x) == a for x in final[-seguidos:])):
                elegido = k
                break
        final.append(cola.pop(elegido))
    return final
