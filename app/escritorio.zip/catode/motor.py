"""Cat-ode escritorio · el motor. yt-dlp para vídeos, búsquedas, canales y listas (se actualiza solo cada día); la API
interna de YouTube (innertube) para los relacionados, que es la red neuronal de recomendaciones de YouTube; el RSS de
cada canal para las novedades. Los enlaces se escriben igual que en el móvil, para que la sincronización cuadre.
Desde la 0.4.0 (02/10/2026) las búsquedas y los canales también van por innertube, para tener en las listas las
visualizaciones, la fecha y la duración de cada vídeo; yt-dlp queda de reserva si YouTube cambia algo."""
import concurrent.futures as cf
import json
import os
import re
import shutil
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from dataclasses import dataclass, asdict

import yt_dlp

from . import metadatos as md
from . import roto

AGENTE = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0"


@dataclass
class Elemento:
    tipo: str            # VIDEO, CANAL o LISTA
    url: str
    titulo: str
    autor: str = ""
    autorUrl: str = ""
    miniatura: str = ""
    duracion: int = -1
    detalle: str = ""
    fecha: int = 0       # milisegundos, como en el móvil

    def dict(self):
        # 06/10/2026 (perfil de uso): todos los campos son escalares; asdict copiaba en profundidad campo a campo y era lo
        # más caro de cada página y de cada guardado de datos (149 canales en /api/estado, 5000 vídeos al guardar)
        d = self.__dict__
        return {k: d[k] for k in _CAMPOS}


_CAMPOS = tuple(Elemento.__dataclass_fields__)
_POR_DEFECTO = None


def elemento_de_dict(d):
    global _POR_DEFECTO
    if _POR_DEFECTO is None:
        _POR_DEFECTO = Elemento("", "", "").dict()
    return Elemento(**{k: d.get(k, v) for k, v in _POR_DEFECTO.items()})


def url_video(vid):
    return f"https://www.youtube.com/watch?v={vid}"


def id_video(url):
    m = re.search(r"(?:v=|youtu\.be/|shorts/)([A-Za-z0-9_-]{11})", url or "")
    return m.group(1) if m else url


def miniatura(vid):
    return f"https://i.ytimg.com/vi/{vid}/mqdefault.jpg"


# 24/10/2026 («algunos vídeos salen con 0 o 1 visualización y no cargan»): eran estrenos que aún no han empezado
# (-nl18l8sE08, «Premieres in 29 hours»). YouTube los pone en la pestaña de vídeos del canal y en los relacionados con la
# etiqueta «Próximamente» y «Fecha de estreno: 25/10/26, 4:00» (o «Programado para …» si es un directo), sin duración ni
# visualizaciones. Llevan el detalle «Próximamente · …»: en la página del canal se ven con su fecha y en el Inicio, los
# relacionados y la reproducción automática no entran.
PROXIMAMENTE = "Próximamente"
_PROGRAMADO = re.compile(r"(fecha de estreno|estreno el|programado para|premieres|scheduled for|\besperando\b|\bwaiting\b)", re.I)


def programado(e):
    """¿Un estreno o un directo que aún no ha empezado (detalle «Próximamente · …»)? Vale para Elemento y para dict."""
    d = (e.get("detalle") if isinstance(e, dict) else getattr(e, "detalle", "")) or ""
    return d.startswith(PROXIMAMENTE)


def cifra(n):
    if n is None or n < 0:
        return ""
    return f"{n / 1e6:.1f} M".replace(".", ",") if n >= 1_000_000 else f"{n / 1e3:.0f} mil" if n >= 1000 else str(n)


def tiempo(s):
    if s is None or s < 0:
        return ""
    s = int(s)
    return f"{s // 3600}:{s % 3600 // 60:02d}:{s % 60:02d}" if s >= 3600 else f"{s // 60}:{s % 60:02d}"


def hace(ms):
    return md.hace(ms)


def node():
    """yt-dlp necesita JavaScript para descifrar YouTube: el node del sistema, el de la instalación o el de nvm.
    18/10/2026: la instalación nueva de Windows trae el suyo en <raíz>\\node\\node.exe (raíz = la carpeta madre de app\\);
    se usa si no hay node en el PATH."""
    n = shutil.which("node")
    if not n:
        raiz = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        propio = os.path.join(raiz, "node", "node.exe" if os.name == "nt" else "node")
        n = propio if os.path.isfile(propio) else None
    if not n:
        cands = sorted(os.path.expanduser("~/.nvm/versions/node/") + d + "/bin/node"
                       for d in (os.listdir(os.path.expanduser("~/.nvm/versions/node/")) if os.path.isdir(os.path.expanduser("~/.nvm/versions/node/")) else []))
        n = cands[-1] if cands else None
    return n


class _Callado:
    """yt-dlp escribe «ERROR: …» aunque se le pida silencio (p. ej. un canal sin pestaña de Shorts): aquí no se enseña."""
    def debug(self, m): pass
    def info(self, m): pass
    def warning(self, m): pass
    def error(self, m): pass


def _opciones(**mas):
    import tempfile
    tmp = os.path.join(tempfile.gettempdir(), "catode-ytdlp")
    os.makedirs(tmp, exist_ok=True)
    # «paths»: yt-dlp prueba los formatos HLS bajando un trocito a un archivo; sin esto lo hacía en la carpeta de trabajo
    # (C:\Windows\System32 si la abre una tarea) y fallaba con «Permission denied» (02/10/2026)
    o = {"quiet": True, "no_warnings": True, "skip_download": True, "noprogress": True, "logger": _Callado(),
         "paths": {"home": tmp, "temp": tmp}}
    if os.environ.get("CATODE_CACHE"):   # 18/10/2026: la caché de yt-dlp, dentro de la caché aislada de prueba
        o["cachedir"] = os.path.join(os.environ["CATODE_CACHE"], "yt-dlp")
    if node():
        o["js_runtimes"] = {"node": {"path": node()}}
    o.update(mas)
    return o


def _plano(url, n=None):
    o = _opciones(extract_flat="in_playlist")
    if n:
        o["playlistend"] = n
    with yt_dlp.YoutubeDL(o) as y:
        return y.extract_info(url, download=False) or {}


def _de_plano(e):
    vid = e.get("id", "")
    if e.get("ie_key") == "YoutubeTab" or str(e.get("url", "")).find("/channel/") >= 0 and len(vid) > 11:
        cid = e.get("channel_id") or vid
        return Elemento("CANAL", f"https://www.youtube.com/channel/{cid}", e.get("title") or e.get("channel") or "",
                        miniatura=_mejor(e.get("thumbnails")), detalle=(cifra(e.get("channel_follower_count")) + " suscriptores") if e.get("channel_follower_count") else "")
    if len(vid) != 11:
        return None
    cid = e.get("channel_id") or ""
    return Elemento("VIDEO", url_video(vid), e.get("title") or "", e.get("channel") or e.get("uploader") or "",
                    f"https://www.youtube.com/channel/{cid}" if cid else (e.get("channel_url") or ""),
                    miniatura(vid), int(e["duration"]) if e.get("duration") else -1,
                    (cifra(e.get("view_count")) + " visualizaciones") if e.get("view_count") else "")


def _mejor(imgs):
    imgs = [i for i in (imgs or []) if i.get("url")]
    if not imgs:
        return ""
    u = max(imgs, key=lambda i: (i.get("height") or 0) * (i.get("width") or 0)).get("url", "")
    return "https:" + u if u.startswith("//") else u


def buscar(q, n=40):
    """Vídeos y canales que encajen, con innertube (visualizaciones exactas, fecha y duración); si falla, con yt-dlp."""
    try:
        r = _buscar_innertube(q, n)
        if any(e.tipo == "VIDEO" for e in r):
            return r
        roto.apuntar_analisis("la búsqueda")   # 18/10/2026: innertube sin vídeos = YouTube ha cambiado la página
    except Exception as e:
        roto.apuntar_analisis("la búsqueda", e)
    return _buscar_ytdlp(q, n)


def _video_renderer(v):
    vid = v.get("videoId", "")
    dueno = v.get("ownerText") or v.get("longBylineText") or {}
    cid = md.buscar(dueno, "browseId") or ""
    vistas = _texto(v.get("viewCountText"))
    detalle = md.texto_vistas(vistas)
    if v.get("upcomingEventData"):   # 24/10/2026: estreno o directo que aún no ha empezado (ver programado)
        inicio = str(v["upcomingEventData"].get("startTime") or "")
        detalle = PROXIMAMENTE + (time.strftime(" · %d/%m/%y, %H:%M", time.localtime(int(inicio))) if inicio.isdigit() else "")
    return Elemento("VIDEO", url_video(vid), _texto(v.get("title")), _texto(dueno), f"https://www.youtube.com/channel/{cid}" if cid else "",
                    miniatura(vid), _segundos(_texto(v.get("lengthText"))), detalle,
                    md.fecha_relativa(_texto(v.get("publishedTimeText"))))


def _canal_renderer(c):
    cid = c.get("channelId", "")
    subs = next((t for t in (_texto(c.get("subscriberCountText")), _texto(c.get("videoCountText"))) if "suscriptor" in t), "")
    return Elemento("CANAL", f"https://www.youtube.com/channel/{cid}", _texto(c.get("title")),
                    miniatura=_mejor(c.get("thumbnail", {}).get("thumbnails")), detalle=subs.replace("\u00a0", " "))


def _buscar_innertube(q, n=40):
    with cf.ThreadPoolExecutor(2) as ex:
        fc = ex.submit(md.innertube, "search", {"query": q, "params": "EgIQAg=="})   # solo canales
        r = md.innertube("search", {"query": q})
        videos = [_video_renderer(v) for v in md.todos(r.get("contents", {}), "videoRenderer") if v.get("videoId")]
        tok = (md.buscar(r.get("contents", {}), "continuationCommand") or {}).get("token")
        if tok and len(videos) < n:
            try:
                m = md.innertube("search", {"continuation": tok})
                videos += [_video_renderer(v) for v in md.todos(m.get("onResponseReceivedCommands", []), "videoRenderer") if v.get("videoId")]
            except Exception:
                pass
        try:
            canales = [_canal_renderer(c) for c in md.todos(fc.result().get("contents", {}), "channelRenderer")][:3]
        except Exception:
            canales = []
    vistos, res = set(), []
    for e in canales + videos:
        if e.url not in vistos:
            vistos.add(e.url)
            res.append(e)
    return res[:n + 3]


def _buscar_ytdlp(q, n=40):
    """Vídeos (yt-dlp) y, aparte, los canales que encajen (filtro de canales de la búsqueda de YouTube)."""
    with cf.ThreadPoolExecutor(2) as ex:
        v = ex.submit(_plano, f"ytsearch{n}:{q}")
        c = ex.submit(_plano, "https://www.youtube.com/results?" + urllib.parse.urlencode({"search_query": q, "sp": "EgIQAg=="}), 4)
        canales = [x for x in (_de_plano(e) for e in (c.result().get("entries") or [])) if x and x.tipo == "CANAL"][:3]
        videos = [x for x in (_de_plano(e) for e in (v.result().get("entries") or [])) if x]
    vistos, r = set(), []
    for e in canales + videos:   # sin repetidos (un canal puede salir dos veces)
        if e.url not in vistos:
            vistos.add(e.url); r.append(e)
    return r


def sugerencias(q):
    try:
        u = "https://suggestqueries-clients6.youtube.com/complete/search?" + urllib.parse.urlencode(
            {"client": "youtube", "ds": "yt", "hl": "es", "gl": "es", "q": q})
        t = urllib.request.urlopen(urllib.request.Request(u, headers={"User-Agent": AGENTE}), timeout=5).read().decode("utf-8", "replace")
        datos = json.loads(t[t.index("(") + 1:t.rindex(")")])
        return [s[0] for s in datos[1]][:10]
    except Exception:
        return []


def canal(url):
    """La cabecera del canal y sus últimos vídeos (con visualizaciones, fecha y duración)."""
    cab, videos, _ = canal_completo(url)
    return cab, videos


def canal_completo(url, n=60):
    """(cabecera, vídeos, datos del canal) con innertube: nombre, avatar, banner, verificado, handle, suscriptores
    tal como los da YouTube, etiquetas y descripción; si falla, yt-dlp (sin esos datos)."""
    try:
        return _canal_innertube(url, n)
    except Exception as e:
        roto.apuntar_analisis("el canal", e)   # 18/10/2026: ¿YouTube ha cambiado la página del canal?
        cab, videos = _canal_ytdlp(url)
        return cab, videos, {"id": md.id_canal(cab.url) or md.id_canal(url), "nombre": cab.titulo, "avatar": cab.miniatura,
                             "suscriptores": cab.detalle, "banner": "", "verificado": "", "handle": "", "etiquetas": [],
                             "descripcion": "", "cabecera": None}


def _fuentes(o):
    """La imagen más grande de una lista de «sources» o «thumbnails»."""
    imgs = (o or {}).get("sources") or (o or {}).get("thumbnails") or []
    return _mejor(imgs)


def _canal_innertube(url, n=60):
    cid = md.resolver_canal(url)
    if not cid:
        raise ValueError("no encuentro el canal")
    r = md.innertube("browse", {"browseId": cid, "params": "EgZ2aWRlb3PyBgQKAjoA"})   # pestaña «Vídeos»
    cab_vm = md.buscar(r.get("header", {}), "pageHeaderViewModel") or {}
    meta = r.get("metadata", {}).get("channelMetadataRenderer", {})
    micro = r.get("microformat", {}).get("microformatDataRenderer", {})
    nombre = _texto(md.buscar(cab_vm.get("title", {}), "text")) or meta.get("title", "")
    filas = [[_texto(p.get("text")) for p in f.get("metadataParts", [])]
             for f in (md.buscar(cab_vm.get("metadata", {}), "metadataRows") or [])]
    partes = [p.replace("\u00a0", " ") for f in filas for p in f]
    subs = next((p for p in partes if "suscriptor" in p), "")
    imagenes = [str(x) for x in md.todos(cab_vm.get("title", {}), "imageName")]
    etiqueta_titulo = str(md.buscar(cab_vm.get("title", {}), "label") or "")
    verificado = ("canal oficial de artista" if "AUDIO_BADGE" in imagenes or "artista" in etiqueta_titulo
                  else "verificado" if any("CHECK" in x for x in imagenes) or "verificad" in etiqueta_titulo else "")
    avatar = _fuentes(md.buscar(cab_vm.get("image", {}), "image")) or _fuentes(meta.get("avatar"))
    info = {"id": cid, "nombre": nombre, "avatar": avatar, "banner": _fuentes(md.buscar(cab_vm.get("banner", {}), "image")),
            "verificado": verificado, "handle": next((p for p in partes if p.startswith("@")), ""), "suscriptores": subs,
            "videos": next((p for p in partes if "vídeo" in p), ""), "etiquetas": micro.get("tags", []),
            "descripcion": meta.get("description", ""), "cabecera": r.get("header")}
    base = f"https://www.youtube.com/channel/{cid}"
    cab = Elemento("CANAL", base, nombre, miniatura=avatar, detalle=subs)
    videos = [x for x in (_lockup(l, nombre, base) for l in md.todos(r.get("contents", {}), "lockupViewModel")) if x]
    videos += [x for x in (_video_renderer(v) for v in md.todos(r.get("contents", {}), "videoRenderer")) if x]
    # 31/10/2026 (el autor: «estás publicando vídeos repetidos en YouTube»): su canal salía con cada vídeo DOS veces. La
    # página siguiente se tomaba del primer continuationCommand de la respuesta, y en un canal de menos de 30 vídeos el
    # único que hay es el del botón de orden «Más recientes» (cabecera de la rejilla): pedirlo devolvía los mismos vídeos.
    # La página siguiente de verdad es la de continuationItemRenderer; y además nunca entra un vídeo que ya esté.
    tok = next(((md.buscar(c, "continuationCommand") or {}).get("token")
                for c in md.todos(r.get("contents", {}), "continuationItemRenderer")), None)
    if tok and len(videos) < n:
        try:
            m = md.innertube("browse", {"continuation": tok})
            videos += [x for x in (_lockup(l, nombre, base) for l in md.todos(m.get("onResponseReceivedActions", []), "lockupViewModel")) if x]
        except Exception:
            pass
    vistos = set()
    videos = [v for v in videos if not (v.url in vistos or vistos.add(v.url))]
    for v in videos:
        v.autor, v.autorUrl = v.autor or nombre, v.autorUrl or base
    if not videos and not nombre:
        raise ValueError("canal vacío")
    return cab, videos[:n], info


def _canal_ytdlp(url):
    base = url.rstrip("/")
    r = _plano(base + "/videos", 60)
    cab = Elemento("CANAL", base, r.get("channel") or r.get("title") or "", miniatura=_mejor(
        [t for t in (r.get("thumbnails") or []) if "avatar" in str(t.get("id", ""))] or r.get("thumbnails")),
        detalle=(cifra(r.get("channel_follower_count")) + " suscriptores") if r.get("channel_follower_count") else "")
    videos = [x for x in (_de_plano(e) for e in (r.get("entries") or [])) if x and x.tipo == "VIDEO"]
    for v in videos:
        v.autor, v.autorUrl = v.autor or cab.titulo, v.autorUrl or base
    return cab, videos


def lista(url):
    r = _plano(url, 300)
    return r.get("title") or "", [x for x in (_de_plano(e) for e in (r.get("entries") or [])) if x and x.tipo == "VIDEO"]


# ---- innertube: la ficha y los relacionados (las recomendaciones de YouTube para ese vídeo) ----
def _innertube(endpoint, cuerpo):
    datos = {"context": {"client": {"clientName": "WEB", "clientVersion": "2.20250930.01.00", "hl": "es", "gl": "ES"}}}
    datos.update(cuerpo)
    req = urllib.request.Request(f"https://www.youtube.com/youtubei/v1/{endpoint}?prettyPrint=false", json.dumps(datos).encode(),
                                 {"Content-Type": "application/json", "User-Agent": AGENTE, "Origin": "https://www.youtube.com"})
    return json.loads(urllib.request.urlopen(req, timeout=10).read())


def _texto(t):
    if not t:
        return ""
    if isinstance(t, str):
        return t
    if "simpleText" in t:
        return t["simpleText"]
    if "content" in t:
        return t["content"]
    return "".join(r.get("text", "") for r in t.get("runs", []))


def _buscar_claves(o, clave):
    """Todos los diccionarios que cuelgan de «clave» en cualquier sitio del árbol."""
    if isinstance(o, dict):
        for k, v in o.items():
            if k == clave:
                yield v
            yield from _buscar_claves(v, clave)
    elif isinstance(o, list):
        for v in o:
            yield from _buscar_claves(v, clave)


# 28/10/2026 · canales vistos con la insignia de verificado (YouTube la da a partir de 100 000 suscriptores) en los
# relacionados y en las pestañas de los canales: descubrir.py los aparta del Inicio y de Explorar (lo popular de canales que
# no sigues) sin pedir el tamaño de cada canal. Los «canales oficiales de artista» (otra insignia) no cuentan.
VERIFICADOS = set()


def _relacionado(r):
    if "compactVideoRenderer" in r:
        c = r["compactVideoRenderer"]
        vid = c.get("videoId", "")
        canal_id = next(_buscar_claves(c.get("longBylineText", {}), "browseId"), "")
        if canal_id and any(str(b.get("style", "")) == "BADGE_STYLE_TYPE_VERIFIED" for b in _buscar_claves(c.get("ownerBadges", []), "metadataBadgeRenderer")):
            VERIFICADOS.add(f"https://www.youtube.com/channel/{canal_id}")
        return Elemento("VIDEO", url_video(vid), _texto(c.get("title")), _texto(c.get("longBylineText")),
                        f"https://www.youtube.com/channel/{canal_id}" if canal_id else "", miniatura(vid),
                        _segundos(_texto(c.get("lengthText"))),
                        PROXIMAMENTE if c.get("upcomingEventData") else md.texto_vistas(_texto(c.get("shortViewCountText"))),
                        md.fecha_relativa(_texto(c.get("publishedTimeText"))))
    if "lockupViewModel" in r:
        return _lockup(r["lockupViewModel"])
    return None


def _lockup(c, autor="", autor_url=""):
    """Un vídeo en el formato nuevo de YouTube (relacionados, pestaña de vídeos de un canal): las visualizaciones
    («207 M»), la fecha («hace 16 a») y la duración salen de sus filas de metadatos y de la etiqueta de la miniatura."""
    if c.get("contentType") != "LOCKUP_CONTENT_TYPE_VIDEO":
        return None
    vid = c.get("contentId", "")
    meta = c.get("metadata", {}).get("lockupMetadataViewModel", {})
    partes = [_texto(p.get("text")).replace("\u00a0", " ") for fila in meta.get("metadata", {}).get("contentMetadataViewModel", {}).get("metadataRows", [])
              for p in fila.get("metadataParts", [])]
    vistas = next((p for p in partes if md.es_vistas(p)), "")
    fecha_txt = next((p for p in partes if md.fecha_relativa(p)), "")
    otros = [p for p in partes if p and p != vistas and p != fecha_txt]
    dur = next((x.get("text", "") for x in _buscar_claves(c.get("contentImage", {}), "thumbnailBadgeViewModel")
                if re.fullmatch(r"\d+(:\d\d)+", str(x.get("text", "")))), "")
    canal_id = next((x for x in _buscar_claves(meta, "browseId") if str(x).startswith("UC")), "")
    if canal_id and not autor_url:   # la insignia de verificado va en la primera fila (el nombre del canal)
        filas = meta.get("metadata", {}).get("contentMetadataViewModel", {}).get("metadataRows", [])
        if filas and any(str(x) == "CHECK_CIRCLE_FILLED" for x in _buscar_claves(filas[0], "imageName")):
            VERIFICADOS.add(f"https://www.youtube.com/channel/{canal_id}")
    insignias = [str(x.get("text", "")) for x in _buscar_claves(c.get("contentImage", {}), "thumbnailBadgeViewModel")]
    en_directo = any("DIRECTO" in str(x.get("text", "")).upper() or "LIVE" in str(x.get("badgeStyle", ""))
                     for x in _buscar_claves(c.get("contentImage", {}), "thumbnailBadgeViewModel"))
    # 24/10/2026: estreno o directo que aún no ha empezado (ver programado): «Próximamente» y «Fecha de estreno: …»
    cuando = next((p for p in otros if _PROGRAMADO.search(p)), "")
    proximo = bool(cuando) or any(x.strip().lower() in ("próximamente", "upcoming") for x in insignias)
    if cuando:
        otros = [p for p in otros if p != cuando]
    detalle = " · ".join(x for x in (PROXIMAMENTE, cuando) if x) if proximo else \
        " · ".join(x for x in (md.texto_vistas(vistas), "en directo" if en_directo and not dur else "") if x)
    return Elemento("VIDEO", url_video(vid), _texto(meta.get("title")), autor or (otros[0] if otros else ""),
                    autor_url or (f"https://www.youtube.com/channel/{canal_id}" if canal_id else ""), miniatura(vid), _segundos(dur),
                    detalle, md.fecha_relativa(fecha_txt))


def _segundos(t):
    try:
        n = [int(x) for x in t.strip().split(":")]
        return sum(v * 60 ** i for i, v in enumerate(reversed(n)))
    except Exception:
        return -1


def ficha(url):
    """Título, canal, descripción (con enlaces), visualizaciones exactas, fecha y relacionados de un vídeo (sin pedir los
    formatos: eso lo hace mpv). La respuesta queda guardada unos minutos para la sección «Datos» (metadatos.extra)."""
    vid = id_video(url)
    r = md.siguiente(vid)
    prim = next(_buscar_claves(r, "videoPrimaryInfoRenderer"), {})
    sec = next(_buscar_claves(r, "videoSecondaryInfoRenderer"), {})
    dueno = sec.get("owner", {}).get("videoOwnerRenderer", {})
    canal_id = next(_buscar_claves(dueno, "browseId"), "")
    vistas = _texto(prim.get("viewCount", {}).get("videoViewCountRenderer", {}).get("viewCount"))
    resultados = next(_buscar_claves(r, "secondaryResults"), {})
    items = resultados.get("secondaryResults", {}).get("results", []) if isinstance(resultados, dict) else []
    # 24/10/2026: sin estrenos que aún no han empezado (la reproducción automática se paraba en ellos)
    rel = [x for x in (_relacionado(i) for i in items) if x and x.url != url_video(vid) and not programado(x)]
    vrc = prim.get("viewCount", {}).get("videoViewCountRenderer", {})
    exactas = md.numero(_texto(vrc.get("viewCount"))) if not vrc.get("isLive") else -1
    return {"url": url_video(vid), "id": vid, "titulo": _texto(prim.get("title")), "autor": _texto(dueno.get("title")),
            "autorUrl": f"https://www.youtube.com/channel/{canal_id}" if canal_id else "",
            "descripcion": _texto(sec.get("attributedDescription")) or _texto(sec.get("description")),
            "descripcionHtml": md.descripcion_html(sec.get("attributedDescription") or sec.get("description")),
            "vistas": vistas, "vistasExactas": exactas, "textoFecha": _texto(prim.get("dateText")),
            "fechaRelativa": _texto(prim.get("relativeDateText")),
            "canalSuscriptores": _texto(dueno.get("subscriberCountText")).replace("\u00a0", " "),
            "miniatura": miniatura(vid), "relacionados": rel,
            # 1.0.0: el avatar del canal y los capítulos (para la página del vídeo, como en YouTube)
            "avatar": _mejor(dueno.get("thumbnail", {}).get("thumbnails")), "capitulos": _seguro(md.capitulos, r)}


def relacionados(url):
    try:
        return ficha(url)["relacionados"]
    except Exception:
        return []


_CONEXIONES = threading.local()


def _rss_crudo(cid):
    """El RSS de un canal por una conexión que se reutiliza (una por hilo): 28/10/2026, mirar 149 canales sin abrir 149
    conexiones cifradas seguidas (descubrir.py lo hace en cada visita a Suscripciones)."""
    import http.client
    ruta = f"/feeds/videos.xml?channel_id={cid}"
    for intento in range(2):
        con = getattr(_CONEXIONES, "yt", None)
        if con is None:
            con = _CONEXIONES.yt = http.client.HTTPSConnection("www.youtube.com", timeout=10)
        try:
            con.request("GET", ruta, headers={"User-Agent": AGENTE, "Accept-Encoding": "identity"})
            r = con.getresponse()
            cuerpo = r.read()
            if r.status != 200:
                raise urllib.error.HTTPError(f"https://www.youtube.com{ruta}", r.status, r.reason, r.headers, None)
            return cuerpo
        except urllib.error.HTTPError:
            raise
        except Exception:   # conexión cerrada por el otro lado: otra nueva, una vez
            try:
                con.close()
            except Exception:   # noqa: BLE001
                pass
            _CONEXIONES.yt = None
            if intento:
                raise


def rss_canal(url, titulo="", por_canal=15):
    """Los últimos vídeos de un canal por su RSS (rápido y sin pasar por la web de YouTube); [] si no es un canal UC…"""
    cid = url.split("/channel/")[-1].split("/")[0].split("?")[0]
    if not cid.startswith("UC"):
        return []
    t = _rss_crudo(cid)
    ns = {"a": "http://www.w3.org/2005/Atom", "yt": "http://www.youtube.com/xml/schemas/2015", "media": "http://search.yahoo.com/mrss/"}
    r = []
    for e in ET.fromstring(t).findall("a:entry", ns)[:por_canal]:
        vid = e.findtext("yt:videoId", "", ns)
        pub = e.findtext("a:published", "", ns)
        ms = md.fecha_iso(pub)   # la hora del RSS va en UTC («+00:00»)
        corto = "/shorts/" in (e.find("a:link", ns).get("href", "") if e.find("a:link", ns) is not None else "")
        est = e.find(".//media:statistics", ns)
        vistas = int(est.get("views", "-1")) if est is not None and est.get("views", "").isdigit() else -1
        r.append(Elemento("VIDEO", url_video(vid), e.findtext("a:title", "", ns), titulo, url, miniatura(vid), -1,
                          " · ".join(x for x in ("Short" if corto else "", f"{md.miles(vistas)} visualizaciones" if vistas >= 0 else "") if x), ms))
    return r


def novedades(canales, por_canal=15, n=300, hilos=4):
    """15/10/2026: 4 a la vez (antes 8) y, si el RSS falla, como mucho 30 canales por la página del canal en cada llamada
    (con el RSS caído eran 150-200 páginas seguidas, y YouTube marcaba la IP de casa como robot)."""
    respaldo = [30]
    cerrojo = threading.Lock()
    rotos = []   # 18/10/2026: fallos de la página del canal (roto.py, una vez por llamada)
    def rss(c):
        return rss_canal(c.url, c.titulo, por_canal)
    def uno(c):
        # YouTube a veces responde 404 al RSS de un canal (o de todos, durante horas): entonces, por la página del canal
        try:
            r = rss(c)
            if r:
                return r
        except Exception:
            pass
        with cerrojo:
            if respaldo[0] <= 0:
                return []
            respaldo[0] -= 1
        try:
            _, videos, _ = _canal_innertube(c.url, por_canal)
            for v in videos:
                v.autor, v.autorUrl = v.autor or c.titulo, c.url
            return videos[:por_canal]
        except Exception as e:
            if roto.clasificar(e) == "roto":
                rotos.append(e)
            return []
    with cf.ThreadPoolExecutor(hilos) as ex:
        todos = [x for l in ex.map(uno, canales) for x in l]
    if rotos:
        roto.apuntar_analisis("las novedades", rotos[0])
    return sorted(todos, key=lambda e: -e.fecha)[:n]


def _seguro(f, *a):
    try:
        return f(*a)
    except Exception:
        return []


def para_ti(historial, suscripciones, n=60):
    """Recomendaciones de YouTube calculadas sobre lo que ha visto el autor: los relacionados de sus últimos vídeos,
    juntos, sin lo ya visto; sube lo que se repite y lo de sus canales."""
    semillas = [e for e in historial if e.tipo == "VIDEO"][:15]
    vistos = {id_video(e.url) for e in historial}
    canales = {s.url for s in suscripciones}
    puntos, elementos = {}, {}
    errores = []

    def rel_de(u):   # 18/10/2026: como relacionados(), pero guarda el fallo (si fallan todos, roto.py lo cuenta)
        try:
            return ficha(u)["relacionados"]
        except Exception as e:
            errores.append(e)
            return []
    with cf.ThreadPoolExecutor(6) as ex:
        for i, rel in enumerate(ex.map(rel_de, [s.url for s in semillas])):
            for j, e in enumerate(rel[:20]):
                vid = id_video(e.url)
                if vid in vistos:
                    continue
                puntos[vid] = puntos.get(vid, 0) + (1.0 / (1 + i * 0.15)) * (1.0 / (1 + j * 0.08)) + (0.5 if e.autorUrl in canales else 0)
                elementos.setdefault(vid, e)
    if len(semillas) >= 2 and len(errores) == len(semillas):
        roto.apuntar_analisis("el inicio", next((e for e in errores if roto.clasificar(e) == "roto"), errores[0]))
    return [elementos[v] for v in sorted(puntos, key=lambda v: -puntos[v])[:n]]


# ================================================================ 1.0.0 (02/10/2026): lo que faltaba para igualar a YouTube
FILTROS = {
    "tipo": {"Vídeos": 1, "Canales": 2, "Listas": 3, "Películas": 4},
    "fecha": {"Última hora": 1, "Hoy": 2, "Esta semana": 3, "Este mes": 4, "Este año": 5},
    "duracion": {"Menos de 4 min": 1, "Más de 20 min": 2, "4-20 min": 3},
    "orden": {"Relevancia": 0, "Fecha de subida": 2, "Visualizaciones": 3, "Valoración": 1},
}


def _pb_varint(n):
    out = bytearray()
    while True:
        b = n & 0x7F
        n >>= 7
        out.append(b | (0x80 if n else 0))
        if not n:
            return bytes(out)


def parametros_busqueda(filtros):
    """Los filtros de la búsqueda de YouTube («sp»): protobuf {1: orden, 2: {1: fecha, 2: tipo, 3: duración}}."""
    import base64
    f = filtros or {}
    interno = b""
    for campo, clave in ((1, "fecha"), (2, "tipo"), (3, "duracion")):
        v = FILTROS[clave].get(f.get(clave, ""), 0)
        if v:
            interno += bytes([campo << 3]) + _pb_varint(v)
    total = b""
    orden = FILTROS["orden"].get(f.get("orden", ""), 0)
    if orden:
        total += bytes([1 << 3]) + _pb_varint(orden)
    if interno:
        total += bytes([(2 << 3) | 2]) + _pb_varint(len(interno)) + interno
    return base64.b64encode(total).decode() if total else ""


def _lista_renderer(l):
    """Una lista de reproducción en los resultados (lockupViewModel de tipo lista)."""
    lid = l.get("contentId", "")
    md_ = (l.get("metadata", {}) or {}).get("lockupMetadataViewModel", {})
    titulo = (md_.get("title") or {}).get("content", "")
    img = md.buscar(l.get("contentImage", {}), "sources") or [{}]
    n = next((b.get("text") for b in md.todos(l.get("contentImage", {}), "thumbnailBadgeViewModel")), "")
    return Elemento("LISTA", f"https://www.youtube.com/playlist?list={lid}", titulo, miniatura=(img[-1] or {}).get("url", ""), detalle=n)


def buscar_filtrada(q, filtros=None, continuacion=None):
    """Búsqueda con filtros; devuelve (elementos, token de la página siguiente)."""
    try:
        r, tok = _buscar_filtrada(q, filtros, continuacion)
    except Exception as e:
        roto.apuntar_analisis("la búsqueda", e)   # 18/10/2026: ¿YouTube ha cambiado la página?
        raise
    return r, tok


def _buscar_filtrada(q, filtros=None, continuacion=None):
    if continuacion:
        r = md.innertube("search", {"continuation": continuacion})
        raiz = r.get("onResponseReceivedCommands", [])
    else:
        cuerpo = {"query": q}
        sp = parametros_busqueda(filtros)
        if sp:
            cuerpo["params"] = sp
        r = md.innertube("search", cuerpo)
        raiz = r.get("contents", {})
    res = []
    for o in md.todos(raiz, "itemSectionRenderer"):
        for item in o.get("contents", []):
            if "videoRenderer" in item and item["videoRenderer"].get("videoId"):
                res.append(_video_renderer(item["videoRenderer"]))
            elif "channelRenderer" in item:
                res.append(_canal_renderer(item["channelRenderer"]))
            elif "lockupViewModel" in item and item["lockupViewModel"].get("contentId"):
                l = item["lockupViewModel"]
                try:   # vídeo, o lista / mix / pódcast (todas se abren como lista)
                    res.append(_lockup(l) if l.get("contentType") == "LOCKUP_CONTENT_TYPE_VIDEO" else _lista_renderer(l))
                except Exception:
                    pass
    tok = (md.buscar(raiz, "continuationCommand") or {}).get("token")
    res = [e for e in res if e is not None and e.url]
    if not res and not continuacion and md.buscar(raiz, "backgroundPromoRenderer") is None:
        roto.apuntar_analisis("la búsqueda")   # sin nada y sin el «no hay resultados» de YouTube: no se entiende la página
    return res, tok


def comentarios(url, continuacion=None):
    """Los comentarios de un vídeo, como en YouTube (los más destacados primero): ([{autor, foto, texto, megusta,
    cuando, respuestas}], token de la página siguiente)."""
    if not continuacion:
        n = md.innertube("next", {"videoId": id_video(url)})
        continuacion = None
        for s in md.todos(n, "itemSectionRenderer"):
            if s.get("sectionIdentifier") == "comment-item-section":
                continuacion = (md.buscar(s, "continuationCommand") or {}).get("token")
        if not continuacion:
            return [], None
    r = md.innertube("next", {"continuation": continuacion})
    datos = {}
    for m in md.todos(r.get("frameworkUpdates", {}), "commentEntityPayload"):
        p, a, t = m.get("properties", {}), m.get("author", {}), m.get("toolbar", {})
        datos[p.get("commentId")] = {"autor": a.get("displayName", ""), "foto": a.get("avatarThumbnailUrl", ""),
                                     "texto": (p.get("content") or {}).get("content", ""), "megusta": t.get("likeCountNotliked", ""),
                                     "cuando": p.get("publishedTime", ""), "respuestas": t.get("replyCount", ""),
                                     "fijado": False, "autorCanal": a.get("channelId", "")}
    orden = [x.get("commentId") for x in md.todos(r, "commentViewModel")]
    lista = [datos[c] for c in orden if c in datos] or list(datos.values())
    sig = None
    for c in md.todos(r, "continuationItemRenderer"):
        sig = (md.buscar(c, "continuationCommand") or {}).get("token") or sig
    return lista, sig


EXPLORAR = {   # los canales de tema de YouTube: lo que más se ve de cada cosa
    "Música": "UC-9-kyTW8ZkZNDHQJ6FgpwQ", "Videojuegos": "UCOpNcN46UbXVtpKMrmU4Abg", "Noticias": "UCYfdidRxbB8Qhf0Nx7ioOYw",
    "Deportes": "UCEgdi0XIXXZ-qJOFPf4JSKw", "Aprendizaje": "UCtFRv9O2AHqOZjjynzrv-xg", "Moda y belleza": "UCrpQ4p1Ql_hG8rKXIKM1MOQ",
}


def explorar(categoria):
    cid = EXPLORAR.get(categoria)
    if not cid:
        return []
    try:
        r = [e for e in canal_completo(f"https://www.youtube.com/channel/{cid}")[1] if e.tipo in ("VIDEO", "LISTA")]
        if r:
            return r
    except Exception:
        pass
    # los canales de tema no siempre dan su portada: lo más visto de esta semana en esa categoría, en España
    return [e for e in buscar_filtrada(categoria, {"tipo": "Vídeos", "fecha": "Esta semana", "orden": "Visualizaciones"})[0] if e.tipo == "VIDEO"]


def numero_suscriptores(t):
    """«1,36 M de suscriptores», «159 K suscriptores», «12,3 mil suscriptores», «1.234 suscriptores» → número (o -1)."""
    t = (t or "").lower().replace("\xa0", " ")
    m = re.search(r"([\d.,]+)\s*(mill|mil|m|k)?\b", t)
    if not m or "suscript" not in t:
        return -1
    num, suf = m.group(1), m.group(2)
    try:
        if suf:
            return int(float(num.replace(".", "").replace(",", ".") if "," in num else num) * {"mill": 1e6, "m": 1e6, "mil": 1e3, "k": 1e3}[suf])
        return int(num.replace(".", "").replace(",", ""))
    except ValueError:
        return -1


def destacados(url):
    """28/10/2026 · Los canales que recomienda el propio creador: [(url, nombre, suscriptores o -1, avatar)]. La pestaña
    «Canales» ya no existe (pedirla devuelve la portada): están en un estante de la portada del canal («Ecosistema de…»),
    con sus suscriptores, así que lo grande se descarta sin pedir nada más. Sale en descubrir.py (Explorar)."""
    cid = md.resolver_canal(url)
    if not cid:
        return []
    r = md.innertube("browse", {"browseId": cid})
    salida, vistos = [], {cid}
    for g in list(md.todos(r, "gridChannelRenderer")) + list(md.todos(r, "channelRenderer")):
        c = g.get("channelId", "") if isinstance(g, dict) else ""
        if not c.startswith("UC") or c in vistos:
            continue
        vistos.add(c)
        salida.append((f"https://www.youtube.com/channel/{c}", _texto(g.get("title")).strip(),
                       numero_suscriptores(_texto(g.get("subscriberCountText"))), _mejor(g.get("thumbnail", {}).get("thumbnails"))))
    return salida


def patrocinios(url):
    """Los tramos que la comunidad de SponsorBlock marca (patrocinio, autopromoción, «suscríbete», intro, final…).
    Se pide por los 4 primeros caracteres del hash del vídeo: SponsorBlock no sabe qué vídeo es."""
    import hashlib
    vid = id_video(url)
    pref = hashlib.sha256(vid.encode()).hexdigest()[:4]
    # 19/10/2026 «los vídeos siguen interrumpiéndose a veces y pasa a otro»: sin «outro» (el final del vídeo): saltarlo es
    # llegar al final y que empiece otro vídeo mientras el youtuber aún habla
    cats = urllib.parse.quote(json.dumps(["sponsor", "selfpromo", "interaction", "intro", "music_offtopic"]))
    try:
        t = urllib.request.urlopen(urllib.request.Request(f"https://sponsor.ajay.app/api/skipSegments/{pref}?categories={cats}",
                                                          headers={"User-Agent": AGENTE}), timeout=6).read()
        for v in json.loads(t):
            if v.get("videoID") == vid:
                return [(s["segment"][0], s["segment"][1], s.get("category", "")) for s in v.get("segments", [])]
    except Exception:
        pass
    return []


def carpeta_descargas():
    if os.name == "nt":
        d = os.path.join(os.environ.get("USERPROFILE", os.path.expanduser("~")), "Videos", "Cat-ode")
    else:
        d = os.path.join(os.path.expanduser("~"), "Vídeos", "Cat-ode")
    os.makedirs(d, exist_ok=True)
    return d


def ffmpeg():
    """La ruta de ffmpeg: el del sistema o el que trae imageio-ffmpeg. None si no hay ninguno."""
    import shutil
    r = shutil.which("ffmpeg")
    if r:
        return r
    try:
        import imageio_ffmpeg
        r = imageio_ffmpeg.get_ffmpeg_exe()
        return r if r and os.path.exists(r) else None
    except Exception:   # noqa: BLE001
        return None


def preparar_ffmpeg(progreso=None):
    """Si falta ffmpeg, se instala en el momento (la primera descarga tarda un poco más) y se devuelve su ruta."""
    r = ffmpeg()
    if r:
        return r
    import subprocess
    import sys
    if progreso:
        progreso(0, "preparando las descargas (una sola vez)…")
    subprocess.run([sys.executable, "-m", "pip", "install", "-q", "--disable-pip-version-check", "imageio-ffmpeg"],
                   capture_output=True, timeout=900, creationflags=0x08000000 if os.name == "nt" else 0)
    import importlib
    importlib.invalidate_caches()
    return ffmpeg()


def descargar(e, solo_audio=False, alto=720, progreso=None):
    """Descarga un vídeo (o solo su sonido) a la carpeta de Cat-ode. progreso(fraccion, texto). Devuelve la ruta."""
    destino = carpeta_descargas()
    ruta = {}

    def gancho(d):
        if d.get("status") == "downloading" and progreso:
            total = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
            progreso((d.get("downloaded_bytes", 0) / total) if total else 0, d.get("_speed_str", "").strip())
        elif d.get("status") == "finished":
            ruta["f"] = d.get("filename")
    fmt = "ba[ext=m4a]/ba" if solo_audio else f"bv*[height<={alto}][vcodec^=avc1]+ba[ext=m4a]/bv*[height<={alto}][ext=mp4]+ba[ext=m4a]/b[height<={alto}][ext=mp4]/b[height<={alto}]/b"
    opciones = _opciones(format=fmt, outtmpl=os.path.join(destino, "%(title).150B [%(id)s].%(ext)s"), progress_hooks=[gancho],
                         merge_output_format="mp4", noplaylist=True, quiet=True, no_warnings=True)
    opciones.pop("extract_flat", None)
    opciones["skip_download"] = False
    ff = preparar_ffmpeg(progreso)
    if ff:
        opciones["ffmpeg_location"] = ff
    elif not solo_audio:   # sin ffmpeg no se pueden unir imagen y sonido: el formato que ya viene junto (hasta 360p)
        opciones["format"] = f"b[height<={alto}][ext=mp4]/b[ext=mp4]/b"
    with yt_dlp.YoutubeDL(opciones) as y:
        info = y.extract_info(e.url, download=True)
        f = y.prepare_filename(info)
    if not solo_audio and not os.path.exists(f):
        f = os.path.splitext(f)[0] + ".mp4"
    return f if os.path.exists(f) else ruta.get("f", f)


def descargados():
    """Lo descargado, lo último primero: [(ruta, título, id)]."""
    d = carpeta_descargas()
    r = []
    for n in os.listdir(d):
        m = re.match(r"(.*) \[([\w-]{11})\]\.(mp4|m4a|webm|mkv|mp3|opus)$", n)
        if m:
            r.append((os.path.join(d, n), m.group(1), m.group(2)))
    return sorted(r, key=lambda x: -os.path.getmtime(x[0]))


def canal_pestana(url, pestana, n=60):
    """Las pestañas del canal que no son «Vídeos»: shorts, streams (directos) o playlists (listas)."""
    base = url.rstrip("/")
    try:
        r = _plano(f"{base}/{pestana}", n)
    except Exception as e:  # noqa: BLE001
        if "does not have" in str(e):   # el canal no tiene esa pestaña: no es un error
            return []
        raise
    salida = []
    for e in r.get("entries") or []:
        if pestana == "playlists":
            pid = e.get("id") or ""
            if pid:
                salida.append(Elemento("LISTA", f"https://www.youtube.com/playlist?list={pid}", e.get("title") or "",
                                       r.get("channel") or "", base, _mejor(e.get("thumbnails")),
                                       detalle=(f"{e['playlist_count']} vídeos" if e.get("playlist_count") else "")))
            continue
        x = _de_plano(e)
        if x and x.tipo == "VIDEO":
            x.autor, x.autorUrl = x.autor or r.get("channel") or "", x.autorUrl or base
            salida.append(x)
    return salida


def shorts(canales, por_canal=6, n_canales=16):
    """Shorts recientes de los canales que sigue el autor (los de más canales a la vez, mezclados)."""
    import random
    elegidos = random.sample(list(canales), min(n_canales, len(canales)))
    salida = []
    with cf.ThreadPoolExecutor(6) as ex:
        for lote in ex.map(lambda c: _seguro(canal_pestana, c.url, "shorts", por_canal) or [], elegidos):
            salida.extend(lote)
    random.shuffle(salida)
    return salida
