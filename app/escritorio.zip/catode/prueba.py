"""Cat-ode escritorio · prueba de funcionamiento sin mirar la pantalla (catode.pyw --prueba). Recorre las secciones y
las funciones, y escribe una línea «OK» o «FALLA» por cada una; al final, el resumen. Si existe ~/.local/bin/progreso,
alimenta su barra. Sale con código 0 si todo va bien."""
import json
import os
import shutil
import subprocess
import sys
import time

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QCursor
from PySide6.QtWidgets import QApplication, QPushButton, QLabel

from . import motor

VIDEO_CAPITULOS = os.environ.get("CATODE_VIDEO_PRUEBA") or "https://www.youtube.com/watch?v=UtTMIPSc7kE"   # «Antigua Roma - Toda su historia»: 37 capítulos (comprobado el 02/10/2026)


def captura_ventana_windows(hwnd, ruta, mandos=None):
    """Windows: la ventana de Cat-ode tal como se ve (con el vídeo de mpv, los mandos y la barra de título), y solo ella."""
    import ctypes
    from ctypes import wintypes
    from PySide6.QtGui import QImage
    u32, g32 = ctypes.windll.user32, ctypes.windll.gdi32
    r = wintypes.RECT(); ctypes.windll.dwmapi.DwmGetWindowAttribute(hwnd, 9, ctypes.byref(r), ctypes.sizeof(r))   # con el marco
    w, h = r.right - r.left, r.bottom - r.top
    pantalla = u32.GetDC(0); dc = g32.CreateCompatibleDC(pantalla); bmp = g32.CreateCompatibleBitmap(pantalla, w, h)
    g32.SelectObject(dc, bmp)
    u32.PrintWindow(hwnd, dc, 2)   # solo esta ventana (aunque otra la tape), con el contenido de DirectX de mpv
    class BMI(ctypes.Structure):
        _fields_ = [("biSize", ctypes.c_uint32), ("biWidth", ctypes.c_int32), ("biHeight", ctypes.c_int32), ("biPlanes", ctypes.c_uint16),
                    ("biBitCount", ctypes.c_uint16), ("biCompression", ctypes.c_uint32), ("biSizeImage", ctypes.c_uint32),
                    ("x", ctypes.c_int32), ("y", ctypes.c_int32), ("u", ctypes.c_uint32), ("i", ctypes.c_uint32)]
    bi = BMI(); bi.biSize = ctypes.sizeof(BMI); bi.biWidth, bi.biHeight, bi.biPlanes, bi.biBitCount = w, -h, 1, 32
    datos = ctypes.create_string_buffer(w * h * 4)
    g32.GetDIBits(dc, bmp, 0, h, datos, ctypes.byref(bi), 0)
    img = QImage(datos.raw, w, h, QImage.Format_RGB32).copy()
    if mandos is not None and mandos.isVisible():   # los mandos son otra ventana (transparente): encima, en su sitio
        from PySide6.QtGui import QPainter
        p = QPainter(img); g = mandos.geometry()
        p.drawPixmap(g.x() - r.left, g.y() - r.top, mandos.grab()); p.end()
    img.save(ruta)
    g32.DeleteObject(bmp); g32.DeleteDC(dc); u32.ReleaseDC(0, pantalla)


def empezar(app, v):
    pasos, resultados = [], []
    barra = shutil.which("progreso") or os.path.expanduser("~/.local/bin/progreso")

    def avance():
        if os.path.exists(barra):
            subprocess.run([barra, "set", "catode-prueba", "Prueba de Cat-ode escritorio", str(len(resultados)),
                            str(len(pasos)), "pasos"], env={**os.environ, "PROGRESO_PID": str(os.getpid())},
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    capturas = os.environ.get("CATODE_CAPTURAS", "")   # carpeta: guarda una imagen de la ventana tras cada paso

    def anotar(nombre, bien, detalle=""):
        if capturas:
            os.makedirs(capturas, exist_ok=True)
            v.grab().save(os.path.join(capturas, f"{len(resultados) + 1:02d}.png"))
        resultados.append((nombre, bien))
        print(f"{'OK    ' if bien else 'FALLA '} {nombre:34s} {detalle}", flush=True)
        avance()

    def esperar(cond, segundos, siguiente):
        fin = time.time() + segundos

        def mirar():
            try:
                hecho = cond()
            except Exception:
                hecho = False
            if hecho or time.time() > fin:
                siguiente(bool(hecho))
            else:
                QTimer.singleShot(400, mirar)
        mirar()

    def tarjetas():
        r = v.pag.rejilla
        return len(r.widgets) if r.aviso.text() != "Cargando…" else 0

    def seccion(nombre, accion, minimo=1, segundos=40):
        def paso(seguir):
            accion()
            esperar(lambda: tarjetas() >= max(1, minimo) or (minimo == 0 and v.pag.rejilla.aviso.text() not in ("Cargando…", "")), segundos,
                    lambda ok: (anotar(nombre, ok, f"{tarjetas()} elementos · {v.pag.rejilla.aviso.text()[:60]}"), seguir()))
        pasos.append((nombre, paso))

    def paso_simple(nombre, accion, cond, segundos=30, detalle=lambda: ""):
        def paso(seguir):
            try:
                accion()
            except Exception as e:  # noqa: BLE001
                anotar(nombre, False, repr(e)[:120])
                return seguir()
            esperar(cond, segundos, lambda ok: (anotar(nombre, ok, detalle()), seguir()))
        pasos.append((nombre, paso))

    rep = v.rep
    rep.mpv.mute = True
    seccion("Inicio («Para ti»)", lambda: v.ir_seccion("inicio"), 12)
    sitio = {}

    def bajar_y_abrir():
        b = v.pag.rejilla.verticalScrollBar()
        for _ in range(4):   # baja como una persona: varias pantallas (y se cargan más tarjetas)
            b.setValue(b.maximum()); QApplication.processEvents(); time.sleep(0.3); QApplication.processEvents()
        b.setValue(int(b.maximum() * 0.7)); QApplication.processEvents()
        sitio["v"] = b.value()
        w = next(x for x in v.pag.rejilla.widgets if x.y() + x.height() > b.value() and getattr(x, "e", None) and x.e.tipo == "VIDEO")
        v.abrir(w.e)
    paso_simple("Inicio: bajar y abrir un vídeo", bajar_y_abrir, lambda: v.paginas.currentWidget() is v.video, 10,
                lambda: f"bajado a {sitio.get('v')}")
    paso_simple("Atrás: vuelve al mismo sitio del Inicio", v.volver,
                lambda: v.paginas.currentWidget() is v.pag and abs(v.pag.rejilla.verticalScrollBar().value() - sitio["v"]) < 40, 10,
                lambda: f"{sitio.get('v')} → {v.pag.rejilla.verticalScrollBar().value()}")
    # los temas los calcula el servidor (/app/parati.json): sin servidor (las pruebas van sin sincro.json) solo hay 3 fichas fijas
    # 03/10/2026: «Continuar viendo» al principio del Inicio (si hay vídeos a medias en los datos de la prueba)
    # 03/10/2026: vista previa al posar el ratón sobre una tarjeta (mpv aparte, sin sonido)
    def previa_entrar():
        t = next(x for x in v.pag.rejilla.widgets if x.isVisible() and getattr(x, "e", None) and x.e.tipo == "VIDEO")
        v.previa.probar(t)
    def previa_dentro():
        """23/10/2026: en Linux, ¿pinta mpv DENTRO de la miniatura? Con el contexto de Wayland abría una ventana suya aparte
        y esta prueba (posición y zona visible) salía bien igual. Dentro = la ventana X11 de la zona tiene una hija (la de mpv)."""
        if os.name == "nt" or not shutil.which("xwininfo"):
            return True
        r = subprocess.run(["xwininfo", "-children", "-id", str(int(v.previa.zona.winId()))], capture_output=True, text=True, timeout=5)
        return any(l.strip().split(" ")[0].isdigit() and int(l.strip().split(" ")[0]) > 0 for l in r.stdout.splitlines() if " child" in l)
    paso_simple("Vista previa: al posar el ratón, el vídeo se ve en la tarjeta", previa_entrar,
                lambda: v.previa.mpv is not None and v.previa.zona.isVisible() and (v.previa.mpv.time_pos or 0) > 0.5 and previa_dentro(), 30,
                lambda: f"pos {v.previa.mpv.time_pos if v.previa.mpv else None} · zona {v.previa.zona.width()}x{v.previa.zona.height()}"
                        f" · dentro de la miniatura {previa_dentro()}")
    foto = os.environ.get("CATODE_PRUEBA_CAPTURA", "")   # 23/10/2026: foto de la pantalla entera con la vista previa puesta
    if foto and shutil.which("captura_pantalla.py"):
        paso_simple("Vista previa: foto de la pantalla", lambda: subprocess.run(["captura_pantalla.py", foto], timeout=30),
                    lambda: os.path.exists(foto), 5)
    paso_simple("Vista previa: al salir se para y se esconde", v.previa.parar, lambda: not v.previa.zona.isVisible(), 3)
    paso_simple("Inicio: «Continuar viendo» primero (si hay vídeos a medias)", lambda: None,
                lambda: not v.datos.continuar_viendo(1) or any("Continuar viendo" in (getattr(w, "motivo", "") or "") for w in v.pag.rejilla.widgets[:8]), 10,
                lambda: f"{len(v.datos.continuar_viendo(8))} a medias · 1.ª tarjeta: {(getattr(v.pag.rejilla.widgets[0], 'motivo', '') if v.pag.rejilla.widgets else '')[:40]}")
    paso_simple("Inicio: fichas de tema", lambda: None, lambda: v.pag.chips.count() > 4 or (not v.datos.conf and v.pag.chips.count() - 1 == 3), 20,
                lambda: f"{v.pag.chips.count() - 1} fichas" + ("" if v.datos.conf else " (sin servidor: solo las fijas)"))
    seccion("Suscripciones (novedades)", lambda: v.ir_seccion("suscripciones"), 12, 90)
    # 03/10/2026: Shorts en vertical, uno a uno (antes cuadrícula)
    paso_simple("Shorts: en vertical, suena el primero", lambda: v.ir_seccion("shorts"),
                lambda: v.paginas.currentWidget() is v.pshorts and v.pshorts.zona is not None and v.rep.actual is not None and v.rep.pos > 1
                and v.pshorts.marco.width() < v.pshorts.marco.height(), 90,
                lambda: f"{v.pshorts.aviso.text()[:40]} · marco {v.pshorts.marco.width()}x{v.pshorts.marco.height()} · {v.pshorts.titulo.text()[:30]}")
    paso_simple("Shorts: siguiente (como la rueda) cambia de short", lambda: (estado.__setitem__("s", v.rep.actual.url), v.pshorts.pasar(True)),
                lambda: v.rep.actual is not None and v.rep.actual.url != estado["s"] and v.rep.pos > 0.5, 40)
    paso_simple("Salir de los Shorts: se para y la zona vuelve a su sitio", lambda: v.ir_seccion("explorar"),
                lambda: v.pshorts.zona is None and v.rep.actual is None and v.video.zonas.indexOf(v.zonas_pestana[v.pestana]) >= 0, 10)
    seccion("Explorar", lambda: v.ir_seccion("explorar"), 4, 60)
    seccion("Historial", lambda: v.ir_seccion("historial"), 5)
    seccion("Búsqueda", lambda: v.buscar("flavour trip"), 5)
    seccion("Búsqueda con filtros", lambda: v._refiltrar("flavour trip", {}, "fecha", "Este año"), 1)
    paso_simple("Sugerencias al escribir", lambda: (v.campo.setText("musica rel"), v._sugerir()),
                lambda: v.modelo.rowCount() >= 3, 15, lambda: f"{v.modelo.rowCount()} sugerencias")
    # el canal: el del primer vídeo del «Para ti» (uno con vídeos de sobra); la lista: la primera de las que tenga
    def canal():
        return next((x["autorUrl"] for x in (v._parati or {}).get("videos", []) if x.get("autorUrl")),
                    "https://www.youtube.com/channel/UC-9-kyTW8ZkZNDHQJ6FgpwQ")
    seccion("Canal (vídeos)", lambda: v.abrir_canal(canal()), 5, 60)
    seccion("Canal (pestaña Shorts)", lambda: v._canal(canal(), "shorts"), 0, 60)
    seccion("Canal (pestaña Listas)", lambda: v._canal(canal(), "playlists"), 0, 60)
    seccion("Búsqueda de listas", lambda: v._resultados("grandes éxitos", {"tipo": "Listas"}), 1, 60)
    seccion("Lista de YouTube", lambda: v.abrir(next(e for e in v.pag.rejilla.elementos if e.tipo == "LISTA")), 2, 60)

    def abrir_video():
        v.abrir_video(motor.Elemento("VIDEO", VIDEO_CAPITULOS, "", "", "", motor.miniatura(motor.id_video(VIDEO_CAPITULOS))))
    paso_simple("Reproducir un vídeo", abrir_video, lambda: rep.actual is not None and rep.pos > 3, 60,
                lambda: f"{rep.pos:.0f}/{rep.dur:.0f} s · {getattr(rep.mpv, 'width', 0)}x{getattr(rep.mpv, 'height', 0)} · "
                        f"perdidos {getattr(rep.mpv, 'frame_drop_count', '?')}")
    fluidez = {}

    def empezar_fluidez():
        if os.environ.get("CATODE_FLUIDEZ_COMPLETA") and not v.isFullScreen():   # medir a pantalla completa
            v.pantalla_completa()
        if os.environ.get("CATODE_APAGAR_REMOTO") and not v.ajustes.get("apagar_remoto"):   # 05/10/2026: medir con el remoto apagado
            v.apagar_remoto(True, avisar=False)
        # antes de medir, que la calidad automática ya esté decidida (si recarga a mitad, los contadores vuelven a 0)
        fin = time.time() + 3
        while time.time() < fin:
            QApplication.processEvents(); time.sleep(0.05)
        v.revisar_calidad()
        fin = time.time() + 4
        while time.time() < fin and (getattr(rep, "_recargando", False) or not rep._arrancado):
            QApplication.processEvents(); time.sleep(0.05)
        fluidez["t"], fluidez["p"] = time.time(), (rep.mpv.frame_drop_count or 0) + (rep.mpv.decoder_frame_drop_count or 0)
        fluidez["turno"] = rep._turno
        fluidez["desfase"] = 0

    def fluida():
        fluidez["desfase"] = max(fluidez.get("desfase", 0), abs(rep.mpv.avsync or 0))
        if time.time() - fluidez["t"] < 20:
            return False
        if rep._turno != fluidez.get("turno"):   # se recargó durante la medida: se mide otra vez desde aquí
            empezar_fluidez()
            return False
        perdidos = (rep.mpv.frame_drop_count or 0) + (rep.mpv.decoder_frame_drop_count or 0) - fluidez["p"]
        fluidez["perdidos"] = perdidos
        fluidez["perdidos"] = perdidos
        # 20 s a 25-30 fps son ~550 fotogramas: menos del 2 % perdidos, y la imagen a la par del sonido (04/10/2026: con la
        # copia de fotogramas no se perdía ninguno pero la imagen iba 8 s detrás del sonido, y la prueba lo daba por bueno)
        return perdidos <= 12 and abs(rep.mpv.avsync or 0) < 0.25
    def captura_mpv():
        r = os.environ.get("CATODE_CAPTURA_MPV")   # lo que pinta mpv en la ventana (con su escalado), para ver la nitidez
        if r:
            rep.mpv.command("screenshot-to-file", r, "window")
    def remoto_conectado():   # 04/10/2026: con Moonlight conectado a Sunshine la gráfica del N100 va al 95 % y se pierden
        try:                  # fotogramas en cualquier reproductor (YouTube en Chrome igual): se dice en el resultado
            with open(r"C:\Program Files\Sunshine\config\sunshine.log", encoding="utf-8", errors="replace") as f:
                lineas = [x for x in f.readlines()[-400:] if "CLIENT CONNECTED" in x or "CLIENT DISCONNECTED" in x]
            return bool(lineas) and "CLIENT CONNECTED" in lineas[-1]
        except OSError:
            return False
    paso_simple("Fluidez (20 s de vídeo)", empezar_fluidez, lambda: (lambda ok: (captura_mpv() if time.time() - fluidez["t"] >= 20 else None, ok)[1])(fluida()), 70,
                lambda: f"{fluidez.get('perdidos', '?')} fotogramas perdidos (descodificador {rep.mpv.decoder_frame_drop_count}, pantalla {rep.mpv.frame_drop_count}, "
                       f"retrasados {rep.mpv.vo_delayed_frame_count}) · {rep.mpv.width}x{rep.mpv.height} · {rep.mpv.hwdec_current or 'por programa'} · "
                       f"{rep.mpv.container_fps or 0:.0f} fps del vídeo (descodificados {rep.mpv.estimated_vf_fps or 0:.1f}/s, "
                       f"mostrados {rep.mpv.estimated_display_fps or 0:.1f}/s), pantalla a {rep.mpv.display_fps or 0:.0f} Hz, sincronía {rep.mpv.video_sync}, "
                       f"desfase imagen-sonido {1000 * (rep.mpv.avsync or 0):+.0f} ms (máx. {1000 * fluidez.get('desfase', 0):.0f} ms)"
                       + (" · ESCRITORIO REMOTO CONECTADO (Sunshine): medida no válida" if remoto_conectado() else ""))
    # ---- lo que hace una persona sobre el vídeo (02/10/2026: el autor no podía pausar con un clic, ni usar el doble clic,
    # ni salir de la pantalla completa). Los clics entran en mpv por la misma vía que los del ratón; las teclas, en la ventana.
    from PySide6.QtTest import QTest
    from PySide6.QtCore import Qt as _Qt
    from PySide6.QtWidgets import QApplication

    def clic(boton):
        rep.mpv.command("keypress", boton)

    def tecla(t):
        v.activateWindow(); v.video.setFocus(); QTest.keyClick(v, t)
    estado = {}
    def llena():   # 03/10/2026: en el mini PC la ventana se ponía a pantalla completa pero el vídeo se quedaba en 1344×576
        z = v.zonas_pestana[v.pestana]
        return v.isFullScreen() and z.isVisible() and z.width() >= v.width() * 0.97 and z.height() >= v.height() * 0.97
    def boton_entra():   # la prueba de fluidez puede dejarla a pantalla completa: se sale antes
        if v.isFullScreen():
            v.pantalla_completa()
            fin = time.time() + 1.5
            while time.time() < fin:
                QApplication.processEvents(); time.sleep(0.05)
        rep.mpv.command("cycle", "fullscreen")
    paso_simple("Botón de pantalla completa (propiedad de mpv): entra", boton_entra, llena, 5,
                lambda: f"vídeo {v.zonas_pestana[v.pestana].width()}×{v.zonas_pestana[v.pestana].height()} en {v.width()}×{v.height()}")
    paso_simple("Botón de pantalla completa (propiedad de mpv): sale", lambda: rep.mpv.command("cycle", "fullscreen"), lambda: not v.isFullScreen(), 5)
    if os.environ.get("CATODE_RATON_REAL"):   # entrada REAL del sistema: Windows (SendInput) y Linux (XTest del servidor X)
        import ctypes
        if os.name == "nt":
            from ctypes import wintypes
            u32 = ctypes.windll.user32
            VK = {"delete": 0x2E, "f5": 0x74, "question": 0xBF, "prior": 0x21, "next": 0x22, "space": 0x20, "left": 0x25, "up": 0x26, "right": 0x27, "down": 0x28, "f": 0x46, "escape": 0x1B, "home": 0x24, "f9": 0x78}

            def fisico(w, fx=0.5, fy=0.5):
                if w is v.video.video:   # la única ventana nativa (la de mpv): su rectángulo real
                    r = wintypes.RECT(); u32.GetWindowRect(int(w.winId()), ctypes.byref(r))
                    return int(r.left + (r.right - r.left) * fx), int(r.top + (r.bottom - r.top) * fy)
                # el resto, con la posición de Qt (pedir winId() convertiría el widget en ventana nativa)
                g = w.mapToGlobal(w.rect().topLeft()); ratio = (w.screen() or QApplication.primaryScreen()).devicePixelRatio()
                return int((g.x() + w.width() * fx) * ratio), int((g.y() + w.height() * fy) * ratio)

            def mover(x, y): u32.SetCursorPos(x, y)

            def boton(b, dos=False):
                ab = {1: (0x0002, 0x0004, 0), 2: (0x0020, 0x0040, 0), 3: (0x0008, 0x0010, 0), 8: (0x0080, 0x0100, 1), 9: (0x0080, 0x0100, 2)}[b]
                for _ in range(2 if dos else 1):
                    u32.mouse_event(ab[0], 0, 0, ab[2], 0); time.sleep(0.03); u32.mouse_event(ab[1], 0, 0, ab[2], 0); time.sleep(0.08)

            EXT = {0x25, 0x26, 0x27, 0x28, 0x2E, 0x24, 0x23, 0x21, 0x22, 0x2D}   # flechas, Supr, Inicio, Fin, RePág, AvPág, Ins: teclas extendidas
            def ext(k): return 1 if k in EXT else 0   # sin KEYEVENTF_EXTENDEDKEY, Windows las toma por el teclado numérico (con Bloq Num, dígitos)

            def tecla(n):
                u32.keybd_event(VK[n], 0, ext(VK[n]), 0); time.sleep(0.03); u32.keybd_event(VK[n], 0, ext(VK[n]) | 2, 0)

            def tecla_car(c):   # un carácter tal cual (KEYEVENTF_UNICODE): «?» no depende de la distribución del teclado
                u32.keybd_event(0, ord(c), 4, 0); time.sleep(0.03); u32.keybd_event(0, ord(c), 4 | 2, 0)

            def combo(mod, n):   # «ctrl»/«alt»/«ctrl+shift» + tecla (letra o nombre de VK)
                ms = [{"ctrl": 0x11, "alt": 0x12, "shift": 0x10}[x] for x in mod.split("+")]; k = VK.get(n) or ord(n.upper())
                for m in ms:
                    u32.keybd_event(m, 0, 0, 0); time.sleep(0.03)
                u32.keybd_event(k, 0, ext(k), 0); time.sleep(0.03); u32.keybd_event(k, 0, ext(k) | 2, 0); time.sleep(0.03)
                for m in reversed(ms):
                    u32.keybd_event(m, 0, 2, 0)

            def arrastrar(a, b):   # botón izquierdo pulsado de a hasta b, en pasos (05/10/2026: reordenar pestañas)
                u32.SetCursorPos(*a); time.sleep(0.1); u32.mouse_event(0x0002, 0, 0, 0, 0); time.sleep(0.1)
                for k in range(1, 13):
                    u32.SetCursorPos(int(a[0] + (b[0] - a[0]) * k / 12), int(a[1] + (b[1] - a[1]) * k / 12)); vivo(0.05)
                time.sleep(0.1); u32.mouse_event(0x0004, 0, 0, 0, 0)

            def rueda_abajo(): u32.mouse_event(0x0800, 0, 0, ctypes.c_uint32(-120 & 0xFFFFFFFF).value, 0)

            def ctrl_rueda_arriba():   # 05/10/2026: Ctrl+rueda = zoom
                u32.keybd_event(0x11, 0, 0, 0); time.sleep(0.03); u32.mouse_event(0x0800, 0, 0, 120, 0); time.sleep(0.05); u32.keybd_event(0x11, 0, 2, 0)
        else:
            import ctypes.util
            x11 = ctypes.CDLL(ctypes.util.find_library("X11")); xt = ctypes.CDLL(ctypes.util.find_library("Xtst"))
            x11.XOpenDisplay.restype = ctypes.c_void_p
            x11.XKeysymToKeycode.argtypes = [ctypes.c_void_p, ctypes.c_ulong]
            x11.XStringToKeysym.restype = ctypes.c_ulong
            dpy = ctypes.c_void_p(x11.XOpenDisplay(None))

            def fisico(w, fx=0.5, fy=0.5):
                g = w.mapToGlobal(w.rect().topLeft()); ratio = w.devicePixelRatioF()
                return int((g.x() + w.width() * fx) * ratio), int((g.y() + w.height() * fy) * ratio)

            def mover(x, y): xt.XTestFakeMotionEvent(dpy, -1, x, y, 0); x11.XFlush(dpy)

            def boton(b, dos=False):
                for _ in range(2 if dos else 1):
                    xt.XTestFakeButtonEvent(dpy, b, 1, 0); x11.XFlush(dpy); time.sleep(0.03)
                    xt.XTestFakeButtonEvent(dpy, b, 0, 0); x11.XFlush(dpy); time.sleep(0.08)

            def rueda_abajo():
                xt.XTestFakeButtonEvent(dpy, 5, 1, 0); x11.XFlush(dpy); time.sleep(0.03); xt.XTestFakeButtonEvent(dpy, 5, 0, 0); x11.XFlush(dpy)

            def ctrl_rueda_arriba():   # 05/10/2026: Ctrl+rueda = zoom
                km = x11.XKeysymToKeycode(dpy, x11.XStringToKeysym(b"Control_L"))
                xt.XTestFakeKeyEvent(dpy, km, 1, 0); x11.XFlush(dpy); time.sleep(0.05)
                xt.XTestFakeButtonEvent(dpy, 4, 1, 0); x11.XFlush(dpy); time.sleep(0.03); xt.XTestFakeButtonEvent(dpy, 4, 0, 0); x11.XFlush(dpy)
                time.sleep(0.05); xt.XTestFakeKeyEvent(dpy, km, 0, 0); x11.XFlush(dpy)

            def tecla(n):
                kc = x11.XKeysymToKeycode(dpy, x11.XStringToKeysym({"space": b"space", "right": b"Right", "down": b"Down", "f": b"f",
                                                                     "left": b"Left", "up": b"Up", "f5": b"F5",
                                                                     "escape": b"Escape", "home": b"Home", "f9": b"F9", "delete": b"Delete"}[n]))
                xt.XTestFakeKeyEvent(dpy, kc, 1, 0); x11.XFlush(dpy); time.sleep(0.03); xt.XTestFakeKeyEvent(dpy, kc, 0, 0); x11.XFlush(dpy)

            def combo(mod, n):   # «ctrl»/«alt»/«ctrl+shift» + tecla (letra o nombre X: Left, Right…)
                kms = [x11.XKeysymToKeycode(dpy, x11.XStringToKeysym({"ctrl": b"Control_L", "alt": b"Alt_L", "shift": b"Shift_L"}[x]))
                       for x in mod.split("+")]
                kc = x11.XKeysymToKeycode(dpy, x11.XStringToKeysym({"left": b"Left", "right": b"Right", "prior": b"Prior",
                                                                     "next": b"Next"}.get(n, n.encode())))
                for km in kms:
                    xt.XTestFakeKeyEvent(dpy, km, 1, 0); x11.XFlush(dpy); time.sleep(0.03)
                xt.XTestFakeKeyEvent(dpy, kc, 1, 0); x11.XFlush(dpy); time.sleep(0.03)
                xt.XTestFakeKeyEvent(dpy, kc, 0, 0); x11.XFlush(dpy); time.sleep(0.03)
                for km in reversed(kms):
                    xt.XTestFakeKeyEvent(dpy, km, 0, 0); x11.XFlush(dpy)

            def arrastrar(a, b):   # botón izquierdo pulsado de a hasta b, en pasos (05/10/2026: reordenar pestañas)
                mover(*a); vivo(0.15); xt.XTestFakeButtonEvent(dpy, 1, 1, 0); x11.XFlush(dpy); vivo(0.15)   # con vivo: Qt ve cada paso
                for k in range(1, 13):
                    mover(int(a[0] + (b[0] - a[0]) * k / 12), int(a[1] + (b[1] - a[1]) * k / 12)); vivo(0.05)
                vivo(0.15); xt.XTestFakeButtonEvent(dpy, 1, 0, 0); x11.XFlush(dpy)

        def vivo(seg):
            """Esperar dejando correr la interfaz (con time.sleep la app no ve el ratón ni sus temporizadores)."""
            fin = time.time() + seg
            while time.time() < fin:
                QApplication.processEvents(); time.sleep(0.02)

        def en_video(fx=0.5, fy=0.5):
            v.activateWindow(); mover(*fisico(v.video.video, fx, fy)); time.sleep(0.15)

        def clic_real(dos=False, derecho=False):
            en_video(); boton(3 if derecho else 1, dos)

        def menu_real():
            QTimer.singleShot(1500, lambda: (estado.__setitem__("menu", type(QApplication.activePopupWidget()).__name__),
                                             QApplication.activePopupWidget() and QApplication.activePopupWidget().close()))
            clic_real(derecho=True)

        def tecla_real(n):
            v.activateWindow(); time.sleep(0.1); tecla(n)

        def maximizada_vuelve():
            v.showMaximized(); vivo(1.2); tecla_real("f"); vivo(2.0); tecla_real("escape")

        def central_menu():
            if v.isFullScreen():
                v.pantalla_completa(); vivo(1.0)
            estado["pestanas"] = len(v.pestanas)
            fila = next(i for i in range(v.menu.count()) if v.menu.item(i).data(Qt.UserRole) == "historial")
            r = v.menu.visualItemRect(v.menu.item(fila)); c = r.center()
            g = v.menu.viewport().mapToGlobal(c); d = v.menu.devicePixelRatioF()
            v.activateWindow(); mover(int(g.x() * d), int(g.y() * d)); time.sleep(0.15); boton(2); vivo(1.5)

        def clic_barra():
            en_video(0.4, 0.4); vivo(0.2); en_video(0.6, 0.6); vivo(0.5)   # que salgan los mandos
            print("barra:", fisico(v.controles.posicion, 0.5, 0.5), v.controles.visibles, v.controles.abajo.isVisible(), v.controles.isVisible(), QApplication.activePopupWidget(), "bajo:", QApplication.widgetAt(*fisico(v.controles.posicion, 0.5, 0.5)), v.controles.posicion.isVisible(), v.controles.posicion.geometry(), flush=True); mover(*fisico(v.controles.posicion, 0.5, 0.5)); time.sleep(0.15); boton(1)

        def rueda_ajustes():
            en_video(0.4, 0.4); vivo(0.2); en_video(0.6, 0.6); vivo(0.5)   # mover el ratón: salen los mandos
            b = [x for x in v.controles.findChildren(QPushButton) if "Ajustes" in x.toolTip()][0]
            QTimer.singleShot(1500, lambda: (estado.__setitem__("ajustes", [a.text() for a in QApplication.activePopupWidget().actions()]
                                                                if QApplication.activePopupWidget() else None),
                                             QApplication.activePopupWidget() and QApplication.activePopupWidget().close()))
            destino = fisico(b, 0.5, 0.5)
            mover(*destino); time.sleep(0.15); boton(1)
        estado["menu"] = None
        reales = (
            ("Clic REAL en el vídeo: pausa", lambda: (estado.__setitem__("p", rep.pausa), clic_real()), lambda: rep.pausa != estado["p"]),
            ("Clic REAL: sigue", lambda: (estado.__setitem__("p", rep.pausa), clic_real()), lambda: rep.pausa != estado["p"]),
            ("Doble clic REAL: pantalla completa", lambda: clic_real(True), llena),
            ("Ratón REAL en pantalla completa: salen los mandos", lambda: (time.sleep(3.5), en_video(0.4, 0.4), en_video(0.5, 0.5)),
             lambda: v.controles.visibles and v.controles.isVisible()),
            ("Quieto 3 s: los mandos se esconden", lambda: None, lambda: not v.controles.visibles),
            ("Doble clic REAL: sale", lambda: (time.sleep(0.5), clic_real(True)), lambda: not v.isFullScreen()),
            ("Clic derecho REAL: menú", menu_real, lambda: estado.get("menu") == "QMenu"),
            ("Solo un menú abierto y cerrado", lambda: time.sleep(0.5), lambda: QApplication.activePopupWidget() is None),
            # 05/10/2026: la batería silencia poniendo el volumen a 0 y desde 0 no se puede bajar: antes se sube a 20
            ("Rueda REAL: baja el volumen", lambda: (v.barra.vol.setValue(max(v.barra.vol.value(), 20)), estado.__setitem__("vol", v.barra.vol.value()), en_video(), rueda_abajo()),
             lambda: v.barra.vol.value() == estado["vol"] - 5),
            ("Tecla REAL espacio: pausa", lambda: (estado.__setitem__("p", rep.pausa), tecla_real("space")), lambda: rep.pausa != estado["p"]),
            ("Tecla REAL espacio: sigue", lambda: (estado.__setitem__("p", rep.pausa), tecla_real("space")), lambda: rep.pausa != estado["p"]),
            ("Tecla REAL →: +5 s", lambda: (estado.__setitem__("t", rep.pos), tecla_real("right")), lambda: rep.pos >= estado["t"] + 4),
            ("Tecla REAL F: pantalla completa", lambda: tecla_real("f"), llena),
            ("Tecla REAL Esc: sale", lambda: tecla_real("escape"), lambda: not v.isFullScreen()),
            # 05/10/2026 (el autor: al salir de pantalla completa «la ventana se reduce», «insultante»): maximizada → F → Esc → sigue maximizada
            ("Maximizada: F REAL entra y Esc REAL la deja MAXIMIZADA", maximizada_vuelve, lambda: not v.isFullScreen() and v.isMaximized()),
            ("Mandos del vídeo: rueda de ajustes REAL", rueda_ajustes,
             lambda: estado.get("ajustes") and any(t.startswith("Calidad") for t in estado["ajustes"])),
            ("Clic REAL en la mitad de la barra", clic_barra, lambda: rep.dur and abs(rep.pos - rep.dur / 2) < rep.dur * 0.06),
            # 05/10/2026: botón central sobre «Historial» en el panel izquierdo → una pestaña más, en Historial
            ("Botón central REAL en el menú: pestaña nueva", central_menu,
             lambda: len(v.pestanas) == estado.get("pestanas", -1) + 1 and v.barra_pestanas.tabText(v.pestana).startswith("Historial")),
            ("Tecla REAL Inicio: al principio", lambda: tecla_real("home"), lambda: rep.pos < 5),
            ("Tras todo sigue sonando", lambda: None, lambda: (not rep.pausa) or (setattr(rep.mpv, "pause", False) or False)),
        )
        def self_ok():
            return v.ajustes.get('avisos') is False and v.ajustes.get('avisos_apagados_0510') is True

        def combo_real(mod, n):
            v.activateWindow(); time.sleep(0.1); combo(mod, n)

        def pestana_real(i, b=2):   # botón del ratón sobre la pestaña i de la barra
            r = v.barra_pestanas.tabRect(i); g = v.barra_pestanas.mapToGlobal(r.center()); d = v.barra_pestanas.devicePixelRatioF()
            v.activateWindow(); mover(int(g.x() * d), int(g.y() * d)); time.sleep(0.15); boton(b); vivo(1.0)

        def menu_real(clave, b=2, ctrl=False):   # botón del ratón (o Ctrl+clic) sobre una sección del panel izquierdo
            fila = next(i for i in range(v.menu.count()) if v.menu.item(i).data(Qt.UserRole) == clave)
            g = v.menu.viewport().mapToGlobal(v.menu.visualItemRect(v.menu.item(fila)).center()); d = v.menu.devicePixelRatioF()
            v.activateWindow(); mover(int(g.x() * d), int(g.y() * d)); time.sleep(0.15)
            if ctrl:
                if os.name == "nt":
                    u32.keybd_event(0x11, 0, 0, 0); time.sleep(0.03); boton(1); u32.keybd_event(0x11, 0, 2, 0)
                else:
                    km = x11.XKeysymToKeycode(dpy, x11.XStringToKeysym(b"Control_L"))
                    xt.XTestFakeKeyEvent(dpy, km, 1, 0); x11.XFlush(dpy); time.sleep(0.03); boton(1); xt.XTestFakeKeyEvent(dpy, km, 0, 0); x11.XFlush(dpy)
            else:
                boton(b)
            vivo(1.2)

        # 05/10/2026: las funciones de la interfaz, como las usa el autor, sin abrir ningún vídeo (modo CATODE_PRUEBA_INTERFAZ: sin red)
        n0 = {}
        if os.environ.get("CATODE_PRUEBA_PESTANAS"):   # 05/10/2026: el lanzador dejó pestañas guardadas; deben reabrirse al arrancar
            paso_simple("Interfaz: al arrancar se reabren las pestañas recordadas", lambda: None,
                        lambda: len(v.pestanas) == int(os.environ["CATODE_PRUEBA_PESTANAS"]) and v.barra_pestanas.tabText(0).startswith("Historial")
                        and v.barra_pestanas.tabText(1).startswith("Ver más tarde"), 8,
                        lambda: f"pestañas {len(v.pestanas)}: " + " · ".join(v.barra_pestanas.tabText(i) for i in range(len(v.pestanas))))
            paso_simple("Interfaz: se cierran las recordadas y queda una", lambda: [v.cerrar_pestana(len(v.pestanas) - 1) for _ in range(len(v.pestanas) - 1)],
                        lambda: len(v.pestanas) == 1, 6)
        # 24/10/2026 («catode enseña siempre los mismos vídeos… algunos salen con 0 o 1 visualización y no cargan»): con cinco
        # mezclas nuevas (Actualizar), lo que ya ha salido 3 veces sin abrirlo no vuelve (mezcla.Ensenado), y un estreno que aún
        # no ha empezado (motor.programado) no sale nunca en el Inicio
        rot = {"t": 0}

        def tarjetas_inicio():
            seguir_viendo = {e.url for e, _, _ in v.datos.continuar_viendo(4)}
            return [motor.id_video(w.e.url) for w in v.pag.rejilla.widgets
                    if getattr(w, "e", None) and w.e.tipo == "VIDEO" and w.e.url not in seguir_viendo]

        def actualizar_inicio():
            if not rot.get("servidor"):   # sin red no hay servidor: su Para ti es el de los fixtures, con un estreno arriba
                with open(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
                                       "pruebas", "fixtures", "parati.json"), encoding="utf-8") as f:
                    p = json.load(f)
                p["videos"].insert(0, dict(p["videos"][0], url=motor.url_video("-nl18l8sE08"), titulo="Estreno de prueba",
                                           detalle=motor.PROXIMAMENTE + " · Fecha de estreno: 25/10/26, 4:00", duracion=-1))
                rot["servidor"] = v.datos.del_servidor
                v.datos.del_servidor = lambda r, o=rot["servidor"]: dict(p) if r == "/app/parati.json" else o(r)
            rot["t"] = getattr(v, "_parati_t", 0)
            v.ir_seccion("inicio"); v.inicio("Todo", True)
        for n in range(5):
            paso_simple(f"Interfaz: Inicio, mezcla nueva {n + 1} de 5 (Actualizar)", actualizar_inicio,
                        lambda: getattr(v, "_parati_t", 0) > rot["t"] and bool(tarjetas_inicio()), 15)

        def sin_repetidos():
            cans = getattr(v, "_cansados_inicio", set())
            ids = tarjetas_inicio()
            distintos = len(v._ensenado.m)   # lo enseñado en las 5 mezclas (24 cada una): rota de verdad
            rot["d"] = f"{distintos} distintos, {len(cans)} apartados, {len(set(ids) & cans)} en pantalla de {len(ids)}, estreno {'-nl18l8sE08' in ids}"
            return distintos >= 70 and (len(ids) <= v._ensenado.MINIMO or not set(ids) & cans) and "-nl18l8sE08" not in ids \
                and max((x[0] for x in v._ensenado.m.values()), default=0) <= v._ensenado.VECES + 1
        paso_simple("Interfaz: Inicio, lo enseñado 3 veces sin abrir ya no sale, ni los estrenos",
                    lambda: rot.get("servidor") and setattr(v.datos, "del_servidor", rot["servidor"]), sin_repetidos, 5, lambda: rot.get("d", ""))
        paso_simple("Interfaz: Ctrl+T REAL abre una pestaña", lambda: (n0.__setitem__("p", len(v.pestanas)), combo_real("ctrl", "t")),
                    lambda: len(v.pestanas) == n0["p"] + 1, 5, lambda: f"pestañas {len(v.pestanas)}")
        paso_simple("Interfaz: Ctrl+W REAL la cierra", lambda: (n0.__setitem__("p", len(v.pestanas)), combo_real("ctrl", "w")),
                    lambda: len(v.pestanas) == n0["p"] - 1, 5, lambda: f"pestañas {len(v.pestanas)}")
        paso_simple("Interfaz: botón central REAL en el menú (Historial) abre pestaña nueva", lambda: (n0.__setitem__("p", len(v.pestanas)), menu_real("historial")),
                    lambda: len(v.pestanas) == n0["p"] + 1 and v.barra_pestanas.tabText(v.pestana).startswith("Historial"), 6,
                    lambda: f"pestañas {len(v.pestanas)} · pestaña «{v.barra_pestanas.tabText(v.pestana)}»")
        paso_simple("Interfaz: Ctrl+clic REAL en el menú (Ver más tarde) abre pestaña nueva", lambda: (n0.__setitem__("p", len(v.pestanas)), menu_real("despues", ctrl=True)),
                    lambda: len(v.pestanas) == n0["p"] + 1 and v.barra_pestanas.tabText(v.pestana).startswith("Ver más tarde"), 6,
                    lambda: f"pestañas {len(v.pestanas)} · pestaña «{v.barra_pestanas.tabText(v.pestana)}»")
        paso_simple("Interfaz: botón central REAL sobre una pestaña la cierra", lambda: (n0.__setitem__("p", len(v.pestanas)), pestana_real(len(v.pestanas) - 1)),
                    lambda: len(v.pestanas) == n0["p"] - 1, 6, lambda: f"pestañas {len(v.pestanas)}")
        paso_simple("Interfaz: clic REAL en el menú (Historial) va en la misma pestaña", lambda: (n0.__setitem__("p", len(v.pestanas)), menu_real("historial", b=1)),
                    lambda: len(v.pestanas) == n0["p"] and v.pila and v.pila[-1][0] == v.historial, 6, lambda: f"pestañas {len(v.pestanas)}")
        paso_simple("Interfaz: Alt+← REAL vuelve atrás", lambda: (v.ir_seccion("despues"), vivo(0.5), combo_real("alt", "left")),
                    lambda: v.pila and v.pila[-1][0] == v.historial, 6, lambda: f"pila {len(v.pila)} · arriba {getattr(v.pila[-1][0], '__name__', '?') if v.pila else '-'}")
        def voz_simulada():   # sin dictado real: pulsar el micrófono y «dictar» escribiendo en el campo
            estado["voz"] = None; v._buscar_original = v.buscar; v.buscar = lambda q: estado.__setitem__("voz", q)
            v._voz_sin_dictado = True; v.activateWindow(); mover(*fisico(v.b_voz, 0.5, 0.5)); time.sleep(0.15); boton(1); vivo(0.5)
            v.campo.setText("prueba por voz"); vivo(2.4); v.buscar = v._buscar_original
        paso_simple("Interfaz: micrófono del buscador: al dejar de dictar busca solo", voz_simulada,
                    lambda: estado.get("voz") == "prueba por voz", 4, lambda: f"buscó {estado.get('voz')!r}")
        paso_simple("Interfaz: las notificaciones del sistema están apagadas", lambda: None,
                    lambda: self_ok(), 3, lambda: f"avisos={v.ajustes.get('avisos')} marca={v.ajustes.get('avisos_apagados_0510')}")
        paso_simple("Interfaz: Ajustes se abre desde el menú", lambda: menu_real("ajustes", b=1),
                    lambda: v.paginas.currentWidget() is v.opciones, 6)
        # 05/10/2026: convenciones de navegador de DISENO_PENDIENTE.md (Alta)
        def punto_pestana(i):
            r = v.barra_pestanas.tabRect(i); g = v.barra_pestanas.mapToGlobal(r.center()); d = v.barra_pestanas.devicePixelRatioF()
            return int(g.x() * d), int(g.y() * d)

        def tres():   # tres pestañas, en Inicio, Historial y Ver más tarde
            [v.cerrar_pestana(len(v.pestanas) - 1) for _ in range(len(v.pestanas) - 1)]
            v.ir_seccion("inicio"); v.nueva_pestana(); v.ir_seccion("historial"); v.nueva_pestana(); v.ir_seccion("despues"); vivo(0.5)

        def coherente():
            return v.pestanas[v.pestana] is v.pila and v.reps[v.pestana] is v.rep and v.barra_pestanas.currentIndex() == v.pestana

        def menu_pestana(i, accion):   # clic derecho REAL en la pestaña i y pulsar «accion» en su menú
            def pulsar(intento=0):   # en Windows el menú puede tardar (el motor de Edge recién creado): se espera hasta 4 s
                m = QApplication.activePopupWidget()
                if m is None and intento < 26:
                    return QTimer.singleShot(150, lambda: pulsar(intento + 1))
                estado["menu_pestana"] = [a.text() for a in m.actions()] if m else None
                a = next((a for a in (m.actions() if m else []) if a.text().startswith(accion)), None)
                if m:
                    m.close()
                if a:
                    a.trigger()
            QTimer.singleShot(400, pulsar)
            pestana_real(i, b=3); vivo(1.0)

        def boton5():
            v.ir_seccion("historial"); v.ir_seccion("despues"); vivo(0.4); combo_real("alt", "left"); vivo(0.6)
            v.activateWindow(); mover(*fisico(v.paginas, 0.5, 0.5)); time.sleep(0.15); boton(9)
        paso_simple("Interfaz: botón 5 REAL del ratón va adelante", boton5,
                    lambda: v.pila and v.pila[-1][0] == v.despues, 6, lambda: f"arriba {getattr(v.pila[-1][0], '__name__', '?') if v.pila else '-'}")
        paso_simple("Interfaz: Ctrl+1 REAL va a la primera pestaña", lambda: (tres(), combo_real("ctrl", "1")),
                    lambda: v.pestana == 0 and coherente(), 8, lambda: f"pestaña {v.pestana} de {len(v.pestanas)}")
        paso_simple("Interfaz: Ctrl+9 REAL va a la última", lambda: combo_real("ctrl", "9"),
                    lambda: v.pestana == len(v.pestanas) - 1 and coherente(), 6, lambda: f"pestaña {v.pestana}")
        paso_simple("Interfaz: Ctrl+RePág REAL va a la anterior", lambda: combo_real("ctrl", "prior"),
                    lambda: v.pestana == len(v.pestanas) - 2 and coherente(), 6, lambda: f"pestaña {v.pestana}")
        paso_simple("Interfaz: Ctrl+AvPág REAL va a la siguiente", lambda: combo_real("ctrl", "next"),
                    lambda: v.pestana == len(v.pestanas) - 1 and coherente(), 6, lambda: f"pestaña {v.pestana}")
        paso_simple("Interfaz: arrastrar REAL la última pestaña al principio la mueve con su historial",
                    lambda: (n0.__setitem__("pila", v.pestanas[-1]), arrastrar(punto_pestana(len(v.pestanas) - 1), punto_pestana(0)), vivo(1.0)),
                    lambda: v.pestanas[0] is n0["pila"] and coherente() and v.pestanas[0][-1][0] == v.despues, 6,
                    lambda: f"pestaña {v.pestana} · primera {getattr(v.pestanas[0][-1][0], '__name__', '?')} · coherente {coherente()}")
        paso_simple("Interfaz: clic derecho REAL en la pestaña → Duplicar", lambda: (n0.__setitem__("p", len(v.pestanas)), menu_pestana(0, "Duplicar")),
                    lambda: len(v.pestanas) == n0["p"] + 1 and v.pila[-1][0] == v.despues and coherente(), 6,
                    lambda: f"pestañas {len(v.pestanas)} · menú {estado.get('menu_pestana')}")
        paso_simple("Interfaz: menú de pestaña → Cerrar las de la derecha", lambda: (n0.__setitem__("p", len(v.pestanas)), menu_pestana(1, "Cerrar las de la derecha")),
                    lambda: len(v.pestanas) == 2 and coherente(), 8, lambda: f"pestañas {len(v.pestanas)}")
        paso_simple("Interfaz: Ctrl+Mayús+T REAL reabre la última cerrada",
                    lambda: (combo_real("ctrl", "w"), vivo(0.6), n0.__setitem__("p", len(v.pestanas)), combo_real("ctrl+shift", "t")),
                    lambda: len(v.pestanas) == n0["p"] + 1 and coherente() and len(v.pila) >= 1, 8, lambda: f"pestañas {len(v.pestanas)}")
        paso_simple("Interfaz: menú de pestaña → Cerrar las otras", lambda: menu_pestana(0, "Cerrar las otras"),
                    lambda: len(v.pestanas) == 1 and coherente(), 8, lambda: f"pestañas {len(v.pestanas)}")
        paso_simple("Interfaz: doble clic REAL en el hueco de las pestañas abre una", lambda: (n0.__setitem__("p", len(v.pestanas)),
                    v.activateWindow(), mover(*fisico(v.caja_pest, 0.92, 0.5)), time.sleep(0.15), boton(1, dos=True), vivo(0.8)),
                    lambda: len(v.pestanas) == n0["p"] + 1, 6, lambda: f"pestañas {len(v.pestanas)}")
        paso_simple("Interfaz: las pestañas se pueden guardar para reabrirlas",
                    lambda: estado.__setitem__("guardables", json.dumps(v._pestanas_guardables())),
                    lambda: len(json.loads(estado["guardables"])) == len(v.pestanas), 3, lambda: estado.get("guardables", "")[:120])
        # 05/10/2026: DISENO_PENDIENTE.md (Media y Baja)
        def flechas_menu(i_accion, central=False):   # clic derecho (o central) REAL en la flecha atrás
            v.ir_seccion("inicio"); v.ir_seccion("historial"); v.ir_seccion("despues"); vivo(0.4)
            n0["esperada"] = v._clave(v.pila[-3] if not central else v.pila[-2]); n0["p"] = len(v.pestanas)
            if not central:
                def pulsar():
                    m = QApplication.activePopupWidget()
                    estado["menu_flecha"] = [a.text() for a in m.actions()] if m else None
                    if m and len(m.actions()) > i_accion:
                        m.actions()[i_accion].trigger()
                    m and m.close()
                QTimer.singleShot(900, pulsar)
            v.activateWindow(); mover(*fisico(v.b_atras)); time.sleep(0.15); boton(2 if central else 3); vivo(0.8)

        def rejilla_flecha():
            v.ir_seccion("historial")
            def mirar(t0=time.time()):
                ws = [w for w in v.pag.rejilla.widgets if w.isVisible()]
                if len(ws) >= 2 or time.time() - t0 > 8:
                    estado["ws"] = ws
                    if len(ws) >= 2:
                        ws[0].setFocus(Qt.TabFocusReason); vivo(0.2)
                        tecla_real("down" if ws[0].fila else "right")
                else:
                    QTimer.singleShot(300, mirar)
            mirar()

        def con_aviso(f):
            original = v.avisar
            v.avisar = lambda t, *a, **k: (estado.__setitem__("aviso", t), original(t, *a, **k))
            estado["aviso"] = None; f(); vivo(0.6); v.avisar = original

        paso_simple("Interfaz: clic derecho REAL en «atrás» → salta dos páginas", lambda: flechas_menu(1),
                    lambda: v.pila and v._clave(v.pila[-1]) == n0["esperada"], 6,
                    lambda: f"menú {estado.get('menu_flecha')} · arriba {getattr(v.pila[-1][0], '__name__', '?') if v.pila else '-'}")
        paso_simple("Interfaz: botón central REAL en «atrás» → la página anterior en pestaña nueva", lambda: flechas_menu(0, central=True),
                    lambda: len(v.pestanas) == n0["p"] + 1 and v._clave(v.pila[-1]) == n0["esperada"] and coherente(), 6,
                    lambda: f"pestañas {len(v.pestanas)} · arriba {getattr(v.pila[-1][0], '__name__', '?') if v.pila else '-'}")
        paso_simple("Interfaz: F5 REAL recarga la página", lambda: (v.ir_seccion("historial"), vivo(0.3), n0.__setitem__("pila", len(v.pila)),
                    con_aviso(lambda: tecla_real("f5"))),
                    lambda: estado.get("aviso") == "Recargado" and len(v.pila) == n0["pila"], 6, lambda: f"aviso {estado.get('aviso')}")
        paso_simple("Interfaz: Ctrl+R REAL recarga la página", lambda: con_aviso(lambda: combo_real("ctrl", "r")),
                    lambda: estado.get("aviso") == "Recargado", 6, lambda: f"aviso {estado.get('aviso')}")
        paso_simple("Interfaz: el título de la ventana es el de la página", lambda: v.ir_seccion("historial"),
                    lambda: v.windowTitle().startswith("Historial") and v.windowTitle().endswith("· Cat-ode"), 4, lambda: v.windowTitle())
        paso_simple("Interfaz: flecha REAL en la rejilla pasa a la tarjeta de al lado", rejilla_flecha,
                    lambda: len(estado.get("ws") or []) >= 2 and QApplication.focusWidget() in estado["ws"] and QApplication.focusWidget() is not estado["ws"][0], 10,
                    lambda: f"tarjetas {len(estado.get('ws') or [])} · teclado en {type(QApplication.focusWidget()).__name__}")
        paso_simple("Interfaz: Ctrl+K REAL lleva al buscador", lambda: (v.campo.clearFocus(), v.paginas.setFocus(), combo_real("ctrl", "k")),
                    lambda: QApplication.focusWidget() is v.campo, 4, lambda: f"teclado en {type(QApplication.focusWidget()).__name__}")
        paso_simple("Interfaz: Esc REAL suelta el buscador", lambda: tecla_real("escape"),
                    lambda: QApplication.focusWidget() is not v.campo, 4, lambda: f"teclado en {type(QApplication.focusWidget()).__name__}")
        paso_simple("Interfaz: Ctrl+E REAL lleva al buscador", lambda: (v.paginas.setFocus(), combo_real("ctrl", "e")),
                    lambda: QApplication.focusWidget() is v.campo, 4, lambda: f"teclado en {type(QApplication.focusWidget()).__name__}")
        paso_simple("Interfaz: Ctrl+F REAL (sin transcripción a la vista) lleva al buscador",
                    lambda: (tecla_real("escape"), vivo(0.3), v.paginas.setFocus(), combo_real("ctrl", "f")),
                    lambda: QApplication.focusWidget() is v.campo, 4, lambda: f"teclado en {type(QApplication.focusWidget()).__name__}")
        paso_simple("Interfaz: «?» REAL enseña los atajos", lambda: (tecla_real("escape"), vivo(0.3), v.paginas.setFocus(), v.activateWindow(), time.sleep(0.1),
                                                                   tecla_car("?") if os.name == "nt" else combo("shift", "question")),
                    lambda: getattr(v, "_dialogo_atajos", None) is not None and v._dialogo_atajos.isVisible(), 4,
                    lambda: f"teclado en {type(QApplication.focusWidget()).__name__}")
        paso_simple("Interfaz: la lista de atajos se cierra", lambda: v._dialogo_atajos.close(), lambda: not v._dialogo_atajos.isVisible(), 3)
        def sugerencia_fuera():
            v.datos.buscado("prueba catode borrar"); v.campo.setText(""); v.activateWindow(); v.campo.setFocus(); v._sugerir(); vivo(0.3)
            c = v.campo.completer(); c.complete(); vivo(0.4)
            filas = v.modelo.stringList()
            if "⟲  prueba catode borrar" in filas:
                c.popup().setCurrentIndex(c.completionModel().index(filas.index("⟲  prueba catode borrar"), 0)); vivo(0.2)
                combo("shift", "delete" if os.name == "nt" else "Delete")
            vivo(0.4); c.popup().hide()

        paso_simple("Interfaz: Ctrl+rueda REAL agranda la interfaz", lambda: (v.paginas.setFocus(), v.activateWindow(),
                    mover(*fisico(v.paginas, 0.5, 0.5)), time.sleep(0.15), ctrl_rueda_arriba(), vivo(0.6)),
                    lambda: v.ajustes.get("escala") == 1.1 and QApplication.instance().font().pixelSize() == 15, 4,
                    lambda: f"escala {v.ajustes.get('escala')} · letra {QApplication.instance().font().pixelSize()}")
        paso_simple("Interfaz: la escala vuelve al 100 %", lambda: (v.poner_escala(1.0), vivo(0.5)),
                    lambda: QApplication.instance().font().pixelSize() == 14, 3)
        paso_simple("Interfaz: botón central REAL en el logo abre el Inicio en pestaña nueva",
                    lambda: (n0.__setitem__("p", len(v.pestanas)), v.activateWindow(), mover(*fisico(v.arriba.findChild(QLabel, "logo"))),
                             time.sleep(0.15), boton(2), vivo(0.8)),
                    lambda: len(v.pestanas) == n0["p"] + 1 and coherente(), 5, lambda: f"pestañas {len(v.pestanas)}")
        paso_simple("Interfaz: la ventana tiene tamaño mínimo", lambda: None,
                    lambda: v.minimumSize().width() >= 900 and v.minimumSize().height() >= 540, 2, lambda: str(v.minimumSize()))
        # 05/10/2026: lo que actúa sobre un vídeo sonando se prueba con un ARCHIVO LOCAL (CATODE_VIDEO_LOCAL), sin red ni YouTube
        local = os.environ.get("CATODE_VIDEO_LOCAL")
        if local and os.path.exists(local):
            from . import motor as _motor
            e_local = _motor.Elemento(tipo="VIDEO", url="https://www.youtube.com/watch?v=localprueba", titulo="Vídeo local de prueba")
            e_local2 = _motor.Elemento(tipo="VIDEO", url="https://www.youtube.com/watch?v=localprueb2", titulo="Vídeo local de prueba 2")
            def suena_local():
                v.rep._locales[e_local.url] = local; v.rep._locales[e_local2.url] = local
                v.ir_seccion("inicio"); v.abrir(e_local)
            paso_simple("Interfaz (vídeo local): reproduce un archivo sin red", suena_local,
                        lambda: v.rep.actual is not None and not v.rep.pausa and v.rep.pos > 0.5, 20, lambda: f"pos {v.rep.pos:.1f} pausa {v.rep.pausa}")
            def mini_enganchado():   # Windows: la ventana de Edge cuelga de la zona del mini y tiene tamaño; Linux: la zona está dentro del mini
                f = v.flotante
                if f is None or not f.isVisible() or f.zona.parent() is not f:
                    return False
                ctl = getattr(getattr(v.rep, "mpv", None), "_ctl", None)
                if ctl is None:
                    return True
                return int(ctl.ParentWindow.ToInt64()) == int(f.zona.winId()) and ctl.Bounds.Width > 100
            paso_simple("Interfaz (vídeo local): el minirreproductor se ve (vídeo enganchado al mini)", lambda: (v._a_flotante("mini"), vivo(1.0)),
                        mini_enganchado, 6, lambda: f"flotante {v.flotante is not None} · visible {v.flotante is not None and v.flotante.isVisible()}")
            def arrastrar_mini():
                f = v.flotante; estado["mini0"] = f.pos().x(); v.activateWindow()
                mover(*fisico(f, 0.5, 0.15)); time.sleep(0.15); arrastrar_hasta = fisico(f, 0.5, 0.15)
                arrastrar((arrastrar_hasta[0], arrastrar_hasta[1]), (arrastrar_hasta[0] - 250, arrastrar_hasta[1] - 150)); vivo(0.6)
            paso_simple("Interfaz (vídeo local): el mini se mueve arrastrándolo con el ratón REAL", arrastrar_mini,
                        lambda: v.flotante is not None and v.flotante.pos().x() < estado["mini0"] - 100, 6,
                        lambda: f"x {v.flotante.pos().x() if v.flotante else '-'} (antes {estado.get('mini0')})")
            paso_simple("Interfaz (vídeo local): Esc REAL devuelve el mini a su sitio", lambda: (v.activateWindow(), v.paginas.setFocus(), tecla_real("escape")),
                        lambda: v.flotante is None and v.rep.actual is not None, 6, lambda: f"flotante {v.flotante is not None}")
            # 22/10/2026 (3.9, audio de Mateo: «no hay manera de quitar el mini reproductor sin parar la música»)
            def quitar_mini():
                v._a_flotante("mini"); vivo(1.0); v.activateWindow()
                estado["pos_q"] = v.rep.pos
                mover(*fisico(v.flotante.quitar, 0.5, 0.5)); time.sleep(0.15); boton(1); vivo(1.5)
            paso_simple("Interfaz (vídeo local): ✕ REAL de la mini la quita y el vídeo SIGUE sonando", quitar_mini,
                        lambda: v.flotante is None and v.rep.actual is not None and not v.rep.pausa and v.rep.pos > estado["pos_q"], 6,
                        lambda: f"flotante {v.flotante is not None} · pausa {v.rep.pausa} · pos {v.rep.pos:.1f} (antes {estado.get('pos_q', 0):.1f})")
            paso_simple("Interfaz (vídeo local): la mini quitada no vuelve sola al cambiar de página", lambda: (v.ir_seccion("historial"), vivo(1.0)),
                        lambda: v.flotante is None and not v.rep.pausa, 4, lambda: f"flotante {v.flotante is not None}")
            paso_simple("Interfaz (vídeo local): al volver al vídeo, la mini puede volver a salir", lambda: (v.paginas.setCurrentWidget(v.video), vivo(0.8)),
                        lambda: not getattr(v, "_mini_quitada", True) and v.flotante is None, 4, lambda: f"quitada {getattr(v, '_mini_quitada', None)}")
            paso_simple("Interfaz (vídeo local): silenciar la pestaña y volver a activarla", lambda: (estado.__setitem__("m0", bool(v.rep.mpv.mute)), v.silenciar_pestana(v.pestana)),
                        lambda: bool(v.rep.mpv.mute) != estado["m0"], 4, lambda: f"silencio {v.rep.mpv.mute}")
            paso_simple("Interfaz (vídeo local): la pestaña vuelve a sonar", lambda: v.silenciar_pestana(v.pestana), lambda: bool(v.rep.mpv.mute) == estado["m0"], 4)
            def cola_supr():
                v.rep.encolar(e_local2); vivo(0.5); v.video.refrescar_cola(); vivo(0.3)
                w = v.video.cola; w.setCurrentRow(1); w.setFocus(); v.activateWindow(); vivo(0.3); tecla_real("delete")
            paso_simple("Interfaz (vídeo local): Supr REAL quita el siguiente de la cola", cola_supr,
                        lambda: len(v.rep.cola) == 1, 6, lambda: f"cola {len(v.rep.cola)}")
            # 06/10/2026: retirado «cerrar → bandeja»; cerrar con vídeo sonando cierra de verdad (lo comprueba el cierre final de la prueba)
            paso_simple("Interfaz (vídeo local): parar", lambda: v.rep.parar() if hasattr(v.rep, "parar") else v.cerrar_pestana(v.pestana), lambda: v.rep.actual is None, 6)
        paso_simple("Interfaz: Mayús+Supr REAL borra una búsqueda de las sugerencias", sugerencia_fuera,
                    lambda: "prueba catode borrar" not in v.datos.busquedas(300) and "⟲  prueba catode borrar" not in v.modelo.stringList(), 4,
                    lambda: f"sugerencias {v.modelo.stringList()[:4]}")
        paso_simple("Interfaz: cerrar pestañas sobrantes deja una", lambda: [v.cerrar_pestana(len(v.pestanas) - 1) for _ in range(len(v.pestanas) - 1)],
                    lambda: len(v.pestanas) == 1, 6)

        paso_simple("Empieza sonando", lambda: setattr(rep.mpv, "pause", False), lambda: not rep.pausa, 3)
        # 04/10/2026: la prueba de fluidez la dejaba a pantalla completa y el doble clic la quitaba (se daba por fallo)
        paso_simple("Empieza en ventana", lambda: v.isFullScreen() and v.pantalla_completa(), lambda: not v.isFullScreen(), 3)
        if os.name == "nt":   # 05/10/2026: «apagar el remoto» (F9): la ventana queda fuera de la captura de pantalla y vuelve
            reales += (("Tecla REAL F9: remoto apagado", lambda: tecla_real("f9"), lambda: v.ajustes.get("apagar_remoto") is True),
                       ("Tecla REAL F9: remoto encendido", lambda: tecla_real("f9"), lambda: v.ajustes.get("apagar_remoto") is False))
        for nombre, accion, cond in reales:
            paso_simple(nombre, accion, cond, 6, lambda: f"pausa={rep.pausa} pos={rep.pos:.0f}/{rep.dur:.0f} completa={v.isFullScreen()} "
                                                     f"teclado={type(QApplication.focusWidget()).__name__}")

        def inicio_flecha():
            v.ir_seccion("inicio"); QApplication.processEvents(); time.sleep(1.5)
            estado["vol"], estado["scroll"] = v.barra.vol.value(), v.pag.rejilla.verticalScrollBar().value()
            v.pag.rejilla.setFocus(); tecla_real("down"); tecla_real("down"); tecla_real("down")
        paso_simple("Inicio: flecha REAL ↓ desplaza (no toca el volumen)", inicio_flecha,
                    lambda: v.barra.vol.value() == estado["vol"] and v.pag.rejilla.verticalScrollBar().value() > estado["scroll"], 6,
                    lambda: f"volumen {estado.get('vol')}→{v.barra.vol.value()} desplazamiento {estado.get('scroll')}→{v.pag.rejilla.verticalScrollBar().value()}")

        def previa_raton():   # 03/10/2026: con el ratón de verdad (antes solo por código y en Linux no salía)
            v.ir_seccion("inicio"); QApplication.processEvents(); time.sleep(1.5)
            t = next(x for x in v.pag.rejilla.widgets if x.isVisible() and getattr(x, "e", None) and x.e.tipo == "VIDEO")
            v.activateWindow(); mover(*fisico(t, 0.5, 0.3)); time.sleep(0.2); mover(*fisico(t, 0.52, 0.32))
        paso_simple("Vista previa con el ratón REAL encima de una tarjeta", previa_raton,
                    lambda: v.previa.mpv is not None and v.previa.zona.isVisible() and (v.previa.mpv.time_pos or 0) > 0.5 and previa_dentro(), 30,
                    lambda: f"pos {v.previa.mpv.time_pos if v.previa.mpv else None} · zona visible {v.previa.zona.isVisible()}")
        paso_simple("Vista previa: al quitar el ratón se para", lambda: (mover(*fisico(v.arriba, 0.5, 0.5)), time.sleep(0.3)),
                    lambda: not v.previa.zona.isVisible(), 4)

        def atras_raton():
            estado["pag"] = v.paginas.currentWidget()
            v.abrir_video(rep.actual, sonar=False); QApplication.processEvents(); time.sleep(1)
            v.activateWindow(); mover(*fisico(v.video.titulo, 0.5, 0.5)); time.sleep(0.15); boton(8)
        paso_simple("Botón REAL «atrás» del ratón", atras_raton, lambda: v.paginas.currentWidget() is not v.video, 6)

        # ---- pestañas como las usa una persona (03/10/2026: con tres pestañas los mandos eran los del primer vídeo y
        # tapaban el Inicio; el botón central de la rueda no cerraba) ----
        def punto(w, p):
            g = w.mapToGlobal(p); ratio = w.devicePixelRatioF() if os.name != "nt" else (w.screen() or QApplication.primaryScreen()).devicePixelRatio()
            return int(g.x() * ratio), int(g.y() * ratio)

        def pestana_central(i):
            v.activateWindow(); mover(*punto(v.barra_pestanas, v.barra_pestanas.tabRect(i).center())); time.sleep(0.15); boton(2)
        e2 = motor.Elemento("VIDEO", VIDEO_CAPITULOS, "Prueba pestaña", "", "", motor.miniatura(motor.id_video(VIDEO_CAPITULOS)))

        def pestana_dos():
            v.abrir_video(rep.actual, sonar=False); vivo(0.5)   # la pestaña 1 se deja en su vídeo (al volver, deben salir sus mandos)
            v.nueva_pestana(e2); v.reps[1].mpv.mute = True
        paso_simple("Pestaña 2 con vídeo: suena la suya y la 1 sigue", pestana_dos,
                    lambda: len(v.reps) == 2 and v.rep is v.reps[1] and v.reps[1].pos > 0 and not rep.pausa, 25,
                    lambda: f"pos1={rep.pos:.0f} pos2={v.reps[1].pos:.0f}")

        def pestana_tres():
            v.nueva_pestana(); vivo(1.5)
            t = next((w for w in v.pag.rejilla.widgets if w.isVisible()), None)
            if t is not None:
                mover(*fisico(t, 0.5, 0.5)); vivo(0.3)
            estado["bajo"] = type(QApplication.widgetAt(QCursor.pos())).__name__
        paso_simple("Pestaña 3 nueva (Inicio): mandos fuera, el Inicio se puede pulsar", pestana_tres,
                    lambda: not v.controles.isVisible() and v.paginas.currentWidget() is v.pag
                    and not v.controles.isAncestorOf(QApplication.widgetAt(QCursor.pos()) or v), 6,
                    lambda: f"mandos visibles={v.controles.isVisible()} bajo el ratón: {estado.get('bajo')}")

        def pestana_tres_video():
            v.abrir(rep.actual); fin = time.time() + 25
            while time.time() < fin and not (v.reps[2].pos > 0 and v.controles.isVisible()):
                vivo(0.2)
            v.reps[2].mpv.mute = True
            estado["p1"], estado["p3"] = rep.pausa, v.reps[2].pausa
            en_video(0.4, 0.4); vivo(0.2); en_video(0.6, 0.6); vivo(0.6)   # salen los mandos
            mover(*fisico(v.controles.play, 0.5, 0.5)); time.sleep(0.15); boton(1)
        paso_simple("Pestaña 3 con vídeo: el play REAL de los mandos pausa ESTE vídeo, no el primero", pestana_tres_video,
                    lambda: v.reps[2].pausa != estado["p3"] and rep.pausa == estado["p1"], 6,
                    lambda: f"pausa1={rep.pausa} pausa3={v.reps[2].pausa} mandos={v.controles.isVisible()}")
        paso_simple("Clic REAL en el vídeo de la pestaña 3: sigue", lambda: (estado.__setitem__("p3", v.reps[2].pausa), clic_real()),
                    lambda: v.reps[2].pausa != estado["p3"] and rep.pausa == estado["p1"], 6)
        paso_simple("Botón central REAL sobre la pestaña 2: se cierra", lambda: pestana_central(1),
                    lambda: len(v.pestanas) == 2 and v.barra_pestanas.count() == 2 and len(v.reps) == 2, 6,
                    lambda: f"{len(v.pestanas)} pestañas")
        paso_simple("Botón central REAL sobre la activa: se cierra y vuelve la 1, que sigue sonando", lambda: pestana_central(1),
                    lambda: len(v.pestanas) == 1 and v.rep is rep and rep.actual is not None and not rep.pausa
                    and v.paginas.currentWidget() is v.video and v.controles.isVisible(), 8,
                    lambda: f"{len(v.pestanas)} pestañas · pausa1={rep.pausa} · mandos={v.controles.isVisible()}")

        # ---- esfuerzo (03/10/2026: en el mini PC, con tres pestañas y el remoto, Cat-ode «dejó de responder») ----
        estado["vivo"] = 0
        def tres_pestanas():   # cuatro, como las abrió el autor
            for _ in range(3):
                v.nueva_pestana(e2); v.reps[-1].mpv.mute = True; QApplication.processEvents(); time.sleep(1)
        paso_simple("Esfuerzo: cuatro pestañas con vídeo a la vez", tres_pestanas,
                    lambda: len(v.reps) == 4 and all(r.pos > 0 for r in v.reps), 60,
                    lambda: " · ".join(f"{r.pos:.0f} s" for r in v.reps))
        def saltar():
            for i in range(12):
                v.barra_pestanas.setCurrentIndex(i % 4); QApplication.processEvents(); time.sleep(0.35)
            estado["vivo"] = time.time()
        paso_simple("Esfuerzo: saltar 12 veces entre las cuatro sin colgarse", saltar,
                    lambda: estado["vivo"] and time.time() - estado["vivo"] < 30 and all(not r.pausa for r in v.reps), 20,
                    lambda: " · ".join(f"{r.pos:.0f} s" for r in v.reps))
        paso_simple("Esfuerzo: cerrar las tres de más", lambda: (v.cerrar_pestana(3), QApplication.processEvents(), v.cerrar_pestana(2), QApplication.processEvents(), v.cerrar_pestana(1)),
                    lambda: len(v.pestanas) == 1 and v.rep is rep and not rep.pausa, 8, lambda: f"{len(v.pestanas)} pestañas")
    if os.name == "nt" and os.environ.get("CATODE_CAPTURA_VENTANA"):   # la ventana entera, para revisar cómo queda
        carpeta = os.environ["CATODE_CAPTURA_VENTANA"]

        def foto(n):
            os.makedirs(carpeta, exist_ok=True)
            v.raise_(); v.activateWindow()
            fin = time.time() + 0.6   # dejando correr la interfaz (fundidos, imágenes)
            while time.time() < fin:
                QApplication.processEvents(); time.sleep(0.02)
            captura_ventana_windows(int(v.winId()), os.path.join(carpeta, n + ".png"), v.controles)
        paso_simple("Foto: vídeo con mandos", lambda: (v.controles.mostrar(), foto("video_mandos")), lambda: True, 2)
        paso_simple("Foto: pantalla completa", lambda: (v.pantalla_completa(), time.sleep(1.5), v.controles.mostrar(), foto("completa"),
                                                       v.pantalla_completa()), lambda: True, 3)
        def foto_inicio():
            v.ir_seccion("inicio")
            fin = time.time() + 4
            while time.time() < fin:
                QApplication.processEvents(); time.sleep(0.03)
            foto("inicio")
            r = v.pag.rejilla if hasattr(v.pag, "rejilla") else None
            t = next((w for w in getattr(r, "widgets", []) if w.isVisible()), None)
            if t is not None:   # el ratón encima de la primera tarjeta: así se ve cómo queda el resaltado
                import ctypes
                g = t.mapToGlobal(t.rect().center())
                ctypes.windll.user32.SetCursorPos(g.x(), g.y())
                fin = time.time() + 0.8
                while time.time() < fin:
                    QApplication.processEvents(); time.sleep(0.03)
                foto("inicio_raton")

        def foto_video():
            v.abrir_video(rep.actual, sonar=False)
            fin = time.time() + 5
            while time.time() < fin:
                QApplication.processEvents(); time.sleep(0.03)
            foto("ficha")
            v.info_datos = getattr(v.video, "datos", None)
            v.ir_seccion("ajustes") if hasattr(v, "ir_seccion") else None
            fin = time.time() + 1.5
            while time.time() < fin:
                QApplication.processEvents(); time.sleep(0.03)
            foto("ajustes")
        paso_simple("Foto: Inicio", foto_inicio, lambda: True, 8)
        paso_simple("Foto: ficha y ajustes", foto_video, lambda: True, 9)
    paso_simple("Ficha del vídeo", lambda: None, lambda: v.video.ficha is not None and v.video.titulo.text() not in ("", "Cargando…"), 30,
                lambda: v.video.titulo.text()[:50])
    paso_simple("«A continuación»", lambda: None, lambda: len(v.video.relacionados.widgets) >= 5, 30,
                lambda: f"{len(v.video.relacionados.widgets)} relacionados")
    paso_simple("Capítulos", lambda: None, lambda: v.video.capitulos.count() > 1, 20,
                lambda: f"{max(0, v.video.capitulos.count() - 1)} capítulos")
    # 03/10/2026: transcripción con buscador
    paso_simple("Transcripción: líneas con su minuto", lambda: v.video._alternar_transcripcion(),
                lambda: v.video.tr_caja.isVisible() and v.video.tr_lista.count() > 20, 30,
                lambda: f"{v.video.tr_lista.count()} líneas · {v.video.tr_aviso.text()[:50]}")
    paso_simple("Transcripción: buscar una palabra filtra", lambda: v.video.tr_buscar.setText("roma"),
                lambda: 0 < sum(1 for i in range(v.video.tr_lista.count()) if not v.video.tr_lista.item(i).isHidden()) < v.video.tr_lista.count(), 5,
                lambda: f"{sum(1 for i in range(v.video.tr_lista.count()) if not v.video.tr_lista.item(i).isHidden())} con «roma»")
    paso_simple("Transcripción: clic en una línea salta a su minuto",
                lambda: (v.video.tr_buscar.setText(""), v.video.tr_lista.itemClicked.emit(v.video.tr_lista.item(min(40, v.video.tr_lista.count() - 1)))),
                lambda: 0 <= rep.pos - v.video.tr_lista.item(min(40, v.video.tr_lista.count() - 1)).data(Qt.UserRole) < 25, 15,
                lambda: f"pos {rep.pos:.0f} s")
    paso_simple("Transcripción: se pliega", v.video._alternar_transcripcion, lambda: not v.video.tr_caja.isVisible(), 3)
    paso_simple("Comentarios", v.video._cargar_comentarios, lambda: v.video.comentarios.count() >= 5, 30,
                lambda: f"{v.video.comentarios.count()} comentarios")
    paso_simple("Saltar a un capítulo", lambda: v.saltar(VIDEO_CAPITULOS, 120), lambda: rep.pos >= 118, 20, lambda: f"en {rep.pos:.0f} s")
    paso_simple("Velocidad 1,5×", lambda: rep.velocidad(1.5), lambda: abs(rep.mpv.speed - 1.5) < 0.01, 5)
    paso_simple("Solo sonido", lambda: rep.solo_sonido(True), lambda: str(rep.mpv.vid) in ("False", "no", "None"), 10,
                lambda: f"vid={rep.mpv.vid}")
    paso_simple("Volver a la imagen", lambda: (rep.solo_sonido(False), rep.velocidad(1.0)), lambda: rep.mpv.vid not in (False, "no", None), 10)

    esperado = {}

    def a_continuacion():
        rel = v.video.rel
        esperado["id"] = motor.id_video(rel[0].url)
        v.encolar(rel[1])
        v.a_continuacion(rel[0])
    paso_simple("Cola y «a continuación»", a_continuacion,
                lambda: len(rep.cola) == 3 and motor.id_video(rep.cola[1].url) == esperado["id"], 10,
                lambda: f"cola de {len(rep.cola)}")
    paso_simple("Siguiente de la cola", rep.siguiente,
                lambda: rep.actual is not None and motor.id_video(rep.actual.url) == esperado["id"] and rep.pos > 1, 40,
                lambda: (rep.actual.titulo[:40] if rep.actual else ""))

    def guardar_pos():
        v._guardar_posicion()
    paso_simple("Guardar por dónde va", guardar_pos, lambda: (guardar_pos() or True) and v.datos.posicion(rep.actual.url)[0] > 0, 20,
                lambda: f"{v.datos.posicion(rep.actual.url)} · suena {rep.pos:.0f}/{rep.dur:.0f} s")
    e_prueba = motor.Elemento("VIDEO", VIDEO_CAPITULOS, "Prueba", "", "", motor.miniatura(motor.id_video(VIDEO_CAPITULOS)))
    paso_simple("Ver más tarde (poner y quitar)", lambda: (v.datos.alternar("despues", e_prueba), v.datos.alternar("despues", e_prueba)),
                lambda: not v.datos.contiene("despues", e_prueba.url), 5)
    # 03/10/2026: lo que pidió el autor a la vista: visualizaciones y fecha bajo el título, números en 👍 👎, y «No me gusta»
    paso_simple("Bajo el título: visualizaciones y fecha", lambda: None,
                lambda: "visualizaciones" in v.video.resumen.text() and "·" in v.video.resumen.text(), 15, lambda: v.video.resumen.text()[:80])
    paso_simple("Botones 👍 👎 con los números", lambda: None,
                lambda: v.video.megusta.text() not in ("👍  Me gusta", "") and v.video.nomegusta.text().startswith("👎  ≈"), 20,
                lambda: f"{v.video.megusta.text()} / {v.video.nomegusta.text()}")

    def no_me_gusta():
        v.video.megusta.click(); v.video.nomegusta.click()   # 👎 quita 👍
    paso_simple("«No me gusta» (y quita «Me gusta»)", no_me_gusta,
                lambda: v.video.e and v.datos.contiene("nomegusta", v.video.e.url) and not v.datos.contiene("megusta", v.video.e.url)
                and v.video.nomegusta.isChecked() and not v.video.megusta.isChecked(), 5)
    paso_simple("Quitar «No me gusta»", lambda: v.video.nomegusta.click(), lambda: not v.datos.contiene("nomegusta", v.video.e.url), 5)
    paso_simple("Menú del vídeo y compartir", lambda: (__import__("catode.tarjetas", fromlist=["x"]).menu_video(v, e_prueba),
                                                   __import__("catode.tarjetas", fromlist=["x"]).menu_compartir(v, e_prueba, 90)),
                lambda: True, 2)
    # 03/10/2026: la grabación de un directo: solo DASH por trozos sin duración (no cargaba nunca: mpv -16)
    VIDEO_DASH = "https://www.youtube.com/watch?v=7Z3ZGj2RKvE"   # «WWII Restored | From the Fall of France…»
    paso_simple("Vídeo solo DASH por trozos: empieza", lambda: v.abrir_enlace(VIDEO_DASH),
                lambda: rep.actual is not None and motor.id_video(rep.actual.url) == motor.id_video(VIDEO_DASH) and rep.pos > 2, 45,
                lambda: f"en {rep.pos:.0f} s · {rep.mpv.video_format}")
    paso_simple("Enlace con minuto (t=)", lambda: v.abrir_enlace(f"https://youtu.be/{motor.id_video(VIDEO_CAPITULOS)}?t=300"),
                lambda: rep.actual is not None and motor.id_video(rep.actual.url) == motor.id_video(VIDEO_CAPITULOS) and rep.pos >= 298, 40,
                lambda: f"en {rep.pos:.0f} s")
    # 03/10/2026: la miniatura del momento al pasar por la barra (storyboard de YouTube)
    from PySide6.QtCore import QPoint
    paso_simple("Miniatura al pasar por la barra", lambda: v.controles.vista.mostrar(rep, 0.5, QPoint(600, 600)),
                lambda: rep.storyboard and v.controles.vista.isVisible() and v.controles.vista.pixmap() and not v.controles.vista.pixmap().isNull()
                and (v.controles.vista.mostrar(rep, 0.5, QPoint(600, 600)) or True) and not v.controles.vista.pixmap().isNull(), 15,
                lambda: f"storyboard {bool(rep.storyboard)} · {len((rep.storyboard or {}).get('mosaicos', []))} mosaicos · hora {v.controles.vista.text()}")
    paso_simple("La miniatura se esconde al salir de la barra", v.controles.vista.hide, lambda: not v.controles.vista.isVisible(), 3)
    paso_simple("Subtítulos disponibles", lambda: None, lambda: len(rep.subtitulos()) >= 1, 20, lambda: f"{len(rep.subtitulos())} pistas")
    seccion("Ver más tarde (página)", lambda: v.ir_seccion("despues"), 0, 5)
    seccion("Listas (página)", lambda: v.ir_seccion("listas"), 0, 5)
    seccion("Descargas (página)", lambda: v.ir_seccion("descargas"), 0, 5)
    paso_simple("Ajustes", lambda: v.ir_seccion("ajustes"), lambda: v.paginas.currentWidget() is v.opciones, 5)

    def cuenta_miembros():
        # 18/10/2026: sin nombres de cuenta en lo que se reparte: CATODE_PRUEBA_MIEMBROS=«navegador:nombre» (la pone
        # pruebas/windows_bateria.sh) o la cuenta elegida en Ajustes; sin ninguna, el paso no tiene nada que localizar
        from . import miembros, cuenta
        nav, _, nombre = os.environ.get("CATODE_PRUEBA_MIEMBROS", "").partition(":")
        elegida = {"navegador": nav, "nombre": nombre} if nombre else v.ajustes.get("cuenta_miembros")
        if not (elegida or {}).get("nombre"):
            estado["miembros"] = "sin cuenta de miembros elegida"
            return True
        estado["miembros"] = miembros.localizar({"cuenta_miembros": elegida}) or ("sin sesión de YouTube en este equipo" if not cuenta.navegadores() else None)
        return estado["miembros"] is not None
    paso_simple("Vídeos de miembros: la cuenta elegida se localiza en el navegador", lambda: None, cuenta_miembros, 30,
                lambda: str(estado.get("miembros")))
    # 03/10/2026: flechas ← → de la barra (como el navegador) y cerrar la última pestaña
    paso_simple("Flecha ← vuelve a la sección anterior", lambda: (v.ir_seccion("historial"), v.ir_seccion("despues"), v.b_atras.click()),
                lambda: v.pila and v.pila[-1][0] == v.historial and v.b_adelante.isEnabled(), 6,
                lambda: f"pila {len(v.pila)} · adelante activo {v.b_adelante.isEnabled()}")
    paso_simple("Flecha → deshace el atrás", lambda: v.b_adelante.click(), lambda: v.pila and v.pila[-1][0] == v.despues and not v.b_adelante.isEnabled(), 6)
    paso_simple("Cerrar la última pestaña: se para el vídeo y queda el Inicio", lambda: v.cerrar_pestana(0),
                lambda: len(v.pestanas) == 1 and v.rep.actual is None and v.paginas.currentWidget() is v.pag and len(v.pila) == 1, 8,
                lambda: f"pestañas {len(v.pestanas)} · suena {v.rep.actual is not None} · pila {len(v.pila)}")

    if os.environ.get("CATODE_PRUEBA_INTERFAZ"):   # 05/10/2026: funciones de la interfaz, SIN RED (ninguna petición a YouTube)
        pasos[:] = [p for p in pasos if p[0].startswith(("Interfaz", "Flecha "))]
    desde = os.environ.get("CATODE_PRUEBA_DESDE", "")   # p. ej. «Reproducir»: empieza por ese paso (para repetir solo una parte)
    if desde:
        k = next((n for n, (nombre, _) in enumerate(pasos) if nombre.startswith(desde)), 0)
        del pasos[:k]
    solo = [x for x in os.environ.get("CATODE_PRUEBA_SOLO", "").split(",") if x]   # «Shorts,Inicio»: solo esos pasos
    if solo:
        pasos[:] = [p for p in pasos if any(p[0].startswith(x) for x in solo)]

    def siguiente_paso(i=0):
        if i >= len(pasos):
            bien = sum(1 for _, b in resultados if b)
            print(f"--- {bien}/{len(resultados)} pruebas bien", flush=True)
            if os.path.exists(barra):
                subprocess.run([barra, "fin", "catode-prueba"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            v.codigo_salida = 0 if bien == len(resultados) else 1
            v._saliendo = True   # 05/10/2026: con vídeo sonando, cerrar ya no sale (va a la bandeja): aquí se sale de verdad
            v.close()   # como al cerrar la ventana: para todos los reproductores (03/10/2026: salir sin cerrarla reventaba en Windows)
            QTimer.singleShot(2000, lambda: app.exit(0 if bien == len(resultados) else 1))   # que mpv termine de parar
            return
        pasos[i][1](lambda: QTimer.singleShot(300, lambda: siguiente_paso(i + 1)))
    avance()
    QTimer.singleShot(2500, siguiente_paso)
