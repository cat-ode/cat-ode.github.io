"""Cat-ode escritorio · «Traer mi YouTube» como servicio (18/10/2026), para la interfaz web (servidor_web.py, rutas
/api/cuenta) y para la Qt (interfaz.py, Ajustes). Orden del autor: «quiero que coja los canales de mi otra cuenta de youtube
(que configuraré desde la propia app e importará en local todos los datos de la cuenta)» y «la opción traer desde youtube
tiene que tener una opción de "actualizar cuenta desde youtube", por si se han suscrito nuevos canales y otra de
"actualizar youtube desde cat-ode"».

Un trabajo cada vez, en su hilo; lo que pasa sale por emitir("cuenta", {fase, texto, fraccion, hecho, resumen, error,
plan}). Fases: «leer» (A, Actualizar cuenta desde YouTube), «plan» y «aplicar» (B, Actualizar YouTube desde Cat-ode).

De dónde sale la sesión de YouTube («origen»):
- «app»: la ventana de Google DENTRO de Cat-ode (Windows, interfaz_web.VentanaCuenta); pedir_galletas(listo) la abre si
  hace falta y llama listo(galletas) o listo(None, motivo);
- un navegador de este equipo («firefox», «chrome»…: cuenta.navegadores()), el respaldo si Google no deja entrar;
- «falsa» (solo con CATODE_PRUEBA_INTERFAZ): un YouTube de mentira en memoria (_SesionFalsa), para probar los botones sin
  red. Ni una petición sale del equipo."""
import json
import os
import secrets
import threading
import time
import urllib.error

from . import cuenta

EVENTO = "cuenta"


def _registro(texto):
    try:
        from .resolutor import registro
        registro(texto)
    except Exception:   # noqa: BLE001
        pass


class CuentaServicio:
    def __init__(self, datos, emitir, pedir_galletas=None, borrar_galletas=None, falsa=None, cerrar_galletas=None):
        self.datos = datos
        self.emitir = emitir
        self.pedir_galletas = pedir_galletas        # lo pone la ventana web de Windows
        self.borrar_galletas = borrar_galletas
        # 18/10/2026 (hallazgo 13): cierra la ventana de Google si se cancela o se acaba el tiempo de entrar
        self.cerrar_galletas = cerrar_galletas
        self.falsa = bool(os.environ.get("CATODE_PRUEBA_INTERFAZ")) if falsa is None else bool(falsa)
        self.pausa = 0.05 if self.falsa else cuenta.PAUSA
        self._cerrojo = threading.Lock()
        self._hilo = None
        self._fase = ""
        self._parar = threading.Event()
        self._plan = None
        self._sesion_plan = None
        self._ultimo = {}

    # ---------------------------------------------------------------- estado
    def origen(self):
        """El origen elegido (guardado), o el que toca: la app si hay ventana de Google; si no, un navegador."""
        if self.falsa:
            return "falsa"
        o = cuenta.estado_cuenta().get("origen")
        if o:
            return o
        return "app" if self.pedir_galletas else None

    def estado(self):
        est = cuenta.estado_cuenta()
        n_hist, n_subs = self.datos.cuantos("historial"), self.datos.cuantos("suscripciones")
        r = {"origen": self.origen(), "nombre_origen": self._nombre_origen(self.origen()), "ventana": bool(self.pedir_galletas),
             "trabajando": self._fase, "ultimo": self._ultimo, "destino": est.get("destino"),
             "ultima_lectura": est.get("ultima_lectura"), "sesion": bool(est.get("sesion")) or self.falsa,
             "historial": n_hist, "suscripciones": n_subs,
             "plan": self._vista_plan(self._plan) if self._plan else None}
        if self.falsa:
            r["falsa"] = {"llamadas": list(_SesionFalsa.unica().llamadas)}
        return r

    @staticmethod
    def _nombre_origen(o):
        if o == "app":
            return "la sesión de Google de Cat-ode"
        if o == "falsa":
            return "la cuenta de prueba"
        if o:
            return f"la sesión de {cuenta.NOMBRES.get(o, o)} de este equipo"
        return ""

    # ---------------------------------------------------------------- órdenes
    def accion(self, accion, **k):
        """Las órdenes de la página o de la Qt. Las largas vuelven al momento ({empezado}) y siguen por el evento."""
        if accion == "estado":
            return self.estado()
        if accion == "actualizar_cuenta":
            if k.get("origen"):
                self._poner_origen(k["origen"])
            return self._lanzar("leer", self._leer)
        if accion == "plan":
            if k.get("origen"):
                self._poner_origen(k["origen"])
            return self._lanzar("plan", lambda: self._planear(k.get("destino")))
        if accion == "aplicar":
            plan = self._plan
            if not plan or (k.get("plan") and k["plan"] != plan["id"]):
                return {"error": "Ese plan ya no vale: vuelve a pulsar «Actualizar YouTube desde Cat-ode»"}
            return self._lanzar("aplicar", lambda: self._aplicar(plan))
        if accion == "cancelar":
            self._parar.set()
            return {"cancelado": True}
        if accion == "olvidar_plan":
            self._plan = self._sesion_plan = None
            return {}
        if accion == "origen":
            self._poner_origen(k.get("origen"))
            return self.estado()
        if accion == "navegadores":
            return {"navegadores": [{"clave": c, "nombre": n} for c, n in (cuenta.navegadores() if not self.falsa else [])]}
        if accion == "cerrar_sesion":
            return self._cerrar_sesion()
        if accion == "importar_musica":   # 22/10/2026: «Importar tu música» (YouTube Music, Spotify, Amazon Music, carpeta, CSV)
            return self._lanzar("musica", lambda: self._importar_musica(k.get("via", ""), k.get("valor", "")))
        return None

    def _importar_musica(self, via, valor):
        """Orden del autor (22/10/2026): «quien use Catode redistributable debe poder importar en local su biblioteca de spotify,
        amazon music y youtube music». Todo en este aparato (importar_musica.py); al acabar, la sección Música se repinta."""
        from . import importar_musica as im
        nombres = {"youtube": "YouTube Music", "spotify_archivo": "Spotify", "spotify_enlace": "Spotify", "amazon_enlace": "Amazon Music",
                   "csv": "el CSV", "carpeta": "tu carpeta"}
        self._evento("musica", texto=f"Importando {nombres.get(via, 'tu música')}…")
        if via == "youtube":
            res, fuente = im.youtube_music(self._sesion("musica").g, aviso=lambda t: self._evento("musica", texto=t)), "youtube"
        elif via == "spotify_archivo":
            res, fuente = im.spotify_archivo(valor), "spotify"
        elif via == "spotify_enlace":
            res, fuente = im.spotify_enlace(valor), "spotify"
        elif via == "csv":
            res, fuente = im.csv_archivo(valor), "csv"
        elif via == "carpeta":
            res, fuente = im.carpeta(valor), "carpeta"
        else:
            raise RuntimeError("No sé importar de ahí")
        nl, nc = im.guardar(self.datos, fuente, res)
        if not nc:
            raise RuntimeError("No había ninguna canción que importar")
        self._evento("musica", hecho=True, resumen=f"Importada{'' if nc == 1 else 's'} {nc} canci{'ón' if nc == 1 else 'ones'} en {nl} lista{'' if nl == 1 else 's'} de {nombres.get(via, 'tu música')}")

    def _poner_origen(self, origen):
        if origen in (None, "", "app") or origen in cuenta.NOMBRES or origen == "falsa":
            cuenta.guardar_estado_cuenta({"origen": origen or None})

    def _lanzar(self, fase, trabajo):
        with self._cerrojo:
            if self._hilo is not None and self._hilo.is_alive():
                return {"ocupado": True, "fase": self._fase}
            self._fase = fase
            self._parar.clear()
            self._hilo = threading.Thread(target=self._correr, args=(fase, trabajo), daemon=True, name=f"cuenta-{fase}")
            self._hilo.start()
        return {"empezado": True, "fase": fase}

    def _correr(self, fase, trabajo):
        try:
            trabajo()
        except Exception as error:   # noqa: BLE001
            self._evento(fase, hecho=True, error=self._texto_error(error))
        finally:
            self._fase = ""

    def _evento(self, fase, **d):
        d["fase"] = fase
        d.setdefault("hecho", False)
        if d.get("hecho"):
            self._ultimo = dict(d)
            _registro(f"cuenta: {fase} → {d.get('resumen') or d.get('error') or 'plan listo'}"[:300])
        try:
            self.emitir(EVENTO, d)
        except Exception:   # noqa: BLE001
            pass

    @staticmethod
    def _texto_error(error):
        try:
            from .servicio import clasificar, marcar_bloqueo
            clase, texto, _ = clasificar(error)
            if clase == "bloqueo":
                marcar_bloqueo()
                return "YouTube ha frenado las peticiones: no insisto. Prueba más tarde."
            if isinstance(error, (RuntimeError, ValueError)):
                return str(error)[:200]
            return texto
        except Exception:   # noqa: BLE001
            return str(error)[:200]

    # ---------------------------------------------------------------- la sesión
    def _sesion(self, fase):
        """La sesión de YouTube del origen elegido (puede esperar a que el autor entre en Google en la ventana)."""
        if self.falsa:
            return _SesionFalsa.unica()
        o = self.origen()
        if o == "app" and self.pedir_galletas:
            return cuenta.abrir(self._galletas_app(fase))
        if not o or o == "app":
            self._evento(fase, texto="Buscando una sesión de YouTube en los navegadores de este equipo…")
            navs = cuenta.navegadores()
            if not navs:
                raise RuntimeError("No hay ninguna sesión de YouTube abierta en Firefox, Chrome, Edge o Brave de este equipo")
            o = navs[0][0]
            cuenta.guardar_estado_cuenta({"origen": o})   # la próxima vez, sin volver a buscar
        return cuenta.abrir(o)

    def _galletas_app(self, fase):
        self._evento(fase, texto="Abriendo YouTube en la ventana de Google de Cat-ode…")
        listo, res = threading.Event(), {}

        def al_acabar(galletas, motivo=None):
            res["g"], res["motivo"] = galletas, motivo
            listo.set()
        self.pedir_galletas(al_acabar)
        t0 = time.time()
        avisado = False
        while not listo.wait(1.0):
            if self._parar.is_set() or time.time() - t0 > 20 * 60:   # el tiempo de la contraseña y del segundo paso
                if self.cerrar_galletas:   # 18/10/2026 (hallazgo 13): que la ventana de Google no se quede abierta
                    try:
                        self.cerrar_galletas()
                    except Exception as error:   # noqa: BLE001
                        _registro(f"cuenta: no he podido cerrar la ventana de Google ({error!r})"[:200])
                raise RuntimeError("Sin entrar en Google: cancelado")
            if not avisado and time.time() - t0 > 4:   # la sesión guardada no ha bastado: hay que entrar
                self._evento(fase, texto="Entra con tu cuenta de Google en la ventana que se ha abierto…")
                avisado = True
        if not res.get("g"):
            raise RuntimeError(res.get("motivo") or "No se ha entrado en Google. Puedes usar la sesión de Firefox de este equipo.")
        cuenta.guardar_estado_cuenta({"sesion": True})
        return res["g"]

    def _cerrar_sesion(self):
        if self._hilo is not None and self._hilo.is_alive():
            return {"ocupado": True, "fase": self._fase}
        if self.borrar_galletas and self.origen() == "app":
            try:
                self.borrar_galletas()
            except Exception as error:   # noqa: BLE001
                _registro(f"cuenta: no he podido borrar las galletas ({error!r})"[:200])
        # sin sesión, la foto ya no dice nada (otra cuenta tendría otros canales): se olvida con el destino y el origen
        cuenta.guardar_estado_cuenta({"sesion": False, "origen": None, "destino": None, "foto": {}, "lecturas": {}})
        self._plan = self._sesion_plan = None
        self._ultimo = {}
        if self.falsa:
            _SesionFalsa.unica().llamadas.clear()
        return self.estado()

    # ---------------------------------------------------------------- A · Actualizar cuenta desde YouTube
    def _leer(self):
        s = self._sesion("leer")
        self._evento("leer", texto="Leyendo tu YouTube…")
        # 18/10/2026 (hallazgo 4): Cancelar y un 429 paran la lectura entre página y página, con pausa entre peticiones;
        # (hallazgos 7 y 8) con los datos, para no traer como nuevo lo ya conocido ni lo borrado
        leido = cuenta.leer(s, aviso=lambda t: self._evento("leer", texto=t), parar=self._parar.is_set,
                            pausa=(0.0 if self.falsa else cuenta.PAUSA_LECTURA), datos=self.datos)
        resumen, n = cuenta.volcar_nuevo(self.datos, leido)
        self._evento("leer", hecho=True, resumen=resumen, cuentas=n, identidades=len(leido.get("cuentas") or []))

    # ---------------------------------------------------------------- B · Actualizar YouTube desde Cat-ode
    def _planear(self, destino_clave=None):
        s = self._sesion("plan")
        s.parar, s.pausa = self._parar.is_set, (0.0 if self.falsa else cuenta.PAUSA_LECTURA)   # 18/10/2026 (hallazgo 4)
        self._evento("plan", texto="Buscando tus cuentas y canales de YouTube…")
        ids = cuenta.identidades(s, aviso=lambda t: self._evento("plan", texto=t))
        if not ids:
            raise RuntimeError("YouTube no ha reconocido la sesión (vuelve a entrar y repite)")
        guardada = cuenta.estado_cuenta().get("destino")
        if destino_clave:
            guardada = {"clave": destino_clave}
        destino = cuenta.elegir_destino(ids, guardada)
        if destino_clave:   # «recordar la elegida»
            cuenta.guardar_estado_cuenta({"destino": {"clave": destino["clave"], "au": destino["au"], "pagina": destino["pagina"],
                                                      "nombre": destino["nombre"]}})
        plan = cuenta.plan_youtube(self.datos, s, destino, aviso=lambda t: self._evento("plan", texto=t),
                                   parar=self._parar.is_set, pausa=(0.0 if self.falsa else cuenta.PAUSA_LECTURA))
        plan["id"] = secrets.token_hex(6)
        plan["identidades"] = [{"clave": i["clave"], "nombre": i["nombre"], "au": i["au"], "pagina": i["pagina"]} for i in ids]
        self._plan, self._sesion_plan = plan, s
        self._evento("plan", hecho=True, plan=self._vista_plan(plan))

    @staticmethod
    def _vista_plan(plan):
        """Lo que enseña el diálogo de confirmación: números, nombres de los canales y las identidades para elegir."""
        n = cuenta.numeros_plan(plan)
        return {"id": plan["id"], "numeros": n, "identidad": plan["identidad"], "identidades": plan.get("identidades") or [],
                "suscribir": [c["titulo"] for c in plan["suscribir"]], "quitar": [c["titulo"] for c in plan["quitar"]],
                "sin_identificar": plan.get("sin_identificar") or [],
                "sin_leer": [k for k in ("megusta", "despues") if plan.get(k) is None],
                "vacio": not (n["suscribir"] or n["quitar"] or n["megusta"] or n["despues"])}

    def _aplicar(self, plan):
        s = self._sesion_plan or self._sesion("aplicar")
        destino = plan["identidad"]
        cuenta.guardar_estado_cuenta({"destino": {"clave": destino["clave"], "au": destino["au"], "pagina": destino["pagina"],
                                                  "nombre": destino["nombre"]}})

        def progreso(hecho, total, texto):
            self._evento("aplicar", texto=texto or "Aplicando…", fraccion=(hecho / total) if total else 1.0)
        r = cuenta.aplicar(s, plan, aviso=lambda t: self._evento("aplicar", texto=t), progreso=progreso, pausa=self.pausa,
                           parar=self._parar.is_set)
        self._plan = self._sesion_plan = None
        self._evento("aplicar", hecho=True, resumen=r["resumen"], resultado={k: r[k] for k in ("hechos", "fallos", "parado", "quedan")})


# ==================================================================================================== YouTube de mentira
def _uc(n):
    return ("UC" + f"catodeprueba{n:02d}").ljust(24, "x")[:24]


def _vid(n):
    return f"catodevid{n:02d}"[:11]


class _SesionFalsa(cuenta._Sesion):
    """Un YouTube de prueba en memoria con las respuestas de innertube que lee cuenta.py (cuentas, suscripciones,
    historial, «Me gusta», «Ver más tarde», listas, resolve_url) y las órdenes de B. Apunta cada orden en «llamadas».
    fallar = {"tipo": "429"|"error", "desde": n}: la orden n-ésima (y las siguientes) falla así (para las pruebas)."""
    _yo = None

    @classmethod
    def unica(cls):
        if cls._yo is None:
            cls._yo = cls()
        return cls._yo

    def __init__(self):   # noqa: D401 (sin galletas: nada sale del equipo)
        self.g = {"SAPISID": "prueba"}
        self.cab = ""
        self.ua = cuenta.UA
        self.llamadas = []
        self.fallar = None
        self.ordenes = 0
        self.ids = {"0:": "Cuenta de prueba", "0:PMARCA": "Canal de prueba"}
        self.subs = {"0:": {_uc(k): f"Canal de prueba {k}" for k in range(1, 5)}, "0:PMARCA": {_uc(5): "Canal de prueba 5"}}
        self.historial = [(_vid(k), f"Vídeo de prueba {k}", 1 + k % 4) for k in range(1, 7)]
        self.megusta = {"0:": [_vid(1), _vid(2)], "0:PMARCA": None}
        self.despues = {"0:": [_vid(3)], "0:PMARCA": None}
        self.listas = {"PLcatodeprueba1": ("Lista de prueba", [_vid(4), _vid(5)])}
        self.handles = {"https://www.youtube.com/@canaldeprueba": _uc(9)}
        self.nombres = {_uc(9): "Canal con nombre"}

    def api(self, ep, cuerpo, au=0, pagina=None):
        clave = f"{int(au or 0)}:{pagina or ''}"
        time.sleep(0.01)
        if ep == "account/accounts_list":
            if int(au or 0) != 0:
                raise RuntimeError("no hay más cuentas")
            items = []
            for k, nombre in self.ids.items():
                tokens = [{"accountStateToken": {"obfuscatedGaiaId": "G0"}}]
                if k.split(":")[1]:
                    tokens.insert(0, {"pageIdToken": {"pageId": k.split(":")[1]}})
                items.append({"accountItemRenderer": {"accountName": {"simpleText": nombre},
                                                      "serviceEndpoint": {"selectActiveIdentityEndpoint": {"supportedTokens": tokens}}}})
            return {"contents": items}
        if ep == "browse" and "browseId" in cuerpo:
            b = cuerpo["browseId"]
            if b == "FEchannels":
                return {"contents": [{"channelRenderer": {"channelId": c, "title": {"simpleText": t}, "thumbnail": {"thumbnails": []}}}
                                     for c, t in self.subs.get(clave, {}).items()]}
            if b == "FEhistory":
                return {"contents": [self._video("videoRenderer", v, t, c) for v, t, c in self.historial]} if clave == "0:" else {"contents": []}
            if b in ("VLLL", "VLWL"):
                lista = (self.megusta if b == "VLLL" else self.despues).get(clave)
                if lista is None:
                    raise RuntimeError("HTTP Error 400: Bad Request")
                return {"contents": [self._video("playlistVideoRenderer", v, f"Vídeo {v}", 1) for v in lista]}
            if b == "FEplaylist_aggregation":
                if clave != "0:":
                    return {"contents": []}
                return {"contents": [{"lockupViewModel": {"contentId": lid, "contentType": "LOCKUP_CONTENT_TYPE_PLAYLIST",
                                                          "metadata": {"lockupMetadataViewModel": {"title": {"content": t}}}}}
                                     for lid, (t, _) in self.listas.items()]}
            if b.startswith("VL") and b[2:] in self.listas:
                return {"contents": [self._video("playlistVideoRenderer", v, f"Vídeo {v}", 2) for v in self.listas[b[2:]][1]]}
            raise RuntimeError(f"HTTP Error 404: {b}")
        if ep == "navigation/resolve_url":
            cid = self.handles.get(cuerpo.get("url", "").rstrip("/"))
            if not cid:
                raise urllib.error.HTTPError(cuerpo.get("url", ""), 404, "Not Found", {}, None)
            return {"endpoint": {"browseEndpoint": {"browseId": cid}}}
        # las órdenes de B
        self.ordenes += 1
        self.llamadas.append({"ep": ep, "cuerpo": cuerpo, "identidad": clave})
        if self.fallar and self.ordenes >= int(self.fallar.get("desde", 1)):
            if self.fallar.get("tipo") == "429":
                raise urllib.error.HTTPError("https://www.youtube.com/youtubei/v1/" + ep, 429, "Too Many Requests", {}, None)
            return {"error": {"code": 500, "message": "fallo de prueba"}}
        if ep == "subscription/subscribe":
            for c in cuerpo["channelIds"]:
                self.subs.setdefault(clave, {})[c] = self.nombres.get(c, f"Canal {c[-6:]}")
            return {"actions": [{"updateSubscribeButtonAction": {"subscribed": True}}]}
        if ep == "subscription/unsubscribe":
            for c in cuerpo["channelIds"]:
                self.subs.setdefault(clave, {}).pop(c, None)
            return {"actions": [{"updateSubscribeButtonAction": {"subscribed": False}}]}
        if ep == "like/like":
            self.megusta.setdefault(clave, []).insert(0, cuerpo["target"]["videoId"])
            return {"responseContext": {}}
        if ep == "browse/edit_playlist":
            for a in cuerpo.get("actions") or []:
                self.despues.setdefault(clave, []).append(a.get("addedVideoId"))
            return {"status": "STATUS_SUCCEEDED"}
        return {"error": {"code": 404, "message": f"desconocido: {ep}"}}

    @staticmethod
    def _video(tipo, vid, titulo, canal):
        return {tipo: {"videoId": vid, "title": {"simpleText": titulo},
                       "shortBylineText": {"runs": [{"text": f"Canal de prueba {canal}",
                                                     "navigationEndpoint": {"browseEndpoint": {"browseId": _uc(canal)}}}]},
                       "lengthText": {"simpleText": "3:21"}}}


def reiniciar_falsa():
    """Para las pruebas: un YouTube de prueba nuevo."""
    _SesionFalsa._yo = None
    return _SesionFalsa.unica()


if __name__ == "__main__":   # vistazo rápido sin red: python -m catode.cuenta_servicio
    print(json.dumps(_SesionFalsa.unica().api("account/accounts_list", {}, 0), ensure_ascii=False)[:300])
