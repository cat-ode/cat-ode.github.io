"""Cat-ode escritorio · «Poner en la tele» (03/10/2026, como el móvil): busca en la red de casa las teles con DIAL (lo que
usa el botón de enviar del YouTube oficial) y le pide a su YouTube que abra el vídeo. Sin cuenta y sin internet."""
import re
import socket
import time
import urllib.request

from . import motor


def buscar(espera=3.5):
    msg = ("M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nMX: 2\r\n"
           "ST: urn:dial-multiscreen-org:service:dial:1\r\n\r\n").encode()
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
    s.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 2)
    s.settimeout(0.5)
    sitios = []
    try:
        for _ in range(2):
            s.sendto(msg, ("239.255.255.250", 1900))
        fin = time.time() + espera
        while time.time() < fin:
            try:
                datos, _ = s.recvfrom(4096)
            except socket.timeout:
                continue
            m = re.search(r"(?im)^location:\s*(\S+)", datos.decode("utf-8", "ignore"))
            if m and m.group(1) not in sitios:
                sitios.append(m.group(1))
    finally:
        s.close()
    teles = {}
    for u in sitios:
        try:
            r = urllib.request.urlopen(u, timeout=4)
            app = r.headers.get("Application-URL")
            if not app:
                continue
            x = r.read().decode("utf-8", "ignore")
            m = re.search(r"<friendlyName>(.*?)</friendlyName>", x)
            teles[app.rstrip("/")] = (m.group(1) if m else "Tele").replace("&amp;", "&")
        except Exception:   # noqa: BLE001
            continue
    return [(nombre, app) for app, nombre in teles.items()]


def poner(app, url):
    q = urllib.request.Request(app + "/YouTube", data=f"v={motor.id_video(url)}".encode(),
                               headers={"Content-Type": "text/plain; charset=utf-8"}, method="POST")
    try:
        return 200 <= urllib.request.urlopen(q, timeout=8).status < 300
    except Exception:   # noqa: BLE001
        return False
