"""Cat-ode escritorio · aperturas para el panel de Claroscuro (19/10/2026; puesto en la app el 22/10/2026).
Va junto a recuento_cliente.py, en la misma carpeta, para que viaje en escritorio.zip.

Orden del autor: «Haz un contador de descargas y usos integrado en las versiones que se usan y añádelo a mi contador de
Dos Gatos». Una apertura cada vez que arranca Cat-ode de verdad (la ventana principal): no cuentan la instancia que solo
trae al frente la que ya está abierta, el relanzamiento tras actualizarse (--reinicio) ni las pruebas.
En Linux, ~/.config/catode se copia entre el Dell y el ProBook (Syncthing): el archivo lleva el nombre del equipo para
que cada uno sea su propia instalación.
Uso en catode.pyw, justo después de «from catode import interfaz, interfaz_web» (ahí ya solo sigue la instancia principal
y datos.py, que importa el motor, ya está cargado: no añade nada al arranque):
    from catode import recuento; recuento.al_arrancar()
"""
import os
import socket
import sys

from . import VERSION
from .datos import carpeta_config
from .recuento_cliente import Contador

_contador = None


def al_arrancar():
    global _contador
    if any(a in sys.argv for a in ("--prueba", "--reinicio", "--medir")) or os.environ.get("CATODE_PRUEBA_INTERFAZ"):
        return
    try:
        nombre = "recuento.json" if os.name == "nt" else f"recuento-{socket.gethostname()}.json"
        _contador = Contador("catode", "windows" if os.name == "nt" else "linux", VERSION, carpeta_config(), nombre=nombre)
        _contador.apertura()
    except Exception:   # noqa: BLE001 (el contador nunca puede impedir que Cat-ode arranque)
        pass


def reintentar():
    """Para el reloj de 20 minutos que ya existe (actualizar.empezar): manda lo que quedara en cola sin red."""
    if _contador:
        _contador.enviar_pendientes()
