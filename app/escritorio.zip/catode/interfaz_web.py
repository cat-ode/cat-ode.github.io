"""Cat-ode escritorio · la ventana de la interfaz web (06/10/2026, DISENO_WEB.md §1.1-1.2, §1.10 y módulo M0).

VentanaWeb es una QMainWindow mínima: título, icono, geometría (la misma clave «geometria» de escritorio-ajustes.json que
la Qt) y UN CoreWebView2Controller a tamaño de la ventana, creado con motor_web.crear_webview (lo mismo que usa MpvWeb).
La página (catode/web/index.html) la sirve servidor_web.ServidorWeb en http://127.0.0.1:<puerto>/index.html?t=<token>.

Vuelta atrás a la Qt, sin que el autor haga nada: si WebView2 no arranca (o CATODE_WEBVIEW2_FALLA=1, para probarlo) o
si la página no manda POST /api/lista en 10 s, se apunta interfaz=qt (solo si falló de verdad) y se abre interfaz.Ventana.

activa(): solo en Windows y con WebView2 disponible; --clasica o CATODE_INTERFAZ=qt la apagan. Sin interfaz elegida (ni
local ni remota, p. ej. en un equipo recién instalado) es la web (06/10/2026 y 18/10/2026: «instalador de Windows» para
aparatos nuevos). En Linux siempre False (la Qt de siempre).

VentanaCuenta (18/10/2026, «Traer mi YouTube»): la ventana de Google DENTRO de la app, con su propio entorno de WebView2
(carpeta «cuenta», sin --disable-web-security), para leer las galletas de YouTube de la otra cuenta del autor."""
import json
import os
import re
import sys
import threading
import time
from types import SimpleNamespace

from PySide6.QtCore import QAbstractNativeEventFilter, QByteArray, QEvent, QTimer, Qt
from PySide6.QtWidgets import QApplication, QMainWindow, QWidget

from . import ajustes as aj
from .resolutor import registro


# 06/10/2026: en la prueba (o con CATODE_DEPURAR_WEB), lo que la consola de WebView2 diría (errores, avisos, promesas sin
# atrapar) llega al registro por POST /api/prueba {registro}. Corre en cada documento, también en el iframe del reproductor,
# que lo pasa al padre por postMessage (su origen es opaco y no tiene el token).
CONSOLA_JS = r"""(function(){
if (window.__catodeConsola) return; window.__catodeConsola = 1;
var arriba = window.parent === window, tok = new URLSearchParams(location.search).get("t") || "", n = 0;
var donde = arriba ? "pagina" : "iframe";
function manda(t){ if (n++ > 300) return; t = String(t).slice(0, 500);
  if (!arriba) { try { window.parent.postMessage({catodeConsola: t}, "*"); } catch (e) {} return; }
  try { fetch("/api/prueba", {method: "POST", headers: {"X-Catode": tok || window.CATODE_TOKEN || "", "Content-Type": "application/json"}, body: JSON.stringify({registro: t})}); } catch (e) {} }
function txt(a){ try { return typeof a === "string" ? a : (a && a.stack) || JSON.stringify(a); } catch (e) { return String(a); } }
window.addEventListener("error", function(e){ var o = e.target && e.target !== window ? " recurso " + (e.target.tagName || "") + " " + (e.target.src || e.target.href || "") : "";
  manda(donde + " error: " + (e.message || "") + o + " @" + (e.filename || "") + ":" + (e.lineno || "")); }, true);
window.addEventListener("unhandledrejection", function(e){ manda(donde + " promesa: " + txt(e.reason)); });
["error", "warn"].forEach(function(k){ var o = console[k]; console[k] = function(){
  try { var t = Array.prototype.map.call(arguments, txt).join(" "); if (!/^(OK|FALLA) /.test(t)) manda(donde + " console." + k + ": " + t); } catch (e) {}
  return o.apply(console, arguments); }; });
if (arriba) window.addEventListener("message", function(e){ if (e.data && typeof e.data === "object" && e.data.catodeConsola) manda(e.data.catodeConsola); });
else manda("iframe: arranca " + location.pathname + " chrome.webview=" + !!(window.chrome && window.chrome.webview));
})();"""


def activa(argv=None):
    argv = sys.argv if argv is None else argv
    if os.name != "nt" or "--clasica" in argv:
        return False
    modo = os.environ.get("CATODE_INTERFAZ", "").strip().lower()
    if modo == "qt":
        return False
    try:
        from . import motor_web
        if not motor_web.disponible():
            return False
    except Exception:   # noqa: BLE001
        return False
    if modo == "web":
        return True
    return True   # 06/10/2026, orden del autor («elimina la versión antigua en Windows»): la web es LA interfaz de Windows;
    # la Qt solo con --clasica o CATODE_INTERFAZ=qt. Lo de abajo (interruptor local/remoto y vigía) queda sin efecto.
    # 18/10/2026: así también en un equipo nuevo sin «interfaz» ni «interfaz_remota» en sus ajustes (el instalador).
    a = aj.leer()
    # M8 · vigía (§1.10): 3 arranques seguidos de la web sin «lista» (se colgó o murió antes de los 10 s) → la Qt
    if int(a.get("web_sin_lista", 0) or 0) >= 3:
        a["interfaz"], a["web_sin_lista"] = "qt", 0
        aj.guardar(a)
        registro("web: 3 arranques sin «lista»: vuelta a la interfaz clásica")
        return False
    # interruptor: lo local («qt» tras una vuelta atrás o elegido en Ajustes) manda; si no, el remoto del servidor del
    # autor (/app/escritorio.json, clave «interfaz», guardado la última vez como «interfaz_remota»)
    local, remota = a.get("interfaz"), a.get("interfaz_remota")
    if local == "qt" or remota == "qt":
        return False
    return local == "web" or remota == "web"


def _vigilar_cierre(tope=12.0):
    """06/10/2026: el proceso se quedó vivo tras cerrar la ventana y la app no volvía a abrir. Desde que se pide cerrar,
    un hilo aparte termina el proceso en seco a los 12 s (el guardado tarda como mucho 3 + 5 s), pase lo que pase."""
    if os.environ.get("CATODE_CIERRE_VIEJO"):   # solo para pruebas/windows_cierre.sh: reproduce el fallo (sin vigilante)
        return

    def matar():
        time.sleep(tope)
        try:
            registro("web: el cierre no ha terminado en 12 s: se termina el proceso")
        except Exception:   # noqa: BLE001
            pass
        try:
            if os.name == "nt":
                import ctypes
                from ctypes import wintypes
                k = ctypes.windll.kernel32
                k.GetCurrentProcess.restype = wintypes.HANDLE
                k.TerminateProcess.argtypes = [wintypes.HANDLE, wintypes.UINT]
                k.TerminateProcess(k.GetCurrentProcess(), 0)
        finally:
            os._exit(0)
    threading.Thread(target=matar, daemon=True, name="vigia-cierre").start()


def viva(v):
    """La ventana que manda: la Qt si la web ya volvió atrás (para catode.pyw: instancia única y enlaces)."""
    return getattr(v, "qt", None) or v


class _TeclasMultimedia(QAbstractNativeEventFilter):
    """Play/Pausa, Siguiente, Anterior y Parar del teclado: la página las recibe por SSE «tecla» (§2.4)."""
    WM_KEYDOWN, WM_APPCOMMAND = 0x0100, 0x0319
    TECLAS = {0xB0: "siguiente", 0xB1: "anterior", 0xB2: "parar", 0xB3: "play"}
    ORDENES = {11: "siguiente", 12: "anterior", 13: "parar", 14: "play", 46: "play", 47: "pausa"}

    def __init__(self, emitir):
        super().__init__()
        self.emitir = emitir

    def nativeEventFilter(self, tipo, mensaje):
        try:
            if bytes(tipo) != b"windows_generic_MSG":
                return False, 0
            import ctypes.wintypes
            msg = ctypes.wintypes.MSG.from_address(int(mensaje))
            nombre = None
            if msg.message == self.WM_KEYDOWN:
                nombre = self.TECLAS.get(msg.wParam)
            elif msg.message == self.WM_APPCOMMAND:
                nombre = self.ORDENES.get((msg.lParam >> 16) & 0x0FFF)
            if nombre:
                self.emitir("tecla", {"nombre": nombre})
                return True, 0
        except Exception:   # noqa: BLE001
            pass
        return False, 0


class VentanaWeb(QMainWindow):
    def __init__(self):
        super().__init__()
        t_init = time.time()
        from . import motor_web
        # 06/10/2026: el entorno de Edge se pide ya (arranca a la vez que el servicio, el servidor y la ventana)
        if not os.environ.get("CATODE_WEBVIEW2_FALLA"):
            motor_web.precalentar(registro)
        t_edge = time.time()
        from . import fichas
        fichas.preparar()   # 06/10/2026: el mensajero de los hilos a la ventana (sin él, actualizar.py no reinicia la app)
        from .servicio import Servicio
        from .servidor_web import ServidorWeb
        self._mw = motor_web
        self.setWindowTitle("Cat-ode")
        self.resize(1440, 900)
        self.setMinimumSize(900, 540)
        self.prueba = "--prueba" in sys.argv
        self.servicio = Servicio.instancia()          # con CATODE_PRUEBA_INTERFAZ: fixtures y red cortada
        self.ajustes = self.servicio.ajustes          # el mismo dict: lo que guarde la página lo ve la ventana
        self.datos = self.servicio.datos
        if self.ajustes.get("geometria"):
            self.restoreGeometry(QByteArray.fromBase64(self.ajustes["geometria"].encode()))
        if not self.prueba:   # el vigía: cuenta este arranque hasta que llegue «lista»
            self.ajustes["web_sin_lista"] = int(self.ajustes.get("web_sin_lista", 0) or 0) + 1
            aj.guardar(self.ajustes)
        # compatibilidad con catode.pyw (instancia única y enlaces al arrancar) y con actualizar.py
        self.rep = SimpleNamespace(actual=None, pausa=True)
        self.pestanas, self.pila, self.inicio = [None], [], None
        self.codigo_salida = 0
        self.qt = None
        self._ctl = self._wv = None
        self._lista = False
        self._volviendo = False
        self._cerrando = False
        self._hilo = motor_web._AlHilo()
        self._tiempos = {"init": t_init, "edge_pedido": t_edge, "ventana": time.time()}   # 06/10/2026: los tramos del arranque (perfil)
        self.zona = QWidget(self)
        self.zona.setAttribute(Qt.WA_NativeWindow)
        self.zona.setAttribute(Qt.WA_DontCreateNativeAncestors)
        self.zona.setStyleSheet("background: #0F0F0F;")
        self.setCentralWidget(self.zona)
        self.zona.installEventFilter(self)
        # 06/10/2026: puerto fijo (la caché de Edge va por origen); la prueba, otro, para no pisarse con la app del autor
        preferido = int(os.environ.get("CATODE_PUERTO_WEB") or (47923 if self.prueba else 47913))
        self.servidor = ServidorWeb(self.servicio, solo=False, prueba=self.prueba, puerto_preferido=preferido,
                                    al_ventana=self._ventana_desde_hilo,
                                    al_lista=lambda: self._hilo.llega.emit(self._llega_lista),
                                    al_guardado=lambda: None,
                                    al_galletas=self._galletas_desde_hilo,
                                    al_borrar_galletas=self._borrar_galletas_desde_hilo,
                                    al_cerrar_galletas=self._cerrar_galletas_desde_hilo).empezar()
        self._cuenta_v = None   # 18/10/2026: la ventana de Google (VentanaCuenta) abierta, si la hay
        self.servicio.al_reiniciar = lambda: self._hilo.llega.emit(self.reiniciar_cuando_libre)
        self.servicio.al_novedades = lambda nuevos: self._hilo.llega.emit(lambda: self._avisar_novedades(nuevos))
        self._poner_bandeja()
        registro(f"web: servidor en {self.servidor.base} (fixtures={self.servicio.fixtures})")
        self._teclas = _TeclasMultimedia(self.servidor.eventos.emitir)
        QApplication.instance().installNativeEventFilter(self._teclas)
        self._reloj_vuelta = QTimer(self, singleShot=True, interval=int(float(os.environ.get("CATODE_WEB_ESPERA", "10")) * 1000))
        self._reloj_vuelta.timeout.connect(self._sin_respuesta)
        # los 10 s cuentan desde que hay controlador (_con_controlador): crear WebView2 en frío en el N100 puede tardar;
        # hasta entonces, un tope de seguridad de 45 s por si el controlador no llega nunca
        self._reloj_vuelta.start(45_000)
        self.show()   # como la Qt (interfaz.py 2013): la ventana nativa ya creada para meter dentro la de Edge
        QTimer.singleShot(0, self._crear)

    # ---------------------------------------------------------------- WebView2
    def _crear(self):
        if os.environ.get("CATODE_WEBVIEW2_FALLA"):   # prueba de la vuelta atrás
            registro("web: WebView2 no arranca (fallo simulado, CATODE_WEBVIEW2_FALLA)")
            return self._volver_a_qt("WebView2 no arranca (simulado)", apuntar=False)
        try:
            self._mw.crear_webview(lambda: int(self.zona.winId()), self._con_controlador, registro,
                                   al_entorno=lambda _env: self._tiempos.setdefault("entorno", time.time()))
        except RuntimeError as error:
            self._volver_a_qt(f"WebView2 no arranca ({error})")

    def _con_controlador(self, ctl):
        if self._volviendo:
            try:
                ctl.Close()
            except Exception:   # noqa: BLE001
                pass
            return
        self._ctl, self._wv = ctl, ctl.CoreWebView2
        self._tiempos.setdefault("controlador", time.time())
        if not self._lista:
            self._reloj_vuelta.start(int(float(os.environ.get("CATODE_WEB_ESPERA", "10")) * 1000))
        s = self._wv.Settings
        s.AreDefaultContextMenusEnabled = False            # el menú de Edge no (la página pone los suyos)
        s.AreDevToolsEnabled = bool(os.environ.get("CATODE_DEPURAR_WEB"))
        try:
            s.AreBrowserAcceleratorKeysEnabled = bool(os.environ.get("CATODE_DEPURAR_WEB"))   # F5, F11, Ctrl+F… de Edge, no
        except Exception:   # noqa: BLE001
            pass
        s.IsStatusBarEnabled = False
        self._wv.NavigationCompleted += self._navegada
        # la app no se va nunca de index.html: soltar un archivo o un enlace no navega el control entero, lo que no sea
        # del servidor local se cancela (YouTube → la página lo abre en una pestaña; lo demás, al navegador del sistema)
        # y window.open / target=_blank no abren ventanas sueltas de msedgewebview2
        try:
            ctl.AllowExternalDrop = False
        except Exception:   # noqa: BLE001 (SDK antiguo: queda NavigationStarting)
            pass
        self._wv.NavigationStarting += self._navegando
        try:
            self._wv.NewWindowRequested += self._ventana_nueva
        except Exception:   # noqa: BLE001
            pass
        try:
            ctl.ZoomFactor = float(self.ajustes.get("escala", 1.0) or 1.0)
        except Exception:   # noqa: BLE001
            pass
        if self.prueba or os.environ.get("CATODE_DEPURAR_WEB"):   # errores y avisos de la consola (página e iframes) al registro
            try:
                self._wv.AddScriptToExecuteOnDocumentCreatedAsync(CONSOLA_JS)
            except Exception as error:   # noqa: BLE001
                registro(f"web: sin volcado de consola ({error})")
        self._colocar()
        self._tiempos.setdefault("pedida", time.time())
        self._wv.Navigate(self.servidor.direccion())
        registro(f"web: página pedida ({self.servidor.base}/index.html)")

    def _propia(self, uri):
        return uri.startswith(self.servidor.base + "/") or uri == self.servidor.base

    def _navegando(self, _remitente, args):
        try:
            uri = str(args.Uri or "")
        except Exception:   # noqa: BLE001
            return
        if self._propia(uri):
            return
        args.Cancel = True
        registro(f"web: navegación fuera de la app cancelada ({uri[:120]})")
        QTimer.singleShot(0, lambda: self._enlace_de_fuera(uri))

    def _ventana_nueva(self, _remitente, args):
        try:
            args.Handled = True   # sin ventana suelta de msedgewebview2
            uri = str(args.Uri or "")
        except Exception:   # noqa: BLE001
            return
        registro(f"web: ventana nueva evitada ({uri[:120]})")
        QTimer.singleShot(0, lambda: self._enlace_de_fuera(uri))

    def _enlace_de_fuera(self, uri):
        """YouTube → la página (SSE «abrir»: ella decide si va en pestaña nueva); http(s) → navegador del sistema."""
        from PySide6.QtCore import QUrl
        from PySide6.QtGui import QDesktopServices
        if re.match(r"https?://([\w-]+\.)?(youtube\.com|youtu\.be)/", uri, re.I):
            self.abrir_enlace(uri, nueva=True)
        elif re.match(r"https?://", uri, re.I) and not self._propia(uri):
            QDesktopServices.openUrl(QUrl(uri))
        # file:, data:, about:… soltados o colados: nada (la app sigue en su página)

    def _navegada(self, _remitente, args):
        try:
            registro(f"web: página cargada (bien={args.IsSuccess}, estado={args.WebErrorStatus})")
        except Exception:   # noqa: BLE001
            pass
        self._enfocar()

    def _colocar(self):
        if self._ctl is None:
            return
        from System.Drawing import Rectangle
        r = self.zona.devicePixelRatioF()
        self._ctl.Bounds = Rectangle(0, 0, int(self.zona.width() * r), int(self.zona.height() * r))
        self._ctl.IsVisible = True

    def _enfocar(self):
        """El foco del teclado, a la página (tras pantalla completa, normal o restaurar)."""
        if self._ctl is None:
            return
        try:
            from Microsoft.Web.WebView2.Core import CoreWebView2MoveFocusReason
            self._ctl.MoveFocus(CoreWebView2MoveFocusReason.Programmatic)
        except Exception:   # noqa: BLE001
            pass

    def eventFilter(self, obj, ev):
        if obj is getattr(self, "zona", None) and ev.type() in (QEvent.Resize, QEvent.Show, QEvent.Move):
            self._colocar()
        return False

    def _estado_ventana(self, nuevo=False):
        """El estado real de la ventana, NUMERADO (06/10/2026): cada cambio sube «n»; la página solo acepta el «n» más alto
        que ha visto, así un aviso viejo que llega tarde (SSE) no puede pisar a uno nuevo (respuesta de una orden)."""
        if nuevo:
            self._ventana_n = getattr(self, "_ventana_n", 0) + 1
        return {"completa": self.isFullScreen(), "maximizada": self.isMaximized(), "n": getattr(self, "_ventana_n", 0)}

    def changeEvent(self, ev):
        if not hasattr(self, "servidor"):   # restoreGeometry en __init__, antes de tener servidor
            return super().changeEvent(ev)
        if ev.type() == QEvent.WindowStateChange:
            QTimer.singleShot(50, self._enfocar)
            self.servidor.eventos.emitir("ventana", self._estado_ventana(nuevo=True))
        elif ev.type() == QEvent.ActivationChange and self.isActiveWindow():
            QTimer.singleShot(0, self._enfocar)
        super().changeEvent(ev)

    # ---------------------------------------------------------------- página lista / sin respuesta
    def _llega_lista(self):
        if self._lista or self._volviendo:
            return
        self._lista = True
        self._tiempos.setdefault("lista", time.time())
        self._reloj_vuelta.stop()
        registro("web: lista")
        if self.ajustes.get("web_sin_lista"):
            self.ajustes["web_sin_lista"] = 0
            aj.guardar(self.ajustes)
        if not self.prueba:   # el interruptor remoto, para el próximo arranque (sin retrasar este)
            threading.Thread(target=self._mirar_interruptor, daemon=True).start()
        # lo que en la Qt arranca con la ventana, aquí cuando la página ya va: sincronizar, escuchar, novedades, versión
        self.servicio.arrancar()
        from . import actualizar
        if not self.prueba:
            actualizar.empezar(self.servicio)
            self._reloj_version = QTimer(self, interval=20 * 60_000)
            self._reloj_version.timeout.connect(lambda: actualizar.empezar(self.servicio))
            self._reloj_version.start()
        if self.prueba:   # la batería de Windows: la de la página (prueba_web.js por ExecuteScriptAsync) y la ventana
            print(f"{'OK    '} {'web: lista (index.html desde 127.0.0.1)':34s} {self.servidor.base}", flush=True)
            from . import prueba_web
            QTimer.singleShot(500, lambda: prueba_web.empezar(self))

    def _mirar_interruptor(self):
        try:
            r = self.datos.del_servidor("/app/escritorio.json") or {}
        except Exception:   # noqa: BLE001
            return
        valor = r.get("interfaz") if isinstance(r, dict) else None
        if valor in ("qt", "web", None) and self.ajustes.get("interfaz_remota") != valor:
            if valor is None:
                self.ajustes.pop("interfaz_remota", None)
            else:
                self.ajustes["interfaz_remota"] = valor
            self.servicio.guardar_ajustes()
            registro(f"web: interruptor remoto = {valor}")

    def _sin_respuesta(self):
        if self._lista or self._volviendo:
            return
        registro("web: sin respuesta")
        # solo en esta sesión: un arranque lento suelto no apaga la web para siempre (web_sin_lista ya cuenta este
        # arranque; el vigía la apaga tras 3 seguidos)
        self._volver_a_qt("la página no respondió en 10 s", apuntar=False)

    def _volver_a_qt(self, motivo, apuntar=True):
        """La interfaz clásica, en el mismo proceso. apuntar: deja interfaz=qt en los ajustes (la próxima vez, Qt)."""
        if self._volviendo:
            return
        self._volviendo = True
        self._reloj_vuelta.stop()
        registro(f"web: vuelta a la interfaz clásica ({motivo})")
        print(f"web: vuelta a la interfaz clásica ({motivo})", flush=True)
        if apuntar and not os.environ.get("CATODE_INTERFAZ"):
            self.ajustes["interfaz"] = "qt"
            aj.guardar(self.ajustes)
        try:
            if self._ctl is not None:
                self._ctl.Close()
        except Exception:   # noqa: BLE001
            pass
        self._ctl = self._wv = None
        try:
            QApplication.instance().removeNativeEventFilter(self._teclas)
        except Exception:   # noqa: BLE001
            pass
        if getattr(self, "bandeja", None) is not None:   # la Qt pone la suya
            self.bandeja.hide()
        self.servidor.parar()
        self.servicio.datos.esperar_guardado()
        from . import interfaz
        self.qt = qt = interfaz.Ventana()
        if not self.ajustes.get("geometria"):
            qt.setGeometry(self.geometry())
        qt.show()
        if os.name == "nt":   # barra de título oscura, como catode.pyw
            try:
                import ctypes
                oscuro = ctypes.c_int(1)
                ctypes.windll.dwmapi.DwmSetWindowAttribute(int(qt.winId()), 20, ctypes.byref(oscuro), ctypes.sizeof(oscuro))
            except Exception:   # noqa: BLE001
                pass
        self.hide()
        if self.prueba:
            from . import prueba
            prueba.empezar(QApplication.instance(), qt)

    # ---------------------------------------------------------------- bandeja y avisos del sistema (interfaz.py 3996-4048)
    def _poner_bandeja(self):
        """M8: el icono de la bandeja con su menú (Mostrar · Pausar/Seguir · Salir) y el aviso de vídeos nuevos."""
        self.bandeja = None
        if self.prueba:
            return
        try:
            from PySide6.QtGui import QIcon
            from PySide6.QtWidgets import QMenu, QSystemTrayIcon
            if not QSystemTrayIcon.isSystemTrayAvailable():
                return
            ruta = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "catode.svg")
            b = QSystemTrayIcon(QIcon(ruta), self)
            b.setToolTip("Cat-ode")
            b.messageClicked.connect(self._abrir_campana)
            b.activated.connect(lambda motivo: motivo != QSystemTrayIcon.Context and self._mostrar())
            m = QMenu(self)
            m.addAction("Mostrar Cat-ode", self._mostrar)
            m.addAction("Pausar / Seguir", lambda: self.servidor.eventos.emitir("tecla", {"nombre": "play"}))
            m.addSeparator()
            m.addAction("Salir", self.close)
            b.setContextMenu(m)
            b.show()
            self.bandeja = b
        except Exception as error:   # noqa: BLE001
            registro(f"web: sin bandeja ({error})")

    def _mostrar(self):
        self.showNormal(); self.raise_(); self.activateWindow()

    def _abrir_campana(self):
        self._mostrar()
        self.servidor.eventos.emitir("abrir_campana", {})

    def _avisar_novedades(self, nuevos):
        if not (self.ajustes.get("avisos", False) and self.bandeja is not None and nuevos):   # apagados por defecto
            return
        from PySide6.QtGui import QIcon
        lineas = "\n".join(f"{e.autor}: {e.titulo[:60]}" for e in nuevos[:3]) + ("\n…" if len(nuevos) > 3 else "")
        n = len(nuevos)
        self.bandeja.showMessage(f"{n} vídeo{'s' if n > 1 else ''} nuevo{'s' if n > 1 else ''} de tus canales", lineas, QIcon(), 8000)

    # ---------------------------------------------------------------- órdenes de la página (POST /api/ventana)
    def _ventana_desde_hilo(self, accion, valor):
        """Llega del hilo del servidor: se hace en el de la ventana y se espera (como mucho 3 s) a su resultado."""
        if accion == "elegir_ruta":   # 22/10/2026 «Importar tu música»: solo la ruta (un ZIP no se lee como texto); SSE «archivo»
            self._hilo.llega.emit(lambda: self._elegir_ruta(valor or {}))
            return {}
        if accion == "elegir_archivo":   # modal: no se espera (la respuesta va por SSE «archivo»)
            self._hilo.llega.emit(lambda: self._elegir_archivo(valor))
            return {}
        # 06/10/2026 (perfil de uso): lo que no devuelve nada a la página no espera al hilo de la ventana (ocupado con Edge,
        # cada orden esperaba su turno: título a cada navegación, pantalla completa, abrir fuera…). Solo esperan las que
        # contestan algo: leer el portapapeles y el zoom
        # (06/10/2026 tarde: «completa», «normal» y «estado» SÍ esperan: su respuesta es el estado real de la ventana, la
        # única verdad de la página; sin esperarla, la pantalla completa dependía de avisos SSE que llegan desordenados)
        if not (accion in ("zoom", "completa", "normal", "estado", "raton") or (accion == "portapapeles" and valor is None)):
            if accion == "titulo":
                if valor == getattr(self, "_titulo_pedido", None):
                    return {}
                self._titulo_pedido = valor

            def sin_esperar():
                try:
                    self._ventana(accion, valor)
                except Exception as error:   # noqa: BLE001
                    registro(f"web: ventana {accion}: {error!r}"[:160])
            self._hilo.llega.emit(sin_esperar)
            return {}
        hecho, res = threading.Event(), {}

        def hacer():
            try:
                res.update(self._ventana(accion, valor) or {})
            except Exception as error:   # noqa: BLE001
                res["error"] = str(error)[:160]
            hecho.set()
        self._hilo.llega.emit(hacer)
        hecho.wait(3)
        return res

    def _ventana(self, accion, valor):
        from PySide6.QtCore import QUrl
        from PySide6.QtGui import QDesktopServices
        if accion == "completa":
            antes = self.isFullScreen()
            if not antes:   # el reintento de 400 ms llega ya en completa (isMaximized False): no se pisa
                self._maximizada_antes = self.isMaximized()
            self.showFullScreen()
            est = self._estado_ventana()   # 06/10/2026: la única verdad para la página
            registro(f"web: ventana completa (antes {antes}) → {est['completa']} n{est['n']}")   # 07/10/2026: rastro en catode.log
            return est
        elif accion == "normal":
            antes = self.isFullScreen()
            if antes:
                self.showMaximized() if getattr(self, "_maximizada_antes", False) else self.showNormal()
            est = self._estado_ventana()
            registro(f"web: ventana normal (antes completa {antes}) → {est['completa']} n{est['n']}")
            return est
        elif accion == "estado":
            return self._estado_ventana()
        elif accion == "titulo":
            self.setWindowTitle(str(valor or "Cat-ode"))
        elif accion == "cerrar":
            QTimer.singleShot(0, self.close)
        elif accion == "zoom":
            z = max(0.5, min(3.0, float(valor or 1.0)))
            if self._ctl is not None:
                self._ctl.ZoomFactor = z
            self.ajustes["escala"] = z
            aj.guardar(self.ajustes)
            return {"zoom": z}
        elif accion == "portapapeles":
            cb = QApplication.clipboard()
            if valor is None:
                return {"texto": cb.text()}
            cb.setText(str(valor))
        elif accion == "carpeta_descargas":
            from . import motor
            QDesktopServices.openUrl(QUrl.fromLocalFile(motor.carpeta_descargas()))
        elif accion == "abrir_fuera":   # 19/10/2026: al navegador de verdad (el del sistema es Cat-ode para YouTube)
            from . import compartir
            compartir.abrir_fuera(str(valor))
        elif accion == "enlaces":   # 19/10/2026: Cat-ode para los enlaces de YouTube (sistema_enlaces.py); solo Windows
            if os.name != "nt":
                return {"predeterminado": False, "no": "solo Windows"}
            from . import sistema_enlaces as se
            if valor == "pedir":
                se.registrar()
                se.pedir()
                registro("web: enlaces de YouTube: registrado y abierta la página de Aplicaciones predeterminadas")
            return {"predeterminado": se.estado()}
        elif accion == "compartir":   # 19/10/2026 «tienen que abrirse directamente en las apps»: {app, url, titulo}
            from . import compartir
            v = valor if isinstance(valor, dict) else {}
            via = compartir.compartir(str(v.get("app", "")), str(v.get("url", "")), str(v.get("titulo", "")))
            registro(f"web: compartir en {v.get('app')} por {via or 'nada'}")
            return {"via": via}
        elif accion == "voz":
            self._voz()
        elif accion == "pip":
            pass   # imagen en imagen nativa de Edge: la pide la página (video.requestPictureInPicture)
        elif accion == "raton":
            return self._raton_prueba(valor)
        else:
            return {"desconocida": accion}
        return {}

    def _raton_prueba(self, valor):
        """07/10/2026 · SOLO en las pruebas: un ratón de verdad DENTRO del motor de Edge, sin tocar el del sistema (en el mini
        PC no se simula entrada: memoria feedback-minipc-sin-entrada-simulada). Va por el protocolo de DevTools de WebView2
        (Input.dispatchMouseEvent): el evento hace el mismo camino que el del autor —quién está debajo del cursor, el <video>
        del iframe, su postMessage— cosa que rep()._mensaje({tipo:"doble"}) se saltaba (y así las baterías decían «doble clic
        bien» mientras al autor no le hacía nada). valor: {x, y (px CSS de la vista), tipo: mover|clic|doble}."""
        if not (self.prueba or os.environ.get("CATODE_PRUEBA_INTERFAZ")) or self._wv is None:
            return {"error": "solo en prueba"}
        v = valor or {}
        x, y, tipo = float(v.get("x", 0)), float(v.get("y", 0)), str(v.get("tipo", "clic"))
        # en el mismo hilo que creó el control y sin esperar los Task: el protocolo conserva el orden de las llamadas
        def cdp(t, n=0):
            p = {"type": t, "x": x, "y": y, "button": "left" if n else "none", "clickCount": n, "buttons": 1 if t == "mousePressed" else 0}
            self._wv.CallDevToolsProtocolMethodAsync("Input.dispatchMouseEvent", json.dumps(p))
        cdp("mouseMoved")
        if tipo in ("clic", "doble"):
            cdp("mousePressed", 1); cdp("mouseReleased", 1)
        if tipo == "doble":
            cdp("mousePressed", 2); cdp("mouseReleased", 2)
        return {"hecho": True, "tipo": tipo}

    def _voz(self):
        """El dictado del sistema (Win+H), como el micrófono de la Qt. Nunca en las pruebas (sin entrada simulada)."""
        if self.prueba or os.environ.get("CATODE_PRUEBA_INTERFAZ") or os.name != "nt":
            self.servidor.eventos.emitir("voz", {"texto": ""})
            return
        import ctypes
        u = ctypes.windll.user32
        u.keybd_event(0x5B, 0, 0, 0); u.keybd_event(0x48, 0, 0, 0); u.keybd_event(0x48, 0, 2, 0); u.keybd_event(0x5B, 0, 2, 0)

    def _elegir_ruta(self, v):
        from PySide6.QtWidgets import QFileDialog
        if v.get("tipo") == "carpeta":
            ruta = QFileDialog.getExistingDirectory(self, "Elegir la carpeta de tu música", os.path.expanduser("~"))
        else:
            ruta, _ = QFileDialog.getOpenFileName(self, "Elegir archivo", os.path.expanduser("~"), str(v.get("filtro") or "Todos (*.*)"))
        self.servidor.eventos.emitir("archivo", {"ruta": ruta or "", "para": v.get("para", "")})

    def _elegir_archivo(self, filtro):
        from PySide6.QtWidgets import QFileDialog
        ruta, _ = QFileDialog.getOpenFileName(self, "Elegir archivo", "", str(filtro or "CSV (*.csv);;Todos (*.*)"))
        texto = ""
        if ruta:
            try:
                with open(ruta, encoding="utf-8", errors="replace") as f:
                    texto = f.read()
            except OSError as error:
                registro(f"web: no puedo leer {ruta} ({error})")
        self.servidor.eventos.emitir("archivo", {"texto": texto, "ruta": ruta})

    # ---------------------------------------------------------------- «Traer mi YouTube» (18/10/2026)
    def _galletas_desde_hilo(self, listo):
        """Del hilo de cuenta_servicio: las galletas de YouTube de la ventana de Google (listo(galletas) o listo(None,
        motivo)). Todo lo de WebView2, en el hilo de la ventana."""
        self._hilo.llega.emit(lambda: self._abrir_cuenta(listo, "entrar"))

    def _borrar_galletas_desde_hilo(self):
        """«Cerrar sesión»: borra las galletas del entorno de la ventana de Google (sin enseñarla). Espera como mucho 20 s."""
        hecho = threading.Event()
        self._hilo.llega.emit(lambda: self._abrir_cuenta(lambda *_a: hecho.set(), "salir"))
        hecho.wait(20)

    def _cerrar_galletas_desde_hilo(self):
        """18/10/2026 (hallazgo 13): Cancelar (o 20 minutos sin entrar) cierra la ventana de Google, en su hilo."""
        def cerrar():
            v = self._cuenta_v
            if v is not None and not v.acabada:
                v.terminar(None, "Cancelado")
        self._hilo.llega.emit(cerrar)

    def _abrir_cuenta(self, listo, modo):
        v = self._cuenta_v
        if v is not None and not v.acabada:
            if modo == "entrar" and v.modo == "entrar":   # ya abierta: se espera a la misma
                v.esperando.append(listo)
                v.traer_al_frente()
                return
            v.terminar(None, "Otra orden de la cuenta")
        try:
            self._cuenta_v = VentanaCuenta(listo, modo, self)
        except Exception as error:   # noqa: BLE001 (sin WebView2: el respaldo es la sesión de Firefox)
            registro(f"cuenta: la ventana de Google no abre ({error!r})"[:200])
            listo(None, "No he podido abrir la ventana de Google. Usa la sesión de Firefox de este equipo.")

    # ---------------------------------------------------------------- catode.pyw y actualizar.py
    def abrir_enlace(self, url, *_a, nueva=None):
        self.servidor.eventos.emitir("abrir", {"url": url, "nueva": bool(nueva)})

    @property
    def estado_actualizacion(self):
        return self.servicio.estado_actualizacion

    @estado_actualizacion.setter
    def estado_actualizacion(self, texto):
        self.servicio.estado_actualizacion = texto
        self.servidor.eventos.emitir("actualizacion", {"estado": texto})

    def guardar_ajustes(self):
        aj.guardar(self.ajustes)

    def reiniciar_cuando_libre(self):
        """Versión nueva descargada: se reinicia sola cuando no suena nada (la página manda la posición cada 5 s)."""
        if time.time() - getattr(self.servicio, "_ultima_pos", 0) < 15:
            return QTimer.singleShot(30_000, self.reiniciar_cuando_libre)
        if getattr(self, "_reiniciando", False):
            return
        self._reiniciando = True
        from PySide6.QtCore import QProcess
        pyw = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "catode.pyw")
        QProcess.startDetached(sys.executable, [pyw, "--reinicio"])
        self.close()

    # ---------------------------------------------------------------- cerrar
    def closeEvent(self, ev):
        if self._volviendo:   # la Qt ya manda: esta ventana solo se esconde
            ev.accept()
            return
        if self._cerrando:
            ev.accept()
            return
        self._cerrando = True
        _vigilar_cierre()
        if self.isFullScreen():   # se guarda la geometría de antes de la pantalla completa (maximizada si lo estaba)
            self.showMaximized() if getattr(self, "_maximizada_antes", False) else self.showNormal()
        # la página guarda lo suyo (pestañas, posiciones) y lo confirma con POST /api/guardado; como mucho 3 s
        self.servidor.guardado_recibido.clear()
        self.servidor.eventos.emitir("cerrar", {})
        t0 = time.time()
        while self._lista and not self.servidor.guardado_recibido.is_set() and time.time() - t0 < 3:
            QApplication.processEvents()
            time.sleep(0.02)
        registro(f"web: cerrar (guardado {'confirmado' if self.servidor.guardado_recibido.is_set() else 'sin confirmar'} en {time.time() - t0:.1f} s)")
        self.ajustes["geometria"] = bytes(self.saveGeometry().toBase64()).decode()
        self.servicio.cerrar()
        try:   # con los datos ya guardados se suelta el nombre de instancia única: una vieja atascada no impide abrir otra
            if not os.environ.get("CATODE_CIERRE_VIEJO"):   # (la prueba «fantasma» reproduce la 1.1.5: no soltaba el nombre)
                getattr(self, "_soltar_instancia", lambda: None)()
        except Exception:   # noqa: BLE001
            pass
        try:
            if self._ctl is not None:
                self._ctl.Close()
        except Exception:   # noqa: BLE001
            pass
        self.servidor.parar()
        ev.accept()
        QTimer.singleShot(0, lambda: QApplication.instance().exit(self.codigo_salida))


# ==================================================================================================== la ventana de Google
ENTRAR_GOOGLE = "https://accounts.google.com/ServiceLogin?service=youtube&hl=es&continue=https://www.youtube.com/"
_ENTORNO_CUENTA = {"tarea": None}


def carpeta_cuenta():
    """<carpeta de Cat-ode>\\cuenta: los datos de Edge de la ventana de Google (sus galletas se quedan aquí: las siguientes
    veces se leen sin volver a entrar)."""
    from . import motor_web
    return os.path.join(motor_web.carpeta_app(), "cuenta")


class VentanaCuenta(QMainWindow):
    """18/10/2026 · entrar con Google DENTRO de Cat-ode (orden del autor: «coja los canales de mi otra cuenta de youtube (que
    configuraré desde la propia app e importará en local todos los datos de la cuenta)»).

    Su PROPIO entorno de WebView2 (carpeta «cuenta», aparte de «edge»; sin --disable-web-security: se vacía
    WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS antes de crearlo) y agente de usuario de Chrome de escritorio sin «Edg/» (con la
    marca de Edge embebido Google puede negar la entrada). Primero, oculta, abre youtube.com: si las galletas guardadas aún
    valen (SAPISID), las lee y se cierra sin enseñarse. Si no, se enseña en accounts.google.com/ServiceLogin y, al volver a
    youtube.com con SAPISID, lee TODAS las galletas (también las HttpOnly) con CookieManager.GetCookiesAsync y se cierra.
    modo «salir»: borra sus galletas (DeleteAllCookies) sin enseñarse. al_acabar(galletas | None, motivo) se llama una vez
    (y las demás de «esperando»), siempre en el hilo de la ventana."""

    def __init__(self, al_acabar, modo="entrar", padre=None):
        super().__init__(padre)
        self.modo = modo
        self.esperando = [al_acabar]
        self.acabada = False
        self._ctl = self._wv = None
        self._vista = False
        self._leyendo = False
        self.setWindowTitle("Entrar en YouTube · Cat-ode")
        self.resize(520, 760)
        self.zona = QWidget(self)
        self.zona.setAttribute(Qt.WA_NativeWindow)
        self.zona.setAttribute(Qt.WA_DontCreateNativeAncestors)
        self.zona.setStyleSheet("background: #FFFFFF;")
        self.setCentralWidget(self.zona)
        self.zona.installEventFilter(self)
        self.zona.winId()   # la ventana nativa existe ya, aunque no se enseñe (fase oculta)
        self._reloj = QTimer(self, singleShot=True, interval=25_000)   # la fase oculta no responde: a entrar a la vista
        self._reloj.timeout.connect(lambda: self._a_entrar("sin respuesta de YouTube en 25 s"))
        self._reloj.start()
        QTimer.singleShot(0, self._crear)

    # ---- entorno y control propios
    def _crear(self):
        from . import motor_web as mw
        try:
            Env = mw._net()
            if _ENTORNO_CUENTA["tarea"] is None:
                viejo = mw.vaciar_argumentos()
                opciones = None
                try:
                    from Microsoft.Web.WebView2.Core import CoreWebView2EnvironmentOptions
                    opciones = CoreWebView2EnvironmentOptions()
                    opciones.AdditionalBrowserArguments = ""
                    try:
                        opciones.Language = "es-ES"
                    except Exception:   # noqa: BLE001 (SDK antiguo)
                        pass
                except Exception as error:   # noqa: BLE001
                    registro(f"cuenta: sin opciones de entorno ({error!r})"[:200])
                carpeta = carpeta_cuenta()
                os.makedirs(carpeta, exist_ok=True)
                _ENTORNO_CUENTA["tarea"] = Env.CreateAsync(None, carpeta, opciones)
                _ENTORNO_CUENTA["viejo"] = viejo
            mw.esperar(_ENTORNO_CUENTA["tarea"], self._con_entorno, registro)
        except Exception as error:   # noqa: BLE001
            registro(f"cuenta: WebView2 no arranca ({error!r})"[:200])
            self.terminar(None, "No he podido abrir la ventana de Google. Usa la sesión de Firefox de este equipo.")

    def _con_entorno(self, env):
        from System import IntPtr
        from . import motor_web as mw
        mw.poner_argumentos(_ENTORNO_CUENTA.pop("viejo", None))   # la variable vuelve para los motores de vídeo
        if self.acabada:
            return
        registro("cuenta: entorno de la ventana de Google listo (carpeta «cuenta», sin argumentos)")
        mw.esperar(env.CreateCoreWebView2ControllerAsync(IntPtr(int(self.zona.winId()))), self._con_controlador, registro)

    def _con_controlador(self, ctl):
        if self.acabada:
            try:
                ctl.Close()
            except Exception:   # noqa: BLE001
                pass
            return
        from . import cuenta
        self._ctl, self._wv = ctl, ctl.CoreWebView2
        st = self._wv.Settings
        try:
            st.UserAgent = cuenta.UA_CHROME
        except Exception as error:   # noqa: BLE001 (SDK sin UserAgent: sigue con el de Edge)
            registro(f"cuenta: sin agente de usuario propio ({error!r})"[:200])
        st.AreDevToolsEnabled = False
        st.IsStatusBarEnabled = False
        self._wv.NavigationCompleted += self._navegada
        try:
            self._wv.NewWindowRequested += self._ventana_nueva
        except Exception:   # noqa: BLE001
            pass
        self._colocar()
        if self.modo == "salir":
            try:
                self._wv.CookieManager.DeleteAllCookies()
                registro("cuenta: galletas de la ventana de Google borradas")
            except Exception as error:   # noqa: BLE001
                registro(f"cuenta: no he podido borrar las galletas ({error!r})"[:200])
            return self.terminar(None, "sesión cerrada")
        self._ctl.IsVisible = False
        self._wv.Navigate("https://www.youtube.com/")   # fase oculta: ¿siguen valiendo las galletas guardadas?

    def _ventana_nueva(self, _remitente, args):
        try:   # un enlace de Google que pide ventana nueva: en la misma
            args.Handled = True
            uri = str(args.Uri or "")
            if uri.startswith("https://"):
                self._wv.Navigate(uri)
        except Exception:   # noqa: BLE001
            pass

    def _navegada(self, _remitente, _args):
        if self.acabada or self._wv is None:
            return
        try:
            uri = str(self._wv.Source or "")
        except Exception:   # noqa: BLE001
            uri = ""
        anfitrion = re.sub(r"^https?://([^/:?#]+).*$", r"\1", uri).lower()
        if anfitrion in ("www.youtube.com", "m.youtube.com", "youtube.com"):
            self._leer_galletas()
        elif not self._vista:
            self._a_entrar(f"fase oculta en {anfitrion or 'nada'}")

    def _leer_galletas(self):
        if self._leyendo:
            return
        self._leyendo = True
        from . import motor_web as mw
        try:
            mw.esperar(self._wv.CookieManager.GetCookiesAsync("https://www.youtube.com"), self._con_galletas, registro)
        except Exception as error:   # noqa: BLE001
            self._leyendo = False
            registro(f"cuenta: no puedo leer las galletas ({error!r})"[:200])

    def _con_galletas(self, lista):
        self._leyendo = False
        d = {}
        try:
            for c in lista:
                d[str(c.Name)] = str(c.Value)
        except Exception as error:   # noqa: BLE001
            registro(f"cuenta: galletas ilegibles ({error!r})"[:200])
        if d.get("SAPISID") or d.get("__Secure-3PAPISID"):
            registro(f"cuenta: sesión de YouTube leída ({len(d)} galletas, {'a la vista' if self._vista else 'sin enseñar la ventana'})")
            return self.terminar(d, None)
        if not self._vista:
            self._a_entrar("sin sesión guardada")

    def _a_entrar(self, motivo):
        if self.acabada or self._vista:
            return
        if self.modo != "entrar":   # «salir» nunca se enseña
            return self.terminar(None, motivo)
        self._vista = True
        self._reloj.stop()
        registro(f"cuenta: a entrar en Google ({motivo})")
        self.show()
        self.traer_al_frente()
        if self._ctl is not None:
            self._ctl.IsVisible = True
            self._colocar()
            self._wv.Navigate(ENTRAR_GOOGLE)
        else:   # el control aún no está: se espera un poco más (sigue oculto); si no llega nunca, se dice
            self._vista = False
            self._sin_control = getattr(self, "_sin_control", 0) + 1
            if self._sin_control > 4:
                return self.terminar(None, "La ventana de Google no arranca. Usa la sesión de Firefox de este equipo.")
            self._reloj.start(5_000)

    def traer_al_frente(self):
        if self._vista:
            self.showNormal(); self.raise_(); self.activateWindow()

    def _colocar(self):
        if self._ctl is None:
            return
        from System.Drawing import Rectangle
        r = self.zona.devicePixelRatioF()
        self._ctl.Bounds = Rectangle(0, 0, int(self.zona.width() * r), int(self.zona.height() * r))

    def eventFilter(self, obj, ev):
        if obj is getattr(self, "zona", None) and ev.type() in (QEvent.Resize, QEvent.Show):
            self._colocar()
        return False

    def terminar(self, galletas, motivo):
        if self.acabada:
            return
        self.acabada = True
        self._reloj.stop()
        for f in self.esperando:
            try:
                f(galletas, motivo)
            except Exception as error:   # noqa: BLE001
                registro(f"cuenta: {error!r}"[:200])
        try:
            if self._ctl is not None:
                self._ctl.Close()
        except Exception:   # noqa: BLE001
            pass
        self._ctl = self._wv = None
        self.hide()
        self.deleteLater()

    def closeEvent(self, ev):
        if not self.acabada:
            self.terminar(None, "Has cerrado la ventana sin entrar en Google. Puedes usar la sesión de Firefox de este equipo.")
        ev.accept()
