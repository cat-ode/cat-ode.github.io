"""Cat-ode escritorio · crear mpv aunque el libmpv del sistema sea más viejo. 02/11/2026.

MEDIDO en un Debian 12 limpio con el paquete .deb (su libmpv es la 0.35.1): Cat-ode se cerraba al abrir con «mpv option does not
exist … input-cursor-passthrough», una opción que llegó en la 0.37 (Ubuntu 24.04 trae la 0.37 y por eso aquí nunca se vio). Si
este libmpv no conoce alguna de las opciones, se crea sin ella: Cat-ode funciona igual (sin esa, el ratón sobre el vídeo lo recibe
mpv en vez de Cat-ode)."""


def crear_mpv(**opciones):
    import mpv
    while True:
        try:
            return mpv.MPV(**opciones)
        except AttributeError as e:
            a = e.args
            datos = a[2] if len(a) > 2 and isinstance(a[2], tuple) else ()
            nombre = datos[1].decode("utf-8", "replace").replace("-", "_") if len(datos) > 1 and isinstance(datos[1], bytes) else ""
            if not a or "option does not exist" not in str(a[0]) or nombre not in opciones:
                raise
            opciones.pop(nombre)
            try:
                from .resolutor import registro
                registro(f"mpv: este libmpv no tiene la opción {nombre}; sigo sin ella")
            except Exception:   # noqa: BLE001
                pass
