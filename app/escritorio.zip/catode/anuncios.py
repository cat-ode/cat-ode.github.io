"""Cat-ode · los anuncios que el creador mete dentro del vídeo (03/10/2026: «quiero que la app se salte los anuncios de
los vídeos, los que hacen dentro del video haciéndote perder el tiempo con basura publicitaria»).

SponsorBlock solo cubre lo que alguien ya ha marcado (en su historial, 1 de cada 5 vídeos). Esto los busca él mismo:
  1. capítulos cuyo nombre es de anuncio («Patrocinador», «Sponsor», «Publicidad») o lleva la marca anunciada;
  2. en los subtítulos (los automáticos valen): grupos de frases de anuncio («patrocinado por», «gracias a … por»,
     «usa el código», «% de descuento», «enlace en la descripción»…) junto con las marcas de los enlaces de la descripción.
Prudente: varias señales en menos de un minuto (al menos una fuerte) y como mucho 150 s por tramo.
Devuelve [(inicio, fin, "anuncio")] en segundos.

15/10/2026: YouTube contestaba a los subtítulos con su página «tráfico automático» (HTTP 429) y no saltaba nada, en
silencio. Ahora solo se leen si la descripción avisa de publicidad («publi», «patrocinado», código de descuento, una
marca conocida), se piden como Chrome (curl_cffi, igual que yt-dlp) y, si YouTube los niega, 6 h sin pedirlos y apuntado."""
import os
import threading
import re
import time
import urllib.error
import urllib.request

FUERTE = re.compile(r"patrocin|sponsor|c[óo]digo (de )?descuento|discount code|use (the )?code|usa (el )?c[óo]digo|"
                    r"con el c[óo]digo|promo ?code|% (de descuento|off)|por ciento de descuento|gracias a \w+ por (patrocinar|apoyar|hacer posible)|"
                    r"thanks to \w+ for sponsoring|this (video|episode) is (brought to you|sponsored)|este (v[íi]deo|episodio) (est[áa] patrocinado|es posible gracias)", re.I)
DEBIL = re.compile(r"enlace (en|de) la descripci[óo]n|link (en|in) (la |the )?descripci[óo]n|link (in|below)|descarga (la app|gratis)|"
                   r"prueba gratis|free trial|primer mes|first month|reg[íi]strate gratis|sign up (for free|today|now)|"
                   r"\boferta\b|\bahorra\b|\bsave \d+|\bvpn\b|\bcup[óo]n\b|\bcoupon\b", re.I)
AVISO = re.compile(r"\bpubli\b|publicidad|patrocin|sponsor|colaboraci[óo]n (pagada|con)|promoci[óo]n pagada|paid promotion|"
                   r"c[óo]digo|descuento|discount|promo ?code|\bcode\b|\bcup[óo]n|\bcoupon|% off|afiliad|affiliate", re.I)
MARCA_TEXTO = re.compile(r"(?:\bpubli(?:cidad)?|patrocinad[oa] por|patrocinador(?:es)?|sponsored by|sponsor)\W{0,4}"
                         r"([A-Za-z0-9][\w&'-]*(?: [A-Z][\w&'-]*)?)", re.I)
NO_MARCA = {"de", "del", "por", "el", "la", "los", "las", "en", "con", "un", "una", "this", "the", "of", "by", "and", "y", "es"}
CAPITULO = re.compile(r"patrocin|sponsor|publicidad|anuncio|\bad\b|advert|promo", re.I)
MARCAS_HABITUALES = ("nordvpn", "surfshark", "expressvpn", "raid shadow", "squarespace", "skillshare", "audible", "hellofresh",
                     "manscaped", "brilliant", "incogni", "bitdefender", "keeper", "trade republic", "revolut", "freepik",
                     "hostinger", "odoo", "holded", "factorial", "babbel", "storytel", "curiositystream", "ground news",
                     "aura", "honey", "ridge", "established titles", "displate", "hims", "shopify", "wix", "notion")


def marcas_de(descripcion):
    """Las marcas de los enlaces de la descripción (dominios), sin las redes sociales ni YouTube."""
    fuera = {"youtube", "youtu", "instagram", "twitter", "x", "tiktok", "facebook", "twitch", "patreon", "discord", "spotify",
             "apple", "google", "linktr", "bit", "amzn", "amazon", "paypal", "telegram", "whatsapp", "threads", "linkedin", "ko-fi",
             "bsky", "link", "reddit", "tumblr", "pinterest", "substack", "medium", "goo", "forms", "drive", "docs", "wikipedia", "github"}
    r = set()
    for d in re.findall(r"https?://(?:www\.)?([a-z0-9-]+)\.[a-z.]+", (descripcion or "").lower()):
        if d not in fuera and len(d) > 3:
            r.add(d.replace("-", " "))
    for m in MARCA_TEXTO.findall(descripcion or ""):   # «*publi: Shopify», «patrocinado por NordVPN»
        m = m.strip(" .:'-").lower()
        if len(m) > 2 and m.split()[0] not in NO_MARCA:
            r.add(m)
    return r


def hay_publi(descripcion):
    """La descripción avisa de un anuncio dentro del vídeo: solo entonces se piden los subtítulos."""
    d = descripcion or ""
    return bool(AVISO.search(d)) or any(_palabra(m).search(d) for m in MARCAS_HABITUALES)


def _cues(vtt):
    """(inicio, fin, texto) de un VTT, sin las repeticiones de los subtítulos automáticos."""
    def seg(t):
        p = t.replace(",", ".").split(":")
        return sum(float(x) * 60 ** i for i, x in enumerate(reversed(p)))
    r, ultimo = [], ""
    for b in re.split(r"\n\s*\n", vtt):
        m = re.search(r"([\d:.,]+)\s*-->\s*([\d:.,]+)", b)
        if not m:
            continue
        cuerpo = b[m.end():].split("\n", 1)[1] if "\n" in b[m.end():] else ""   # sin la línea de formato (align:…)
        texto = re.sub(r"<[^>]+>|&gt;|&lt;|\[[^]]*\]", " ", cuerpo).strip().replace("\n", " ")
        if not texto or texto == ultimo:
            continue
        ultimo = texto
        r.append((seg(m.group(1)), seg(m.group(2)), texto))
    return r


def _palabra(m):
    return re.compile(r"(?<![\w])" + re.escape(m) + r"(?![\w])", re.I)


def por_subtitulos(vtt, marcas):
    # 03/10/2026: una sola expresión para todas las marcas (antes, una búsqueda por marca y por línea: con los
    # subtítulos de un vídeo de 2 h en 3-4 pestañas, el N100 dejaba la ventana sin turno 9 s por cada cambio de pestaña)
    lista = sorted({m for m in marcas | set(MARCAS_HABITUALES) if m}, key=len, reverse=True)
    junta = re.compile(r"(?<![\w])(?:" + "|".join(re.escape(m) for m in lista) + r")(?![\w])", re.I) if lista else None
    golpes = []   # (segundo, fuerza)
    for n, (a, b, t) in enumerate(_cues(vtt)):
        if n % 50 == 0:
            time.sleep(0.001)   # cede el turno a la ventana
        tl = t.lower()
        de_marca = len({x.lower() for x in junta.findall(tl)}) if junta else 0
        fuerza = 2 * len(FUERTE.findall(tl)) + len(DEBIL.findall(tl)) + 2 * de_marca
        if fuerza:
            golpes.append((a, b, fuerza, bool(FUERTE.search(tl)) or de_marca > 0))
    tramos, grupo = [], []
    for g in golpes + [(1e9, 1e9, 0, False)]:
        if grupo and g[0] - grupo[-1][1] > 40:
            total = sum(x[2] for x in grupo)
            if total >= 5 and any(x[3] for x in grupo) and len(grupo) >= 3:
                a, b = max(0.0, grupo[0][0] - 3), grupo[-1][1] + 6
                if 25 <= b - a <= 150:
                    tramos.append((a, b, "anuncio"))
            grupo = []
        grupo.append(g)
    return tramos


def por_capitulos(capitulos, duracion, marcas):
    r = []
    marcas = {m for m in marcas}
    for i, (s, nombre) in enumerate(capitulos):
        fin = capitulos[i + 1][0] if i + 1 < len(capitulos) else duracion
        n = (nombre or "").lower()
        if (CAPITULO.search(n) or any(_palabra(m).search(n) for m in marcas | set(MARCAS_HABITUALES))) and 5 <= fin - s <= 240:
            r.append((float(s), float(fin), "anuncio"))
    return r


def detectar(descripcion, capitulos, duracion, vtt_url=None, agente="Mozilla/5.0"):
    marcas = marcas_de(descripcion)
    r = por_capitulos(capitulos or [], duracion or 0, marcas)
    if vtt_url and not r and hay_publi(descripcion):
        vtt = bajar_subtitulos(vtt_url, agente)
        if vtt:
            r = _en_otro_proceso(vtt, marcas)
    return r


_pausa = [0.0]   # hasta cuándo no se piden subtítulos (YouTube los ha negado)


def _apuntar(texto):
    try:
        from .resolutor import registro
        registro(texto)
    except Exception:   # noqa: BLE001
        pass


def bajar_subtitulos(url, agente="Mozilla/5.0", forzar=False):
    """Un VTT de YouTube, pedido como Chrome (curl_cffi) si está; "" si no se puede. Ante «tráfico automático» (429),
    6 h sin pedir subtítulos para anuncios (forzar=True: los pide el autor para verlos en pantalla)."""
    if not forzar and time.time() < _pausa[0]:
        return ""
    codigo, texto = 0, ""
    try:
        try:
            from curl_cffi import requests as cr
            x = cr.get(url, impersonate="chrome", timeout=20)
            codigo, texto = x.status_code, x.text
        except ImportError:
            try:
                texto = urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": agente}), timeout=20).read().decode("utf-8", "ignore")
                codigo = 200
            except urllib.error.HTTPError as e:
                codigo = e.code
    except Exception as error:   # noqa: BLE001
        _apuntar(f"subtítulos: no se han podido leer ({error!r})"[:200])
        return ""
    if codigo == 200 and "WEBVTT" in texto[:200]:
        return texto
    if codigo == 429 or "automated queries" in texto:
        _pausa[0] = time.time() + 6 * 3600
        _apuntar("subtítulos: YouTube los niega (429, tráfico automático); 6 h sin pedirlos para buscar anuncios")
    else:
        _apuntar(f"subtítulos: respuesta {codigo} sin VTT")
    return ""


_UNO = threading.Lock()   # de uno en uno


def _en_otro_proceso(vtt, marcas):
    """El análisis de subtítulos, en un proceso aparte (04/10/2026): en el mismo proceso, con 3-4 vídeos largos a la vez,
    acaparaba el intérprete de Python y la ventana se quedaba 6-7 s sin responder en el N100."""
    import json
    import subprocess
    import sys
    carpeta = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    codigo = ("import sys, json; sys.path.insert(0, sys.argv[1]); from catode.anuncios import por_subtitulos; "
              "d = json.loads(sys.stdin.buffer.read().decode('utf-8')); "
              "sys.stdout.write(json.dumps(por_subtitulos(d['vtt'], set(d['marcas']))))")
    extra = {"creationflags": 0x08000000} if os.name == "nt" else {}   # sin ventana de consola
    with _UNO:
        try:
            p = subprocess.run([sys.executable, "-c", codigo, carpeta], input=json.dumps({"vtt": vtt, "marcas": sorted(marcas)}).encode("utf-8"),
                               capture_output=True, timeout=60, **extra)
            return [tuple(x) for x in json.loads(p.stdout.decode("utf-8") or "[]")]
        except Exception:   # noqa: BLE001 (si el proceso aparte falla, aquí mismo, como antes)
            return por_subtitulos(vtt, marcas)
