"""Cat-ode escritorio · el motor falso de las pruebas sin red (06/10/2026, DISENO_WEB.md §4, módulo M3).

Con CATODE_PRUEBA_INTERFAZ=1 la interfaz web no pide NADA a YouTube ni a Google: motor, metadatos, Datos (servidor del
autor), tele, miembros y el Resolutor leen los fixtures de pruebas/fixtures (o los fabrica grabar_fixtures.sinteticos()
si la carpeta no está), con 300 ms de retardo simulado (CATODE_FIXTURES_RETARDO). Además:
- el socket queda parcheado: todo destino que no sea 127.0.0.1 se rechaza (y se cuenta en bloqueadas);
- los datos van a una carpeta de prueba (CATODE_CARPETA_PRUEBA; si no, ~/.cache/obra/catode-web/datos en Linux y, en
  Windows, %LOCALAPPDATA%\\Cat-ode si es la carpeta de prueba o %TEMP%\\catode-web-prueba): nunca los del autor;
- la primera vez se siembran unos datos de prueba (suscripciones, historial, ver más tarde, me gusta, una lista);
- /api/resolver devuelve el archivo local CATODE_VIDEO_LOCAL (por defecto pruebas/video_prueba.mp4);
- CATODE_FIXTURES_FALLO=inicio[,buscar,…] hace fallar esas funciones como si no hubiera red.
Solo lo activa el servicio web (servicio.Servicio): la interfaz Qt no lo usa."""
import json
import os
import socket
import tempfile
import threading
import time

AQUI = os.path.dirname(os.path.abspath(__file__))
_activo = False
bloqueadas = []          # destinos rechazados por el socket parcheado (deben ser 0 en una prueba bien hecha)
F = {}                   # los fixtures cargados
CARPETA = None           # carpeta de los fixtures (miniatura.jpg, subs.vtt)
DATOS = None             # carpeta de datos de prueba
_cerrojo = threading.Lock()


def _espera():
    try:
        time.sleep(float(os.environ.get("CATODE_FIXTURES_RETARDO", "0.3")))
    except ValueError:
        time.sleep(0.3)


def _falla(nombre):
    if nombre in [x.strip() for x in os.environ.get("CATODE_FIXTURES_FALLO", "").split(",") if x.strip()]:
        raise ConnectionRefusedError(f"fixtures: fallo forzado de «{nombre}» (CATODE_FIXTURES_FALLO)")


def video_local():
    v = os.environ.get("CATODE_VIDEO_LOCAL")
    if v and os.path.exists(v):
        return v
    for c in (os.path.join(os.path.dirname(os.path.dirname(AQUI)), "pruebas", "video_prueba.mp4"),
              os.path.join(os.path.dirname(AQUI), "video_prueba.mp4")):
        if os.path.exists(c):
            return c
    return v or ""


def ruta_local(url):
    """«/fixtures/subs.vtt» → la ruta del archivo en la carpeta de fixtures; lo demás, tal cual."""
    if url.startswith("/fixtures/"):
        r = os.path.join(CARPETA or "", os.path.basename(url))
        if url.startswith("/fixtures/vi/") and not os.path.exists(r):   # variante sin archivo: la pequeña de siempre
            r = os.path.join(CARPETA or "", "miniatura.jpg")
        return r
    return url[5:] if url.startswith("file:") else url


# ---------------------------------------------------------------- red cortada
def _local(host):
    h = str(host or "").strip("[]").lower()
    return h in ("localhost", "::1", "0.0.0.0", "") or h.startswith("127.")


def _parchear_socket():
    orig_connect, orig_connect_ex, orig_sendto = socket.socket.connect, socket.socket.connect_ex, socket.socket.sendto
    orig_gai = socket.getaddrinfo

    def rechazar(destino):
        with _cerrojo:
            bloqueadas.append(str(destino)[:80])
        try:
            from .resolutor import registro
            registro(f"fixtures: conexión saliente bloqueada → {destino}")
        except Exception:   # noqa: BLE001
            pass
        raise ConnectionRefusedError(f"fixtures: red prohibida ({destino})")

    def connect(self, addr):
        if isinstance(addr, tuple) and not _local(addr[0]):
            rechazar(addr)
        return orig_connect(self, addr)

    def connect_ex(self, addr):
        if isinstance(addr, tuple) and not _local(addr[0]):
            rechazar(addr)
        return orig_connect_ex(self, addr)

    def sendto(self, datos, *a):
        addr = a[-1] if a else None
        if isinstance(addr, tuple) and not _local(addr[0]):
            rechazar(addr)
        return orig_sendto(self, datos, *a)

    def getaddrinfo(host, *a, **k):
        if not _local(host if not isinstance(host, bytes) else host.decode(errors="replace")):
            with _cerrojo:
                bloqueadas.append(f"dns {host}")
            raise socket.gaierror(f"fixtures: DNS prohibido ({host})")
        return orig_gai(host, *a, **k)
    socket.socket.connect, socket.socket.connect_ex, socket.socket.sendto = connect, connect_ex, sendto
    socket.getaddrinfo = getaddrinfo


# ---------------------------------------------------------------- fixtures
def _cargar_fixtures():
    global CARPETA
    candidatas = [os.environ.get("CATODE_FIXTURES", ""), os.path.join(os.path.dirname(os.path.dirname(AQUI)), "pruebas", "fixtures"),
                  os.path.join(os.path.dirname(AQUI), "fixtures")]
    for c in candidatas:
        if c and os.path.exists(os.path.join(c, "parati.json")):
            CARPETA = c
            for n in os.listdir(c):
                if n.endswith(".json"):
                    with open(os.path.join(c, n), encoding="utf-8") as f:
                        F[n[:-5]] = json.load(f)
            break
    else:   # sin carpeta: sintéticos en memoria y la miniatura y los subtítulos en una carpeta temporal
        from . import grabar_fixtures as g
        F.update(g.sinteticos())
        CARPETA = os.path.join(tempfile.gettempdir(), "catode-fixtures")
        os.makedirs(CARPETA, exist_ok=True)
        if not os.path.exists(os.path.join(CARPETA, "miniatura.jpg")):
            g.miniatura(os.path.join(CARPETA, "miniatura.jpg"))
        with open(os.path.join(CARPETA, "subs.vtt"), "w", encoding="utf-8") as f:
            f.write(g.vtt())
    # las fechas, a hoy (así «Hoy» y «Esta semana» tienen algo aunque los fixtures sean de otro día)
    fechas = [v.get("fecha") or 0 for v in F.get("novedades", {}).get("videos", [])]
    delta = int(time.time() * 1000) - max(fechas) - 3600_000 if fechas and max(fechas) else 0
    if delta > 0:
        for clave in ("parati", "novedades", "historial_yt"):
            for v in F.get(clave, {}).get("videos", []):
                if v.get("fecha"):
                    v["fecha"] += delta
        for v in F.get("canal", {}).get("videos", []):
            if v.get("fecha"):
                v["fecha"] += delta


def _E(d):
    from . import motor
    return motor.elemento_de_dict(d)


def _todos_los_videos():
    return F["parati"]["videos"] + F["novedades"]["videos"] + F.get("historial_yt", {}).get("videos", [])


def _buscar_video(vid):
    from . import motor
    return next((v for v in _todos_los_videos() if motor.id_video(v.get("url", "")) == vid), None)


# ---------------------------------------------------------------- carpeta de datos aparte y semilla
def _carpeta_datos():
    global DATOS
    d = os.environ.get("CATODE_CARPETA_PRUEBA")
    if not d:
        if os.name == "nt":
            la = os.environ.get("LOCALAPPDATA", "")
            d = os.path.join(la, "Cat-ode") if "prueba" in la.lower() else os.path.join(tempfile.gettempdir(), "catode-web-prueba")
        else:
            d = os.path.expanduser("~/.cache/obra/catode-web/datos")
    os.makedirs(d, exist_ok=True)
    DATOS = d
    from . import datos, metadatos, ajustes
    datos.carpeta_datos = lambda: (os.makedirs(d, exist_ok=True), d)[1]
    datos.carpeta_config = lambda: d
    metadatos._carpeta_cache = lambda: d
    ajustes.carpeta = lambda: d


def _sembrar():
    """La primera vez: datos de prueba creíbles en la carpeta aparte."""
    import platform
    from . import datos
    archivo = os.path.join(DATOS, f"datos-{platform.node()}.json")
    if os.path.exists(archivo):
        return
    d = datos.Datos()
    ahora = int(time.time() * 1000)

    def poner(col, clave, e, x=None, i=0):
        d.c[col][clave] = {"t": ahora - i * 60_000, "activo": True, "e": e, "x": x}
    for i, c in enumerate(F.get("suscripciones", [])):
        poner("suscripciones", c["url"], _E(c), None, i)
    hist = F.get("historial_yt", {}).get("videos", [])[:30]
    for i, v in enumerate(hist):
        poner("historial", v["url"], _E(dict(v, fecha=0)), None, i)
    for i, v in enumerate(hist[:2]):   # «Continuar viendo»
        dur = v.get("duracion") if (v.get("duracion") or 0) > 200 else 600
        poner("posiciones", v["url"], None, {"s": 120, "d": dur}, i)
    for i, v in enumerate(F["parati"]["videos"][:5]):
        poner("despues", v["url"], _E(v), None, i)
    for i, v in enumerate(F["novedades"]["videos"][:5]):
        poner("megusta", v["url"], _E(v), None, i)
    poner("listas", "propia:1", None, {"nombre": "Para luego (prueba)", "videos": [dict(v) for v in F["parati"]["videos"][5:9]]})
    for i, q in enumerate(("gatos", "pan de masa madre", "saturno")):
        poner("busquedas", q, None, {"q": q}, i)
    d._guardar_ya()


# ---------------------------------------------------------------- los parches
def _parchear_modulos():
    from . import motor, metadatos as md, datos, tele, miembros, resolutor, actualizar

    def canal_cab(url):
        c = F["canal"]["cabecera"]
        s = next((x for x in F.get("suscripciones", []) if x["url"] == url), None)
        return _E(dict(c, url=url or c["url"], titulo=(s or c)["titulo"]))

    def buscar(q, n=40):
        _espera(); _falla("buscar")
        return [_E(x) for x in F["busqueda"]["elementos"]][:n]

    def buscar_filtrada(q, filtros=None, continuacion=None):
        _espera(); _falla("buscar")
        els = F["busqueda"]["elementos"]
        if continuacion:   # segunda página: los mismos con otros ids (no se repiten en la rejilla)
            els = [dict(x, url=x["url"][:-1] + ("Z" if x["url"][-1] != "Z" else "Y"), titulo=x["titulo"] + " (2)") for x in reversed(els)
                   if x.get("tipo") == "VIDEO"]
        tipo = (filtros or {}).get("tipo")
        if tipo:
            quiero = {"Vídeos": "VIDEO", "Canales": "CANAL", "Listas": "LISTA"}.get(tipo)
            if quiero:
                els = [x for x in els if x.get("tipo") == quiero]
        return [_E(x) for x in els], (None if continuacion else F["busqueda"].get("cursor"))

    def sugerencias(q):
        _espera(); _falla("sugerencias")
        s = F.get("sugerencias", [])
        return [x for x in s if q.lower().strip() in x] or s

    def canal_completo(url, n=60):
        _espera(); _falla("canal")
        info = dict(F["canal"]["info"])
        cab = canal_cab(url)
        info["nombre"] = cab.titulo
        return cab, [_E(v) for v in F["canal"]["videos"]][:n], info

    def canal(url):   # sin retardo, por lo mismo
        _falla("canal")
        return canal_cab(url), [_E(v) for v in F["canal"]["videos"]]

    def canal_pestana(url, pestana, n=60):
        _espera(); _falla("canal")
        return [_E(v) for v in F["canal"].get(pestana, [])][:n]

    def lista(url):
        _espera(); _falla("lista")
        return F["lista_yt"]["titulo"], [_E(v) for v in F["lista_yt"]["videos"]]

    def ficha(url, _sin_espera=False):
        if not _sin_espera:
            _espera()
        _falla("ficha")
        vid = motor.id_video(url)
        f = json.loads(json.dumps(F["ficha"]))
        v = _buscar_video(vid)
        if v:
            f.update({"titulo": v["titulo"], "autor": v["autor"], "autorUrl": v["autorUrl"]})
        f.update({"url": motor.url_video(vid), "id": vid, "miniatura": motor.miniatura(vid)})
        f["relacionados"] = [_E(r) for r in f.get("relacionados", []) if motor.id_video(r["url"]) != vid]
        f["capitulos"] = [tuple(c) for c in f.get("capitulos", [])]
        return f

    def relacionados(url):   # sin retardo: el entorno de «fulminar» hace decenas (en serie sumaría segundos falsos)
        return ficha(url, True)["relacionados"]

    def novedades(canales, por_canal=15, n=300):
        _espera(); _falla("suscripciones")
        return [_E(v) for v in F["novedades"]["videos"]][:n]

    def para_ti(historial, suscripciones, n=60):
        _espera(); _falla("inicio")
        return [_E(v) for v in F["parati"]["videos"]][:n]

    def explorar(categoria):
        _espera(); _falla("explorar")
        ex = F["explorar"]
        return [_E(v) for v in ex.get(categoria) or next(iter(ex.values()))]

    def comentarios(url, continuacion=None):
        _espera(); _falla("comentarios")
        c = F["comentarios"]
        return c["comentarios"][:10] if not continuacion else c["comentarios"][10:], (c.get("cursor") if not continuacion else None)

    def shorts(canales, por_canal=6, n_canales=16):
        _espera(); _falla("shorts")
        return [_E(v) for v in F.get("shorts", [])]

    def descargar(e, solo_audio=False, alto=720, progreso=None):
        _falla("descargar")
        for i in range(1, 6):
            time.sleep(0.25)
            if progreso:
                progreso(i / 5, f"{e.titulo[:30]} · {i * 20} %")
        return video_local()

    def descargados():
        v = video_local()
        return [(v, "Vídeo de prueba (descargado)", "")] if v and os.path.exists(v) else []

    def carpeta_descargas():
        d = os.path.join(DATOS, "descargas")
        os.makedirs(d, exist_ok=True)
        return d

    def sin_red(*_a, **_k):
        raise ConnectionRefusedError("fixtures: sin red")

    for nombre, f in (("buscar", buscar), ("buscar_filtrada", buscar_filtrada), ("sugerencias", sugerencias), ("canal", canal),
                      ("canal_completo", canal_completo), ("canal_pestana", canal_pestana), ("lista", lista), ("ficha", ficha),
                      ("relacionados", relacionados), ("novedades", novedades), ("para_ti", para_ti), ("explorar", explorar),
                      ("comentarios", comentarios), ("shorts", shorts), ("patrocinios", lambda url: []), ("descargar", descargar),
                      ("descargados", descargados), ("carpeta_descargas", carpeta_descargas), ("_innertube", sin_red)):
        setattr(motor, nombre, f)

    def completo(url, duracion_s=-1):
        _espera(); _falla("completo")
        return json.loads(json.dumps(F["completo"]))

    def acerca_de(canal_url, cabecera=None):
        _espera(); _falla("acerca")
        return dict(F["acerca"])

    def valoracion(urls, avance=None):
        _espera()
        r = {"hechos": len(urls[:15]), "total": len(urls[:15]), "conVotos": len(urls[:15]), "mediaMeGusta": 97.4, "mediaNoMeGusta": 2.6}
        if avance:
            avance(r)
        return r

    def resumen(url, avisar_bloqueo=False):
        v = _buscar_video(motor.id_video(url)) or {}
        return {"duracion": v.get("duracion", 600), "vistas": 123456, "fecha": v.get("fecha", 0)}
    md.completo, md.acerca_de, md.valoracion = completo, acerca_de, valoracion

    # 28/10/2026 · descubrir.py (Inicio, Suscripciones y Explorar calculados en la app) con los fixtures y sin red: el RSS de
    # cada canal, sus novedades del fixture; los relacionados, los de la ficha; los destacados, los canales de los
    # relacionados y la búsqueda que no se siguen (pequeños); los vídeos de un canal, los del canal del fixture con otra
    # dirección por canal (si no, todos los descubiertos tendrían los mismos vídeos).
    import hashlib
    from . import descubrir
    subs_f = {s["url"] for s in F.get("suscripciones", [])}
    nombres_f = {}
    for v in F["ficha"].get("relacionados", []) + F["busqueda"]["elementos"]:
        u = v.get("autorUrl") or (v.get("url") if v.get("tipo") == "CANAL" else "")
        if u and u not in nombres_f:
            nombres_f[u] = v.get("autor") or v.get("titulo") or "Canal de prueba"

    def d_rss(url, titulo=""):
        _falla("suscripciones")
        _falla("inicio")
        return [_E(v) for v in F["novedades"]["videos"] if v.get("autorUrl") == url][:15]

    def d_relacionados(url):
        _falla("inicio")
        return ficha(url, True)["relacionados"]

    def d_destacados(url):
        _falla("explorar")
        return [(u, n, 45_600, "") for u, n in nombres_f.items() if u not in subs_f and u != url][:6]

    def d_canal(url, n=12):
        _falla("canal")
        cab = canal_cab(url)
        if url not in subs_f and nombres_f.get(url):
            cab = _E(dict(cab.dict(), titulo=nombres_f[url]))
        ahora = int(time.time() * 1000)
        videos = []
        for i, v in enumerate(F["canal"]["videos"][:n]):
            vid = hashlib.md5(f"{url}#{i}".encode()).hexdigest()[:11]
            videos.append(_E(dict(v, url=motor.url_video(vid), autor=cab.titulo, autorUrl=url, fecha=ahora - (i + 1) * 86_400_000)))
        return cab, videos, dict(F["canal"]["info"], nombre=cab.titulo, suscriptores="45,6 mil suscriptores")
    descubrir.pedir_rss, descubrir.pedir_relacionados, descubrir.pedir_destacados, descubrir.pedir_canal = \
        d_rss, d_relacionados, d_destacados, d_canal
    # con lo guardado, el Inicio sale aunque no haya red (es lo que se quiere); el fallo forzado «inicio» lo hace fallar
    # entero, para probar el cartel y el reintento de la página
    inicio_real = descubrir.Descubrir.inicio

    def d_inicio(self, *a, **k):
        _falla("inicio")
        return inicio_real(self, *a, **k)
    descubrir.Descubrir.inicio = d_inicio
    md.votos = lambda url: dict(F["completo"]["votos"])
    md.resumen, md.innertube = resumen, sin_red

    def del_servidor(self, ruta):
        _espera()
        ahora = int(time.time() * 1000)
        if ruta == "/app/parati.json":
            _falla("inicio")
            return dict(F["parati"], generado=ahora)
        if ruta == "/app/novedades.json":
            _falla("suscripciones")
            return dict(F["novedades"], generado=ahora)
        if ruta == "/app/historial.json":
            return dict(F.get("historial_yt", {"videos": []}), generado=ahora)
        return None

    def sincronizar(self):
        self.estado_sincro = f"Sincronizado a las {time.strftime('%H:%M')} (prueba sin red)"
        return True
    datos.Datos.del_servidor, datos.Datos.sincronizar = del_servidor, sincronizar
    datos.Datos.escuchar = lambda self, al_cambiar: None
    datos.pedir = lambda *a, **k: None
    tele.buscar = lambda espera=3.5: [("Tele de prueba", "http://127.0.0.1:9/apps/YouTube")]
    tele.poner = lambda app, url: True
    miembros.cuentas = lambda: [("firefox", "Firefox", "0", "", "Cuenta de prueba")]
    actualizar.empezar = lambda *a, **k: None

    def resolver(self, url, alto, fondo=False):
        _espera(); _falla("resolver")
        v = _buscar_video(motor.id_video(url)) or {}
        return {"t": time.time(), "ruta": video_local(), "hls": None, "titulo": v.get("titulo") or "Vídeo de prueba",
                "duracion": 25, "directo": False, "storyboard": None, "subs": [("/fixtures/subs.vtt", "Español", "es")], "alto": 360}
    resolutor.Resolutor.resolver = resolver
    resolutor.Resolutor._rapido = lambda self, url: None
    resolutor.Resolutor._hls = lambda self, url, i: None


def activar():
    """Una vez por proceso. Devuelve la carpeta de los fixtures."""
    global _activo
    if _activo:
        return CARPETA
    _activo = True
    _parchear_socket()
    _cargar_fixtures()
    _carpeta_datos()
    _parchear_modulos()
    _sembrar()
    try:
        from .resolutor import registro
        registro(f"fixtures: activos ({CARPETA}); datos de prueba en {DATOS}; red cortada (solo 127.0.0.1)")
    except Exception:   # noqa: BLE001
        pass
    return CARPETA


def activo():
    return _activo
