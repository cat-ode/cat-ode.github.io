"""Cat-ode escritorio · el servidor local de la interfaz web (06/10/2026, DISENO_WEB.md §1.3, §2 y módulo M2).

http://127.0.0.1:<puerto>/index.html?t=<token>: estáticos de catode/web/ (con ?v=VERSION en cada script y hoja), /api/*
en JSON según el contrato §2.3 (todo /api exige la cabecera X-Catode: <token>; /api/eventos admite también ?t=, porque
EventSource no deja poner cabeceras), /api/eventos por SSE (§2.4), /fixtures/* en modo de prueba y /<id> con saltos
(Range) para los archivos locales, como _ServidorLocal (motor_web.py). HTTP/1.1 con keep-alive y Content-Length
siempre (el N100 no abre un TCP por petición); Server-Timing en todo /api; semáforo de 4 para lo que tira de la red; una
petición cuyo cliente ya se fue antes de empezar no se procesa.

Solo, sin ventana (para probar en el ProBook):
    python -m catode.servidor_web --solo --puerto 8791 --fixtures [--token XXXX] [--prueba]"""
import json
import os
import queue
import re
import secrets
import select
import socket
import sys
import threading
import time
import urllib.parse
from collections import deque

if __package__ in (None, ""):   # python catode/servidor_web.py
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    __package__ = "catode"

from . import VERSION  # noqa: E402

_FIRMA = None


def firma_web():
    """La clave de caché de los ficheros de la página: VERSION + huella de su CONTENIDO (06/10/2026). Se servían como
    «inmutables un año» con ?v=VERSION: con el puerto fijo (origen estable), si cambiaba un fichero sin cambiar VERSION
    —las baterías del mini PC antes de publicar, o una instalación en caliente— Edge seguía usando el JavaScript VIEJO.
    Con la huella, cualquier cambio de cualquier fichero de web/ da direcciones nuevas."""
    global _FIRMA
    if _FIRMA is None:
        import hashlib
        h = hashlib.sha1()
        raiz = os.path.join(os.path.dirname(os.path.abspath(__file__)), "web")
        try:
            for carpeta, subs, ficheros in os.walk(raiz):
                subs.sort()
                for f in sorted(ficheros):
                    ruta = os.path.join(carpeta, f)
                    h.update(os.path.relpath(ruta, raiz).replace(os.sep, "/").encode())
                    with open(ruta, "rb") as fichero:
                        h.update(fichero.read())
            _FIRMA = f"{VERSION}-{h.hexdigest()[:8]}"
        except Exception:   # noqa: BLE001
            _FIRMA = VERSION
    return _FIRMA
from .motor_web import _ServidorLocal  # noqa: E402

AQUI = os.path.dirname(os.path.abspath(__file__))
WEB = os.path.join(AQUI, "web")
CSP = ("default-src 'self'; img-src 'self' data: https://*.ytimg.com https://*.ggpht.com https://*.googleusercontent.com; "
       "media-src 'self' blob:; frame-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self'")
TIPOS = {".html": "text/html; charset=utf-8", ".js": "application/javascript; charset=utf-8", ".css": "text/css; charset=utf-8",
         ".json": "application/json; charset=utf-8", ".svg": "image/svg+xml", ".png": "image/png", ".jpg": "image/jpeg",
         ".jpeg": "image/jpeg", ".gif": "image/gif", ".webp": "image/webp", ".ico": "image/x-icon", ".woff2": "font/woff2",
         ".woff": "font/woff", ".ttf": "font/ttf", ".vtt": "text/vtt; charset=utf-8", ".mp4": "video/mp4", ".webm": "video/webm",
         ".m4a": "audio/mp4", ".mp3": "audio/mpeg", ".opus": "audio/ogg", ".txt": "text/plain; charset=utf-8"}
CON_RED = re.compile(r"^/api/(pagina/(inicio|suscripciones|explorar|lista_yt|nut|shorts|canal)|canal/|buscar|video/|resolver|tele|completar)")
# lo de relleno (tarjetas y anuncios del creador, por detrás): su propio semáforo de 1, para no quitar huecos del de 4 a
# lo que pulsa el autor (resolver, ficha, páginas). En la Qt, Relleno tenía su propio grupo y no competía con el vídeo
DE_FONDO = re.compile(r"^/api/(completar|video/tramos)")
CODIGOS = {"bloqueo": 503, "sin_red": 504, "servidor_autor": 502, "imposible": 422}
IMAGENES = ("https://i.ytimg.com/", "https://i9.ytimg.com/", "https://yt3.ggpht.com/", "https://yt3.googleusercontent.com/",
            "https://lh3.googleusercontent.com/")


def _registro(texto):
    try:
        from .resolutor import registro
        registro(texto)
    except Exception:   # noqa: BLE001
        print("Cat-ode:", texto, file=sys.stderr, flush=True)


class Eventos:
    """SSE: una cola por cliente y las últimas 200 para quien vuelve con Last-Event-ID. Un cliente nuevo (sin
    Last-Event-ID) solo recibe lo que se emitió antes de que se conectara el primero (p. ej. el enlace con el que se
    abrió Cat-ode); así recargar la página no repite avisos viejos."""
    def __init__(self):
        self.clientes = set()
        self.historia = deque(maxlen=200)
        self.n = 0
        self.cerrojo = threading.Lock()
        self._hubo_cliente = False

    def emitir(self, tipo, datos=None):
        with self.cerrojo:
            self.n += 1
            ev = (self.n, tipo, json.dumps(datos if datos is not None else {}, ensure_ascii=False))
            self.historia.append(ev)
            for q in list(self.clientes):
                q.put(ev)

    def suscribir(self, desde=0):
        q = queue.Queue()
        with self.cerrojo:
            self.clientes.add(q)
            if desde or not self._hubo_cliente:
                for ev in self.historia:
                    if ev[0] > desde:
                        q.put(ev)
            self._hubo_cliente = True
        return q

    def soltar(self, q):
        with self.cerrojo:
            self.clientes.discard(q)


def _sin_imagenes_de_fuera(o):
    """Modo de prueba: toda miniatura o avatar de YouTube → /fixtures/… (ni una petición a ytimg). 06/10/2026: las de un
    vídeo (i.ytimg.com/vi/<id>/<variante>.jpg) → /fixtures/vi/<id>/<variante>.jpg: una dirección distinta por vídeo y la
    variante intacta, para que la página elija su tamaño (M5.nitida: hq720…) y el navegador decodifique cada una como en
    casa (fixtures/hq720.jpg es de 1280×720); lo demás (avatares), miniatura.jpg."""
    if isinstance(o, str):
        if not o.startswith(IMAGENES):
            return o
        m = re.match(r"https://i\d?\.ytimg\.com/vi(?:_webp)?/([\w-]{11})/(\w+)\.\w+", o)
        return f"/fixtures/vi/{m.group(1)}/{m.group(2)}.jpg" if m else "/fixtures/miniatura.jpg"
    if isinstance(o, list):
        return [_sin_imagenes_de_fuera(x) for x in o]
    if isinstance(o, dict):
        return {k: _sin_imagenes_de_fuera(v) for k, v in o.items()}
    return o


class ServidorWeb(_ServidorLocal):
    """El servidor de la interfaz web. Reutiliza de _ServidorLocal la forma de publicar archivos (url(ruta) → /<id>)."""

    def __init__(self, servicio=None, puerto=0, token=None, solo=False, prueba=False, fixtures=None, puerto_preferido=None,
                 al_ventana=None, al_lista=None, al_guardado=None, al_galletas=None, al_borrar_galletas=None,
                 al_cerrar_galletas=None):
        import http.server
        import socketserver
        if servicio is None:
            from .servicio import Servicio
            servicio = Servicio.instancia(fixtures=fixtures)
        self.servicio = servicio
        self.fixtures = servicio.fixtures
        self.token = token or secrets.token_hex(16)
        self.solo, self.prueba = solo, prueba
        self.al_ventana, self.al_lista, self.al_guardado = al_ventana, al_lista, al_guardado
        # 18/10/2026 · «Traer mi YouTube» (cuenta_servicio): la ventana de Google de la app (VentanaWeb, Windows) da las
        # galletas de YouTube; sin ella (Linux, --solo) la sesión sale de un navegador del equipo, y con fixtures, de la falsa
        self.al_galletas, self.al_borrar_galletas = al_galletas, al_borrar_galletas
        self.al_cerrar_galletas = al_cerrar_galletas   # 18/10/2026 (hallazgo 13): cierra la ventana de Google al cancelar
        self._cuenta = None
        self._cerrojo_cuenta = threading.Lock()   # 18/10/2026 (hallazgo 12): un solo CuentaServicio aunque lleguen dos a la vez
        self.eventos = Eventos()
        self.semaforo = threading.Semaphore(4)
        self.semaforo_fondo = threading.Semaphore(1)
        self.rutas = {}
        self.lista_recibida = threading.Event()
        self.guardado_recibido = threading.Event()
        self.al_prueba_fin = None          # M8: lo pone prueba_web.py (fin de la batería de la página)
        self.al_prueba_perfil = None       # 06/10/2026: el modo perfil de prueba_web.js (rondas del arranque y la tabla)
        self.prueba_fin = None
        self.parado = False
        servicio.emitir = self.eventos.emitir
        servicio.servir_archivo = self._servir_archivo
        servidor = self

        class Peticion(http.server.BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"
            # 06/10/2026 (perfil de uso): sin esto, cada respuesta con keep-alive salía en dos envíos (cabeceras y cuerpo) y
            # el segundo esperaba al ACK retardado del cliente (Nagle): +40 ms por petición en Linux y hasta +200 ms en
            # Windows (las /api/ventana de 211 ms y /api/estado de 106 ms de medidas.jsonl, con 0,1-3 ms de trabajo)
            disable_nagle_algorithm = True
            timeout = 45          # una conexión keep-alive callada se cierra sola (las SSE laten cada 15 s)
            server_version = "Cat-ode/" + VERSION
            sys_version = ""

            def log_message(self, *_a):
                pass

            def do_GET(self):
                servidor._atender(self, "GET", True)

            def do_HEAD(self):
                servidor._atender(self, "GET", False)

            def do_POST(self):
                servidor._atender(self, "POST", True)

            def do_PUT(self):
                servidor._atender(self, "PUT", True)

            def do_OPTIONS(self):
                self.send_response(204); self.send_header("Content-Length", "0"); self.end_headers()

        class Servidor(socketserver.ThreadingMixIn, http.server.HTTPServer):
            daemon_threads = True
            # en Windows, SO_REUSEADDR dejaría a dos procesos el mismo puerto: allí, puerto en exclusiva
            allow_reuse_address = os.name != "nt"
            request_queue_size = 64

            def server_bind(self):
                if os.name == "nt" and hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
                    self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
                super().server_bind()

        # 06/10/2026 (perfil en el mini PC): con un puerto al azar cada arranque era un ORIGEN nuevo para Edge: ni su caché
        # HTTP ni la de código de V8 servían (los 20 guiones, las hojas, las fuentes y hls.js, bajados y compilados de
        # nuevo: 700 ms hasta las tarjetas frente a 165 ms con caché). Con un puerto fijo preferido (si está ocupado, uno al
        # azar, como antes) el segundo arranque ya lo encuentra todo en caché
        self._srv = None
        for p in ([int(puerto_preferido)] if puerto_preferido else []) + [int(puerto or 0)]:
            try:
                self._srv = Servidor(("127.0.0.1", p), Peticion)
                break
            except OSError as error:
                _registro(f"web: puerto {p} ocupado ({error}): otro")
        if self._srv is None:
            self._srv = Servidor(("127.0.0.1", 0), Peticion)
        self.puerto = self._srv.server_address[1]
        self.base = f"http://127.0.0.1:{self.puerto}"

    # ---------------------------------------------------------------- arranque y parada
    def empezar(self):
        threading.Thread(target=self._srv.serve_forever, daemon=True, name="servidor-web").start()
        return self

    def parar(self):
        self.parado = True
        self.eventos.emitir("adios", {})
        try:
            self._srv.shutdown()
            self._srv.server_close()
        except Exception:   # noqa: BLE001
            pass

    def direccion(self, pagina="index.html"):
        return f"{self.base}/{pagina}?t={self.token}"

    def _servir_archivo(self, ruta):
        u = self.url(ruta)
        return u[len(self.base):] if self.fixtures else u

    # ---------------------------------------------------------------- respuestas
    def _enviar(self, h, codigo, cuerpo=b"", tipo="application/json; charset=utf-8", cabeceras=None, con_cuerpo=True):
        h.send_response(codigo)
        h.send_header("Content-Type", tipo)
        h.send_header("Content-Length", str(len(cuerpo)))
        for k, v in (cabeceras or {}).items():
            h.send_header(k, v)
        # cabeceras y cuerpo en UN solo envío (end_headers + write eran dos: ver disable_nagle_algorithm)
        try:
            buf = getattr(h, "_headers_buffer", None)
            if buf is not None and con_cuerpo and cuerpo:
                buf.append(b"\r\n")
                buf.append(cuerpo)
                h.flush_headers()
                return
            h.end_headers()
            if con_cuerpo and cuerpo:
                h.wfile.write(cuerpo)
        except (BrokenPipeError, ConnectionResetError, OSError):
            h.close_connection = True

    def _json(self, h, codigo, datos, t0=None, con_cuerpo=True):
        if self.fixtures:
            datos = _sin_imagenes_de_fuera(datos)
        cuerpo = json.dumps(datos, ensure_ascii=False, default=str).encode("utf-8")
        cab = {"Cache-Control": "no-store"}
        if t0 is not None:
            cab["Server-Timing"] = f"api;dur={(time.perf_counter() - t0) * 1000:.1f}"
        self._enviar(h, codigo, cuerpo, cabeceras=cab, con_cuerpo=con_cuerpo)

    def _error(self, h, error, t0=None):
        from .servicio import clasificar, marcar_bloqueo
        clase, texto, reintentar = clasificar(error)
        if clase == "bloqueo":
            marcar_bloqueo()
            _registro(f"web: BLOQUEO de YouTube ({str(error)[:120]}): sin reintentos (regla 24)")
        self._json(h, CODIGOS.get(clase, 500), {"ok": False, "error": texto, "clase": clase, "reintentar": reintentar}, t0)

    # ---------------------------------------------------------------- reparto
    def _atender(self, h, metodo, con_cuerpo):
        partes = urllib.parse.urlsplit(h.path)
        ruta = urllib.parse.unquote(partes.path)
        q = {k: v[-1] for k, v in urllib.parse.parse_qs(partes.query, keep_blank_values=True).items()}
        try:
            if ruta.startswith("/api/"):
                return self._api(h, metodo, ruta, q)
            if ruta.startswith("/fixtures/") and self.fixtures:
                from . import motor_falso
                return self._archivo(h, motor_falso.ruta_local(ruta), con_cuerpo, cache=True)
            clave = ruta.lstrip("/")
            if clave in self.rutas:
                return self._archivo(h, self.rutas[clave], con_cuerpo, cache=False)
            return self._estatico(h, ruta, q, con_cuerpo)
        except (BrokenPipeError, ConnectionResetError):
            h.close_connection = True
        except Exception as error:   # noqa: BLE001
            _registro(f"web: error en {ruta}: {error!r}"[:200])
            try:
                self._json(h, 500, {"ok": False, "error": str(error)[:200], "clase": "imposible", "reintentar": 0})
            except Exception:   # noqa: BLE001
                h.close_connection = True

    def _estatico(self, h, ruta, q, con_cuerpo):
        if ruta in ("", "/"):
            ruta = "/index.html"
        destino = os.path.normpath(os.path.join(WEB, ruta.lstrip("/")))
        if not destino.startswith(os.path.normpath(WEB) + os.sep) or not os.path.isfile(destino):
            return self._enviar(h, 404, b"no existe", "text/plain; charset=utf-8", con_cuerpo=con_cuerpo)
        ext = os.path.splitext(destino)[1].lower()
        if ext == ".html":
            with open(destino, encoding="utf-8") as f:
                html = f.read()
            # ?v=VERSION en cada script y hoja propios: la caché de Edge no sirve los de la versión anterior
            html = re.sub(r'(<(?:script|link)\b[^>]*?\b(?:src|href)=")(?!https?:|//|data:)([^"?#]+\.(?:js|css))(")',
                          lambda m: f"{m.group(1)}{m.group(2)}?v={firma_web()}{m.group(3)}", html)
            cab = {"Cache-Control": "no-cache"}
            if os.path.basename(destino) == "index.html":
                cab["Content-Security-Policy"] = CSP
                # 22/10/2026: el logo animado al abrir (js/arranque.js), no en las pruebas, al medir ni al reiniciarse sola
                # tras una actualización (como arranque.py en la interfaz Qt)
                if os.environ.get("CATODE_PRUEBA_INTERFAZ") or any(a in sys.argv for a in ("--prueba", "--reinicio", "--medir")):
                    html = re.sub(r'<div id="arranque".*?</div>\s*', "", html, count=1, flags=re.S)
            return self._enviar(h, 200, html.encode("utf-8"), TIPOS[".html"], cab, con_cuerpo)
        return self._archivo(h, destino, con_cuerpo, cache=True)

    def _archivo(self, h, ruta, con_cuerpo, cache=False):
        """Un archivo con saltos (Range), como _ServidorLocal._servir (motor_web.py 85-121)."""
        if not ruta or not os.path.isfile(ruta):
            return self._enviar(h, 404, b"no existe", "text/plain; charset=utf-8", con_cuerpo=con_cuerpo)
        total = os.path.getsize(ruta)
        ini, fin = 0, total - 1
        rango = h.headers.get("Range")
        if rango and rango.startswith("bytes="):
            a, _, b = rango[6:].partition("-")
            try:
                ini = int(a) if a else max(0, total - int(b or 0))
                fin = int(b) if (a and b) else total - 1
            except ValueError:
                ini, fin = 0, total - 1
            fin = min(fin, total - 1)
            if ini > fin:
                h.send_response(416); h.send_header("Content-Range", f"bytes */{total}"); h.send_header("Content-Length", "0"); h.end_headers()
                return
            h.send_response(206); h.send_header("Content-Range", f"bytes {ini}-{fin}/{total}")
        else:
            h.send_response(200)
        tipo = TIPOS.get(os.path.splitext(ruta)[1].lower(), "application/octet-stream")
        h.send_header("Content-Type", tipo); h.send_header("Accept-Ranges", "bytes")
        h.send_header("Content-Length", str(fin - ini + 1)); h.send_header("Access-Control-Allow-Origin", "*")
        h.send_header("Cache-Control", "max-age=31536000, immutable" if cache else "no-cache")
        h.end_headers()
        if not con_cuerpo:
            return
        try:
            with open(ruta, "rb") as f:
                f.seek(ini)
                falta = fin - ini + 1
                while falta > 0:
                    trozo = f.read(min(1 << 16, falta))
                    if not trozo:
                        break
                    h.wfile.write(trozo)
                    falta -= len(trozo)
        except (BrokenPipeError, ConnectionResetError, OSError):
            h.close_connection = True

    def _cuerpo(self, h):
        n = int(h.headers.get("Content-Length") or 0)
        return h.rfile.read(n) if n > 0 else b""

    @staticmethod
    def _cliente_se_fue(h):
        """¿El cliente cerró la conexión (petición abortada) antes de que empecemos?"""
        try:
            r, _, _ = select.select([h.connection], [], [], 0)
            if r:
                return h.connection.recv(1, socket.MSG_PEEK) == b""
        except (OSError, ValueError):
            return True
        return False

    def _api(self, h, metodo, ruta, q):
        t0 = time.perf_counter()
        token = h.headers.get("X-Catode") or (q.get("t") if ruta == "/api/eventos" else None)
        if not token or not secrets.compare_digest(token, self.token):
            return self._json(h, 403, {"ok": False, "error": "Falta el permiso (X-Catode)", "clase": "imposible", "reintentar": 0}, t0)
        if ruta == "/api/eventos":
            return self._sse(h)
        cuerpo = {}
        crudo = b""
        if metodo in ("POST", "PUT"):
            crudo = self._cuerpo(h)
            if crudo and "json" in (h.headers.get("Content-Type") or "json"):
                try:
                    cuerpo = json.loads(crudo.decode("utf-8"))
                except ValueError:
                    return self._json(h, 400, {"ok": False, "error": "JSON no válido", "clase": "imposible", "reintentar": 0}, t0)
        if ruta == "/api/medidas":
            self._medidas(cuerpo)
            h.send_response(204); h.send_header("Content-Length", "0"); h.send_header("Server-Timing", f"api;dur={(time.perf_counter() - t0) * 1000:.1f}")
            h.end_headers()
            return
        red = bool(CON_RED.match(ruta))
        sem = (self.semaforo_fondo if DE_FONDO.match(ruta) else self.semaforo) if red else None
        if sem is not None:
            sem.acquire()
        try:
            if red and self._cliente_se_fue(h):   # abortada antes de empezar: no se procesa
                h.close_connection = True
                return
            h.seguir = lambda: not self._cliente_se_fue(h)   # para las largas (completar): ¿sigue ahí la página?
            r = self._ruta(h, metodo, ruta, q, cuerpo, crudo)
        except Exception as error:   # noqa: BLE001
            return self._error(h, error, t0)
        finally:
            if sem is not None:
                sem.release()
        if r is None:
            return self._json(h, 404, {"ok": False, "error": f"Ruta desconocida: {metodo} {ruta}", "clase": "imposible", "reintentar": 0}, t0)
        self._json(h, 200, {"ok": True, **r}, t0)

    # ---------------------------------------------------------------- las rutas del contrato §2.3
    def _ruta(self, h, metodo, ruta, q, c, crudo):
        s = self.servicio
        si = lambda x: str(x).lower() in ("1", "true", "si", "sí")   # noqa: E731
        if metodo == "GET":
            if ruta.startswith("/api/video/") and str(q.get("url", "")).startswith("cancion:"):
                # 22/10/2026 · «catode musica no funcional»: una canción importada (Spotify, Amazon) abierta desde Música pedía
                # su ficha con «cancion:…» y salía «No he podido cargar la ficha»: la ficha, comentarios… son los de su vídeo
                from . import musica
                q = dict(q, url=musica.resolver_cancion(q["url"]))
            if ruta == "/api/estado":
                r = s.estado()
                if self.fixtures:
                    from . import motor_falso
                    r["red_bloqueada"] = len(motor_falso.bloqueadas)
                r["puerto"] = self.puerto
                return r
            if ruta == "/api/ajustes":
                return s.ajustes_leer()
            if ruta.startswith("/api/pagina/"):
                return self._pagina(ruta[len("/api/pagina/"):], q, si)
            if ruta == "/api/canal/acerca":
                return s.canal_acerca(q.get("url", ""))
            if ruta == "/api/canal/valoracion":
                return s.canal_valoracion(q.get("url", ""))
            if ruta == "/api/buscar":
                return s.buscar(q.get("q", ""), q.get("tipo") or None, q.get("fecha") or None, q.get("duracion") or None,
                                q.get("orden") or None, q.get("cursor") or None)
            if ruta == "/api/sugerencias":
                return s.sugerencias(q.get("q", ""))
            if ruta == "/api/enlace":
                return s.enlace(q.get("url", ""))
            if ruta == "/api/video/ficha":
                return s.ficha(q.get("url", ""))
            if ruta == "/api/video/completo":
                return s.completo(q.get("url", ""), q.get("dur") or -1)
            if ruta == "/api/video/comentarios":
                return s.comentarios(q.get("url", ""), q.get("cursor") or None)
            if ruta == "/api/video/transcripcion":
                return s.transcripcion(q.get("url", ""))
            if ruta == "/api/video/tramos":   # M8: anuncios del creador por detrás (anuncios.detectar)
                return s.tramos(q.get("url", ""), q.get("dur") or 0, q.get("vtt"))
            if ruta == "/api/video/relacionados":
                return s.relacionados(q.get("url", ""), si(q.get("automatica", "0")))
            if ruta == "/api/resolver":
                if si(q.get("fresco", "0")):   # M8: reintento del reproductor → sin la dirección caducada de la caché
                    try:
                        s.resolutor.olvidar(q.get("url", ""))
                    except Exception:   # noqa: BLE001
                        pass
                return s.resolver(q.get("url", ""), q.get("alto") or 1080, si(q.get("fondo", "0")))
            if ruta == "/api/novedades":
                return s.novedades()
            if ruta == "/api/tele":
                return s.teles()
            if ruta == "/api/miembros/cuentas":
                return s.miembros_cuentas()
            if ruta == "/api/vetos":
                return s.datos_accion("vetos")
            if ruta == "/api/cuenta":   # 18/10/2026: «Traer mi YouTube» (estado, plan pendiente, último resumen)
                return self.cuenta().estado()
            return None
        if metodo == "PUT" and ruta == "/api/ajustes":
            return s.ajustes_guardar(c)
        if metodo != "POST":
            return None
        if ruta == "/api/ajustes":
            return s.ajustes_guardar(c)
        if ruta == "/api/posicion":
            return s.posicion(c.get("url", ""), c.get("seg", 0), c.get("dur", 0))
        if ruta == "/api/sonando":
            return s.sonando()
        if ruta == "/api/visto":
            return s.visto(c.get("e"))
        if ruta == "/api/fallo":
            return s.fallo(c.get("url", ""), c.get("error", ""))
        if ruta == "/api/registro":   # 06/10/2026: cortes y reintentos del reproductor, al registro (antes solo a la consola)
            from .resolutor import registro as _reg
            _reg("web (reproductor): " + str(c.get("t", ""))[:400])
            return {}
        if ruta == "/api/datos":
            c = dict(c)
            accion = c.pop("accion", "")
            if accion == "lista" and "que" not in c and c.get("sub") is None and "hacer" not in c:
                c["que"] = c.pop("lista", None) or c.pop("tipo", None)
            r = s.datos_accion(accion, **c)
            # M8: el SSE «datos» con la colección tocada (datos.oyentes solo dice «algo cambió», col ""): así cada página
            # con recargarCon se repinta sola, como la Qt al cambiar una colección
            col = {"alternar": c.get("col"), "quitar": c.get("col") or "suscripciones", "ocultar": "ocultos",
                   "suscribir": "suscripciones", "anular": "suscripciones", "fulminar": "vetos", "fulminar_lote": "vetos",
                   "indultar": "vetos", "tema": "temas", "quitar_tema": "temas", "lista": "listas",
                   "historial": "historial", "borrar_descarga": "descargas"}.get(accion)
            if col:
                self.eventos.emitir("datos", {"col": col, "motivo": accion})
            return r
        if ruta == "/api/cuenta":   # 18/10/2026: actualizar_cuenta · plan · aplicar · cancelar · origen · cerrar_sesion
            c = dict(c)
            r = self.cuenta().accion(c.pop("accion", ""), **c)
            if isinstance(r, dict) and r.get("error"):
                from .servicio import ErrorCat
                raise ErrorCat(r["error"], "imposible")
            return r
        if ruta == "/api/completar":   # M8: fichas.Relleno por lotes (duración, visualizaciones y fecha)
            return s.completar(c.get("urls") or [], seguir=getattr(h, "seguir", None))
        if ruta == "/api/importar":
            return s.importar(self._texto_subido(h, crudo))
        if ruta == "/api/descargar":
            return s.descargar(c.get("e"), c.get("solo_audio", False), c.get("alto", 720))
        if ruta == "/api/tele":
            return s.tele_poner(c.get("tele"), c.get("url", ""))
        if ruta == "/api/remoto":
            return s.remoto(c.get("apagar", True))
        if ruta == "/api/ventana":
            return self._ventana(c.get("accion", ""), c.get("valor"))
        if ruta == "/api/novedades_vistas":   # 22/10/2026: el aviso de novedades de versión, visto
            return s.novedades_vistas()
        if ruta == "/api/lista":
            self.lista_recibida.set()
            _registro("web: lista")
            print("web: lista", flush=True)
            if self.al_lista:
                self.al_lista()
            return {}
        if ruta == "/api/guardado":
            self.guardado_recibido.set()
            if self.al_guardado:
                self.al_guardado()
            return {}
        if ruta == "/api/prueba":
            if not self.prueba:
                return {"ignorado": True}
            if "carga" in c:   # la carga del equipo (CPU de todo y de lo ajeno) antes de medir la fluidez (catode/carga.py)
                from . import carga
                return carga.medir(c.get("carga") or 1)
            if "registro" in c:   # consola de la página y del iframe, y el estado en cada FALLA (diagnóstico de Windows)
                print(f"JS     {str(c.get('registro'))[:3200]}", flush=True)
                return {}
            if "perfil" in c:   # 06/10/2026: el modo perfil (prueba_web.py junta las rondas y escribe la tabla)
                return (self.al_prueba_perfil(c) if self.al_prueba_perfil else None) or {}
            if c.get("fin"):   # M8: el final de la batería de prueba_web.js
                self.prueba_fin = c
                if self.al_prueba_fin:
                    self.al_prueba_fin(c)
                return {}
            bien = bool(c.get("bien"))
            print(f"{'OK    ' if bien else 'FALLA '} {str(c.get('nombre', ''))[:60]:34s} {str(c.get('detalle', ''))[:300]}", flush=True)
            return {}
        return None

    def cuenta(self):
        """El servicio de «Traer mi YouTube» (uno por servidor; sus avisos salen por el SSE «cuenta»)."""
        with self._cerrojo_cuenta:
            if self._cuenta is None:
                from .cuenta_servicio import CuentaServicio
                self._cuenta = CuentaServicio(self.servicio.datos, self.eventos.emitir, pedir_galletas=self.al_galletas,
                                              borrar_galletas=self.al_borrar_galletas, falsa=bool(self.fixtures),
                                              cerrar_galletas=self.al_cerrar_galletas)
            return self._cuenta

    def _pagina(self, nombre, q, si):
        s = self.servicio
        if nombre == "inicio":
            return s.inicio(q.get("tema") or "Todo", si(q.get("recargar", "0")))
        if nombre == "inicio_mas":
            return s.inicio_mas(q.get("tema") or "Todo", q.get("cursor") or 1)
        if nombre == "suscripciones":
            return s.suscripciones(q.get("filtro") or "Todo", si(q.get("recargar", "0")))
        if nombre == "explorar":
            return s.explorar(q.get("categoria") or None, si(q.get("recargar", "0")))
        if nombre == "explorar_mas":   # 28/10/2026: Explorar no se acaba (descubrir.py)
            return s.explorar_mas(q.get("tema") or "Todo", q.get("cursor") or 1)
        if nombre == "historial":
            return s.historial(q.get("q", ""), q.get("cursor") or None)
        if nombre.startswith("coleccion/"):
            return s.coleccion(nombre.split("/", 1)[1])
        if nombre == "listas":
            return s.listas()
        if nombre.startswith("lista_propia/"):
            return s.lista_propia(nombre.split("/", 1)[1])
        if nombre == "musica":   # 22/10/2026 (encargo de música)
            return s.musica(q.get("grupo") or "Todo")
        if nombre.startswith("lista_musica/"):
            return s.lista_musica(nombre.split("/", 1)[1])
        if nombre == "lista_yt":
            return s.lista_yt(q.get("url", ""), q.get("titulo") or "Lista")
        if nombre == "descargas":
            return s.descargas()
        if nombre == "nut":
            return s.nut(q.get("chip") or None)
        if nombre == "gestionar":
            return s.gestionar()
        if nombre == "shorts":
            return s.shorts()
        if nombre == "canal":
            return s.canal(q.get("url", ""), q.get("pestana") or "videos")
        return None

    @staticmethod
    def _texto_subido(h, crudo):
        """El CSV de Takeout: cuerpo tal cual o el primer archivo de un multipart/form-data."""
        tipo = h.headers.get("Content-Type") or ""
        if tipo.startswith("multipart/"):
            from email.parser import BytesParser
            from email.policy import HTTP
            m = BytesParser(policy=HTTP).parsebytes(b"Content-Type: " + tipo.encode() + b"\r\n\r\n" + crudo)
            for parte in m.iter_parts():
                datos = parte.get_payload(decode=True)
                if datos:
                    return datos.decode("utf-8", "replace")
            return ""
        if "json" in tipo:
            try:
                return json.loads(crudo.decode("utf-8")).get("texto", "")
            except Exception:   # noqa: BLE001
                return ""
        return crudo.decode("utf-8", "replace")

    def _ventana(self, accion, valor):
        if self.solo or not self.al_ventana:
            return {"simulado": True, "accion": accion}
        r = self.al_ventana(accion, valor)
        return r if isinstance(r, dict) else {}

    def _medidas(self, lista):
        try:
            from .datos import carpeta_datos
            with open(os.path.join(carpeta_datos(), "medidas.jsonl"), "a", encoding="utf-8") as f:
                for m in (lista if isinstance(lista, list) else [lista]):
                    f.write(json.dumps({**(m if isinstance(m, dict) else {"v": m}), "h": time.time()}, ensure_ascii=False) + "\n")
        except Exception as error:   # noqa: BLE001
            _registro(f"web: no puedo guardar medidas ({error!r})"[:160])

    def _sse(self, h):
        try:
            desde = int(h.headers.get("Last-Event-ID") or 0)
        except ValueError:
            desde = 0
        q = self.eventos.suscribir(desde)
        h.send_response(200)
        h.send_header("Content-Type", "text/event-stream; charset=utf-8")
        h.send_header("Cache-Control", "no-cache")
        h.send_header("X-Accel-Buffering", "no")
        h.end_headers()
        h.close_connection = True   # sin Content-Length: el flujo termina al cerrar
        try:
            h.wfile.write(b"retry: 3000\n\n")
            h.wfile.flush()
            while not self.parado:
                try:
                    n, tipo, datos = q.get(timeout=15)
                    h.wfile.write(f"id: {n}\nevent: {tipo}\ndata: {datos}\n\n".encode("utf-8"))
                except queue.Empty:
                    h.wfile.write(b": latido\n\n")
                h.wfile.flush()
        except (BrokenPipeError, ConnectionResetError, OSError):
            pass
        finally:
            self.eventos.soltar(q)


def main(argv=None):
    import argparse
    p = argparse.ArgumentParser(description="Servidor local de la interfaz web de Cat-ode")
    p.add_argument("--solo", action="store_true", help="sin ventana: /api/ventana se simula")
    p.add_argument("--puerto", type=int, default=0)
    p.add_argument("--fixtures", action="store_true", help="sin red: todo sale de pruebas/fixtures (CATODE_PRUEBA_INTERFAZ=1)")
    p.add_argument("--token", default=None)
    p.add_argument("--prueba", action="store_true", help="admite POST /api/prueba (escribe OK/FALLA)")
    a = p.parse_args(argv)
    if a.fixtures:
        os.environ["CATODE_PRUEBA_INTERFAZ"] = "1"
    from .servicio import Servicio
    s = Servicio.instancia(fixtures=a.fixtures or None)
    srv = ServidorWeb(s, puerto=a.puerto, token=a.token, solo=True, prueba=a.prueba)
    s.arrancar()
    print(f"Cat-ode web: {srv.direccion()}", flush=True)
    try:
        srv._srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        srv.parar()


if __name__ == "__main__":
    main()
