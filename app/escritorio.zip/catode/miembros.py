"""Cat-ode escritorio · vídeos solo para miembros (03/10/2026). Cuando YouTube dice que un vídeo es de miembros, se vuelve a
pedir con la sesión del navegador y la cuenta elegida en Ajustes (p. ej. la segunda cuenta de Google abierta en Firefox,
no la principal). Solo se usa la cuenta para esos vídeos: nunca para buscar, para el Inicio ni para descargar.

Cómo elige la cuenta: yt-dlp lee las galletas del navegador (todas las cuentas de la sesión van en las mismas galletas) y
YouTube decide a cuál atiende por el índice de sesión (X-Goog-AuthUser) y, en los canales de marca, por X-Goog-PageId.
yt-dlp saca esos dos valores de la página del vídeo (siempre la cuenta principal), así que aquí se le dicen los de la
cuenta elegida mientras dura la resolución."""
import threading

from . import cuenta, motor

_cerrojo = threading.Lock()
_indice = None    # índice de sesión de la cuenta elegida mientras se resuelve con cuenta; None = lo que diga yt-dlp
_pagina = None    # X-Goog-PageId del canal de marca, si la cuenta elegida es uno
_parcheado = False
_encontrada = {}  # {nombre de la cuenta: (navegador, au, pagina)} ya localizada en el navegador


def configurada(ajustes):
    return bool((ajustes.get("cuenta_miembros") or {}).get("nombre"))


def es_de_miembros(error):
    t = str(error).lower()
    return "members" in t or "miembros" in t or "join this channel" in t


def _parchear():
    global _parcheado
    if _parcheado:
        return
    from yt_dlp.extractor.youtube import _base
    clase = _base.YoutubeBaseInfoExtractor
    indice_original, pagina_original = clase._extract_session_index, clase._extract_delegated_session_id

    def indice(*data):
        return _indice if _indice is not None else indice_original(*data)

    def pagina(*data):
        return _pagina if _indice is not None else pagina_original(*data)
    clase._extract_session_index = staticmethod(indice)
    clase._extract_delegated_session_id = staticmethod(pagina)
    _parcheado = True


def cuentas():
    """[(navegador, nombre del navegador, au, pagina, nombre de la cuenta)] de todas las cuentas y canales abiertos en los
    navegadores del equipo. Tarda unos segundos (habla con YouTube): llamar desde un hilo."""
    r = []
    for clave, nombre in cuenta.navegadores():
        try:
            for i in cuenta._identidades(cuenta._Sesion(clave), lambda t: None):
                r.append((clave, nombre, i["au"], i["pagina"], i["nombre"]))
        except Exception:   # noqa: BLE001 (ese navegador no deja leer sus galletas)
            pass
    return r


def localizar(ajustes):
    """(navegador, au, pagina) de la cuenta elegida en Ajustes, buscándola entre las abiertas en el navegador; o None."""
    c = ajustes.get("cuenta_miembros") or {}
    nombre = c.get("nombre")
    if not nombre:
        return None
    if nombre in _encontrada:
        return _encontrada[nombre]
    for clave, _, au, pagina, n in cuentas():
        if n.lower() == nombre.lower() and (not c.get("navegador") or c["navegador"] == clave):
            _encontrada[nombre] = (clave, au, pagina)
            return _encontrada[nombre]
    return None


def resolver(url, alto, ajustes):
    """Lo que devuelve yt-dlp para ese vídeo, pedido con la cuenta elegida. Lanza RuntimeError si no hay cuenta o no
    está abierta en ningún navegador del equipo."""
    donde = localizar(ajustes)
    if not donde:
        raise RuntimeError("La cuenta para vídeos de miembros no está abierta en ningún navegador de este equipo")
    navegador, au, pagina = donde
    _parchear()
    import yt_dlp
    from .reproductor import formato
    global _indice, _pagina
    with _cerrojo:
        _indice, _pagina = au, pagina
        try:
            with yt_dlp.YoutubeDL(motor._opciones(format=formato(alto), cookiesfrombrowser=(navegador,), cachedir=False)) as y:
                return y.extract_info(url, download=False)
        finally:
            _indice = _pagina = None
