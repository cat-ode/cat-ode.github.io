"""Cat-ode escritorio · iconos propios (trazados de 24×24 al estilo de los de YouTube, licencia Apache 2.0 de Material
Icons). Sustituyen a los emojis, que Windows pintaba a todo color y Ubuntu de otra forma (02/10/2026: «sale con colores
diferentes»). Mismo dibujo y mismo color en todos los sistemas."""
import os

from PySide6.QtCore import QByteArray, Qt, QRectF, QObject, QEvent
from PySide6.QtWidgets import QMenu, QAbstractButton
from PySide6.QtGui import QIcon, QPixmap, QPainter
from PySide6.QtSvg import QSvgRenderer

CLARO = "#F1F1F1"

TRAZOS = {
    "microfono": "M12 14c1.66 0 3-1.34 3-3V5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3zm5.3-3c0 3-2.54 5.1-5.3 5.1S6.7 14 6.7 11H5c0 3.41 2.72 6.23 6 6.72V21h2v-3.28c3.28-.48 6-3.3 6-6.72h-1.7z",
    "inicio": "M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z",
    "shorts": "M11 21h-1l1-7H7.5c-.58 0-.57-.32-.38-.66.19-.34.05-.08.07-.12C8.48 10.94 10.42 7.54 13 3h1l-1 7h3.5c.49 0 .56.33.47.51l-.07.15C12.96 17.55 11 21 11 21z",
    "suscripciones": "M20 8H4V6h16v2zm-2-6H6v2h12V2zm4 10v8c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2v-8c0-1.1.9-2 2-2h16c1.1 0 2 .9 2 2zm-6 4l-6-3.27v6.53L16 16z",
    "explorar": "M12 10.9c-.61 0-1.1.49-1.1 1.1s.49 1.1 1.1 1.1c.61 0 1.1-.49 1.1-1.1s-.49-1.1-1.1-1.1zM12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm2.19 12.19L6 18l3.81-8.19L18 6l-3.81 8.19z",
    "historial": "M13 3a9 9 0 0 0-9 9H1l3.89 3.89.07.14L9 12H6c0-3.87 3.13-7 7-7s7 3.13 7 7-3.13 7-7 7c-1.93 0-3.68-.79-4.94-2.06l-1.42 1.42A8.954 8.954 0 0 0 13 21a9 9 0 0 0 0-18zm-1 5v5l4.28 2.54.72-1.21-3.5-2.08V8H12z",
    "despues": "M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10 10-4.5 10-10S17.5 2 12 2zm4.2 14.2L11 13V7h1.5v5.2l4.5 2.7-.8 1.3z",
    "megusta": "M1 21h4V9H1v12zm22-11c0-1.1-.9-2-2-2h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 1 7.59 7.59C7.22 7.95 7 8.45 7 9v10c0 1.1.9 2 2 2h9c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73v-2z",
    "listas": "M4 10h12v2H4zm0-4h12v2H4zm0 8h8v2H4zm10 0v6l5-3z",
    "descargas": "M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z",
    "ajustes": "M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58a.49.49 0 0 0 .12-.61l-1.92-3.32a.488.488 0 0 0-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54a.484.484 0 0 0-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58a.49.49 0 0 0-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z",
    "menu": "M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z",
    "buscar": "M15.5 14h-.79l-.28-.27A6.471 6.471 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z",
    "play": "M8 5v14l11-7z",
    "pausa": "M6 19h4V5H6v14zm8-14v14h4V5h-4z",
    "parar": "M6 6h12v12H6z",   # 22/10/2026 (3.9): parar el vídeo de la mini (el ✕ la quita y sigue sonando)
    "siguiente": "M6 18l8.5-6L6 6v12zM16 6v12h2V6h-2z",
    "anterior": "M6 6h2v12H6zm3.5 6l8.5 6V6z",
    "completa": "M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z",
    "cine": "M19 6H5c-1.1 0-2 .9-2 2v8c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm0 10H5V8h14v8z",   # rectángulo 16:9 (modo cine)
    "pip": "M19 11h-8v6h8v-6zm4 8V4.98C23 3.88 22.1 3 21 3H3c-1.1 0-2 .88-2 1.98V19c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2zm-2 .02H3V4.97h18v14.05z",   # imagen en imagen
    "cerrar_completa": "M5 16h3v3h2v-5H5v2zm3-8H5v2h5V5H8v3zm6 11h2v-3h3v-2h-5v5zm2-11V5h-2v5h5V8h-3z",
    "volumen": "M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z",
    "silencio": "M16.5 12c0-1.77-1.02-3.29-2.5-4.03v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51C20.63 14.91 21 13.5 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06c1.38-.31 2.63-.95 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z",
    "compartir": "M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.5-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92s2.92-1.31 2.92-2.92-1.31-2.92-2.92-2.92z",
    "mas": "M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z",
    "mas_h": "M6 10c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm12 0c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm-6 0c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z",
    "cerrar": "M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z",
    "aleatorio": "M10.59 9.17L5.41 4 4 5.41l5.17 5.17 1.42-1.41zM14.5 4l2.04 2.04L4 18.59 5.41 20 17.96 7.46 20 9.5V4h-5.5zm.33 9.41l-1.41 1.41 3.13 3.13L14.5 20H20v-5.5l-2.04 2.04-3.13-3.13z",
    "actualizar": "M17.65 6.35A7.958 7.958 0 0 0 12 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08A5.99 5.99 0 0 1 12 18c-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z",
    "repetir": "M7 7h10v3l4-4-4-4v3H5v6h2V7zm10 10H7v-3l-4 4 4 4v-3h12v-6h-2v4z",
    "auriculares": "M12 1c-4.97 0-9 4.03-9 9v7c0 1.66 1.34 3 3 3h3v-8H5v-2c0-3.87 3.13-7 7-7s7 3.13 7 7v2h-4v8h3c1.66 0 3-1.34 3-3v-7c0-4.97-4.03-9-9-9z",
    "temporizador": "M15 1H9v2h6V1zm-4 13h2V8h-2v6zm8.03-6.61l1.42-1.42c-.43-.51-.9-.99-1.41-1.41l-1.42 1.42A8.962 8.962 0 0 0 12 4c-4.97 0-9 4.03-9 9s4.02 9 9 9a8.994 8.994 0 0 0 7.03-14.61zM12 20c-3.87 0-7-3.13-7-7s3.13-7 7-7 7 3.13 7 7-3.13 7-7 7z",
    "velocidad": "M20.38 8.57l-1.23 1.85a8 8 0 0 1-.22 7.58H5.07A8 8 0 0 1 15.58 6.85l1.85-1.23A10 10 0 0 0 3.35 19a2 2 0 0 0 1.72 1h13.85a2 2 0 0 0 1.74-1 10 10 0 0 0-.27-10.44zm-9.79 6.84a2 2 0 0 0 2.83 0l5.66-8.49-8.49 5.66a2 2 0 0 0 0 2.83z",
    "subtitulos": "M19 4H5a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h14c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm-8 7H9.5v-.5h-2v3h2V13H11v1c0 .55-.45 1-1 1H7c-.55 0-1-.45-1-1v-4c0-.55.45-1 1-1h3c.55 0 1 .45 1 1v1zm7 0h-1.5v-.5h-2v3h2V13H18v1c0 .55-.45 1-1 1h-3c-.55 0-1-.45-1-1v-4c0-.55.45-1 1-1h3c.55 0 1 .45 1 1v1z",
    "cola": "M3 13h2v-2H3v2zm0 4h2v-2H3v2zm0-8h2V7H3v2zm4 4h14v-2H7v2zm0 4h14v-2H7v2zM7 7v2h14V7H7z",
    "musica": "M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z",   # 22/10/2026: modo Música (Material «music_note»)
    "anadir": "M14 10H2v2h12v-2zm0-4H2v2h12V6zm4 8v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zM2 16h8v-2H2v2z",
    "mas_uno": "M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z",
    "campana": "M12 22c1.1 0 2-.9 2-2h-4c0 1.1.89 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z",
    "atras": "M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z",
    "borrar": "M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z",
    "editar": "M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04a.996.996 0 0 0 0-1.41l-2.34-2.34a.996.996 0 0 0-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z",
    "carpeta": "M10 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z",
    "enlace": "M3.9 12c0-1.71 1.39-3.1 3.1-3.1h4V7H7c-2.76 0-5 2.24-5 5s2.24 5 5 5h4v-1.9H7c-1.71 0-3.1-1.39-3.1-3.1zM8 13h8v-2H8v2zm9-6h-4v1.9h4c1.71 0 3.1 1.39 3.1 3.1s-1.39 3.1-3.1 3.1h-4V17h4c2.76 0 5-2.24 5-5s-2.24-5-5-5z",
    "mundo": "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z",
    "persona": "M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z",
    "prohibido": "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zM4 12c0-4.42 3.58-8 8-8 1.85 0 3.55.63 4.9 1.69L5.69 16.9A7.902 7.902 0 0 1 4 12zm8 8c-1.85 0-3.55-.63-4.9-1.69L18.31 7.1A7.902 7.902 0 0 1 20 12c0 4.42-3.58 8-8 8z",
    "a_continuacion": "M4 10h12v2H4zm0-4h12v2H4zm0 8h8v2H4zm10-1v6l5-3z",
    "reloj": "M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z",
}

_cache = {}


def icono(nombre, color=CLARO, tam=24):
    """QIcon nítido (se pinta a 1×, 2× y 3×) del trazo «nombre» en «color»."""
    clave = (nombre, color, tam)
    if clave in _cache:
        return _cache[clave]
    svg = f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="{color}" d="{TRAZOS[nombre]}"/></svg>'
    r = QSvgRenderer(QByteArray(svg.encode()))
    ic = QIcon()
    for escala in (1, 2, 3):
        p = QPixmap(tam * escala, tam * escala)
        p.fill(Qt.transparent)
        pintor = QPainter(p)
        r.render(pintor, QRectF(0, 0, tam * escala, tam * escala))
        pintor.end()
        p.setDevicePixelRatio(escala)
        ic.addPixmap(p)
    _cache[clave] = ic
    return ic


# los emojis que había delante de los textos de botones y menús → su icono
EMOJIS = {"🏠": "inicio", "⚡": "shorts", "📺": "suscripciones", "🧭": "explorar", "🕘": "historial", "🔔": "campana",
          "▶": "play", "⏯": "play", "⏸": "pausa", "⏭": "a_continuacion", "⏮": "anterior", "☰": "cola", "🎵": "musica", "🎧": "auriculares", "🕒": "despues",
          "👍": "megusta", "💔": "megusta", "➕": "anadir", "⬇": "descargas", "👤": "persona", "🚫": "prohibido",
          "🔗": "enlace", "⏱": "reloj", "🌐": "mundo", "🔀": "aleatorio", "⟳": "actualizar", "🗑": "borrar", "✏": "editar",
          "📂": "carpeta", "⛶": "completa", "CC": "subtitulos", "⚙": "ajustes", "🔁": "repetir", "↗": "compartir",
          "🔊": "volumen", "🔇": "silencio", "☾": "temporizador", "✕": "cerrar", "⋮": "mas", "⋯": "mas_h", "🔍": "buscar"}


def separar(texto):
    """«▶  Reproducir todo» → ("play", "Reproducir todo"); sin emoji conocido → (None, texto)."""
    t = (texto or "").strip()
    for e, n in EMOJIS.items():
        if t.startswith(e):
            return n, t[len(e):].strip()
    return None, texto


def iconizar_menu(m):
    """Cambia los emojis del principio de cada opción (y submenú) por iconos."""
    for a in m.actions():
        n, t = separar(a.text())
        if n:
            a.setIcon(icono(n))
            a.setText(t)
        if a.menu():
            iconizar_menu(a.menu())
    return m


def iconizar_boton(b, tam=20):
    """Lo mismo para un botón: el emoji (delante o detrás, como «Suscrito  🔔») pasa a ser su icono."""
    from PySide6.QtCore import QSize
    texto = b.text()
    n, t = separar(texto)
    if not n:
        for e, nombre in EMOJIS.items():
            if len(e) == 1 and texto.rstrip().endswith(e):
                n, t = nombre, texto.rstrip()[:-1].strip()
                break
    if n:
        b.setIcon(icono(n))
        b.setIconSize(QSize(tam, tam))
        b.setText(t)
    return b


def redondear(w, tipo):
    """Menús, bocadillos y listas desplegables con esquinas redondeadas: en Windows 11, las del sistema (con su sombra);
    en Linux, con fondo transparente para que se vea el redondeo de la hoja de estilo."""
    clase = w.metaObject().className()
    if not (isinstance(w, QMenu) or clase in ("QTipLabel", "QComboBoxPrivateContainer")):
        return
    if os.name == "nt":
        if tipo == QEvent.Show:
            try:
                import ctypes
                pref = ctypes.c_int(3 if clase == "QTipLabel" else 2)   # 2 = redondo, 3 = redondo pequeño
                ctypes.windll.dwmapi.DwmSetWindowAttribute(int(w.winId()), 33, ctypes.byref(pref), ctypes.sizeof(pref))
            except Exception:   # noqa: BLE001 (Windows 10: sin redondeo, sin más)
                pass
    elif tipo == QEvent.Polish and isinstance(w, QMenu) and not w.testAttribute(Qt.WA_TranslucentBackground):
        w.setAttribute(Qt.WA_TranslucentBackground)
        w.setWindowFlag(Qt.FramelessWindowHint)
        w.setWindowFlag(Qt.NoDropShadowWindowHint)


class Iconizador(QObject):
    """Vigilante de toda la app: cada botón o menú que aparece cambia sus emojis por iconos (también los que se crean
    sobre la marcha: tarjetas, cabeceras de página, menús del «⋮»)."""
    _TIPOS = frozenset((QEvent.Show, QEvent.Polish))

    def eventFilter(self, obj, ev):
        t = ev.type()   # pasa por aquí cada evento de la app: fuera enseguida lo que no es mostrar o pulir
        if t not in self._TIPOS:
            return False
        if obj.isWidgetType() and obj.isWindow():
            redondear(obj, t)
        if True:
            if isinstance(obj, QMenu):
                iconizar_menu(obj)
            elif isinstance(obj, QAbstractButton) and obj.text():
                iconizar_boton(obj)
        return False
