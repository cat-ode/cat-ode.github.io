"""Cat-ode escritorio · el reproductor: mpv metido en la ventana. 1.0.0 (02/10/2026): la cola la lleva Cat-ode y mpv
reproduce un vídeo cada vez, ya resuelto por el yt-dlp de la propia app (cargado en memoria: ~1 s en vez de los ~6 s de
lanzar yt-dlp aparte), y el siguiente de la cola se resuelve mientras suena el actual, así que empieza al instante. Si
la resolución falla, mpv lo intenta por su cuenta con yt-dlp (como antes)."""
import ctypes.util
import os
import sys
import threading
import time

from PySide6.QtCore import QObject, Signal, Qt

from . import motor

if os.name == "nt":
    os.environ["PATH"] = os.path.dirname(sys.executable) + os.pathsep + os.path.join(os.path.dirname(__file__), "..", "mpv") + os.pathsep + os.environ["PATH"]
else:   # libmpv viene en la carpeta de Cat-ode (sin instalar nada en el sistema)
    _lib = os.path.expanduser("~/.local/share/catode/lib/libmpv.so.2")
    _original = ctypes.util.find_library
    ctypes.util.find_library = lambda n: _lib if n == "mpv" and os.path.exists(_lib) else _original(n)
import mpv  # noqa: E402
from .resolutor import (registro, formato, DEFINITIVOS, definitivo, FRESCO, _edl, _storyboard, _storyboard_spec,  # noqa: E402,F401
                        _pista, Resolutor)   # 06/10/2026: el resolutor vive en resolutor.py (sin Qt) para la interfaz web

al_fallar = None   # 03/10/2026: la ventana pone aquí el aviso al servidor (el arreglador del ProBook se pone en marcha)


def avisar_fallo(url, error):
    try:   # 18/10/2026: ¿YouTube se ha roto? (2 vídeos distintos en 15 min → busca el arreglo YA en Drive)
        from . import roto
        roto.apuntar_video(url, error)
    except Exception:   # noqa: BLE001
        pass
    if al_fallar:
        try:
            al_fallar(url, str(error)[:300])
        except Exception:   # noqa: BLE001
            pass


class Reproductor(QObject):
    aviso = Signal(str)          # «Patrocinio saltado», «Se pausará dentro de 30 min»…
    cambio = Signal()            # título, pausa, posición… (lo mira la barra)
    empieza = Signal(object)     # el Elemento que empieza a sonar
    pide_mas = Signal(object)    # la cola se acabó: el Elemento que sonaba (para la reproducción automática)
    _fin = Signal()              # fin natural de un vídeo (llega del hilo de mpv)
    _imposible = Signal(str)     # un vídeo que YouTube no deja ver (llega del hilo que lo resuelve)
    _reintento = Signal()         # mpv cortó por un error: direcciones nuevas y seguir en el mismo segundo
    _bloqueado = Signal(str)     # 21/10/2026: YouTube pide «no eres un robot» al recargar: quieto, sin reintentos (regla 24)
    pide_pantalla = Signal()     # doble clic en el vídeo o el botón de pantalla completa de mpv
    pide_menu = Signal()         # clic derecho en el vídeo
    volumen_cambia = Signal(int)

    def __init__(self, ventana_video, ajustes):
        super().__init__()
        self.ajustes = ajustes
        self.cola, self.i = [], -1
        self.actual = None
        self.pausa, self.pos, self.dur = True, 0.0, 0.0
        self.resolutor = Resolutor(ajustes)
        self._turno = 0
        self._locales = {}
        self._parar_al_acabar = False
        self._bucle = False
        self._solo, self._fondo, self._vid = False, False, "auto"
        self._elegido, self.directo = True, False
        self.subs_activos = bool(ajustes.get("subtitulos", False))
        self._t_pedido, self._t_res, self._arrancado, self._cargado_nuevo = 0.0, 0.0, True, True
        self.tramos, self._saltados = [], set()   # SponsorBlock: [(desde, hasta, categoría)] del vídeo que suena
        self.saltar_patrocinios = ajustes.get("patrocinios", True)
        ytdlp = os.path.join(os.path.dirname(sys.executable), "yt-dlp" + (".exe" if os.name == "nt" else ""))
        opciones = {"wid": str(int(ventana_video.winId())), "ytdl": True, "osc": False,   # los controles son los de Cat-ode (los de mpv no se pueden tocar: el ratón lo atiende Cat-ode) "input_default_bindings": True,
                    "input_vo_keyboard": False,   # las teclas, siempre a Cat-ode (sus atajos), aunque el ratón esté sobre el vídeo
                    "keep_open": "no", "idle": "yes", "hwdec": "auto-safe",
                    "ytdl_format": formato(720 if ajustes.get("calidad", "auto") == "auto" else ajustes.get("calidad")), "volume": ajustes.get("volumen", 80),
                    "script_opts": f"ytdl_hook-ytdl_path={ytdlp},osc-idlescreen=no",   # sin el «Drop files or URLs to play here» de mpv "force_window": "yes", "cache": "yes",
                    "demuxer_max_bytes": "150MiB", "user_agent": motor.AGENTE}
        # para cuando mpv tenga que resolver solo (si falla lo de dentro): subtítulos en español e inglés.
        # Ojo: mpv separa estas opciones por comas, así que una lista de idiomas con coma rompe yt-dlp (02/10/2026).
        crudas = ["sub-langs=(es|en).*", "write-subs=", "write-auto-subs="]
        if motor.node():
            crudas.append(f"js-runtimes=node:{motor.node()}")
        opciones["ytdl_raw_options"] = ",".join(crudas)
        opciones["input_cursor_passthrough"] = "yes"   # el ratón atraviesa la ventana de mpv y lo recibe Cat-ode
        opciones["cursor_autohide"] = "no"
        opciones["sub_auto"] = "fuzzy"
        opciones["slang"] = "es,spa,en,eng"
        opciones["sid"] = "no"
        opciones["sub_pos"] = "88"   # más arriba: que no los tapen los mandos del vídeo
        if os.name == "nt":
            # el N100 del mini PC va justo: escalado ligero y algo más de prioridad para que el vídeo no se quede sin procesador
            opciones["profile"] = "fast"   # el N100 no da para los escalados finos (580 fotogramas perdidos en 20 s sin esto)
            opciones["priority"] = "abovenormal"
            # con el escritorio remoto (Sunshine) puesto, la gráfica del N100 va al límite (Sunshine 46 %, DWM 38 %):
            # el motor de vídeo clásico gasta menos que gpu-next y un fotograma más de colchón absorbe los picos (02/10/2026)
            opciones["vo"] = "gpu"
            opciones["gpu_api"] = "d3d11"
            opciones["swapchain_depth"] = "4"
            # 04/10/2026: descodificar con la gráfica y pintar SIN copiar (d3d11va). La copia (d3d11va-copy, 1.0.26) gastaba el
            # 61-89 % del 3D del N100 y dejaba la imagen 8 s detrás del sonido (medido con mpv solo en el mini PC); sin copia,
            # 20 % y a la par. (La prueba de fluidez solo contaba fotogramas tirados y la copia los «ahorraba» retrasándose.)
            opciones["hwdec"] = "d3d11va"
        if os.name != "nt":
            # la ventana es X11 (XWayland): con el contexto de Wayland mpv pintaba fuera de ella y no se veía la imagen
            opciones["gpu_context"] = "x11egl"
            # el AV1 por hardware falla en el Intel del Dell y tumba mpv: ese códec, por programa (dav1d)
            opciones["hwdec_codecs"] = "h264,hevc,vp8,vp9,mpeg2video,vc1"
        import locale
        locale.setlocale(locale.LC_NUMERIC, "C")   # mpv solo arranca con números «C» (Qt pone los del sistema)
        for par in filter(None, os.environ.get("CATODE_MPV", "").split(",")):   # pruebas: «clave=valor,clave=valor» sin tocar el código
            clave, _, valor = par.partition("=")
            opciones[clave.strip().replace("-", "_")] = valor.strip()
        if os.environ.get("CATODE_REGISTRO_MPV"):
            opciones["log_file"] = os.environ["CATODE_REGISTRO_MPV"]
        from . import motor_web
        if motor_web.disponible():   # Windows: el motor de Edge (04/10/2026: con mpv el N100 perdía hasta el 90 % de los fotogramas)
            self.mpv = motor_web.MpvWeb(ventana_video, ajustes, registro)
            self._web = True
            registro("vídeo con el motor de Edge (WebView2)")
        else:
            from .mpv_crear import crear_mpv   # 02/11/2026: también con un libmpv viejo (Debian 12)
            self.mpv = crear_mpv(log_handler=None, **opciones)
            self._web = False
        # 03/10/2026: la ventana NUNCA pregunta a mpv directamente (si mpv está ocupado con otra pestaña, la pregunta la
        # dejaba sin responder y Windows la daba por colgada): lee estos valores, que mpv avisa cuando cambian
        self._idle, self._sid, self._vol = True, None, ajustes.get("volumen", 80)
        for p in ("pause", "time-pos", "duration", "volume", "idle-active", "sid", "mute", "video-params"):
            self.mpv.observe_property(p, self._propiedad)
        self._p_visto, self.niveles = 0, []   # 22/10/2026 (3.6): la calidad que se ve y las que tiene el vídeo
        self.sonados = []   # 22/10/2026 (3.8): lo que ha sonado en esta sesión (la reproducción automática no repite canción)
        self._apagado = None
        self._subs_pendientes = []
        self._fin.connect(self._al_acabar, Qt.QueuedConnection)
        self._imposible.connect(self._no_se_puede, Qt.QueuedConnection)
        self._reintento.connect(self._reintentar, Qt.QueuedConnection)
        self._bloqueado.connect(self._quieto_bloqueo, Qt.QueuedConnection)
        self._reintentos = {}
        # 21/10/2026 «catode sigue saltando videos a la mitad… se interrumpe y pasa al siguiente, arréglalo como sea»: un
        # vídeo que YA ha sonado nunca pasa solo al siguiente por un fallo (ver _reintento_lento)
        self._lentos, self._t_lento, self._atascado, self._sano = {}, None, False, 0
        self._t_pedido, self._t_res, self._arrancado = 0.0, 0.0, True
        # vigilante: si suena (sin pausa) y no avanza en 8 s, se recarga con direcciones nuevas en el mismo segundo
        from PySide6.QtCore import QTimer
        self._quieto, self._ult = 0, -1.0
        self._vigia = QTimer(self, interval=2000)
        self._vigia.timeout.connect(self._mirar_parado)
        self._vigia.start()
        # el ratón sobre el vídeo, como en YouTube: clic = pausa, doble clic = pantalla completa, rueda = volumen,
        # clic derecho = menú. (mpv, por defecto, pausaba con el derecho y su pantalla completa no servía incrustado)
        # el ratón lo atiende Cat-ode (ZonaVideo): mpv no debe hacer nada con él (abría un segundo menú con el derecho)
        for tecla, orden in (("MBTN_LEFT", "ignore"), ("MBTN_LEFT_DBL", "ignore"), ("MBTN_RIGHT", "ignore"),
                             ("MBTN_MID", "ignore"), ("WHEEL_UP", "ignore"), ("WHEEL_DOWN", "ignore"),
                             ("MBTN_BACK", "ignore"), ("MBTN_FORWARD", "ignore")):
            try:
                self.mpv.command("keybind", tecla, orden)
            except Exception as error:  # noqa: BLE001
                print("Cat-ode: no se pudo asignar", tecla, error, file=sys.stderr, flush=True)
        self.mpv.register_message_handler("catode-pantalla", lambda *a: self.pide_pantalla.emit())
        self.mpv.register_message_handler("catode-menu", lambda *a: self.pide_menu.emit())
        self._fs = None
        self.mpv.observe_property("fullscreen", self._boton_pantalla)

        @self.mpv.event_callback("end-file")
        def _fin(ev):
            try:
                if ev.data.reason == mpv.MpvEventEndFile.EOF:
                    if getattr(self, "_recargando", False) or (not self.dur and not self.directo):
                        # 03/10/2026: el «fin» del archivo que se sustituye al recargar (cambio de calidad) llegaba con la
                        # duración aún a 0 y se tomaba por el final del vídeo: saltaba al siguiente a mitad
                        registro(f"fin del archivo anterior durante la recarga en {self.pos:.0f} s: no es el final")
                        return
                    if not self.directo and self.dur and self.pos < self.dur - 10 and self.actual is not None and self.actual.url not in self._locales:
                        # un «final» a mitad de vídeo (pasa al saltar lejos en el HLS de YouTube): no es el final, se recarga ahí
                        registro(f"final falso en {self.pos:.0f}/{self.dur:.0f} s: recargo en ese punto")
                        self._reintento.emit()
                    else:
                        registro(f"acabado en {self.pos:.0f} s de {self.dur:.0f} s → lo siguiente")   # 19/10/2026: rastro de cada paso solo
                        self._fin.emit()
                elif ev.data.reason == mpv.MpvEventEndFile.ERROR:
                    registro(f"mpv ha cortado el vídeo por un error ({ev.data.error}) en {self.pos:.0f} s")
                    self._reintento.emit()
            except Exception:
                pass

        @self.mpv.event_callback("file-loaded")
        def _cargado(ev):
            self._cargado_nuevo = True
            subs, self._subs_pendientes = self._subs_pendientes, []
            for url, nombre, lengua in subs:
                try:   # asíncrono: sub-add baja el archivo y, mientras, mpv no atiende a nadie; con 3-4 pestañas la ventana
                    # se quedaba esperándolo y Windows la daba por colgada (vigía de cuelgues, 03/10/2026)
                    if hasattr(self.mpv, "command_async"):
                        self.mpv.command_async("sub-add", url, "auto", nombre, lengua)
                    else:
                        threading.Thread(target=self.mpv.command, args=("sub-add", url, "auto", nombre, lengua), daemon=True).start()
                except Exception:
                    pass
            try:   # los subtítulos, solo si el autor los tiene puestos (salían solos, y encima de los mandos)
                if self.subs_activos:
                    pistas = [t for t in self.mpv.track_list if t.get("type") == "sub"]
                    if pistas:
                        self.mpv.sid = pistas[0]["id"]
                else:
                    self.mpv.sid = "no"
            except Exception:
                pass

    def _boton_pantalla(self, nombre, valor):
        """El botón de pantalla completa de los controles de mpv cambia esta propiedad: se toma como «pulsado» y la
        pantalla completa la hace la ventana de Cat-ode (mpv incrustado no puede)."""
        if self._fs is None:
            self._fs = valor
            return
        if valor != self._fs:
            self._fs = valor
            self.pide_pantalla.emit()

    def _propiedad(self, nombre, valor):
        if nombre == "video-params":   # 22/10/2026 (3.6): lo que pinta mpv de verdad, por el lado corto (como YouTube)
            w, h = ((valor or {}).get("w") or 0, (valor or {}).get("h") or 0) if isinstance(valor, dict) else (0, 0)
            from .resolutor import escalon
            self._p_visto = escalon(min(w, h)) if w and h else 0
            return
        if nombre == "idle-active":
            self._idle = bool(valor)
        elif nombre == "sid":
            self._sid = valor
        if nombre == "mute":
            self._mute = bool(valor)
        if nombre == "volume" and valor is not None:
            self._vol = valor
        if nombre == "pause":
            self.pausa = bool(valor)
        elif nombre == "time-pos":
            if getattr(self, "_recargando", False):   # cambio de calidad: hasta que arranque, el punto es el de antes
                if not (self._cargado_nuevo and valor):
                    return
                self._recargando = False
            if valor is None:   # mientras salta, mpv no sabe dónde está: se queda el destino (si no, un corte recargaba en 0)
                return
            self.pos = valor
            if not self._arrancado and self._cargado_nuevo and self.pos > 0 and self.actual is not None:
                self._arrancado = True
                registro(f"empieza «{self.actual.titulo[:50]}» en {time.time() - self._t_pedido:.1f} s (resolver {self._t_res:.1f} s)")
                self.sonados = (self.sonados + [self.actual])[-30:]
            if self.saltar_patrocinios:
                for a, b, cat in self.tramos:
                    # 19/10/2026: un tramo que llega al final no se salta (se acabaría el vídeo y empezaría otro)
                    if a <= self.pos < b - 0.5 and (a, b) not in self._saltados and self.dur > 0 and b < self.dur - 3:   # 21/10/2026: sin la duración, nada (Dell: salto «de 0 s»)
                        self._saltados.add((a, b))
                        registro(f"salto de tramo {cat} de {a:.0f} s a {b:.0f} s (de {self.dur:.0f} s)")   # 19/10/2026: rastro
                        self.ir_a(b)
                        self.aviso.emit({"sponsor": "Patrocinio saltado", "selfpromo": "Autopromoción saltada",
                                         "interaction": "«Suscríbete» saltado", "intro": "Intro saltada", "outro": "Final saltado",
                                         "music_offtopic": "Parte sin música saltada", "anuncio": "Anuncio saltado"}.get(cat, "Tramo saltado"))
        elif nombre == "duration":
            if valor or not getattr(self, "_recargando", False):
                self.dur = valor or 0.0
        elif nombre == "volume" and valor is not None:
            try:
                self.volumen_cambia.emit(int(valor))
            except RuntimeError:
                pass
        try:
            self.cambio.emit()
        except RuntimeError:   # la ventana ya se ha cerrado
            pass

    # ---- la cola ----
    def _cargar(self, desde=0, recarga=False):
        """Pone a sonar cola[i]: lo resuelve (o lo toma ya resuelto) en otro hilo y se lo pasa a mpv.
        Con recarga (cambio de calidad) es el mismo vídeo: se conserva el punto, la duración y los tramos."""
        self._turno += 1
        turno = self._turno
        e = self.cola[self.i]
        self.actual = e
        self._recargando = recarga
        if recarga:
            self.pos = desde   # si llega otra recarga antes de que arranque esta, sigue desde aquí y no desde 0
        else:
            self._parar_lento()
            self._atascado = False
            self._sano = 0
            self.pos, self.dur = 0.0, 0.0
            self.directo = False
            self.storyboard = None
            self.tramos, self._saltados = [], set()
            self.empieza.emit(e)
        self.cambio.emit()
        alto = self.alto()
        local = self._locales.get(e.url)

        self._t_pedido, self._t_res, self._arrancado, self._cargado_nuevo = time.time(), 0.0, False, False

        ya = None if local else self.resolutor.guardado(e.url, alto)

        def trabajo(ya=ya):
            opciones = {"start": str(int(desde))} if desde else {}   # nada con comas: python-mpv las usa de separador
            titulo = e.titulo
            hls_web = None
            if local:
                ruta, subs = local, []
            elif ya is not None:   # ya resuelto (adelantado): directo a mpv, sin hilos de por medio
                ruta, subs, titulo = ya["ruta"], ya["subs"], ya["titulo"] or e.titulo
                hls_web = ya.get("hls")
                self.directo = ya.get("directo", False)
                self.storyboard = ya.get("storyboard")
            else:
                try:
                    if e.url.startswith("cancion:"):   # 22/10/2026: importada de Spotify o Amazon: su vídeo de YouTube, ahora
                        from . import musica
                        e.url = musica.resolver_cancion(e.url)
                        e.miniatura = e.miniatura or motor.miniatura(motor.id_video(e.url))
                    x = self.resolutor.resolver(e.url, alto)
                    self._t_res = time.time() - self._t_pedido
                    ruta, subs = x["ruta"], x["subs"]
                    hls_web = x.get("hls")
                    titulo = x["titulo"] or e.titulo
                    self.directo = x.get("directo", False)
                    self.storyboard = x.get("storyboard")
                    self.niveles = x.get("niveles") or []
                except Exception as error:  # noqa: BLE001
                    registro(f"no he podido resolver {e.url}: {repr(error)[:200]}")
                    if recarga and turno == self._turno:
                        try:
                            from . import roto
                            if roto.clasificar(error) == "bloqueo":   # regla 24: ni yt-dlp de mpv ni reintentos
                                return lambda: self._bloqueado.emit("YouTube pide comprobar que no eres un robot: me quedo aquí, en pausa")
                        except Exception:  # noqa: BLE001
                            pass
                    if not definitivo(error):
                        avisar_fallo(e.url, repr(error))
                    aviso = definitivo(error)
                    if aviso and turno == self._turno:
                        if recarga and self.pos > 5:   # 21/10/2026: ya sonaba: no se pasa al siguiente
                            return lambda: self._reintento.emit()
                        return lambda: self._imposible.emit(aviso)
                    ruta, subs = e.url, []   # que lo intente mpv con su yt-dlp
            if turno != self._turno:
                return
            self._subs_pendientes = subs
            try:
                if self._web:   # motor de Edge: el manifiesto HLS (o el archivo, si es local)
                    self.mpv.fuente_web = None if local else (hls_web or None)
                self.mpv.force_media_title = titulo or ""
                self.mpv.loadfile(ruta, "replace", **opciones)
                self.mpv.pause = False
            except Exception as error:  # noqa: BLE001
                registro(f"mpv no ha aceptado el vídeo: {repr(error)[:300]}")
            def despues():
                if self.saltar_patrocinios and e.url.startswith("http") and not local:
                    tramos = motor.patrocinios(e.url)
                    if not any(c == "sponsor" for _, _, c in tramos):   # 03/10/2026: si nadie lo ha marcado, lo busca él
                        try:
                            from . import anuncios
                            f = motor.ficha(e.url)
                            # los del idioma original (sin «tlang=», que es traducción automática)
                            vtt = next((u for u, n, l in subs if "tlang=" not in u), None) or next((u for u, n, l in subs), None)
                            tramos = tramos + anuncios.detectar(f.get("descripcion", ""), f.get("capitulos") or [], self.dur or e.duracion, vtt)
                        except Exception:   # noqa: BLE001
                            pass
                    if turno == self._turno:
                        self.tramos = tramos
                self._adelantar()
            return despues

        if ya is not None or local:
            threading.Thread(target=trabajo(), daemon=True).start()   # carga ya; patrocinios y el siguiente, por detrás
        else:
            threading.Thread(target=lambda: (lambda f: f and f())(trabajo()), daemon=True).start()

    def _reintentar(self):
        if self.actual is None or self._t_lento is not None:   # ya hay un intento lento esperando: no se gasta otro
            return
        n = self._reintentos.get(self.actual.url, 0) + 1
        self._reintentos[self.actual.url] = n
        if n > 3:
            # 21/10/2026: solo un vídeo que no ha llegado a sonar se da por imposible y deja paso al siguiente
            if self.pos > 5 and not self.directo and self.actual.url not in self._locales:
                return self._reintento_lento()
            registro(f"«{self.actual.titulo[:50]}» falla tras 3 reintentos sin haber sonado")
            return self._no_se_puede("Este vídeo no se puede reproducir ahora")
        self._sano = 0
        self.resolutor.olvidar(self.actual.url)
        registro(f"reintento {n} de «{self.actual.titulo[:50]}» en {self.pos:.0f} s")
        if n == 2:
            avisar_fallo(self.actual.url, "dos reintentos seguidos")
        self._cargar(max(0, self.pos - 1), recarga=True)   # el mismo punto, sin que la barra vuelva a cero

    # segundos de espera antes de cada intento lento (dirección nueva, el mismo segundo); pocos y espaciados (regla 24)
    LENTOS = (10, 20, 40, 60, 120, 120)

    def _parar_lento(self):
        if self._t_lento is not None:
            self._t_lento.stop()
            self._t_lento = None

    def _reintento_lento(self):
        """21/10/2026: tras los 3 reintentos rápidos de un vídeo que ya sonaba, NUNCA al siguiente: se espera y se vuelve
        al mismo segundo con direcciones nuevas; si tampoco, quieto en ese punto y en pausa (▶ lo vuelve a intentar)."""
        from PySide6.QtCore import QTimer
        e, url = self.actual, self.actual.url
        k = self._lentos[url] = self._lentos.get(url, 0) + 1
        pos = max(0.0, self.pos - 1)
        if k > len(self.LENTOS):
            registro(f"«{e.titulo[:50]}» no sigue tras {3 + len(self.LENTOS)} intentos: me quedo en {pos:.0f} s en pausa (no paso al siguiente)")
            self._quieto_bloqueo("Este vídeo no consigue seguir cargando: pulsa ▶ para intentarlo otra vez")
            return
        s = self.LENTOS[k - 1]
        registro(f"«{e.titulo[:50]}» falla tras 3 reintentos en {pos:.0f} s: NO paso al siguiente; intento lento {k}/{len(self.LENTOS)} en {s} s")
        self.aviso.emit(f"El vídeo se ha cortado: lo vuelvo a intentar en {s} s, en el mismo punto")

        def ahora():
            self._t_lento = None
            if self.actual is not e:
                return
            if self.pausa:   # lo ha pausado él: ▶ lo vuelve a intentar
                self._atascado = True
                return
            self._sano, self._quieto = 0, 0
            self.resolutor.olvidar(url)
            self._cargar(pos, recarga=True)
        self._t_lento = QTimer(self, singleShot=True, interval=int(s * 1000))
        self._t_lento.timeout.connect(ahora)
        self._t_lento.start()

    def _quieto_bloqueo(self, aviso):
        """Quieto en el punto donde iba, en pausa y con el aviso: ni reintentos ni paso al siguiente."""
        self._parar_lento()
        self._atascado = True
        self._orden("set_property", "pause", True)
        self.pausa = True
        registro(f"quieto en {self.pos:.0f} s: {aviso}")
        self.aviso.emit(aviso)
        self.cambio.emit()

    def _mirar_parado(self):
        try:
            activo = self.actual is not None and not self.pausa and not self._idle and self._arrancado
        except Exception:
            return
        if activo and abs(self.pos - self._ult) < 0.1:
            self._quieto += 2
            limite = 4 if time.time() - getattr(self, "_salto", 0) < 30 else 8   # tras un salto, a los 4 s
            if self._quieto >= limite:
                registro(f"parado 8 s en {self.pos:.0f} s: recargo")
                self._quieto = 0
                self._reintentar()
        else:
            self._quieto = 0
            # con 30 s sonando y avanzando, el vídeo está sano: los reintentos empiezan de nuevo (antes nunca volvían a
            # cero y, en un vídeo largo, el cuarto tropiezo suelto lo pasaba al siguiente)
            if activo:
                self._sano += 2
                if self._sano >= 30 and (self._reintentos.get(self.actual.url) or self._lentos.get(self.actual.url)):
                    self._reintentos[self.actual.url] = 0
                    self._lentos[self.actual.url] = 0
        self._ult = self.pos

    def precalentar(self, elementos):
        """Deja resueltos, por detrás y sin estorbar, los primeros vídeos de una página: así empiezan al pulsarlos."""
        alto = self.alto()
        lista = [e for e in elementos if e.tipo == "VIDEO" and e.url.startswith("http")][:4]

        def trabajo():
            for e in lista:
                try:
                    self.resolutor.resolver(e.url, alto, fondo=True)
                except Exception:
                    pass
        threading.Thread(target=trabajo, daemon=True).start()

    def _adelantar(self):
        """Deja resuelto el siguiente de la cola para que empiece sin esperar."""
        if 0 <= self.i + 1 < len(self.cola):
            e = self.cola[self.i + 1]
            if e.url.startswith("http") and e.url not in self._locales:
                try:
                    self.resolutor.resolver(e.url, self.alto(), fondo=True)
                except Exception:
                    pass

    def _no_se_puede(self, aviso):
        """Un vídeo que no se puede ver: si lo has elegido tú, se dice y se para (antes saltaba a otro vídeo sin más);
        si venía solo (cola, reproducción automática), se dice y se pasa al siguiente."""
        registro(f"no se puede: «{self.actual.titulo[:50] if self.actual else ''}» · {aviso}")
        self._orden("stop")
        if self.i + 1 < len(self.cola):
            # 03/10/2026: en una lista o en los Shorts se pasa al siguiente aunque fuera el primero (el primer Short tenía
            # restricción de edad y Cat-ode se quedaba ahí; y con el bucle de los Shorts lo reintentaba sin fin)
            self.aviso.emit(aviso + ": paso al siguiente")
            self.i += 1
            self._elegido = False
            self._cargar()
        elif self._elegido:
            self.aviso.emit(aviso)
            self.cambio.emit()
        else:
            self.aviso.emit(aviso)
            if self.actual is not None:
                self.pide_mas.emit(self.actual)

    def _al_acabar(self):
        if self._bucle:
            return self._cargar()
        if self._parar_al_acabar:
            self._parar_al_acabar = False
            self.aviso.emit("Temporizador: parado al acabar el vídeo")
            return
        if self.i + 1 < len(self.cola):
            self.i += 1
            self._elegido = False
            self._cargar()
        elif self.actual is not None:
            self.pide_mas.emit(self.actual)

    @property
    def indice(self):
        return self.i

    def reproducir(self, e, desde=0):
        self._elegido = True
        self.cola, self.i = [e], 0
        self._cargar(desde)

    def encolar(self, e):
        if self.actual is None or not self.cola:
            return self.reproducir(e)
        self.cola.append(e)
        if len(self.cola) == self.i + 2:
            threading.Thread(target=self._adelantar, daemon=True).start()

    def insertar_siguiente(self, e):
        """«Reproducir a continuación»: justo detrás del que suena."""
        if self.actual is None or not self.cola:
            return self.reproducir(e)
        self.cola.insert(self.i + 1, e)
        threading.Thread(target=self._adelantar, daemon=True).start()

    def todo(self, lista, aleatorio=False):
        import random
        videos = [e for e in lista if e.tipo == "VIDEO"]
        if aleatorio:
            random.shuffle(videos)
        if not videos:
            return
        self.cola, self.i = videos, 0
        self._cargar()

    def saltar_a(self, i):
        """Salta a la posición «i» de la cola."""
        if 0 <= i < len(self.cola):
            self.i = i
            self._cargar()

    def _orden(self, *args):
        """Una orden a mpv SIN esperar (03/10/2026): la ventana nunca se queda esperando a mpv; con varias pestañas,
        mpv podía estar ocupado y Windows daba Cat-ode por colgado."""
        try:
            if hasattr(self.mpv, "command_async"):
                self.mpv.command_async(*[a if isinstance(a, str) else str(a) for a in args])
            else:
                threading.Thread(target=self.mpv.command, args=args, daemon=True).start()
        except Exception as error:  # noqa: BLE001
            registro(f"orden {args[:2]}: {error!r}"[:160])

    def alternar(self):
        if self._atascado and self.pausa and self.actual is not None:   # 21/10/2026: quieto tras un fallo: ▶ lo intenta otra vez
            url = self.actual.url
            self._atascado, self._reintentos[url], self._lentos[url] = False, 0, 0
            registro(f"▶ tras quedarse quieto en {self.pos:.0f} s: lo intento otra vez")
            self.resolutor.olvidar(url)
            self._cargar(max(0.0, self.pos), recarga=True)
            return
        self._orden("cycle", "pause")

    def siguiente(self, origen=None):
        # 21/10/2026: todo paso al siguiente a mitad de un vídeo queda en catode.log con quién lo pidió (el botón, las
        # teclas multimedia o los auriculares no dejaban rastro y no se podía saber si era un salto solo o una pulsación)
        if self.actual is not None and self.dur > 30 and 5 < self.pos < self.dur - 10:
            registro(f"siguiente a mitad de «{self.actual.titulo[:50]}» ({self.pos:.0f} de {self.dur:.0f} s), pedido por: {origen or 'botón o atajo de Cat-ode'}")
        if self.i + 1 < len(self.cola):
            self.i += 1
            self._cargar()
        elif self.actual is not None:
            self.pide_mas.emit(self.actual)

    def anterior(self):
        if self.pos > 5 or self.i <= 0:
            self.ir_a(0)
        else:
            self.i -= 1
            self._cargar()

    def ir_a(self, segundos):
        self.pos = max(0.0, segundos)
        self._salto = time.time()   # tras un salto, si no llegan datos se recarga enseguida (_mirar_parado)
        try:
            self._orden("seek", segundos, "absolute")
        except SystemError:
            pass

    def ir_al_directo(self):
        """En un directo: al momento actual (lo último que ha emitido)."""
        if self.dur:
            self.ir_a(max(0.0, self.dur - 3))

    def mover(self, segundos):
        try:
            self._orden("seek", segundos, "relative")
        except SystemError:
            pass

    def silencio(self):
        self._mute = not getattr(self, "_mute", False)
        self._orden("set", "mute", "yes" if self._mute else "no")
        return self._mute

    def volumen(self, v):
        self._vol = v
        self._orden("set", "volume", v)
        self.ajustes["volumen"] = v

    def solo_sonido(self, si):
        self._solo = si
        self._poner_vid()

    def de_fondo(self, si):
        """Pestaña que no se ve: sigue sonando, pero sin descodificar ni pintar la imagen. Con tres pestañas con vídeo, el
        N100 del mini PC tenía la descodificación de la gráfica al 89 % y DWM al 69 %: todo a saltos (03/10/2026)."""
        self._fondo = si
        self._poner_vid()

    def _poner_vid(self):
        v = "no" if (self._solo or self._fondo) else "auto"
        if v != self._vid:
            self._vid = v
            # en otro hilo: en Windows, volver a dar imagen hace que mpv cree su salida en la ventana de Cat-ode, y eso
            # necesita el hilo de la interfaz; si este se quedaba esperando a mpv, los dos se bloqueaban (la prueba se
            # colgó al cerrar con la rueda la pestaña activa, 03/10/2026)
            threading.Thread(target=self._vid_en_hilo, args=(v,), daemon=True).start()

    def _vid_en_hilo(self, v):
        try:
            self.mpv.vid = v
        except Exception as e:  # noqa: BLE001 (mpv ya cerrado)
            registro(f"vid={v}: {e!r}"[:160])

    alto_auto = 720   # lo pone la ventana según el tamaño del reproductor (calidad «auto», como YouTube)

    def alto(self):
        """La altura que se pide: la elegida o, en «auto», la que pide el tamaño del reproductor."""
        c = self.ajustes.get("calidad", "auto")
        return self.alto_auto if c == "auto" else int(c)

    def calidad(self, alto):
        """Cambia la calidad («auto» o una altura) y vuelve a cargar el vídeo que suena en el mismo punto, sin perder la cola."""
        antes = self.alto()
        registro(f"calidad elegida: {alto}")
        self.ajustes["calidad"] = alto
        self._orden("set", "ytdl-format", formato(self.alto()))
        if self.actual is not None and self.actual.url not in self._locales and self.alto() != antes:
            self._cargar(self.pos, recarga=True)

    def calidad_vista(self):
        """22/10/2026 (encargo 3.6, «debe coincidir la calidad elegida con la que se muestra»): (la calidad que se ve de verdad,
        por qué no es la elegida o «»). La que se ve la dice mpv (video-params), no lo pedido."""
        c, visto = self.ajustes.get("calidad", "auto"), self._p_visto
        if self._solo:
            return visto, "solo sonido"
        if self._fondo:
            return visto, "pestaña de fondo"
        if c == "auto":
            return visto, ""
        pedido = int(c)
        if not visto or visto == pedido:
            return visto or pedido, ""
        return visto, (f"este vídeo no tiene {pedido}p" if visto < pedido else f"este vídeo no baja de {visto}p")

    def poner_alto_auto(self, alto, detalle=""):
        """El reproductor ha cambiado de tamaño: si la calidad es «auto» y hace falta otra, se recarga en el mismo punto.
        Nunca dos recargas por calidad en menos de 45 s (03/10/2026: en el mini PC iba 720p↔1080p cada 25 s, un corte cada vez)."""
        if alto == self.alto_auto:
            return
        if getattr(self, "_web", False):   # con Edge la calidad la fija la página (la mayor hasta 1080): no se recarga nada
            self.alto_auto = alto
            return
        ultima = getattr(self, "_t_recarga_calidad", 0.0)
        if time.time() - ultima < 45 and self.actual is not None:
            registro(f"calidad automática: {self.alto_auto}p → {alto}p pospuesto (recarga hace {time.time() - ultima:.0f} s) {detalle}")
            return
        registro(f"calidad automática: {self.alto_auto}p → {alto}p {detalle}")
        self.alto_auto = alto
        if self.ajustes.get("calidad", "auto") == "auto" and self.actual is not None and self.actual.url not in self._locales:
            self._t_recarga_calidad = time.time()
            self._orden("set", "ytdl-format", formato(alto))
            self._cargar(self.pos, recarga=True)

    def velocidad(self, v):
        self._orden("set", "speed", v)

    def subtitulos(self):
        """[(id, nombre)] de las pistas de subtítulos del vídeo que suena."""
        try:
            return [(t["id"], t.get("title") or t.get("lang") or f"Pista {t['id']}")
                    for t in self.mpv.track_list if t.get("type") == "sub"]
        except Exception:
            return []

    def poner_subtitulos(self, sid):
        self._orden("set", "sid", sid if sid else "no")
        self.subs_activos = bool(sid)
        self.ajustes["subtitulos"] = self.subs_activos

    def bucle(self, si):
        self._bucle = si
        self._orden("set", "loop-file", "inf" if si else "no")

    def apagar_en(self, minutos):
        """Temporizador de apagado: pausa dentro de «minutos» (0 lo quita; -1, al acabar este vídeo)."""
        if self._apagado:
            self._apagado.cancel()
            self._apagado = None
        self._parar_al_acabar = minutos == -1
        if minutos > 0:
            self._apagado = threading.Timer(minutos * 60, lambda: setattr(self.mpv, "pause", True))
            self._apagado.daemon = True
            self._apagado.start()
            self.aviso.emit(f"Se pausará dentro de {minutos} min")
        elif minutos == -1:
            self.aviso.emit("Se parará al acabar este vídeo")

    def reproducir_local(self, ruta, e):
        """Un vídeo descargado: sin red."""
        self._locales[e.url] = ruta
        self.reproducir(e)

    def parar(self):
        self._turno += 1
        self.cola, self.i, self.actual = [], -1, None
        self._orden("stop")
        self.cambio.emit()

    def cerrar(self):
        try:
            if self._web:   # motor de Edge: se cierra del todo
                self.mpv.terminate()
            elif os.name == "nt":   # en Windows terminate() con la ventana incrustada revienta (acceso no válido): se para y el proceso sale
                # sin esperar (03/10/2026): cerrar pestañas colgaba la ventana mientras mpv deshacía su salida de vídeo
                if hasattr(self.mpv, "command_async"):
                    self.mpv.command_async("stop")
                else:
                    threading.Thread(target=self.mpv.command, args=("stop",), daemon=True).start()
            else:
                self.mpv.terminate()
        except Exception:
            pass
