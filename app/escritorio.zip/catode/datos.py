"""Cat-ode escritorio · suscripciones e historial. Se guardan aquí y se comparten con los móviles y los demás
ordenadores a través del servidor propio del autor (HTTPS con su certificado fijado por huella y una clave). En cada
canal y cada vídeo gana el cambio más reciente; igual que en el móvil y en el servidor."""
import hashlib
import http.client
import json
import os
import platform
import socket
import ssl
import threading
import time

from .motor import Elemento, elemento_de_dict


def carpeta_propia():
    """18/10/2026 · CATODE_CARPETA, para probar una instalación aislada («instalador de Windows y de Android para
    aparatos nuevos»): sustituye a %LOCALAPPDATA%\\Cat-ode, ~/.config/catode y ~/.local/share/catode (configuración,
    datos y la carpeta de Edge). None si no está puesta."""
    d = os.environ.get("CATODE_CARPETA", "").strip()
    return os.path.abspath(os.path.expanduser(d)) if d else None


def carpeta_config():
    d = carpeta_propia()
    if d:
        os.makedirs(d, exist_ok=True)
        return d
    return os.path.join(os.environ["LOCALAPPDATA"], "Cat-ode") if os.name == "nt" else os.path.expanduser("~/.config/catode")


def carpeta_datos():
    d = carpeta_propia() or (os.path.join(os.environ["LOCALAPPDATA"], "Cat-ode") if os.name == "nt" else os.path.expanduser("~/.local/share/catode"))
    os.makedirs(d, exist_ok=True)
    return d


# Lo que se comparte entre los equipos. Cada colección es {clave: {t, activo, e, x}}: «e» es un Elemento (vídeo, canal o
# lista) y «x», datos extra (la posición donde se dejó un vídeo, los vídeos de una lista propia…). En cada clave gana el
# cambio más reciente, igual que en el servidor y en el móvil. 1.0.0 (02/10/2026): además de suscripciones e historial,
# «Ver más tarde», «Me gusta», listas propias, posiciones, «No me interesa» y búsquedas.
COLECCIONES = ("suscripciones", "historial", "despues", "megusta", "nomegusta", "listas", "posiciones", "ocultos", "busquedas",
               "ajustes", "biblioteca")   # nomegusta: 03/10/2026, local (nunca va a YouTube) · ajustes y biblioteca: 22/10/2026
# 22/10/2026 · encargo de música, aclaración del autor: «lo que se cambia en windows se cambia en android y en linux y
# viceversa … de TODO: …, ajustes». Los ajustes que existen igual en las tres versiones, en la colección «ajustes» ({t,
# activo, x: {v}}): gana el cambio más reciente, como en todo. La calidad no: cada pantalla y cada red tienen la suya.
AJUSTES_COMUNES = ("automatica", "patrocinios", "reanudar", "pausar_historial", "avisos")
# 22/10/2026 · los orígenes de la biblioteca de música, en el orden de la sección «Música», y su grupo (chip)
# 09/11/2026 · «amplía la sección música muchísimo … muchos canales de directos de lofi, chill out, etc. de música que pueda
# dejar puesta»: «directos» (emisiones 24/7) y «radio» (listas por género y ambiente), detrás de su YouTube Music
ORIGENES_MUSICA = {"youtube music": "YouTube Music", "youtube music · canciones": "YouTube Music", "directos": "Directos",
                   "radio": "Radio", "youtube music · álbum": "Álbumes",
                   "spotify": "Spotify", "spotify · álbum": "Álbumes", "amazon music": "Amazon Music", "amazon music · álbum": "Álbumes",
                   "importada": "Importadas", "importada · álbum": "Álbumes", "tu carpeta": "Tu carpeta", "tu carpeta · álbum": "Tu carpeta",
                   "youtube music · artista": "Artistas", "historial": "Para ti", "historial+relacionados": "Para ti",
                   "relacionados": "Descubrir", "D: del mini PC": "Tu disco"}
TOPES = {"historial": 5000, "posiciones": 3000, "busquedas": 300, "ocultos": 3000}


class Datos:
    def __init__(self):
        # un archivo por equipo: ~/.local/share se sincroniza entre los portátiles y así no se pisan
        self.archivo = os.path.join(carpeta_datos(), f"datos-{platform.node()}.json")
        self.c = {k: {} for k in COLECCIONES}
        self.borrado = 0
        self.cerrojo = threading.RLock()
        self.oyentes = []
        self.estado_sincro = "Sin configurar"
        self._temporizador = None
        self._guardando = threading.Lock()
        self._pide_cerrojo, self._pide, self._escribiendo = threading.Lock(), False, False
        self.pausar_historial = False
        self.al_ajustes = []   # 22/10/2026: avisos de ajustes cambiados en otro equipo: fn({clave: valor})
        try:
            with open(os.path.join(carpeta_config(), "sincro.json")) as f:
                self.conf = json.load(f)
        except Exception:
            self.conf = None
        try:
            with open(self.archivo, encoding="utf-8") as f:
                self._cargar(json.load(f))
        except Exception:
            pass

    # compatibilidad con el código anterior
    @property
    def subs(self):
        return self.c["suscripciones"]

    @property
    def hist(self):
        return self.c["historial"]

    # ---- consultas ----
    def coleccion(self, col, n=None):
        """Los Elementos activos de una colección, lo último primero."""
        with self.cerrojo:
            r = [m["e"] for m in sorted(self.c[col].values(), key=lambda m: -m["t"])
                 if m["activo"] and m.get("e") is not None and (col != "historial" or m["t"] > self.borrado)]
        return r[:n] if n else r

    def suscripciones(self):
        with self.cerrojo:
            return sorted((m["e"] for m in self.subs.values() if m["activo"]), key=lambda e: e.titulo.lower())

    def historial(self, n=1000):
        return self.coleccion("historial", n)

    def contiene(self, col, clave):
        return bool(self.c[col].get(clave, {}).get("activo"))

    def suscrito(self, url):
        return self.contiene("suscripciones", url)

    def extra(self, col, clave):
        m = self.c[col].get(clave)
        return (m or {}).get("x") if m and m.get("activo") else None

    def posicion(self, url):
        """(segundos, duración) donde se dejó el vídeo, o (0, 0)."""
        x = self.extra("posiciones", url) or {}
        return x.get("s", 0), x.get("d", 0)

    def continuar_viendo(self, n=12):
        """Los vídeos dejados a medias (03/10/2026, «Continuar viendo» del Inicio): [(Elemento, segundos, duración)], el
        más reciente primero. A medias = más de 15 s vistos y más de 20 s por ver."""
        with self.cerrojo:
            pos = {u: m for u, m in self.c["posiciones"].items() if m.get("activo", True)}
        r = []
        for e in self.historial(600):
            m = pos.get(e.url)
            if not m:
                continue
            s, d = (m.get("x") or {}).get("s", 0), (m.get("x") or {}).get("d", 0)
            if d and 15 < s < d - 20:
                r.append((m.get("t", 0), e, s, d))
        r.sort(key=lambda x: -x[0])
        return [(e, s, d) for _, e, s, d in r[:n]]

    def listas_propias(self):
        with self.cerrojo:
            return [(k, m["x"]) for k, m in sorted(self.c["listas"].items(), key=lambda kv: -kv[1]["t"]) if m["activo"] and m.get("x")]

    def busquedas(self, n=20):
        with self.cerrojo:
            return [k for k, m in sorted(self.c["busquedas"].items(), key=lambda kv: -kv[1]["t"]) if m["activo"]][:n]

    def vetado(self, e):
        """¿Fuera? (03/10/2026, lo deciden los móviles: «Fulminar canal» y «Temas filtrados»). Por canal fulminado —por
        dirección, por nombre o con el nombre dentro de una colaboración— o por una palabra de un tema en el título,
        el canal o el detalle (sin mayúsculas ni tildes; «ultra*» vale para lo que empieza así)."""
        import re
        import unicodedata

        def sin(t):
            return "".join(c for c in unicodedata.normalize("NFD", (t or "").lower()) if unicodedata.category(c) != "Mn")
        with self.cerrojo:
            firma = tuple((k, m["t"], m["activo"]) for k, m in self.c["ocultos"].items() if k.startswith(("canal:", "tema:")))
            if getattr(self, "_vetos_firma", None) != firma:
                urls, nombres, pal = set(), set(), []
                for k, m in self.c["ocultos"].items():
                    if not m["activo"]:
                        continue
                    x = m.get("x") or {}
                    if k.startswith("canal:"):
                        urls.add(k[6:].lower().split("?")[0].rstrip("/").replace("://m.youtube", "://www.youtube"))
                        if x.get("nombre"):
                            nombres.add(x["nombre"].strip().lower())
                    elif k.startswith("tema:"):
                        pal += [sin(w.strip()) for w in x.get("palabras", []) if w.strip()]
                borde = r"(^|[^\w])"
                self._vetos = (urls, nombres,
                               [re.compile(borde + r"\w*".join(re.escape(t) for t in w.split("*")) + r"($|[^\w])") for w in set(pal)],
                               [re.compile(borde + re.escape(n) + r"($|[^\w])") for n in nombres if len(n) > 3])
                self._vetos_firma = firma
        urls, nombres, temas, colab = self._vetos
        if not (urls or temas):
            return False
        canal = e.tipo == "CANAL"
        url = (e.url if canal else e.autorUrl or "").lower().split("?")[0].rstrip("/").replace("://m.youtube", "://www.youtube")
        nombre = ((e.titulo if canal else e.autor) or "").strip().lower()
        if (url and url in urls) or (nombre and nombre in nombres) or (len(nombre) > 3 and any(r.search(nombre) for r in colab)):
            return True
        texto = sin(f"{e.titulo} {e.autor} {e.detalle}")
        return any(r.search(texto) for r in temas)

    def ocultos(self):
        return {k for k, m in self.c["ocultos"].items() if m["activo"]}

    # ---- cambios ----
    def poner(self, col, clave, e=None, x=None, activo=True):
        with self.cerrojo:
            if e is not None and getattr(e, "fecha", 0) and col == "historial":
                e = Elemento(**{**e.dict(), "fecha": 0})
            self.c[col][clave] = {"t": _ahora(), "activo": activo, "e": e, "x": x}
        self._cambio()

    def alternar(self, col, e):
        """«Ver más tarde» o «Me gusta»: si está, se quita; si no, se pone. Devuelve si queda puesto."""
        si = not self.contiene(col, e.url)
        self.poner(col, e.url, e, activo=si)
        return si

    def temas(self):
        """[(nombre, [palabras])] de los temas filtrados (los mismos que en el móvil)."""
        with self.cerrojo:
            r = [((m.get("x") or {}).get("nombre", k[5:]), (m.get("x") or {}).get("palabras", []))
                 for k, m in self.c["ocultos"].items() if k.startswith("tema:") and m["activo"]]
        return sorted(r, key=lambda x: x[0].lower())

    def poner_tema(self, nombre, palabras):
        nombre = nombre.strip()
        pal = list(dict.fromkeys(p.strip() for p in palabras if p.strip()))
        if nombre and pal:
            self.poner("ocultos", "tema:" + nombre.lower(), None, {"nombre": nombre, "palabras": pal})

    def quitar_tema(self, nombre):
        self.quitar("tema:" + nombre.strip().lower(), "ocultos")

    def fulminados(self):
        """[(url, nombre)] de los canales fulminados."""
        with self.cerrojo:
            r = [(k[6:], (m.get("x") or {}).get("nombre") or k[6:]) for k, m in self.c["ocultos"].items()
                 if k.startswith("canal:") and m["activo"]]
        return sorted(r, key=lambda x: x[1].lower())

    def indultar(self, url):
        self.quitar("canal:" + url, "ocultos")

    def fulminar(self, url, nombre):
        """«Fulminar canal» (03/10/2026): la misma clave que los móviles («canal:<url>» en ocultos), así se propaga a
        todos los Cat-ode; además se anula la suscripción si la había."""
        with self.cerrojo:
            ahora = _ahora()
            self.c["ocultos"]["canal:" + url] = {"t": ahora, "activo": True, "e": Elemento("CANAL", url, nombre),
                                                  "x": {"nombre": nombre, "vetado": True}}
            n = (nombre or "").strip().lower()
            for k, m in list(self.c["suscripciones"].items()):
                e = m.get("e")
                if m["activo"] and (k.rstrip("/") == url.rstrip("/") or (e is not None and (e.titulo or "").strip().lower() == n)):
                    self.c["suscripciones"][k] = {**m, "t": ahora, "activo": False}
        self._cambio()

    def suscribir(self, canal):
        self.poner("suscripciones", canal.url, canal)

    def quitar(self, url, col="suscripciones"):
        with self.cerrojo:
            if url in self.c[col]:
                self.c[col][url] = {**self.c[col][url], "t": _ahora(), "activo": False}
        self._cambio()

    def visto(self, e):
        if str(e.url).startswith("cancion:"):   # 22/10/2026: una canción importada aún sin vídeo: se apunta cuando ya lo tiene
            return
        if not self.pausar_historial and e.titulo and e.url not in getattr(self, "sin_historial", set()):   # lo de Nut no cuenta   # sin título aún (abierto por enlace): lo apunta la ficha al llegar
            self.poner("historial", e.url, e)

    def guardar_posicion(self, url, segundos, duracion):
        """Cada pocos segundos mientras suena; sin sincronizar enseguida (lo hará el siguiente cambio o el reloj)."""
        with self.cerrojo:
            self.c["posiciones"][url] = {"t": _ahora(), "activo": True, "e": None, "x": {"s": int(segundos), "d": int(duracion)}}

    def borrar_historial(self):
        with self.cerrojo:
            self.borrado = _ahora(); self.c["historial"].clear()
        self._cambio()

    def nueva_lista(self, nombre):
        clave = f"propia:{_ahora()}"
        self.poner("listas", clave, None, {"nombre": nombre, "videos": []})
        return clave

    def lista_poner(self, clave, e, dentro=True):
        x = dict(self.extra("listas", clave) or {"nombre": "Lista", "videos": []})
        vids = [v for v in x.get("videos", []) if v.get("url") != e.url]
        if dentro:
            vids.append(e.dict())
        x["videos"] = vids
        self.poner("listas", clave, None, x)

    def borrar_lista(self, clave):
        self.quitar(clave, "listas")

    def buscado(self, q):
        self.poner("busquedas", q.strip().lower(), None, {"q": q.strip()})

    def importar(self, lotes):
        """Volcado de golpe (traer tu YouTube): {col: [(clave, elemento, extra)]}, cada lista de lo más reciente a lo más
        antiguo. Las horas se reparten hacia atrás desde ahora, así el historial queda en su orden; lo que ya está aquí
        con una hora más nueva no se pisa. Un solo guardado y una sola sincronización al final."""
        base = _ahora()
        with self.cerrojo:
            for col, filas in lotes.items():
                for i, (clave, e, x) in enumerate(filas):
                    t = base - 1 - i
                    viejo = self.c[col].get(clave)
                    if viejo and viejo["t"] >= t:
                        continue
                    if e is not None and col == "historial" and getattr(e, "fecha", 0):
                        e = Elemento(**{**e.dict(), "fecha": 0})
                    self.c[col][clave] = {"t": t, "activo": True, "e": e, "x": x}
        self._cambio()

    def importar_nuevo(self, lotes, reactivar=None):
        """«Actualizar cuenta desde YouTube» (18/10/2026, orden del autor: «por si se han suscrito nuevos canales»): como
        importar(), pero SOLO LO NUEVO. {col: [(clave, elemento, extra)]}, cada lista en el orden de YouTube (lo más
        reciente primero). Una clave que no existe se añade; una que existe no se toca, esté activa o no (las bajas hechas
        en Cat-ode no vuelven), salvo dos casos: las listas «cuenta:<id>» activas, que renuevan su contenido, y las claves de
        «reactivar» ({col: {clave: elemento}}), que vuelven activas con la hora de ahora (canales suscritos en YouTube desde
        la última lectura; lo decide cuenta.volcar_nuevo). Nunca borra ni desactiva nada.
        Las horas de lo nuevo se cuelgan de la de su vecino ya conocido más reciente en la lista de YouTube, así el
        historial nuevo queda en el orden de YouTube y no salta por encima de lo visto aquí después.
        Devuelve {col: añadidos, "reactivados": {col: n}, "renovadas": n}."""
        base = _ahora()
        r = {col: 0 for col in lotes}
        r["reactivados"], r["renovadas"] = {}, 0
        with self.cerrojo:
            for col, filas in lotes.items():
                destino = self.c[col]
                ancla, k = base, 0
                # 18/10/2026 · historial: lo nuevo nunca cae por debajo de la fecha de borrado (se perdería al fundir) y,
                # con el historial lleno (TOPES), lo que quedaría por debajo del más viejo no entra (lo quitaría el recorte
                # y cada «Actualizar» lo volvería a contar como nuevo)
                k2, t_min = 0, None
                if col == "historial":
                    vivas = [m["t"] for m in destino.values() if m["activo"] and m["t"] > self.borrado]
                    if len(vivas) >= TOPES.get("historial", 10 ** 9):
                        t_min = min(vivas)
                for clave, e, x in filas:
                    if e is not None and col == "historial" and getattr(e, "fecha", 0):
                        e = Elemento(**{**e.dict(), "fecha": 0})
                    viejo = destino.get(clave)
                    if viejo is not None:
                        if viejo["t"] < ancla:
                            ancla, k = viejo["t"], 0
                        if (col == "listas" and clave.startswith("cuenta:") and viejo["activo"] and x is not None
                                and viejo.get("x") != x):
                            destino[clave] = {"t": base, "activo": True, "e": e if e is not None else viejo.get("e"), "x": x}
                            r["renovadas"] += 1
                        continue
                    k += 1
                    t = ancla - k
                    if col == "historial":
                        if t <= self.borrado:
                            k2 += 1
                            t = max(self.borrado + 1, base - k2)
                        if t_min is not None and t <= t_min:
                            continue
                    destino[clave] = {"t": t, "activo": True, "e": e, "x": x}
                    r[col] += 1
            for col, claves in (reactivar or {}).items():
                for clave, e in claves.items():
                    viejo = self.c[col].get(clave)
                    if viejo is not None and viejo["activo"]:
                        continue
                    self.c[col][clave] = {"t": base, "activo": True, "e": e if e is not None else (viejo or {}).get("e"),
                                          "x": (viejo or {}).get("x")}
                    r["reactivados"][col] = r["reactivados"].get(col, 0) + 1
        self._cambio()
        return r

    def entrada(self, col, clave):
        """18/10/2026 · {t, activo} de una clave, ACTIVA O NO (None si no existe): para saber cuándo se dio de baja algo."""
        with self.cerrojo:
            m = self.c[col].get(clave)
            return {"t": m["t"], "activo": bool(m["activo"]), "e": m.get("e")} if m else None

    def inactivas(self, col):
        """18/10/2026 · {clave: hora} de las claves dadas de baja en una colección (las bajas hechas en Cat-ode)."""
        with self.cerrojo:
            return {k: m["t"] for k, m in self.c[col].items() if not m["activo"]}

    def cuantos(self, col):
        """18/10/2026 · cuántas claves activas tiene una colección (el historial, sin lo borrado)."""
        with self.cerrojo:
            return sum(1 for m in self.c[col].values() if m["activo"] and (col != "historial" or m["t"] > self.borrado))

    def todas(self, col):
        """18/10/2026 · [(clave, {t, activo, e, x})] de una colección, activas e inactivas (copia)."""
        with self.cerrojo:
            return [(k, dict(m)) for k, m in self.c[col].items()]

    def importar_takeout(self, texto):
        n = 0
        for linea in texto.splitlines()[1:]:
            c = linea.strip().split(",", 2)
            if len(c) >= 3 and c[0].startswith("UC"):
                url = f"https://www.youtube.com/channel/{c[0]}"
                if not self.suscrito(url):
                    self.poner("suscripciones", url, Elemento("CANAL", url, c[2].strip().strip('"'))); n += 1
        return n

    # ---- guardar y sincronizar ----
    def estado(self):
        with self.cerrojo:
            def m(d):
                return {k: {"t": v["t"], "activo": v["activo"], **({"e": v["e"].dict()} if v.get("e") is not None else {}),
                            **({"x": v["x"]} if v.get("x") is not None else {})} for k, v in d.items()}
            r = {col: m(self.c[col]) for col in COLECCIONES}
            r["historialBorrado"] = self.borrado
            return r

    def _entrada(self, v):
        return {"t": v["t"], "activo": v.get("activo", True), "e": elemento_de_dict(v["e"]) if v.get("e") else None, "x": v.get("x")}

    def _cargar(self, o):
        self.borrado = o.get("historialBorrado", 0)
        for col in COLECCIONES:
            for k, v in (o.get(col) or {}).items():
                try:
                    self.c[col][k] = self._entrada(v)
                except Exception:
                    pass

    def biblioteca(self):
        """22/10/2026 (encargo de música) · [(clave, x)] de las listas de la biblioteca compartida (las hace el ProBook:
        recomendador/biblioteca.py), en el orden de la sección «Música»: YouTube Music primero (orden del 22/10 «que tire
        de la biblioteca de youtube music»), luego las hechas con lo suyo, para descubrir y su disco."""
        orden = {o: n for n, o in enumerate(ORIGENES_MUSICA)}
        with self.cerrojo:
            r = [(k, m["x"]) for k, m in self.c["biblioteca"].items() if m.get("activo", True) and isinstance(m.get("x"), dict)]
        return sorted(r, key=lambda kx: (orden.get(kx[1].get("origen"), 5), -len(kx[1].get("canciones") or []) if
                                         kx[1].get("origen") in ("historial+relacionados", "D: del mini PC") else 0, kx[1].get("nombre", "")))

    def ajustes_comunes(self):
        """{clave: valor} de los ajustes compartidos entre equipos (los activos)."""
        with self.cerrojo:
            return {k: (m.get("x") or {}).get("v") for k, m in self.c["ajustes"].items()
                    if m.get("activo", True) and k in AJUSTES_COMUNES and "v" in (m.get("x") or {})}

    def sembrar_ajustes(self, ajustes):
        """Al abrir: los ajustes de esta app que AÚN no estén en la colección compartida, pero tras la primera sincronización
        (si no, al estrenarlo ganaría el último aparato en abrirse y no lo que ya tenían los otros)."""
        self._semilla = dict(ajustes)
        if not self.conf:
            self.poner_ajustes(self._semilla, solo_faltan=True)

    def poner_ajustes(self, ajustes, solo_faltan=False):
        """Los ajustes de esta app que han cambiado, a la colección compartida (solo los que cambian: sin ecos)."""
        cambia = False
        with self.cerrojo:
            for k in AJUSTES_COMUNES:
                if solo_faltan and k in self.c["ajustes"]:
                    continue
                if k in ajustes and ajustes[k] is not None:
                    v = bool(ajustes[k])
                    if (self.c["ajustes"].get(k, {}).get("x") or {}).get("v") != v:
                        self.c["ajustes"][k] = {"t": _ahora(), "activo": True, "e": None, "x": {"v": v}}
                        cambia = True
        if cambia:
            self._cambio()

    def fundir(self, o):
        antes = self.ajustes_comunes()
        with self.cerrojo:
            self.borrado = max(self.borrado, o.get("historialBorrado", 0))
            for col in COLECCIONES:
                destino = self.c[col]
                for k, v in (o.get(col) or {}).items():
                    if destino.get(k, {}).get("t", -1) < v.get("t", 0):
                        try:
                            destino[k] = self._entrada(v)
                        except Exception:
                            pass
            for k in [k for k, v in self.hist.items() if v["t"] <= self.borrado]:
                del self.hist[k]
            for col, tope in TOPES.items():
                if len(self.c[col]) > tope:
                    for k, _ in sorted(self.c[col].items(), key=lambda kv: kv[1]["t"])[:len(self.c[col]) - tope]:
                        del self.c[col][k]
        self._guardar(); self._avisar()
        despues = self.ajustes_comunes()
        if despues != antes:   # 22/10/2026: ajustes cambiados en otro equipo
            cambiados = {k: v for k, v in despues.items() if antes.get(k) != v}
            for fn in list(self.al_ajustes):
                try:
                    fn(cambiados)
                except Exception:   # noqa: BLE001
                    pass

    def _cambio(self):
        self._guardar(); self._avisar()
        if self._temporizador:
            self._temporizador.cancel()
        self._temporizador = threading.Timer(0.4, self.sincronizar)   # al momento (03/10/2026: antes 5 s)
        self._temporizador.daemon = True
        self._temporizador.start()

    def _guardar(self):
        """Pide guardar y vuelve al momento: escribe un hilo aparte, juntando los cambios seguidos (04/10/2026: guardar el
        historial entero en el hilo de la ventana la dejaba 6 s sin responder en el N100 al abrir cada vídeo)."""
        with self._pide_cerrojo:
            self._pide = True
            if self._escribiendo:
                return
            self._escribiendo = True
        threading.Thread(target=self._escritor, daemon=True, name="datos-guardar").start()

    def _escritor(self):
        while True:
            time.sleep(0.3)
            with self._pide_cerrojo:
                if not self._pide:
                    self._escribiendo = False
                    return
                self._pide = False
            try:
                self._guardar_ya()
            except Exception:   # noqa: BLE001 (disco lleno, permisos…): se reintenta con el siguiente cambio
                pass

    def esperar_guardado(self, tope=5.0):
        """Al cerrar la app: que lo último quede escrito."""
        t0 = time.time()
        while time.time() - t0 < tope:
            with self._pide_cerrojo:
                if not self._pide and not self._escribiendo:
                    return
            time.sleep(0.05)

    def _guardar_ya(self):
        # 03/10/2026 · en Windows, reemplazar un archivo abierto en ese instante (otro hilo leyéndolo) falla: se reintenta
        with self._guardando:
            tmp = self.archivo + ".tmp"
            # json.dumps (codificador en C) y una sola escritura: json.dump(f) usa el codificador en Python, 4 veces más
            # lento con los 2,4 MB de datos del autor, y retenía el GIL del servidor web mientras tanto (06/10/2026)
            texto = json.dumps(self.estado())
            with open(tmp, "w", encoding="utf-8") as f:
                f.write(texto)
            for i in range(20):
                try:
                    os.replace(tmp, self.archivo)
                    return
                except PermissionError:
                    time.sleep(0.05 * (i + 1))

    def _avisar(self):
        for o in list(self.oyentes):
            try:
                o()
            except Exception:
                pass

    def sincronizar(self):
        if not self.conf:
            return False
        cuerpo = json.dumps(self.estado()).encode()
        for s in self.conf["servidores"]:
            try:
                self.fundir(json.loads(pedir(self.conf, s, "POST", "/sincro", cuerpo)))
                self.estado_sincro = f"Sincronizado a las {time.strftime('%H:%M')} ({s})"
                semilla, self._semilla = getattr(self, "_semilla", None), None
                if semilla:   # 22/10/2026: tras la primera sincronización, lo que faltaba en la colección de ajustes
                    self.poner_ajustes(semilla, solo_faltan=True)
                self._avisar()
                return True
            except Exception:
                continue
        self.estado_sincro = "Sin conexión con tu servidor"
        self._avisar()
        return False

    def escuchar(self, al_cambiar):
        """03/10/2026 · se queda escuchando al servidor (GET /espera): en cuanto otro equipo cambia algo, lo trae y avisa
        (al_cambiar, desde este hilo). Un hilo para toda la vida de la app; si no hay red, reintenta cada pocos segundos."""
        if not self.conf:
            return
        def bucle():
            v = 0
            while True:
                hecho = False
                for s in self.conf["servidores"]:
                    try:
                        r = json.loads(pedir(self.conf, s, "GET", f"/espera?v={v}", espera=35) or b"{}")
                        nuevo = r.get("v", v)
                        if nuevo != v:
                            if v:   # la primera respuesta solo da el número
                                self.sincronizar(); al_cambiar()
                            v = nuevo
                        hecho = True
                        break
                    except Exception:
                        continue
                if not hecho:
                    time.sleep(5)
        threading.Thread(target=bucle, daemon=True).start()

    def del_servidor(self, ruta):
        """Un archivo del servidor (p. ej. /app/parati.json) o None si no hay red."""
        if not self.conf:
            return None
        for s in self.conf["servidores"]:
            try:
                r = pedir(self.conf, s, "GET", ruta)
                return json.loads(r) if r else None
            except Exception:
                continue
        return None


def pedir(conf, servidor, metodo, ruta, cuerpo=None, espera=6):
    """Una petición al servidor del autor: TLS con su certificado fijado (huella SHA-256) y la clave."""
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    c = http.client.HTTPSConnection(servidor, conf.get("puerto", 8790), timeout=espera, context=ctx)
    try:
        c.connect()
        if hashlib.sha256(c.sock.getpeercert(binary_form=True)).hexdigest() != conf["huella"]:
            raise ssl.SSLError("No es el servidor del autor")
        c.request(metodo, ruta, body=cuerpo, headers={"Authorization": f"Bearer {conf['clave']}", "Content-Type": "application/json"})
        r = c.getresponse()
        datos = r.read()
        if r.status == 404:
            return None
        if r.status != 200:
            raise IOError(f"HTTP {r.status}")
        return datos
    finally:
        c.close()


def _ahora():
    return int(time.time() * 1000)
