"""Cat-ode · Inicio, Suscripciones y Explorar calculados en la propia app, sin servidor (28/10/2026).

Orden del autor: «la opción de explorar de cat-ode me pone vídeos populares de mierda y nada relacionado con las temáticas
de mis canales pero distintos, para ampliar mi catálogo de intereses y canales, además los videos de inicio siguen siendo
siempre los mismos y no hay manera de refrescarlos y que varíen … tampoco funciona bien la sección de suscripciones, en el
mismo sentido. No se trata de tener un puto servicio activo permanentemente en mi portátil, se trata de que la app funcione
bien para cualquiera, en local y sin servicios específicos corriendo en segundo plano».

Antes, el Inicio era la lista de 400 que calculaba el ProBook cada 2 horas (catode-parati, 11 min y 1,9 GB) y la app solo la
barajaba; Suscripciones, la lista del servidor de hasta 6 horas (el ⟳ devolvía la misma; 76 de 149 canales); Explorar, lo más
visto de los «canales de tema» de YouTube. Ahora todo sale de aquí, en cada aparato y solo mientras se usa la app, con lo que
la app va guardando (Almacen, sin sincronizar) y un tope de peticiones a YouTube en cada visita:
  · Suscripciones: el RSS de cada canal, guardado 30 min; ⟳ lo vuelve a pedir de verdad; nunca 3 seguidos del mismo canal.
  · Inicio: cada visita nueva usa otras semillas (lo que has visto, tus «me gusta», lo último de tus canales) cuyos
    relacionados entran arriba; con lo nuevo de tus canales y lo descubierto en Explorar; sorteo con peso (lo ya enseñado
    pesa menos), en la primera pantalla un vídeo por canal y nada de lo que estaba arriba la vez anterior.
  · Explorar: canales que NO sigues, cerca de los tuyos: los que recomiendan tus creadores (estante de canales de su
    portada) y los que YouTube pone junto a varios de tus canales; sin canales de más de 100 000 suscriptores (salvo música
    en directo y viajes), sin cebo, sin lo de mascotas (es de Nut) ni lo vetado. Cada vídeo dice por qué sale.
  · «Mi estilo» (su orden del 03/10/2026: canales de menos de 100 000 suscriptores): los canales verificados (YouTube da la
    insignia a partir de 100 000) que no sigues no salen en el Inicio ni en Explorar; se puede apagar (estilo=False).
Cuando ya hay bastante guardado, la página sale con lo guardado al momento y lo de la visita siguiente se pide justo
después, dentro de la app (nada corre si la app está cerrada). Sin Qt: lo usan la interfaz Qt (Linux) y el servicio de la
interfaz web (Windows). El móvil hace lo mismo en Descubrir.kt."""
import collections
import concurrent.futures as cf
import functools
import json
import math
import os
import random
import re
import threading
import time

from . import motor

DIA = 86400.0
TOPE_SUSCRIPTORES = 100_000
# lo que el autor dejó pasar aunque sea grande (03/10/2026, recomendador/estilo.py): directos de música y viajes; lo de
# mascotas no sale en Explorar ni en el Inicio (tiene su sitio: «Para Nut»)
EXCEPCIONES = {
    "Nut": re.compile(r"\bdogs?\b|perr[oa]s?\b|\bpets?\b|mascotas?|\bcats?\b|gat[oa]s?\b|cat tv|cat games|for cats|para gatos|"
                      r"kitten|birds for cats|squirrels? for", re.I),
    "música en directo": re.compile(r"lo-?fi|chill|beats|radio|24/7|ambient|downtempo|dj set|live set|boiler room|deep house|"
                                    r"jazz hop|synthwave|study music|relax(ing)? music|música (para|relajante)", re.I),
    "viajes": re.compile(r"viaj|travel|mochiler|backpack|vuelta al mundo|nómada|nomad|road ?trip|expedici", re.I),
}
CEBO = re.compile(r"\b(mi|su) (hija|hijo|esposo|esposa|marido|mujer|suegra|suegro|yerno|nuera|nieto|nieta|vecina)\b.*\b(me|le)\b|"
                  r"murió|muere|no entres|no creerás|nadie (lo )?esperaba|impactante|increíble lo que|te sorprenderá|"
                  r"en shock|humill|desaparec|acus[óo]|traici", re.I)
FICHAS_EXPLORAR = ("Todo", "Recomendados por tus canales", "Cerca de tus canales", "Canales")
COMO = "Como "   # ficha «Como <canal>»: lo cercano a uno de tus canales


def carpeta_cache():
    """Dónde guarda la app lo que va sabiendo de YouTube en este aparato (la caché de siempre de la app, metadatos.py):
    Linux ~/.cache/catode (fuera de Syncthing), Windows %LOCALAPPDATA%\\catode; CATODE_CACHE la sustituye (pruebas)."""
    from . import metadatos
    return metadatos._carpeta_cache()


_VISTAS = re.compile(r"(\d[\d.,]*)\s*(mil\s*m(?:ill(?:ones)?)?|mill(?:ones)?|mil|m|k)?\.?\s*(?:de\s+)?visualizaci", re.I)


def vistas(e):
    """Las visualizaciones del detalle («1,2 M visualizaciones», «345 K…», «12 mil…», «395.768…») o -1."""
    d = ((e.get("detalle") if isinstance(e, dict) else getattr(e, "detalle", "")) or "").replace(" ", " ")
    m = _VISTAS.search(d)
    if not m:
        return -1
    num, suf = m.group(1), re.sub(r"\s+", " ", (m.group(2) or "").lower())
    try:
        if not suf:
            return int(re.sub(r"\D", "", num) or -1)
        x = float(num.replace(".", "").replace(",", ".")) if "," in num else float(num) if num.count(".") <= 1 else float(num.replace(".", ""))
        return int(x * (1e9 if suf.startswith("mil m") else 1e6 if suf.startswith("m") else 1e3))
    except ValueError:
        return -1


def factor_popular(v):
    """Lo muy visto de canales que no sigues pesa menos en el Inicio (su estilo: canales pequeños, 03/10/2026)."""
    if v < 0 or v <= 300_000:
        return 1.0
    return 0.6 if v <= 1_000_000 else 0.3 if v <= 5_000_000 else 0.12


def corto(e):
    d = (e.get("detalle") if isinstance(e, dict) else getattr(e, "detalle", "")) or ""
    u = (e.get("url") if isinstance(e, dict) else getattr(e, "url", "")) or ""
    return "/shorts/" in u or d.startswith("Short")


def excepcion(nombre, titulos):
    """¿Mascotas, música en directo o viajes? (por el nombre del canal o por 3 títulos)."""
    textos = [nombre or ""] + list(titulos or [])
    for clave, r in EXCEPCIONES.items():   # lo de mascotas, antes que la música
        if (clave != "viajes" and r.search(nombre or "")) or sum(1 for t in textos if r.search(t or "")) >= 3:
            return clave
    return None


def cebo(titulos):
    """Parte de títulos con pinta de cebo: muchas MAYÚSCULAS, dramas inventados, «MURIÓ», «NO ENTRES»…"""
    titulos = [t for t in (titulos or []) if t]
    if not titulos:
        return 0.0

    def malo(t):
        palabras = re.findall(r"[A-Za-zÁÉÍÓÚÑáéíóúñ]{3,}", t)
        mayus = sum(1 for w in palabras if w.isupper())
        return (palabras and mayus / len(palabras) > 0.35) or bool(CEBO.search(t))
    return sum(1 for t in titulos if malo(t)) / len(titulos)


def _sorteo(items, peso, rnd):
    """Sorteo con pesos sin reposición (Efraimidis-Spirakis): los de más peso salen antes, pero no siempre los mismos."""
    claves = []
    for i, x in enumerate(items):
        p = max(peso(x), 1e-9)
        claves.append((rnd.random() ** (1.0 / p), i))
    return [items[i] for _, i in sorted(claves, reverse=True)]


def _sin_tildes(t):
    """Igual que en Datos.vetado: minúsculas y sin tildes (los temas filtrados se buscan así)."""
    import unicodedata
    return "".join(c for c in unicodedata.normalize("NFD", (t or "").lower()) if unicodedata.category(c) != "Mn")


@functools.lru_cache(maxsize=50_000)
def _id_url(url):
    return motor.id_video(url)


def _id(e):
    return _id_url((e.get("url") if isinstance(e, dict) else getattr(e, "url", "")) or "")


def _hora(k):
    """La hora de una clave del almacén («1794222783.5»); 0 si no lo es."""
    try:
        return float(k)
    except (TypeError, ValueError):
        return 0.0


def sin_tres_seguidos(lista, seguidos=2):
    """El mismo orden, pero sin más de 2 seguidos del mismo canal (mirando hasta 20 por delante)."""
    cola, final = list(lista), []
    while cola:
        elegido = 0
        for k, v in enumerate(cola[:20]):
            if not (len(final) >= seguidos and all(x.autorUrl == v.autorUrl for x in final[-seguidos:])):
                elegido = k
                break
        final.append(cola.pop(elegido))
    return final


# ================================================================ peticiones a YouTube (una por llamada; se cambian en las pruebas)
def pedir_rss(url, titulo=""):
    return motor.rss_canal(url, titulo, 15)


def pedir_canal(url, n=12):
    return motor.canal_completo(url, n)


def pedir_relacionados(url):
    return motor.ficha(url)["relacionados"]


def pedir_destacados(url):
    return motor.destacados(url)


class Almacen:
    """Lo que la app va sabiendo de YouTube en este aparato (JSON en carpeta_cache): el RSS de tus canales, los relacionados
    de las semillas, los canales (tamaño, últimos vídeos, a quién recomiendan), los verificados y la memoria de Explorar.
    Si no se puede leer, se empieza vacío; se escribe entero y de una vez (archivo nuevo + renombrar)."""
    VERSION = 1
    # 09/11/2026 · «portadas» (los canales de arriba de las últimas portadas del Inicio, para que no salga siempre la misma
    # gente) y «subs_vistos» (lo que la página de Suscripciones ya ha enseñado arriba: {id: [veces, hora]})
    SECCIONES = ("rss", "rel", "canales", "explorados", "vistos_explorar", "verificados", "portadas", "subs_vistos")

    def __init__(self, ruta=None):
        self.ruta = ruta or os.path.join(carpeta_cache(), "descubrir.json")
        self.cerrojo = threading.RLock()
        self._escribiendo = threading.Lock()
        try:
            with open(self.ruta, encoding="utf-8") as f:
                m = json.load(f)
        except Exception:   # noqa: BLE001 (sin archivo o roto: vacío)
            m = {}
        if not isinstance(m, dict) or m.get("v") != self.VERSION:
            m = {}
        self.m = {"v": self.VERSION, **{s: (m.get(s) if isinstance(m.get(s), dict) else {}) for s in self.SECCIONES}}
        self.cambiado = False

    def poner(self, seccion, clave, valor):
        with self.cerrojo:
            self.m[seccion][clave] = valor
            self.cambiado = True

    def leer(self, seccion, clave, defecto=None):
        with self.cerrojo:
            return self.m[seccion].get(clave, defecto)

    def copia(self, seccion):
        with self.cerrojo:
            return dict(self.m[seccion])

    def _podar(self):
        ahora = time.time()
        m = self.m
        m["rss"] = {k: v for k, v in m["rss"].items() if ahora - v.get("t", 0) < 14 * DIA}
        rel = {k: v for k, v in m["rel"].items() if ahora - max(v.get("t", 0), v.get("u", 0)) < 4 * DIA}
        if len(rel) > 300:
            rel = dict(sorted(rel.items(), key=lambda kv: -max(kv[1].get("t", 0), kv[1].get("u", 0)))[:300])
        m["rel"] = rel
        can = {k: v for k, v in m["canales"].items() if ahora - max(v.get("t", 0), v.get("td", 0)) < 30 * DIA}
        if len(can) > 2500:
            can = dict(sorted(can.items(), key=lambda kv: -max(kv[1].get("t", 0), kv[1].get("td", 0)))[:2500])
        m["canales"] = can
        m["explorados"] = {k: v for k, v in m["explorados"].items() if ahora - v < 7 * DIA}
        m["vistos_explorar"] = {k: v for k, v in m["vistos_explorar"].items() if isinstance(v, list) and ahora - v[1] < 14 * DIA}
        m["verificados"] = {k: v for k, v in m["verificados"].items() if ahora - v < 30 * DIA}
        por = {k: v for k, v in m["portadas"].items() if isinstance(v, list) and ahora - _hora(k) < 3 * DIA}
        m["portadas"] = dict(sorted(por.items(), key=lambda kv: -_hora(kv[0]))[:12])
        m["subs_vistos"] = {k: v for k, v in m["subs_vistos"].items() if isinstance(v, list) and len(v) == 2 and ahora - v[1] < 7 * DIA}

    def guardar(self):
        """Una copia hecha en un momento (las entradas no cambian: se sustituyen) y el texto fuera del cerrojo, para que las
        páginas no esperen mientras se escribe; un cerrojo aparte para el archivo (dos guardados a la vez)."""
        with self.cerrojo:
            if not self.cambiado:
                return
            self._podar()
            copia = {k: (dict(v) if isinstance(v, dict) else v) for k, v in self.m.items()}
            self.cambiado = False
        texto = json.dumps(copia, ensure_ascii=False, separators=(",", ":"))
        with self._escribiendo:
            try:
                tmp = self.ruta + ".nuevo"
                with open(tmp, "w", encoding="utf-8") as f:
                    f.write(texto)
                os.replace(tmp, self.ruta)
            except Exception:   # noqa: BLE001 (sin disco: sigue en memoria hasta cerrar)
                pass


class Descubrir:
    """Las tres páginas y la campana, calculadas aquí. Cada método hace como mucho unas pocas peticiones a YouTube (los
    topes de abajo), en paralelo y solo cuando se abre la página; lo demás sale de lo guardado."""
    HILOS, HILOS_RSS = 5, 4    # 09/11/2026: 4 a la vez (antes 6): con cientos de canales, ráfagas más suaves
    RSS_FRESCO = 1800          # s: un canal mirado hace menos no se vuelve a pedir (⟳: 60 s)
    RSS_VISITA = 60            # canales que mira una visita a Suscripciones (los que más publican)…
    RSS_VIEJO = 3 * 3600       # …más los mirados hace más de 3 h (con más de 150 canales, proporcionalmente más)…
    RSS_TOPE = 90              # …y NUNCA más de 90 en una llamada (visita, ⟳ o primera vez), tengas 150 canales o 700
    RSS_INICIO = 12            # canales que se miran para el Inicio siguiente (los que más publican)
    RSS_CAMPANA = 10           # y la campana cada 15 min
    RESPALDO = 10              # páginas de canal por llamada si el RSS falla (antes 30: son peticiones más pesadas)
    # 09/11/2026 · variedad (orden del autor: «es una mierda ver siempre los mismos videos y de la misma gente»): los canales
    # que salieron arriba en las últimas portadas pesan menos en la siguiente y no repiten en las 12 primeras
    PORTADA_CANALES = 24       # de cada portada se recuerdan los canales de los 24 primeros
    CANSANCIO_CANAL = 1.2      # cada aparición reciente arriba divide el peso de ese canal por (1 + 1,2 × aparición)
    SUBS_PRIMEROS = 24         # lo que se ve arriba en Suscripciones…
    SUBS_VECES = 3             # …y lo que ha salido arriba 3 veces sin abrirlo baja (sin desaparecer)
    SEMILLAS = 4               # semillas nuevas en cada visita nueva al Inicio
    REL_FRESCO = 3 * DIA       # los relacionados de un vídeo apenas cambian
    INFO_FRESCA = 7 * DIA      # tamaño y vídeos de un canal; los destacados, igual
    INICIO_N = 240

    def __init__(self, datos, almacen=None, estilo=True, fondo=True):
        self.datos = datos
        self.a = almacen if almacen is not None else Almacen()
        self.estilo = estilo     # «Mi estilo»: sin canales grandes que no sigues
        self.fondo = fondo       # False (pruebas): lo de la visita siguiente se pide en el momento
        self._paso = threading.Lock()        # un cálculo de página a la vez (la web atiende en varios hilos)
        self._previo = threading.Lock()      # y una preparación de la visita siguiente a la vez
        self._rss = threading.Lock()
        self._cerrojo = threading.Lock()
        self._fallos, self._pausa = 0, 0.0
        self.peticiones = collections.Counter()   # para las pruebas y el registro
        self._portada = set()   # lo que salió arriba en la portada anterior: al actualizar no vuelve arriba

    # ---------------------------------------------------------------- red, con freno
    def _red(self):
        return time.time() >= self._pausa

    def _bien(self, que):
        with self._cerrojo:
            self._fallos = 0
            self.peticiones[que] += 1

    def _mal(self, que, error=None):
        """YouTube cortando (429, «confirma que no eres un bot»): 30 min sin pedir nada desde aquí; sin red, a los 4 fallos
        seguidos, 5 min. Mientras, lo guardado. Lo demás (un canal sin RSS, un vídeo que ya no está) no frena nada."""
        from . import roto
        clase = roto.clasificar(error) if error is not None else "red"
        with self._cerrojo:
            self.peticiones[que + "_fallo"] += 1
            if clase == "bloqueo":
                self._pausa = time.time() + 1800
            elif clase == "red":
                self._fallos += 1
                if self._fallos >= 4:
                    self._pausa, self._fallos = time.time() + 300, 0

    def _en_paralelo(self, f, cosas, hilos=None):
        cosas = list(cosas)
        if not cosas:
            return []
        with cf.ThreadPoolExecutor(min(hilos or self.HILOS, len(cosas))) as ex:
            return list(ex.map(f, cosas))

    def _apuntar(self, que, t0, antes):
        """Al registro de la app (catode.log): cuánto ha tardado y qué ha pedido a YouTube."""
        try:
            from .resolutor import registro
            hecho = {k: v - antes.get(k, 0) for k, v in self.peticiones.items() if v - antes.get(k, 0)}
            registro(f"descubrir: {que} en {time.time() - t0:.1f} s · peticiones {hecho or 'ninguna'}")
        except Exception:   # noqa: BLE001
            pass

    def _de_fondo(self, f):
        """Lo de la visita siguiente, justo después y dentro de la app (un hilo que acaba en segundos; si ya hay uno, nada)."""
        if not self.fondo:
            return f()
        if not self._previo.acquire(blocking=False):
            return None

        def correr():
            try:
                f()
            except Exception:   # noqa: BLE001 (lo de la visita siguiente nunca tumba nada)
                pass
            finally:
                self._previo.release()
        threading.Thread(target=correr, daemon=True, name="descubrir").start()
        return None

    def _apuntar_verificados(self):
        """Lo que el motor ha visto con la insignia de verificado pasa al almacén (vale 30 días)."""
        nuevos = set(motor.VERIFICADOS)
        if not nuevos:
            return
        ahora = time.time()
        with self.a.cerrojo:
            ver = self.a.m["verificados"]
            for u in nuevos:
                if ahora - ver.get(u, 0) > DIA:
                    ver[u] = ahora
                    self.a.cambiado = True

    def _grande(self, url, nombre="", titulos=()):
        """¿Canal grande que no es excepción? (verificado o con más de 100 000 suscriptores conocidos)."""
        if not self.estilo:
            return False
        if excepcion(nombre, titulos) in ("música en directo", "viajes"):
            return False
        if url in motor.VERIFICADOS or self.a.leer("verificados", url):
            return True
        return (self.a.leer("canales", url) or {}).get("subs", -1) > TOPE_SUSCRIPTORES

    # ---------------------------------------------------------------- vetos (una vez por canal y por página)
    def _al_dia(self):
        """Los vetos de Datos al día para esta página (28/10/2026: mirar Datos.vetado vídeo a vídeo eran 1100 llamadas y
        90 000 búsquedas por portada, segundos en el ProBook): los canales se miran una sola vez (memoria que se vacía si
        los vetos cambian) y los temas filtrados, con sus mismas expresiones, directamente sobre el título."""
        self.datos.vetado(motor.Elemento("CANAL", "", ""))   # Datos recalcula sus vetos si han cambiado
        firma = getattr(self.datos, "_vetos_firma", None)
        if getattr(self, "_vetos_de", object()) != firma:
            self._vetos_memo, self._vetos_de = {}, firma
        vetos = getattr(self.datos, "_vetos", None)
        self._temas_re = list(vetos[2]) if vetos else []

    def _vetado_canal(self, url, nombre=""):
        if not hasattr(self, "_vetos_memo"):
            self._al_dia()
        clave = (url, nombre)
        r = self._vetos_memo.get(clave)
        if r is None:
            r = self._vetos_memo[clave] = self.datos.vetado(motor.Elemento("CANAL", url, nombre))
        return r

    def _vetado(self, e):
        """Lo mismo que Datos.vetado(e) para un vídeo: su canal (una vez) y las palabras de los temas en título, canal y detalle."""
        if self._vetado_canal(e.autorUrl or "", e.autor or ""):
            return True
        if not self._temas_re:
            return False
        texto = _sin_tildes(f"{e.titulo} {e.autor} {e.detalle}")
        return any(r.search(texto) for r in self._temas_re)

    # ---------------------------------------------------------------- lo tuyo
    def _subs(self):
        return [c for c in self.datos.suscripciones() if c.url]

    def _afinidad(self):
        """{canal: peso}: cada vídeo visto suma (más cuanto más reciente), cada «me gusta» 1 y seguirlo 2."""
        af = collections.Counter()
        nombres = {}
        for i, e in enumerate(self.datos.historial(2000)):
            if e.autorUrl:
                af[e.autorUrl] += math.exp(-i / 400)
                nombres.setdefault(e.autorUrl, e.autor)
        for e in self.datos.coleccion("megusta", 300):
            if getattr(e, "autorUrl", ""):
                af[e.autorUrl] += 1
                nombres.setdefault(e.autorUrl, e.autor)
        for c in self._subs():
            af[c.url] += 2
            nombres[c.url] = c.titulo or nombres.get(c.url, "")
        return af, nombres

    def temas(self, n=12):
        """Las fichas del Inicio: tus canales de siempre (lo que más ves), sin lo vetado."""
        _, nombres = self._afinidad()
        vistos = collections.Counter()
        for i, e in enumerate(self.datos.historial(1500)):
            if e.autorUrl:
                vistos[e.autorUrl] += math.exp(-i / 500)
        r = []
        for u, _ in vistos.most_common(60):
            n_ = nombres.get(u, "")
            if n_ and n_ not in r and not self._vetado_canal(u, n_):
                r.append(n_)
            if len(r) >= n:
                break
        return r

    def _positivos(self):
        """Tus canales buenos (los que sigues y los de tus «me gusta»), del más al menos tuyo: [(url, nombre, peso)]."""
        af, nombres = self._afinidad()
        subs = {c.url for c in self._subs()}
        megusta = {getattr(e, "autorUrl", "") for e in self.datos.coleccion("megusta", 300)}
        r = []
        for u in subs | {m for m in megusta if m}:
            n = nombres.get(u, "")
            if not self._vetado_canal(u, n):
                r.append((u, n, af.get(u, 0)))
        return sorted(r, key=lambda x: -x[2])

    def _negativos(self):
        r = {u.lower().rstrip("/") for u, _ in self.datos.fulminados()}
        for e in self.datos.coleccion("nomegusta", 300):
            if getattr(e, "autorUrl", ""):
                r.add(e.autorUrl.lower().rstrip("/"))
        return r

    # ================================================================ Suscripciones
    def _rss_de(self, c, respaldo):
        """Pide lo último de un canal y lo guarda. Si el RSS falla (YouTube da 404 a ratos, a veces de todos durante
        horas), la página del canal, como mucho «respaldo[0]» por llamada (15/10/2026: era lo que marcaba la IP).
        09/11/2026: si no sale por ninguna de las dos (canal cerrado o que ya no existe), se apunta el fallo y el canal espera
        1 h, 2 h, 4 h… hasta 7 días (_espera) antes de volver a pedirse: sin apuntarlo, con cientos de canales uno muerto
        se pedía el PRIMERO en cada visita. Un bloqueo de YouTube o la falta de red no cuentan (no son cosa del canal)."""
        lista, bien, error_rss = None, False, None
        try:
            lista, bien = pedir_rss(c.url, c.titulo), True   # un canal sin vídeos da una lista vacía: vale
            self._bien("rss")
        except Exception as error:   # noqa: BLE001
            error_rss = error
            self._mal("rss", error)
        if not bien:
            with self._cerrojo:
                queda = respaldo[0] > 0
                if queda:
                    respaldo[0] -= 1
            if not queda:
                self._fallo_canal(c, error_rss, probado=False)
                return False
            try:
                _, videos, _ = pedir_canal(c.url, 15)
                self._bien("canal")
                lista = videos[:15]
            except Exception as error:   # noqa: BLE001
                self._mal("canal", error)
                self._fallo_canal(c, error, probado=True)
                return False
        for e in lista:
            e.autor, e.autorUrl = e.autor or c.titulo, e.autorUrl or c.url
        self.a.poner("rss", c.url, {"t": time.time(), "l": [e.dict() for e in lista]})
        return True

    def _fallo_canal(self, c, error, probado):
        """09/11/2026 · El canal no ha dado nada: se apunta la hora y el fallo (lo que ya tenía guardado sigue saliendo) para
        no pedirlo otra vez hasta que pase su espera. «probado»: también falló su página; si no se llegó a probar (sin
        respaldo en esta llamada), cuenta como un fallo como mucho (1 h)."""
        from . import roto
        if error is None or roto.clasificar(error) in ("bloqueo", "red"):
            return
        viejo = self.a.leer("rss", c.url) or {}
        n = int(viejo.get("fallos", 0) or 0)
        n = n + 1 if probado else max(n, 1)
        self.a.poner("rss", c.url, {"t": time.time(), "l": viejo.get("l", []), "fallos": n})

    @staticmethod
    def _espera(entrada):
        """09/11/2026 · Lo que espera un canal que ha fallado n veces seguidas: 1 h, 2 h, 4 h… y como mucho 7 días."""
        n = int((entrada or {}).get("fallos", 0) or 0)
        return 0 if n <= 0 else min(3600 * 2 ** (n - 1), 7 * DIA)

    @staticmethod
    def _prioridad(entrada, ahora):
        """Cuántos vídeos se espera que haya subido desde la última vez: primero los canales que más publican; la edad
        suma algo para que ninguno se quede sin mirar."""
        if not entrada:
            return 1e9
        edad_h = (ahora - entrada.get("t", 0)) / 3600
        fechas = sorted(x.get("fecha") or 0 for x in entrada.get("l", []) if x.get("fecha"))
        ritmo = (len(fechas) - 1) / max(1.0, (fechas[-1] - fechas[0]) / 864e5) if len(fechas) >= 2 else 0.05
        return ritmo * edad_h / 24 + edad_h / 240

    def refrescar_rss(self, fresco=None, tope=None, viejo=None):
        """Vuelve a pedir lo de los canales mirados hace más de «fresco» segundos: como mucho «tope» (los que más pueden
        traer algo) más los mirados hace más de «viejo» (con más de 150 canales, proporcionalmente más tiempo), y NUNCA más
        de RSS_TOPE en una llamada (09/11/2026: con 700 canales, una visita habría pedido 700 RSS de golpe y YouTube
        marca la IP de casa). Los nunca mirados van primero, y entre ellos los de los canales que más ves; un canal que
        falla espera su turno (_espera). Devuelve cuántos."""
        if not self._red():
            return 0
        fresco = self.RSS_FRESCO if fresco is None else fresco
        ahora = time.time()
        rss = self.a.copia("rss")
        subs = self._subs()

        def toca(c):
            ent = rss.get(c.url)
            return not ent or ahora - ent.get("t", 0) > max(fresco, self._espera(ent))
        viejos = [c for c in subs if toca(c)]
        af = self._afinidad()[0] if any(not rss.get(c.url) for c in viejos) else {}
        viejos.sort(key=lambda c: (-self._prioridad(rss.get(c.url), ahora), -af.get(c.url, 0)))
        if tope is not None:
            if viejo is not None:
                viejo = max(viejo, viejo * len(subs) / 150)
            viejos = viejos[:tope] + [c for c in viejos[tope:] if viejo is not None
                                      and (not rss.get(c.url) or ahora - rss[c.url].get("t", 0) > viejo)]
        viejos = viejos[:self.RSS_TOPE]
        respaldo = [self.RESPALDO]
        with self._rss:
            self._en_paralelo(lambda c: self._rss_de(c, respaldo), viejos, self.HILOS_RSS)
        return len(viejos)

    def novedades(self, cortos=False):
        """Lo guardado de tus canales, lo más nuevo primero (sin repetidos). 09/11/2026 (orden del autor: «quita los shorts
        de la sección de suscripciones»): sin Shorts (el RSS los marca: detalle «Short»), salvo cortos=True."""
        subs = {c.url: c for c in self._subs()}
        rss = self.a.copia("rss")
        r, ya = [], set()
        for u, c in subs.items():
            for d in (rss.get(u) or {}).get("l", []):
                e = motor.elemento_de_dict(d)
                vid = _id(e)
                if vid and vid not in ya and (cortos or not corto(e)):
                    ya.add(vid)
                    e.autor, e.autorUrl = e.autor or c.titulo, e.autorUrl or u
                    r.append(e)
        return sorted(r, key=lambda e: -(e.fecha or 0))

    def suscripciones(self, forzar=False, rnd=None):
        """La página «Suscripciones»: lo último de tus canales, SIN SHORTS (09/11/2026). Lo mirado hace menos de 30 min no
        se pide otra vez; de lo demás, los 60 que más publican y los mirados hace mucho; con ⟳ (forzar), lo de hace más de
        1 min; y nunca más de 90 canales por visita (RSS_TOPE). El orden, en _variar_suscripciones."""
        t0, antes = time.time(), dict(self.peticiones)
        hay = any(self.a.leer("rss", c.url) for c in self._subs())
        if forzar:
            self.refrescar_rss(60, self.RSS_TOPE)
        elif not hay:
            self.refrescar_rss(0, self.RSS_TOPE)
        else:
            self.refrescar_rss(self.RSS_FRESCO, self.RSS_VISITA, self.RSS_VIEJO)
        lista = self._variar_suscripciones(self.novedades()[:600], rnd or random.Random())
        self.a.guardar()
        self._apuntar("suscripciones" + (" (⟳)" if forzar else ""), t0, antes)
        return lista

    TRAMOS = (DIA, 3 * DIA, 7 * DIA)   # últimas 24 h, 3 días, una semana y lo de antes

    def _variar_suscripciones(self, lista, rnd):
        """09/11/2026 (orden del autor: «en suscripciones tiene un pase pero siguen siendo siempre los mismos»): por tramos
        de fecha (lo de las últimas 24 h siempre arriba) y, dentro de cada tramo, primero lo que no has visto ni ha salido
        arriba ya 3 veces sin abrirlo, y el primer vídeo de cada canal antes que el segundo y el tercero (así no copan la
        página los que más suben); en los tramos de más de un día, además, con algo de azar en cada visita. Nunca dos
        seguidos del mismo canal. Lo de arriba se apunta (subs_vistos): lo que sale arriba visita tras visita sin abrirse,
        baja (sin desaparecer)."""
        ahora = time.time()
        vistos = {_id(e) for e in self.datos.historial(3000)}
        sv = self.a.copia("subs_vistos")
        tramos = [[] for _ in range(len(self.TRAMOS) + 1)]
        for e in lista:   # ya viene de lo más nuevo a lo más viejo
            edad = ahora - (e.fecha or 0) / 1000
            tramos[next((i for i, t in enumerate(self.TRAMOS) if edad < t), len(self.TRAMOS))].append(e)
        final = []
        for k, tramo in enumerate(tramos):
            por_canal, grupos = collections.Counter(), collections.defaultdict(list)
            for i, e in enumerate(tramo):
                canal = e.autorUrl or e.autor
                por_canal[canal] += 1
                vid = _id(e)
                cansado = (sv.get(vid) or [0])[0] >= self.SUBS_VECES
                grupos[(vid in vistos, cansado, min(por_canal[canal], 3))].append((i, e))
            for clave in sorted(grupos):
                g = grupos[clave]
                if k > 0:   # más de un día: lo más nuevo suele ir antes, pero no siempre en el mismo orden
                    g = sorted(g, key=lambda ie: ie[0] * (0.5 + rnd.random()))
                final.extend(e for _, e in g)
        final = sin_tres_seguidos(final, seguidos=1)
        with self.a.cerrojo:
            m = self.a.m["subs_vistos"]
            for e in final[:self.SUBS_PRIMEROS]:
                vid = _id(e)
                if vid:
                    m[vid] = [int((m.get(vid) or [0, 0])[0]) + 1, ahora]
            self.a.cambiado = True
        return final

    def campana(self):
        """Cada 15 min con la app abierta: mira los 10 canales que más pueden traer algo y devuelve lo de 7 días (sin
        Shorts, como Suscripciones: 09/11/2026)."""
        self.refrescar_rss(self.RSS_FRESCO, self.RSS_CAMPANA)
        self.a.guardar()
        ahora = time.time() * 1000
        return [e for e in self.novedades() if e.fecha and ahora - e.fecha < 7 * 864e5]

    # ================================================================ Inicio
    def _candidatas_semilla(self):
        """(Elemento, peso, cómo): lo que has visto (más lo reciente), tus «me gusta» y lo último de tus canales."""
        r = {}
        hist = [e for e in self.datos.historial(250) if e.tipo == "VIDEO" and not corto(e)]
        for i, e in enumerate(hist):
            r.setdefault(_id(e), (e, 1.0 / (1 + i / 25), "viste"))
        for e in self.datos.coleccion("megusta", 200):
            if getattr(e, "tipo", "VIDEO") == "VIDEO" and _id(e) not in r:
                r[_id(e)] = (e, 0.5, "gustó")
        ahora = time.time() * 1000
        for e in self.novedades()[:80]:
            if not corto(e) and _id(e) not in r and e.fecha and ahora - e.fecha < 30 * 864e5:
                r[_id(e)] = (e, 0.35, "canal")
        return [x for x in r.values() if x[0].url and not self._vetado(x[0])]

    def _elegir_semillas(self, n, rnd):
        """n semillas que no se hayan usado ni preparado en el último día, de canales distintos. 09/11/2026: un canal que
        ya dio semillas en los últimos 3 días pesa menos (1/(1+veces)): si no, lo que más ves daba siempre los relacionados
        de la misma gente."""
        rel = self.a.copia("rel")
        ahora = time.time()
        cands = self._candidatas_semilla()
        de_canal = collections.Counter(v.get("c") for v in rel.values()
                                       if v.get("c") and ahora - max(v.get("u", 0), v.get("p", 0)) < 3 * DIA)

        def libre(e):
            ent = rel.get(_id(e)) or {}
            return ahora - max(ent.get("u", 0), ent.get("p", 0)) > DIA
        libres = [c for c in cands if libre(c[0])]
        if len(libres) < n:
            libres = cands
        orden = _sorteo(libres, lambda c: c[1] / (1 + de_canal.get(c[0].autorUrl, 0)), rnd)
        elegidas, canales = [], set()
        for e, p, como in orden:
            if e.autorUrl in canales:
                continue
            canales.add(e.autorUrl)
            elegidas.append((e, como))
            if len(elegidas) >= n:
                break
        return elegidas

    def _relacionados(self, semillas, uso=True, preparar=False):
        """Pide los relacionados de las semillas que no estén guardados (o tengan más de 3 días). «uso»: entran ya en el
        Inicio; «preparar»: quedan listas para la visita siguiente."""
        ahora = time.time()
        rel = self.a.copia("rel")
        faltan = [(e, c) for e, c in semillas if ahora - (rel.get(_id(e)) or {}).get("t", 0) > self.REL_FRESCO]

        def pedir(sc):
            e, c = sc
            if not self._red():
                return
            try:
                lista = pedir_relacionados(e.url)
                self._bien("relacionados")
            except Exception as error:   # noqa: BLE001
                self._mal("relacionados", error)
                if self._red():   # el vídeo ya no está o no tiene relacionados: no se vuelve a pedir en 3 días
                    self.a.poner("rel", _id(e), {"t": time.time(), "u": 0, "de": e.titulo or "", "c": e.autorUrl or "", "k": c, "l": []})
                return
            viejo = self.a.leer("rel", _id(e)) or {}
            self.a.poner("rel", _id(e), {"t": time.time(), "u": viejo.get("u", 0), "de": e.titulo or "", "c": e.autorUrl or "",
                                         "k": c, "l": [x.dict() for x in lista[:20] if x.tipo == "VIDEO"]})
        self._en_paralelo(pedir, faltan)
        self._apuntar_verificados()
        for e, c in semillas:
            ent = self.a.leer("rel", _id(e))
            if ent and uso:
                self.a.poner("rel", _id(e), dict(ent, u=time.time(), k=c))
            elif ent and preparar:
                self.a.poner("rel", _id(e), dict(ent, p=time.time(), k=c))

    def _preparadas(self):
        """Las semillas pedidas por detrás para esta visita y aún sin usar (las más antiguas primero)."""
        ahora = time.time()
        r = [(k, v) for k, v in self.a.copia("rel").items() if v.get("p") and not v.get("u") and v.get("l") and ahora - v.get("t", 0) < DIA]
        return [k for k, _ in sorted(r, key=lambda kv: kv[1]["p"])]

    def preparar_inicio(self, rnd=None):
        """Lo de la visita siguiente al Inicio: lo nuevo de los canales que más publican y los relacionados de otras 4
        semillas (sin usarlas todavía)."""
        rnd = rnd or random.Random()
        self.refrescar_rss(self.RSS_FRESCO, self.RSS_INICIO)
        if len(self._preparadas()) < self.SEMILLAS:
            self._relacionados(self._elegir_semillas(self.SEMILLAS, rnd), uso=False, preparar=True)
        self.a.guardar()

    def inicio(self, veces=None, cansados=None, rnd=None, red=True):
        """La portada nueva: ([(Elemento, motivo)], temas). «veces» ({id: veces}) y «cansados» son la memoria de lo ya
        enseñado (mezcla.Ensenado); «red» = False solo con lo guardado (las pruebas). Si hay semillas preparadas, sale al
        momento con ellas y las de la vez siguiente se piden después; si no (la primera vez), se piden ahora."""
        rnd = rnd or random.Random()
        veces, cansados = veces or {}, cansados or set()
        t0, antes = time.time(), dict(self.peticiones)
        with self._paso:
            self._al_dia()
            if red:
                listas = self._preparadas()
                if listas:   # lo preparado después de la visita anterior: sale al momento
                    for k in listas[:self.SEMILLAS]:
                        self.a.poner("rel", k, dict(self.a.leer("rel", k), u=time.time()))
                elif not self._hay_relacionados():   # la primera vez (o tras días sin abrirla): se pide ahora
                    if not any(self.a.leer("rss", c.url) for c in self._subs()):
                        self.refrescar_rss(self.RSS_FRESCO, self.RSS_INICIO)
                    self._relacionados(self._elegir_semillas(self.SEMILLAS, rnd))
                # si no, con lo guardado: la portada anterior no vuelve arriba y lo enseñado pesa menos (también cambia)
                self.a.guardar()
            lista = self._componer(veces, cansados, rnd)
        if red:
            self._apuntar("inicio", t0, antes)
            self._de_fondo(self.preparar_inicio)
        return lista, self.temas()

    def _hay_relacionados(self):
        """¿Hay relacionados de semillas usadas en los 3 últimos días?"""
        ahora = time.time()
        return any(v.get("u") and v.get("l") and ahora - v["u"] < 3 * DIA for v in self.a.copia("rel").values())

    def _filtro_inicio(self):
        vistos = {_id(e) for e in self.datos.historial(3000)}
        ocultos = self.datos.ocultos()

        def vale(e, cansados):
            vid = _id(e)
            return (vid and e.tipo == "VIDEO" and vid not in vistos and vid not in cansados and e.url not in ocultos
                    and not motor.programado(e) and not corto(e) and not self._vetado(e))
        return vale

    def _cola_relacionados(self, vale, cansados, subs):
        """Los relacionados de las semillas usadas en los 3 últimos días: las de esta visita pesan 1 y las de hace 6 h la
        mitad (así cada visita trae arriba lo suyo); lo que sale desde varias semillas suma; lo muy popular de canales
        que no sigues pesa menos y lo de canales grandes que no sigues no entra («Mi estilo»)."""
        ahora = time.time()
        puntos, elem, motivo, mejor = collections.Counter(), {}, {}, {}
        for vid_s, ent in self.a.copia("rel").items():
            u = ent.get("u", 0)
            if not u or ahora - u > 3 * DIA:
                continue
            w = 1.0 / (1 + (ahora - u) / (6 * 3600))
            de = (ent.get("de") or "")[:60]
            texto = (f"Porque te gustó «{de}»" if ent.get("k") == "gustó" else f"Porque viste «{de}»") if de else "Relacionado con lo que ves"
            for j, d in enumerate(ent.get("l", [])[:20]):
                e = motor.elemento_de_dict(d)
                if not vale(e, cansados) or _id(e) == vid_s:
                    continue
                p = w / (1 + 0.1 * j)
                if ent.get("c") and e.autorUrl == ent.get("c"):   # 09/11/2026: más del mismo canal que la semilla, la mitad
                    p *= 0.5
                if e.autorUrl not in subs:
                    if self._grande(e.autorUrl, e.autor, [e.titulo]):
                        continue
                    p *= factor_popular(vistas(e))
                vid = _id(e)
                puntos[vid] += p
                elem.setdefault(vid, e)
                if p > mejor.get(vid, 0):
                    mejor[vid], motivo[vid] = p, texto
        return [(elem[v], motivo[v], puntos[v]) for v in puntos]

    def _cola_suscripciones(self, vale, cansados, af):
        """Lo nuevo de tus canales (21 días): lo más reciente y de los canales que más ves, antes (09/11/2026: la afinidad
        suma menos, 0,15 en vez de 0,25 por log: los canales de siempre ya no tapan a los demás)."""
        ahora = time.time() * 1000
        r = []
        for e in self.novedades():
            if not e.fecha or ahora - e.fecha > 21 * 864e5 or not vale(e, cansados):
                continue
            dias = (ahora - e.fecha) / 864e5
            r.append((e, "De tus suscripciones", math.exp(-dias / 6) * (1 + 0.15 * math.log1p(af.get(e.autorUrl, 0)))))
        return r

    def _cola_descubiertos(self, vale, cansados):
        """Lo de los canales descubiertos en Explorar (solo lo guardado: el Inicio no pide nada para esto)."""
        r = []
        for c in self._candidatos(self._positivos())[:60]:
            if not c["vale"]:
                continue
            for e in c["videos"][:2]:
                if vale(e, cansados):
                    r.append((e, c["motivo"], 0.5 + 0.1 * c["puntos"]))
        return r

    def _componer(self, veces, cansados, rnd):
        """Tres colas sorteadas con su peso (lo ya enseñado pesa 1/3, 1/5…): de cada 6, 3 relacionados, 2 de tus canales y
        1 descubierto (si una se acaba, las otras); en los 12 primeros, un vídeo por canal; en los 40 primeros, 2; nunca
        dos seguidos del mismo canal; y nada de lo que estaba en los 24 primeros de la portada anterior vuelve a ellos
        (actualizar enseña otra portada de verdad).
        09/11/2026 (orden del autor: «es una mierda ver siempre los mismos videos y de la misma gente»): también descansa la
        GENTE: cada canal que salió en los 24 primeros de las portadas de los últimos 3 días pesa 1/(1 + 1,2 × apariciones)
        (las de hace más de 12 h cuentan la mitad o menos) y los canales de las 12 primeras de las dos últimas portadas no
        vuelven a las 12 primeras mientras haya otros."""
        vale = self._filtro_inicio()
        af, _ = self._afinidad()
        subs = {c.url for c in self._subs()}
        cansancio, recientes = self._cansancio_canales()

        def peso(x):
            canal = x[0].autorUrl or x[0].autor
            return x[2] / (1 + 2 * veces.get(_id(x[0]), 0)) / (1 + self.CANSANCIO_CANAL * cansancio.get(canal, 0))

        def sortear(cola):
            return _sorteo(cola, peso, rnd)
        colas = {"R": sortear(self._cola_relacionados(vale, cansados, subs)),
                 "S": sortear(self._cola_suscripciones(vale, cansados, af)),
                 "D": sortear(self._cola_descubiertos(vale, cansados))}
        patron = "RSRDRS"
        final, ya, por_canal = [], set(), collections.Counter()
        while len(final) < self.INICIO_N and any(colas.values()):
            quien = patron[len(final) % len(patron)]
            orden = [quien] + [q for q in "RSD" if q != quien]
            n = len(final)
            tope = 1 if n < 12 else 2 if n < 40 else 4
            elegido = None
            for estricto in ((True, False) if n < 12 else (False,)):
                for q in orden:
                    for k, (e, m, _) in enumerate(colas[q][:80]):
                        if _id(e) in ya or (n < 24 and _id(e) in self._portada):
                            continue
                        a = e.autorUrl or e.autor
                        if estricto and a in recientes:
                            continue
                        if por_canal[a] < tope and not (final and (final[-1][0].autorUrl or final[-1][0].autor) == a):
                            elegido = (q, k)
                            break
                    if elegido:
                        break
                if elegido:
                    break
            if elegido is None:   # nada cumple: el primero que quede, sin repetir vídeo
                for q in orden:
                    while colas[q] and _id(colas[q][0][0]) in ya:
                        colas[q].pop(0)
                    if colas[q]:
                        elegido = (q, 0)
                        break
                if elegido is None:
                    break
            e, m, _ = colas[elegido[0]].pop(elegido[1])
            ya.add(_id(e))
            por_canal[e.autorUrl or e.autor] += 1
            final.append((e, m))
        self._portada = {_id(e) for e, _ in final[:24]}
        canales = []
        for e, _ in final[:self.PORTADA_CANALES]:
            c = e.autorUrl or e.autor
            if c and c not in canales:
                canales.append(c)
        if canales:
            self.a.poner("portadas", f"{time.time():.3f}", canales)
        return final

    def _cansancio_canales(self):
        """09/11/2026 · ({canal: apariciones recientes arriba}, canales de las 12 primeras de las dos últimas portadas). Cada
        portada de los últimos 3 días suma a sus canales 1/(1 + horas/12): la de hace 12 h, la mitad."""
        ahora = time.time()
        cansancio, recientes, n = collections.Counter(), set(), 0
        for k, canales in sorted(self.a.copia("portadas").items(), key=lambda kv: -_hora(kv[0])):
            if not isinstance(canales, list):
                continue
            w = 1.0 / (1 + max(0.0, ahora - _hora(k)) / (12 * 3600))
            for c in canales:
                cansancio[c] += w
            if n < 2:
                recientes.update(canales[:12])
                n += 1
        return cansancio, recientes

    # ================================================================ Explorar
    def _destacados(self, urls):
        """Pide el estante de canales recomendados de esos canales tuyos (si no está o tiene más de 7 días)."""
        ahora = time.time()

        def pedir(u):
            if not self._red():
                return
            ent = dict(self.a.leer("canales", u) or {})
            try:
                dest = pedir_destacados(u)
                self._bien("destacados")
            except Exception as error:   # noqa: BLE001
                self._mal("destacados", error)
                if self._red():   # canal que no se deja leer: no se vuelve a pedir en 7 días (lo de antes se queda)
                    ent.update(td=time.time())
                    self.a.poner("canales", u, ent)
                return
            ent.update(td=time.time(), dest=[list(x) for x in dest])
            self.a.poner("canales", u, ent)
        self._en_paralelo(pedir, [u for u in urls if ahora - (self.a.leer("canales", u) or {}).get("td", 0) > self.INFO_FRESCA])

    def _vecinos(self, urls):
        """Los relacionados del último vídeo de esos canales tuyos (lo que YouTube pone a su lado)."""
        ahora = time.time()
        semillas = []
        for u in urls:
            ult = next((motor.elemento_de_dict(d) for d in (self.a.leer("rss", u) or {}).get("l", []) if not corto(d)), None) \
                or next((motor.elemento_de_dict(d) for d in (self.a.leer("canales", u) or {}).get("videos", []) if not corto(d)), None)
            if ult is None and self._red():
                try:
                    lista = pedir_rss(u, "")
                    self._bien("rss")
                    ult = next((e for e in lista if not corto(e)), None)
                except Exception as error:   # noqa: BLE001
                    self._mal("rss", error)
            if ult is not None:
                ult.autorUrl = ult.autorUrl or u
                semillas.append((ult, "explorar"))
            self.a.poner("explorados", u, ahora)
        self._relacionados(semillas, uso=False)

    def _info(self, urls):
        """Tamaño, últimos vídeos y títulos de esos canales (si no están o tienen más de 7 días)."""
        ahora = time.time()

        def pedir(u):
            if not self._red():
                return
            try:
                cab, videos, info = pedir_canal(u, 12)
                self._bien("canal")
            except Exception as error:   # noqa: BLE001
                self._mal("canal", error)
                ent = dict(self.a.leer("canales", u) or {})
                ent.update(t=time.time(), subs=ent.get("subs", -1), malo=True)
                self.a.poner("canales", u, ent)
                return
            ent = dict(self.a.leer("canales", u) or {})
            subs = motor.numero_suscriptores(info.get("suscriptores") or cab.detalle)
            ent.update(t=time.time(), nombre=cab.titulo or ent.get("nombre", ""), avatar=cab.miniatura or info.get("avatar", ""),
                       subs=subs if subs >= 0 else ent.get("subs", -1), titulos=[v.titulo for v in videos[:10]],
                       videos=[v.dict() for v in videos if v.tipo == "VIDEO"][:6], malo=False)
            self.a.poner("canales", u, ent)
            if info.get("verificado") == "verificado":
                self.a.poner("verificados", u, time.time())
        self._en_paralelo(pedir, [u for u in urls if ahora - (self.a.leer("canales", u) or {}).get("t", 0) > self.INFO_FRESCA])

    def _candidatos(self, positivos, foco=None):
        """Los canales que no sigues cerca de los tuyos, con todo lo que se sabe de ellos, del más al menos cercano:
        [{url, nombre, rec (quién lo recomienda), cerca (junto a cuáles de los tuyos), puntos, subs, vale, videos, motivo}].
        «foco»: solo lo cercano a ese canal tuyo (la ficha «Como <canal>»)."""
        pos = {u: n for u, n, _ in positivos}
        neg = self._negativos()
        canales = self.a.copia("canales")
        verificados = self.a.copia("verificados")
        cands = {}

        def c_(u, nombre=""):
            c = cands.get(u)
            if c is None:
                c = cands[u] = {"url": u, "nombre": nombre, "rec": [], "cerca": set(), "vmin": -1, "subs": -1, "avatar": ""}
            if nombre and not c["nombre"]:
                c["nombre"] = nombre
            return c
        for u, nombre in pos.items():
            if foco and u != foco:
                continue
            palabras = set(re.findall(r"\w{4,}", (nombre or "").lower()))
            for d in (canales.get(u) or {}).get("dest", [])[:8]:   # como mucho 8 por creador: nadie llena Explorar él solo
                du, dn, ds, da = (list(d) + ["", -1, ""])[:4]
                if not du or du in pos or du == u:
                    continue
                # sus canales hermanos (misma marca, otros idiomas) no son descubrir nada
                if palabras & set(re.findall(r"\w{4,}", (dn or "").lower())):
                    continue
                c = c_(du, dn)
                if nombre and nombre not in c["rec"]:
                    c["rec"].append(nombre)
                if isinstance(ds, int) and ds >= 0:
                    c["subs"] = ds
                c["avatar"] = c["avatar"] or da
        for ent in self.a.copia("rel").values():
            sc = ent.get("c", "")
            if sc not in pos or (foco and sc != foco):
                continue
            for d in ent.get("l", [])[:20]:
                a = d.get("autorUrl") or ""
                if not a or a in pos or a == sc:
                    continue
                c = c_(a, d.get("autor", ""))
                c["cerca"].add(sc)
                v = vistas(d)
                if v >= 0:
                    c["vmin"] = v if c["vmin"] < 0 else min(c["vmin"], v)
        r = []
        for u, c in cands.items():
            if u.lower().rstrip("/") in neg or self._vetado_canal(u, c["nombre"]):
                continue
            info = canales.get(u) or {}
            c["nombre"] = info.get("nombre") or c["nombre"]
            c["avatar"] = info.get("avatar") or c["avatar"]
            if info.get("subs", -1) >= 0:
                c["subs"] = info["subs"]
            c["verificado"] = u in verificados or u in motor.VERIFICADOS
            c["info"] = bool(info.get("t")) and not info.get("malo")
            c["titulos"] = info.get("titulos", [])
            c["videos"] = [motor.elemento_de_dict(d) for d in info.get("videos", [])]
            c["puntos"] = 4 * len(c["rec"]) + 2 * len(c["cerca"])
            r.append(c)
        hay_cerca2 = sum(1 for c in r if len(c["cerca"]) >= 2) >= 15
        r = [c for c in r if c["rec"] or len(c["cerca"]) >= (2 if hay_cerca2 and not foco else 1)]
        for c in r:
            c["vale"], c["por_que_no"] = self._veredicto(c)
            c["motivo"] = self._motivo(c, pos)
        return sorted(r, key=lambda c: -c["puntos"])

    def _veredicto(self, c):
        """¿Sale en Explorar? Solo lo conocido: con «Mi estilo», menos de 100 000 suscriptores y sin la insignia de
        verificado (salvo música en directo y viajes) y sin cebo; nunca lo de mascotas; con algún vídeo de este año."""
        exc = excepcion(c["nombre"], c["titulos"])
        if exc == "Nut":
            return False, "mascotas"
        if self.estilo and not exc and (c["verificado"] or c["subs"] > TOPE_SUSCRIPTORES):
            return False, "grande"
        if not c["info"] or (self.estilo and c["subs"] < 0):
            return False, "sin datos"
        if self.estilo and cebo(c["titulos"]) >= 0.3:
            return False, "cebo"
        ahora = time.time() * 1000
        if not any(e.fecha and ahora - e.fecha < 365 * 864e5 for e in c["videos"]):
            return False, "parado"
        return True, exc or ""

    def _por_conocer(self, c):
        """¿Merece la pena pedir su tamaño y sus vídeos? No lo que ya se sabe grande: verificado, más de 100 000 o (si
        nadie lo recomienda) todos sus vídeos vistos con más de 1 M de visualizaciones."""
        if c["info"] or time.time() - (self.a.leer("canales", c["url"]) or {}).get("t", 0) < self.INFO_FRESCA:
            return False
        if self.estilo and not excepcion(c["nombre"], []):
            if c["verificado"] or c["subs"] > TOPE_SUSCRIPTORES or (not c["rec"] and c["vmin"] > 1_000_000):
                return False
        return True

    @staticmethod
    def _motivo(c, pos):
        if c["rec"]:
            q = c["rec"]
            return f"Recomendado por {q[0]}" + (f" y {len(q) - 1} más" if len(q) > 1 else "")
        cerca = [pos.get(u, "") for u in c["cerca"] if pos.get(u)]
        if not cerca:
            return "Cerca de tus canales"
        if len(cerca) == 1:
            return f"Cerca de {cerca[0]}"
        if len(cerca) == 2:
            return f"Cerca de {cerca[0]} y {cerca[1]}"
        return f"Cerca de {cerca[0]}, {cerca[1]} y {len(cerca) - 2} más de tus canales"

    def fichas_explorar(self):
        """Las fichas de Explorar (sin pedir nada): las fijas y «Como <canal>» de tus 8 canales de más peso; [] sin canales."""
        self._al_dia()
        positivos = self._positivos()
        return (list(FICHAS_EXPLORAR) + [COMO + n for _, n, _ in positivos[:8] if n]) if positivos else []

    def _paso_explorar(self, positivos, foco, n_dest, n_vec, n_info, minimo, rnd, vistos_ex):
        """La red de una visita a Explorar: destacados de n_dest de tus canales, vecinos de n_vec y el tamaño y los vídeos
        de los mejores candidatos sin conocer, de 6 en 6 hasta tener «minimo» que salgan (como mucho n_info)."""
        ahora = time.time()
        if foco:
            dest, vec = [foco], ([foco] if ahora - self.a.leer("explorados", foco, 0) > DIA else [])
        else:
            # los tuyos de más peso primero, con algo de azar; los ya mirados (7 días los destacados, 3 los vecinos) no
            sin_dest = [x for x in positivos if ahora - (self.a.leer("canales", x[0]) or {}).get("td", 0) > self.INFO_FRESCA]
            sin_vec = [x for x in positivos if ahora - self.a.leer("explorados", x[0], 0) > 3 * DIA]
            dest = [x[0] for x in _sorteo(sin_dest, lambda x: 1 + x[2], rnd)[:n_dest]]
            vec = [x[0] for x in _sorteo(sin_vec, lambda x: 1 + x[2], rnd)[:n_vec]]
        # las dos cosas a la vez (cada una ya pide en paralelo lo suyo)
        with cf.ThreadPoolExecutor(2) as ex:
            list(ex.map(lambda f: f(), [lambda: self._destacados(dest), lambda: self._vecinos(vec)]))
        pedidas = 0
        while pedidas < n_info and self._red():
            cands = self._candidatos(positivos, foco)
            if pedidas and sum(1 for c in cands if c["vale"] and vistos_ex.get(c["url"], [0])[0] < 4) >= minimo:
                break
            lote = [c["url"] for c in cands if self._por_conocer(c)][:min(6, n_info - pedidas)]
            if not lote:
                break
            self._info(lote)
            pedidas += len(lote)
        self.a.guardar()

    def explorar(self, tema="Todo", forzar=False, mas=False, ya=None, rnd=None, red=True):
        """La página Explorar: {"elementos": [Elemento], "motivos": {url: motivo}, "chips": [...], "activo", "aviso"}, o
        None sin canales ni «me gusta» (la página de antes). La primera vez y con ⟳ busca en el momento hasta tener 12
        canales que salgan; con bastante guardado, sale al momento y lo de la vez siguiente se pide después; al bajar
        hasta el final («mas»), otro poco. «ya»: canales ya enseñados en esta visita (las tandas de más no los repiten)."""
        rnd = rnd or random.Random()
        tema = tema or "Todo"
        t0, antes = time.time(), dict(self.peticiones)
        with self._paso:
            self._al_dia()
            positivos = self._positivos()
            if not positivos:
                return None
            foco = None
            if tema.startswith(COMO):
                foco = next((u for u, n, _ in positivos if n == tema[len(COMO):]), None)
            vistos_ex = self.a.copia("vistos_explorar")
            utiles = sum(1 for c in self._candidatos(positivos, foco) if c["vale"] and vistos_ex.get(c["url"], [0])[0] < 4)
            despues = None
            if red and self._red():
                if mas:
                    self._paso_explorar(positivos, foco, 3, 2, 6, 0, rnd, vistos_ex)
                elif utiles < (4 if foco else 6):   # casi nada que enseñar (la primera vez): se busca ya
                    self._paso_explorar(positivos, foco, 6, 3, 12 if foco else 18, 8 if foco else 12, rnd, vistos_ex)
                elif forzar:   # ⟳: algo nuevo en el momento, sin esperar a tenerlo todo
                    self._paso_explorar(positivos, foco, 4, 2, 8, 8, rnd, vistos_ex)
                else:   # con lo guardado sale ya; lo de la vez siguiente se pide después
                    despues = lambda: self._paso_explorar(positivos, foco, 4, 2, 8, 0, random.Random(), vistos_ex)   # noqa: E731
            r = self._pagina_explorar(tema, foco, positivos, mas, ya, rnd, vistos_ex)
        if red:
            self._apuntar(f"explorar «{tema}»" + (" (⟳)" if forzar else " (más)" if mas else ""), t0, antes)
        if despues:
            self._de_fondo(despues)
        return r

    def _pagina_explorar(self, tema, foco, positivos, mas, ya, rnd, vistos_ex):
        cands = [c for c in self._candidatos(positivos, foco) if c["vale"]]
        if tema == "Recomendados por tus canales":
            cands = [c for c in cands if c["rec"]]
        elif tema == "Cerca de tus canales":
            cands = [c for c in cands if not c["rec"]]
        ya = ya if ya is not None else set()
        cands = [c for c in cands if c["url"] not in ya and vistos_ex.get(c["url"], [0])[0] < 4]
        orden = _sorteo(cands, lambda c: (1 + c["puntos"]) / (1 + vistos_ex.get(c["url"], [0])[0]), rnd)
        vistos = {_id(e) for e in self.datos.historial(3000)}
        ocultos = self.datos.ocultos()
        elementos, motivos = [], {}
        if tema == "Canales":
            for c in orden[:40]:
                detalle = " · ".join(x for x in (f"{motor.cifra(c['subs'])} suscriptores" if c["subs"] >= 0 else "", c["motivo"]) if x)
                e = motor.Elemento("CANAL", c["url"], c["nombre"], miniatura=c["avatar"], detalle=detalle)
                elementos.append(e)
                motivos[e.url] = c["motivo"]
                ya.add(c["url"])
        else:
            rondas = [[], []]
            ahora = time.time() * 1000
            for c in orden[:40]:
                buenos = [e for e in c["videos"] if e.tipo == "VIDEO" and _id(e) not in vistos and e.url not in ocultos
                          and not motor.programado(e) and not corto(e) and not self._vetado(e)]
                recientes = [e for e in buenos if e.fecha and ahora - e.fecha < 90 * 864e5]
                elegidos = (recientes or buenos)[:2 if recientes else 1]
                for k, e in enumerate(elegidos):
                    e.autor, e.autorUrl = e.autor or c["nombre"], e.autorUrl or c["url"]
                    motivos[e.url] = (tema + " · " + c["motivo"]) if foco else c["motivo"]
                    rondas[k].append(e)
                if elegidos:
                    ya.add(c["url"])
            elementos = rondas[0] + rondas[1]   # primero un vídeo de cada canal; después, el segundo
        if not mas and tema == "Todo":   # lo enseñado arriba: 4 veces sin seguirlo, fuera 14 días
            for u in list(dict.fromkeys(e.autorUrl if e.tipo == "VIDEO" else e.url for e in elementos))[:12]:
                v = vistos_ex.get(u, [0, 0])
                self.a.poner("vistos_explorar", u, [v[0] + 1, time.time()])
            self.a.guardar()
        chips = list(FICHAS_EXPLORAR) + [COMO + n for _, n, _ in positivos[:8] if n]   # como fichas_explorar()
        aviso = ""
        if not elementos and not mas:
            aviso = ("Aún no conozco canales cerca de los tuyos: vuelve a entrar o pulsa ⟳ y buscaré más."
                     if self._red() else "YouTube no contesta ahora: lo vuelvo a intentar en unos minutos.")
        return {"elementos": elementos, "motivos": motivos, "chips": chips, "activo": tema, "aviso": aviso}

    # ================================================================ para las pruebas y el registro
    def resumen(self):
        return {s: len(self.a.copia(s)) for s in Almacen.SECCIONES} | {"peticiones": dict(self.peticiones)}
