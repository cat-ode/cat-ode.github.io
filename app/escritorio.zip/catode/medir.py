"""Cat-ode escritorio · medida de uso real (catode.pyw --medir): cuánto tarda en abrir, cuánto tarda cada vídeo en empezar
y si aguanta sonando sin pararse. Abre los vídeos como una persona (la tarjeta del Inicio) y escribe una línea por medida.
El autor (02/10/2026): «tarda mucho en abrirse y tarda un siglo en reproducir un vídeo, luego se detiene»."""
import os
import time

from PySide6.QtCore import QTimer

T0 = float(os.environ.get("CATODE_T0", time.time()))
MINUTOS = float(os.environ.get("CATODE_MEDIR_MINUTOS", "5"))


def captura_pantalla(nombre):
    """Windows: la pantalla entera tal como la ve el autor (con mpv), en la carpeta de la prueba."""
    if os.name != "nt":
        return
    import subprocess
    ps = ("Add-Type -AssemblyName System.Windows.Forms,System.Drawing;"
          "$b=[System.Windows.Forms.Screen]::PrimaryScreen.Bounds;$i=New-Object System.Drawing.Bitmap $b.Width,$b.Height;"
          "$g=[System.Drawing.Graphics]::FromImage($i);$g.CopyFromScreen($b.Location,[System.Drawing.Point]::Empty,$b.Size);"
          f"$i.Save('C:\\ProgramData\\Cat-ode\\prueba\\{nombre}.png')")
    subprocess.Popen(["powershell", "-NoProfile", "-Command", ps], creationflags=0x08000000)


def empezar(app, v):
    rep = v.rep
    rep.mpv.mute = True
    r = {"parones": 0, "errores": [], "inicio": None}

    def linea(t):
        print(f"[{time.time() - T0:7.1f} s] {t}", flush=True)

    linea("ventana abierta")

    @rep.mpv.event_callback("end-file")
    def _fin(ev):
        try:
            if ev.data.reason == 4:   # error
                r["errores"].append(str(ev.data.error))
        except Exception:
            pass

    def esperar(cond, segundos, siguiente):
        fin = time.time() + segundos

        def mirar():
            try:
                ok = cond()
            except Exception:
                ok = False
            if ok or time.time() > fin:
                siguiente(bool(ok))
            else:
                QTimer.singleShot(200, mirar)
        mirar()

    def tarjetas():
        return [w for w in v.pag.rejilla.widgets if getattr(w, "e", None) and w.e.tipo == "VIDEO"]

    def inicio_listo(ok):
        linea(f"Inicio con vídeos: {'sí' if ok else 'NO'} ({len(tarjetas())} tarjetas)")
        r["cola"] = tarjetas()[:3]
        QTimer.singleShot(4000, abrir_siguiente)   # una persona mira el Inicio unos segundos antes de pulsar

    def abrir_siguiente():
        if not r["cola"]:
            return aguante()
        w = r["cola"].pop(0)
        t = time.time()
        v.abrir(w.e)   # lo mismo que pulsar la tarjeta
        esperar(lambda: rep.actual is not None and rep.actual.url == w.e.url and rep._arrancado and rep.pos > 0.3 and not rep.pausa, 90,
                lambda ok: (linea(f"vídeo «{w.e.titulo[:40]}»: {'empieza en' if ok else 'NO EMPIEZA tras'} {time.time() - t:.1f} s"
                                  f" · {rep.mpv.width}x{rep.mpv.height} · {rep.mpv.hwdec_current or 'sin gráfica'}"),
                            QTimer.singleShot(4000, abrir_siguiente)))

    def aguante():
        linea(f"aguante: {MINUTOS:.0f} minutos sonando, mirando cada segundo")
        r["t"], r["ult"], r["quieto"] = time.time(), rep.pos, 0.0

        def mirar():
            ahora = rep.pos
            if not rep.pausa and abs(ahora - r["ult"]) < 0.2:
                r["quieto"] += 1
                if r["quieto"] == 3:
                    r["parones"] += 1
                    linea(f"PARÓN en {ahora:.0f} s del vídeo (cache {rep.mpv.demuxer_cache_duration or 0:.0f} s, "
                          f"inactivo={rep.mpv.idle_active}, errores={r['errores'][-1:] })")
            else:
                if r["quieto"] >= 3:
                    linea(f"sigue tras {r['quieto']:.0f} s parado")
                r["quieto"] = 0
            r["ult"] = ahora
            if time.time() - r["t"] < MINUTOS * 60:
                QTimer.singleShot(1000, mirar)
            else:
                linea(f"FIN · parones: {r['parones']} · errores de mpv: {len(r['errores'])} {r['errores'][:2]} · "
                      f"perdidos {rep.mpv.frame_drop_count} · posición {rep.pos:.0f}/{rep.dur:.0f} s")
                rep.parar()
                app.exit(0 if r["parones"] == 0 and not r["errores"] else 1)
        QTimer.singleShot(1000, mirar)

    esperar(lambda: len(tarjetas()) >= 6, 120, inicio_listo)
