"""Cat-ode escritorio · el aviso de novedades al estrenar versión (22/10/2026, el autor: «ni hay mensaje con novedades de versión,
el modo música era relevante avisarlo»). Lo comparten la ventana Qt (Linux) y la interfaz web (Windows).
Los textos están en novedades.json (mismo archivo que android/app/src/main/assets/novedades.json). La versión vista se guarda en
los ajustes de ESTE aparato («novedades_vista»: no está entre los compartidos, datos.AJUSTES_COMUNES)."""
import json
import os

ARCHIVO = os.path.join(os.path.dirname(os.path.abspath(__file__)), "novedades.json")


def _num(v):
    try:
        return tuple(int(x) for x in str(v).split("."))
    except ValueError:
        return (0,)


def pendientes(vista, actual, hay_biblioteca, plataforma="escritorio", archivo=ARCHIVO):
    """Los puntos que hay que enseñar: los de las versiones (de esta plataforma) mayores que la vista y hasta la actual, de la
    más nueva a la más vieja. Sin versión vista, solo los de la actual. Lista vacía si no hay nada que enseñar."""
    try:
        versiones = json.load(open(archivo, encoding="utf-8")).get("versiones") or []
    except Exception:   # noqa: BLE001 (sin archivo o roto: sin aviso, nunca un fallo al abrir)
        return []
    otra = "android" if plataforma == "escritorio" else "escritorio"
    out = []
    for v in sorted(versiones, key=lambda v: _num(v.get(plataforma)), reverse=True):
        n = _num(v.get(plataforma))
        if n > _num(actual) or (n <= _num(vista) if vista else n != _num(actual)):
            continue
        for p in v.get("puntos") or []:
            if p.get("solo") == otra or (p.get("si") == "biblioteca" and not hay_biblioteca):
                continue
            out.append(p.get("texto", ""))
    return [t for t in out if t]
