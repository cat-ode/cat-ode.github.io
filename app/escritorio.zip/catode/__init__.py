"""Cat-ode de escritorio (Linux y Windows) · el YouTube propio del autor, sin cuenta de Google, sin anuncios ni pausas."""
VERSION = "1.2.26"
