"""Cat-ode escritorio · la ventana, al estilo YouTube (1.0.0, 02/10/2026): barra de arriba con el buscador, menú a la
izquierda (Inicio, Shorts, Suscripciones, Explorar y «Tú»: historial, ver más tarde, me gusta, listas y descargas),
cuadrícula de vídeos en el centro, página del vídeo con capítulos, comentarios y «A continuación», y la barra del
reproductor abajo con todo lo que deja tocar YouTube (velocidad, subtítulos, calidad, bucle, solo sonido, temporizador,
cola). Atajos de YouTube: espacio/k, j/l, flechas, f, m, Mayús+N/P, «/»."""
import json
import os
import re
import sys
import threading
import time

from PySide6.QtCore import Qt, QObject, Signal, QTimer, QUrl, QStringListModel, QSize, QRect
from PySide6.QtGui import QIcon, QPixmap, QPalette, QColor, QKeySequence, QShortcut, QPainter, QPainterPath, QDesktopServices, QCursor
from PySide6.QtNetwork import QNetworkAccessManager, QNetworkRequest, QNetworkDiskCache
from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QHBoxLayout, QVBoxLayout, QLabel, QPushButton,
                               QListWidget, QListWidgetItem, QStackedWidget, QLineEdit, QCompleter, QSlider, QComboBox,
                               QCheckBox, QFileDialog, QSizePolicy, QFrame, QScrollArea, QMenu, QInputDialog,
                               QMessageBox, QProgressBar, QTabBar, QAbstractItemView)

from . import cancion, motor, musica, VERSION, fichas, metadatos as md
from .iconos import icono, iconizar_boton, separar, Iconizador
from .efectos import fundido, suavizar
from .datos import Datos, carpeta_datos
from .reproductor import Reproductor, registro
from .tarjetas import Rejilla, menu_compartir, menu_video, ROJO

NARANJA = "#FF7A00"
ESTILO = f"""
QWidget {{ background: transparent; color: #F1F1F1; font-family: "Roboto"; font-size: 14px; }}
QMainWindow, QDialog, QStackedWidget {{ background: #0F0F0F; }}
QListWidget {{ border: none; background: transparent; outline: 0; }}
QListWidget#menu::item {{ padding: 9px 14px; border-radius: 10px; margin: 1px 8px; }}
QListWidget#menu::item:selected {{ background: #272727; color: white; font-weight: 500; }}
QListWidget::item:hover {{ background: #1F1F1F; }}
QPushButton {{ background: #272727; border: none; border-radius: 18px; padding: 8px 16px; font-weight: 500; min-height: 20px; }}
QPushButton:hover {{ background: #3A3A3A; }}
QPushButton:pressed {{ background: #4A4A4A; }}
QPushButton:checked {{ background: #F1F1F1; color: #0F0F0F; }}
QPushButton#principal {{ background: #F1F1F1; color: #0F0F0F; font-weight: 500; }}
QPushButton#principal:hover {{ background: #D9D9D9; }}
QPushButton#chip {{ border-radius: 8px; padding: 6px 12px; }}
QPushButton#chip:checked {{ background: #F1F1F1; color: #0F0F0F; }}
QPushButton#icono {{ background: transparent; font-size: 18px; padding: 4px 8px; border-radius: 14px; min-height: 0; }}
QPushButton#icono:hover {{ background: #272727; }}
QPushButton#icono:pressed {{ background: #3A3A3A; }}
QPushButton#icono:checked {{ background: #3F3F3F; color: {NARANJA}; }}
QLineEdit {{ background: #121212; border: 1px solid #303030; border-radius: 20px; padding: 8px 16px; font-size: 15px;
             selection-background-color: #3EA6FF; selection-color: #0F0F0F; }}
QLineEdit:hover {{ border: 1px solid #3D3D3D; }}
QLineEdit:focus {{ border: 1px solid #1C62B9; background: #0F0F0F; }}
QComboBox {{ background: #272727; border: none; border-radius: 8px; padding: 7px 12px; }}
QComboBox:hover {{ background: #3A3A3A; }}
QComboBox::drop-down {{ border: none; width: 24px; }}
QComboBox QAbstractItemView {{ background: #282828; border: none; padding: 6px; outline: 0; selection-background-color: #3F3F3F; }}
QCheckBox {{ background: transparent; spacing: 12px; }}
QMenu {{ background: #282828; border: none; border-radius: 12px; padding: 8px 0; }}
QMenu::item {{ padding: 9px 24px 9px 16px; background: transparent; }}
QMenu::item:selected {{ background: #3A3A3A; }}
QMenu::item:disabled {{ color: #717171; }}
QMenu::separator {{ height: 1px; background: #3A3A3A; margin: 6px 0; }}
QMenu::icon {{ padding-left: 12px; }}
QToolTip {{ background: #616161; color: #FFFFFF; border: none; border-radius: 6px; padding: 6px 9px; font-size: 12px; }}
QSlider::groove:horizontal {{ height: 4px; background: #4D4D4D; border-radius: 2px; }}
QSlider::sub-page:horizontal {{ background: {ROJO}; border-radius: 2px; }}
QSlider::handle:horizontal {{ background: {ROJO}; width: 13px; margin: -5px 0; border-radius: 6px; }}
QSlider#volumen::sub-page:horizontal {{ background: #F1F1F1; }} QSlider#volumen::handle:horizontal {{ background: #F1F1F1; }}
QLabel#titulo {{ font-size: 20px; font-weight: 700; }}
QLabel#tituloVideo {{ font-size: 20px; font-weight: 700; }}
QLabel#tituloTarjeta {{ font-size: 15px; font-weight: 500; }}
QLabel#tituloFila {{ font-size: 14px; font-weight: 500; }}
QLabel#gris {{ color: #AAAAAA; font-size: 13px; }}
QLabel#motivo {{ color: {NARANJA}; font-size: 12px; }}
QLabel#seccion {{ font-size: 16px; font-weight: 700; padding-top: 10px; }}
QLabel#aviso {{ background: rgba(50,50,50,235); color: #F1F1F1; border-radius: 10px; padding: 11px 16px; }}
QLabel#logo {{ font-size: 20px; font-weight: 700; letter-spacing: -1px; }}
QFrame#barra {{ background: #181818; border-top: 1px solid #272727; }}
QFrame#arriba {{ background: rgba(15,15,15,0.96); }}
QFrame#tarjeta, QFrame#fila {{ border-radius: 12px; }}
QFrame#tarjeta:hover, QFrame#fila:hover {{ background: #1A1A1A; border-radius: 12px; }}
QFrame#caja {{ background: #272727; border-radius: 12px; }}
QStatusBar {{ background: transparent; color: #F1F1F1; }}
QProgressBar {{ background: #272727; border: none; border-radius: 4px; height: 8px; text-align: center; }}
QProgressBar::chunk {{ background: {ROJO}; border-radius: 4px; }}
QScrollArea {{ border: none; }}
QWidget#filaPestanas {{ background: #0F0F0F; border-bottom: 1px solid #272727; }}
QTabBar {{ background: transparent; border: none; }}
QTabBar::tab {{ background: transparent; color: #AAAAAA; height: 32px; min-width: 120px; max-width: 220px; padding: 0 4px 0 12px;
               margin: 6px 4px 6px 0; border: none; border-radius: 10px; font-size: 13px; }}
QTabBar::tab:selected {{ background: #272727; color: #FFFFFF; font-weight: 600; }}
QTabBar::tab:hover:!selected {{ background: #1A1A1A; color: #F1F1F1; }}
QTabBar QToolButton {{ background: #0F0F0F; border: none; color: #FFFFFF; }}
QPushButton#cerrarPestana {{ border: none; border-radius: 10px; background: transparent; padding: 0; }}
QPushButton#cerrarPestana:hover {{ background: rgba(255,255,255,0.16); }}
QAbstractScrollArea > QWidget > QWidget {{ background: #0F0F0F; }}
QListWidget#menu QScrollBar::handle:vertical {{ background: transparent; }}
QListWidget#menu:hover QScrollBar::handle:vertical {{ background: rgba(255,255,255,0.12); }}
QScrollBar:vertical {{ background: transparent; width: 10px; margin: 2px 2px 2px 0; }}
QScrollBar::handle:vertical {{ background: rgba(255,255,255,0.12); border-radius: 4px; min-height: 40px; margin: 0 1px; }}
QScrollBar::handle:vertical:hover {{ background: rgba(255,255,255,0.32); margin: 0; }}
QScrollBar:horizontal {{ background: transparent; height: 10px; margin: 0 2px 2px 2px; }}
QScrollBar::handle:horizontal {{ background: rgba(255,255,255,0.12); border-radius: 4px; min-width: 40px; margin: 1px 0; }}
QScrollBar::handle:horizontal:hover {{ background: rgba(255,255,255,0.32); margin: 0; }}
QScrollBar::add-line, QScrollBar::sub-line, QScrollBar::add-page, QScrollBar::sub-page {{ height: 0; width: 0; background: transparent; }}
"""

POR_TANDA = 48   # tarjetas que se pintan cada vez (el resto, al bajar)


class _Puente(QObject):
    listo = Signal(object, object, object)


_puente = None


def en_hilo(funcion, al_acabar, *args):
    """Hace «funcion» fuera de la ventana y llama a «al_acabar(resultado, error)» en la ventana al terminar."""
    global _puente
    if _puente is None:
        _puente = _Puente()
        _puente.listo.connect(lambda cb, r, e: cb(r, e))

    def trabajo():
        try:
            r = funcion(*args)
            _puente.listo.emit(al_acabar, r, None)
        except Exception as e:  # noqa: BLE001
            _puente.listo.emit(al_acabar, None, e)
    threading.Thread(target=trabajo, daemon=True).start()


class _Recorte(QObject):
    listo = Signal(object, object)   # (clave, QImage)


class Imagenes:
    """Miniaturas desde internet, con caché en disco (~/.cache/catode) y en memoria. Decodificar, escalar y redondear
    se hace en hilos aparte (antes, en el de la interfaz: tirones al desplazarse y al abrir páginas, 02/10/2026); a la
    etiqueta solo llega la imagen hecha, a su tamaño y a la densidad de la pantalla (nítida también con escalado)."""
    def __init__(self):
        from PySide6.QtCore import QThreadPool
        self.red = QNetworkAccessManager()
        cache = QNetworkDiskCache()
        # 18/10/2026: CATODE_CACHE sustituye a %LOCALAPPDATA%\\catode o ~/.cache/catode (pruebas aisladas del instalador)
        base_cache = os.environ.get("CATODE_CACHE", "").strip() or os.path.join(
            os.path.expanduser("~/.cache") if os.name != "nt" else os.environ["LOCALAPPDATA"], "catode")
        cache.setCacheDirectory(os.path.join(base_cache, "miniaturas"))
        cache.setMaximumCacheSize(300 * 1024 * 1024)
        self.red.setCache(cache)
        self.datos = {}      # url → bytes (lo descargado; decodificar otra vez es barato y va en hilo)
        self.hechas = {}     # (url, ancho, alto, redonda) → QPixmap ya listo
        self.esperando = {}  # clave → [etiquetas]
        self.hilos = QThreadPool(); self.hilos.setMaxThreadCount(max(2, min(4, (os.cpu_count() or 2) - 1)))
        self.aviso = _Recorte()
        self.aviso.listo.connect(self._colocar, Qt.QueuedConnection)

    def poner(self, url, etiqueta, ancho, alto, redonda=False):
        if not url:
            return
        clave = (url, ancho, alto, redonda)
        hecha = self.hechas.get(clave)
        if hecha is not None:
            return self._dar(etiqueta, hecha, False)
        if clave in self.esperando:
            return self.esperando[clave].append(etiqueta)
        self.esperando[clave] = [etiqueta]
        if url in self.datos:
            return self._recortar(clave, self.datos[url])
        r = self.red.get(QNetworkRequest(QUrl(url)))

        def listo():
            datos = bytes(r.readAll())
            fallo = r.error() != r.NetworkError.NoError
            r.deleteLater()
            if fallo and ("/oardefault." in url or "/hq720." in url):
                # esa resolución no existe para este vídeo: la siguiente (vertical → 1280×720 → 480×360)
                otra = url.replace("/oardefault.", "/hq720.") if "/oardefault." in url else url.replace("/hq720.", "/hqdefault.")
                for et in self.esperando.pop(clave, []):
                    self.poner(otra, et, ancho, alto, redonda)
                return
            if datos and not fallo:
                if len(self.datos) > 1500:
                    self.datos.clear()
                self.datos[url] = datos
                self._recortar(clave, datos)
            else:
                self.esperando.pop(clave, None)
        r.finished.connect(listo)

    def _recortar(self, clave, datos):
        from PySide6.QtCore import QRunnable
        ratio = QApplication.primaryScreen().devicePixelRatio() if QApplication.primaryScreen() else 1.0
        aviso = self.aviso

        class Trabajo(QRunnable):
            def run(self):
                try:
                    aviso.listo.emit(clave, Imagenes._ajustar(datos, clave[1], clave[2], clave[3], ratio))
                except Exception:   # noqa: BLE001
                    aviso.listo.emit(clave, None)
        self.hilos.start(Trabajo())

    def _colocar(self, clave, imagen):
        etiquetas = self.esperando.pop(clave, [])
        if imagen is None or imagen.isNull():
            return
        p = QPixmap.fromImage(imagen)
        p.setDevicePixelRatio(imagen.devicePixelRatio())
        if len(self.hechas) > 2500:
            self.hechas.clear()
        self.hechas[clave] = p
        for e in etiquetas:
            self._dar(e, p, True)

    @staticmethod
    def _dar(etiqueta, p, nueva):
        try:
            if nueva and hasattr(etiqueta, "aparecer"):
                etiqueta.aparecer(p)   # fundido suave al llegar, como YouTube
            else:
                etiqueta.setPixmap(p)
        except RuntimeError:   # la etiqueta ya no existe (se cambió de página)
            pass

    @staticmethod
    def _ajustar(datos, ancho, alto, redonda, ratio=1.0):
        """En un hilo: solo QImage (QPixmap no se puede tocar fuera del de la interfaz)."""
        from PySide6.QtGui import QImage, QImageReader
        from PySide6.QtCore import QBuffer, QByteArray, QSize
        import math
        W, H = int(ancho * ratio), int(alto * ratio)
        # se descodifica ya reducida (JPEG lo hace a 1/2, 1/4 u 1/8 casi gratis): antes, 40 ms por miniatura en el N100
        buf = QBuffer(); buf.setData(QByteArray(datos)); buf.open(QBuffer.ReadOnly)
        lector = QImageReader(buf)
        t = lector.size()
        if t.isValid() and t.width() > 0 and t.height() > 0:
            f = max(W / t.width(), H / t.height())
            if f < 1:
                lector.setScaledSize(QSize(math.ceil(t.width() * f), math.ceil(t.height() * f)))
        img = lector.read()
        if img.isNull():
            img = QImage.fromData(datos)
            if img.isNull():
                return None
        if img.width() != W or img.height() != H:
            img = img.scaled(W, H, Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
        img = img.copy((img.width() - W) // 2, (img.height() - H) // 2, W, H)
        r = QImage(W, H, QImage.Format_ARGB32_Premultiplied)
        r.fill(Qt.transparent)
        pintor = QPainter(r)
        pintor.setRenderHint(QPainter.Antialiasing)
        camino = QPainterPath()
        if redonda:
            camino.addEllipse(0, 0, W, H)
        else:
            camino.addRoundedRect(0, 0, W, H, 12 * ratio, 12 * ratio)
        pintor.setClipPath(camino)
        pintor.drawImage(0, 0, img)
        pintor.end()
        r.setDevicePixelRatio(ratio)
        return r


def _vaciar(lay):
    while lay.count():
        it = lay.takeAt(0)
        w = it.widget()
        if w:
            w.hide()   # fuera ya: deleteLater tarda un ciclo y mientras se veía debajo de lo nuevo
            w.deleteLater()
        elif it.layout():
            _vaciar(it.layout())


# ================================================================ páginas
class FilaFichas(QScrollArea):
    """La fila de fichas de tema: sin barra de desplazamiento (fea); se mueve con la rueda o arrastrando."""
    def __init__(self):
        super().__init__()
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

    def wheelEvent(self, ev):
        b = self.horizontalScrollBar()
        b.setValue(b.value() - (ev.angleDelta().y() or ev.angleDelta().x()))


class PaginaRejilla(QWidget):
    """Cabecera (atrás, título, botones), fila de fichas (chips) y la cuadrícula o la lista. Todas las páginas de
    vídeos son esta, con otro contenido; «mas» (si la hay) trae la tanda siguiente al llegar abajo."""
    def __init__(self, ventana):
        super().__init__()
        self.ventana = ventana
        v = QVBoxLayout(self)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(0)
        cab = QHBoxLayout()
        cab.setContentsMargins(20, 10, 24, 4)
        self.atras = QPushButton("←")
        self.atras.setObjectName("icono")
        self.atras.setToolTip("Atrás")
        self.atras.clicked.connect(ventana.volver)
        self.titulo = QLabel()
        self.titulo.setObjectName("titulo")
        cab.addWidget(self.atras)
        cab.addWidget(self.titulo)
        cab.addStretch(1)
        self.botones = QHBoxLayout()
        self.botones.setSpacing(8)
        cab.addLayout(self.botones)
        v.addLayout(cab)
        self.chips_caja = FilaFichas()
        self.chips_caja.setWidgetResizable(True)
        self.chips_caja.setFrameShape(QFrame.NoFrame)
        self.chips_caja.setFixedHeight(50)
        self.chips_caja.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        dentro = QWidget()
        self.chips = QHBoxLayout(dentro)
        self.chips.setContentsMargins(24, 6, 24, 6)
        self.chips.setSpacing(10)
        self.chips_caja.setWidget(dentro)
        self.extra = QVBoxLayout()   # la cabecera del canal va encima de sus pestañas, como en YouTube
        self.extra.setContentsMargins(24, 0, 24, 0)
        v.addLayout(self.extra)
        v.addWidget(self.chips_caja)
        self.aviso = QLabel()
        self.aviso.setObjectName("aviso")
        self.aviso.setWordWrap(True)
        self.aviso.hide()
        av = QHBoxLayout()
        av.setContentsMargins(24, 6, 24, 6)
        av.addWidget(self.aviso)
        v.addLayout(av)
        self.rejilla = Rejilla(ventana)
        self.rejilla.al_final.connect(self._al_final)
        v.addWidget(self.rejilla, 1)
        self.cabecera = None
        self.mas = None
        self.turno = 0   # cada página nueva invalida lo que estuviera cargando la anterior

    def preparar(self, titulo, atras=False, botones=(), chips=(), activo=None, al_chip=None, cabecera=None,
                 filas=False, vertical=False, aviso="", quitar=None):
        self.turno += 1
        if self.cabecera is not None and self.cabecera is not cabecera:
            self.cabecera.hide()
        if cabecera is not None:
            if self.cabecera is not cabecera:
                self.extra.addWidget(cabecera)
            cabecera.show()
        self.cabecera = cabecera
        self.titulo.setText(titulo)
        self.titulo.setVisible(bool(titulo))
        self.atras.setVisible(atras)
        _vaciar(self.botones)
        for b in botones:
            if isinstance(b, QWidget):
                self.botones.addWidget(b)
            else:
                texto, accion = b
                w = QPushButton(texto)
                w.clicked.connect(accion)
                self.botones.addWidget(w)
        _vaciar(self.chips)
        for c in chips:
            w = QPushButton(c)
            w.setObjectName("chip")
            w.setCheckable(True)
            w.setChecked(c == activo)
            w.clicked.connect(lambda _=False, c=c: al_chip and al_chip(c))
            w.setMinimumWidth(w.sizeHint().width())   # que la fila no las encoja hasta pisarse unas a otras
            self.chips.addWidget(w)
        self.chips.addStretch()
        self.chips_caja.setVisible(bool(chips))
        self.poner_aviso(aviso)
        self.rejilla.filas, self.rejilla.vertical, self.rejilla.quitar = filas, vertical, quitar
        self.rejilla.ancho_img = 246
        self.mas = None
        self.rejilla.limpiar("Cargando…")
        return self.turno

    def poner_aviso(self, texto):
        self.aviso.setText(texto)
        self.aviso.setVisible(bool(texto))

    def poner(self, elementos, motivos=None, aviso="", mas=None):
        """«mas»: función sin argumentos que devuelve la tanda siguiente (en otro hilo) o None si no hay más."""
        self.rejilla.poner(elementos, motivos, aviso)
        self.mas = mas

    def _al_final(self):
        if not self.mas:
            return
        turno, mas = self.turno, self.mas
        self.mas = None

        def listo(r, error):
            if turno != self.turno or error or not r:
                return
            elementos, motivos, siguiente = r
            self.rejilla.anadir(elementos, motivos)
            self.mas = siguiente
        en_hilo(mas, listo)


class ZonaVideo(QWidget):
    """Donde pinta mpv. mpv deja pasar el ratón (input-cursor-passthrough) y aquí se hace lo de YouTube: un clic pausa o
    sigue, doble clic pone o quita la pantalla completa, botón derecho abre el menú, la rueda cambia el volumen y, en
    pantalla completa, al mover el ratón aparece la barra de controles y el puntero se esconde a los 3 s quieto.
    (02/10/2026: con el ratón en manos de mpv, en Windows los clics no llegaban a nada.)"""
    def __init__(self, ventana):
        super().__init__()
        self.ventana = ventana
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.StrongFocus)
        self._quieto = QTimer(self, singleShot=True, interval=3000)
        self._quieto.timeout.connect(self._esconder)

    def mousePressEvent(self, ev):
        self.setFocus()
        if ev.button() == Qt.LeftButton and getattr(self.ventana, "rep", None):
            self.ventana.rep.alternar()
        elif ev.button() == Qt.RightButton and getattr(self.ventana, "rep", None):
            self.ventana._menu_video_reproductor()

    def mouseDoubleClickEvent(self, ev):
        if ev.button() == Qt.LeftButton:
            if getattr(self.ventana, "rep", None):
                self.ventana.rep.alternar()   # el primer clic del doble ya pausó: se deshace
            f = getattr(self.ventana, "flotante", None)
            if f is not None and f.zona is self:   # en la mini o en imagen en imagen: doble clic = volver a Cat-ode
                self.ventana.volver_de_flotante()
            else:
                self.ventana.pantalla_completa()

    def mouseMoveEvent(self, ev):
        f = getattr(self.ventana, "flotante", None)
        if f is not None and f.zona is self:
            return f.mostrar_mandos()
        self._mover(ev)

    def wheelEvent(self, ev):
        ps = getattr(self.ventana, "pshorts", None)
        if ps is not None and ps.zona is self:   # en los Shorts la rueda pasa de short
            return ps.wheelEvent(ev)
        b = getattr(self.ventana, "barra", None)
        if b:
            b.vol.setValue(max(0, min(130, b.vol.value() + (5 if ev.angleDelta().y() > 0 else -5))))

    def _mover(self, ev):
        self.unsetCursor()
        if getattr(self.ventana, "controles", None):
            self.ventana.controles.mostrar()

    def _esconder(self):
        if self.ventana.isFullScreen():
            self.ventana.barra.hide()
            self.setCursor(Qt.BlankCursor)


from PySide6.QtCore import QEvent as _QE
_EVENTOS_VENTANA = frozenset((_QE.KeyPress, _QE.ShortcutOverride, _QE.MouseButtonPress, _QE.Wheel))   # Wheel: Ctrl+rueda = zoom (05/10/2026)


class _Receptor:
    """Recibe una imagen de Imagenes sin ser una etiqueta (para el modo ambiente)."""
    def __init__(self, destino):
        self.destino = destino

    def setPixmap(self, p):
        self.destino(p)


class CartelVideo(QWidget):
    """En lugar del reproductor, cuando la pestaña tiene un vídeo que no es el que suena (03/10/2026: «al cambiar de
    pestaña se queda el vídeo que estaba reproduciéndose en primer plano»). La portada del vídeo, oscurecida, con el
    botón de reproducir en medio y, debajo, qué suena en otra pestaña. Un clic lo pone aquí."""
    def __init__(self, ventana):
        super().__init__()
        self.ventana = ventana
        self.portada = None
        self.e = None
        self.otro = ""
        self.setCursor(Qt.PointingHandCursor)
        self.setMinimumHeight(220)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

    def poner(self, e, otro=""):
        self.e, self.otro, self.portada = e, otro, None
        vid = motor.id_video(e.url)
        url = f"https://i.ytimg.com/vi/{vid}/hqdefault.jpg" if vid else e.miniatura
        self.ventana.imagenes.poner(url, _Receptor(self._portada), 640, 360)
        self.update()

    def _portada(self, p):
        self.portada = p
        self.update()

    def paintEvent(self, ev):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setRenderHint(QPainter.SmoothPixmapTransform)
        r = self.rect()
        p.fillRect(r, QColor("#000000"))
        if self.portada is not None and not self.portada.isNull():
            img = self.portada.scaled(r.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
            p.drawPixmap((r.width() - img.width()) // 2, (r.height() - img.height()) // 2, img)
        p.fillRect(r, QColor(0, 0, 0, 120))
        c = r.center()
        radio = 34 if self.underMouse() else 31
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(ROJO))
        p.drawEllipse(c, radio, radio)
        p.drawPixmap(c.x() - 15, c.y() - 15, icono("play", "#FFFFFF").pixmap(30, 30))
        from PySide6.QtGui import QLinearGradient
        g = QLinearGradient(0, r.height() - 70, 0, r.height())
        g.setColorAt(0, QColor(0, 0, 0, 0)); g.setColorAt(1, QColor(0, 0, 0, 200))
        p.fillRect(0, r.height() - 70, r.width(), 70, g)
        p.setPen(QColor("#FFFFFF"))
        f = p.font(); f.setPointSizeF(10.5); p.setFont(f)
        texto = f"Suena en otra pestaña: «{self.otro}»" if self.otro else "Reproducir aquí"
        p.drawText(r.adjusted(20, 0, -20, -18), Qt.AlignHCenter | Qt.AlignBottom,
                   p.fontMetrics().elidedText(texto, Qt.ElideRight, r.width() - 40))
        p.end()

    def enterEvent(self, ev):
        self.update()

    def leaveEvent(self, ev):
        self.update()

    def mousePressEvent(self, ev):
        if ev.button() == Qt.LeftButton and self.e is not None:
            self.ventana.reproducir_aqui(self.e)


class PaginaVideo(QWidget):
    """La página del vídeo: el reproductor arriba, debajo título, canal, botones, descripción, capítulos y comentarios;
    a la derecha «A continuación» (con la cola, si hay) y la reproducción automática."""
    def __init__(self, ventana):
        super().__init__()
        self.ventana = ventana
        from PySide6.QtWidgets import QGridLayout
        # 03/10/2026: rejilla para poder alternar con el MODO CINE (vídeo a todo el ancho; debajo, la info y «A continuación»)
        lay = QGridLayout(self)
        lay.setContentsMargins(20, 10, 12, 0)
        lay.setHorizontalSpacing(18)
        lay.setVerticalSpacing(0)
        self.col_video = QWidget()   # el vídeo (o su portada)
        izq = QVBoxLayout(self.col_video)
        izq.setContentsMargins(0, 0, 0, 0)
        izq.setSpacing(0)
        # 03/10/2026: cada pestaña tiene su reproductor y su zona (varias pueden sonar a la vez); se ve la de la pestaña
        # activa y las demás siguen sonando escondidas
        self.zonas = QStackedWidget()
        self.zonas.setMinimumHeight(220)
        self.zonas.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.video = self.nueva_zona()   # la zona de la pestaña activa
        izq.addWidget(self.zonas, 5)
        self.cartel = CartelVideo(ventana)   # en su sitio cuando el vídeo de esta pestaña no es el que suena
        self.cartel.hide()
        izq.addWidget(self.cartel, 5)
        self.setAttribute(Qt.WA_OpaquePaintEvent)   # pinta su fondo entero (paintEvent): lo de encima nunca se acumula
        from .efectos import Ambiente
        self.ambiente = Ambiente(self)   # los colores del vídeo, difuminados, detrás del reproductor y del título
        self._receptor = _Receptor(self.ambiente.poner)
        self.info = QScrollArea()
        self.info.setObjectName("infoVideo")
        self.info.setStyleSheet("QScrollArea#infoVideo, QScrollArea#infoVideo > QWidget, QScrollArea#infoVideo > QWidget > QWidget#contInfo"
                                " { background: transparent; }")
        self.info.setWidgetResizable(True)
        suavizar(self.info)
        self.info.setFrameShape(QFrame.NoFrame)
        self.info.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        cont = QWidget()
        cont.setObjectName("contInfo")
        cont.setMinimumWidth(300)
        iv = QVBoxLayout(cont)
        iv.setContentsMargins(0, 10, 8, 20)
        iv.setSpacing(10)
        self.titulo = QLabel()
        self.titulo.setObjectName("tituloVideo")
        self.titulo.setWordWrap(True)
        self.titulo.setMinimumWidth(200)
        self.titulo.setTextInteractionFlags(Qt.TextSelectableByMouse)
        iv.addWidget(self.titulo)
        # 03/10/2026: visualizaciones y fecha BAJO EL TÍTULO, a la vista (estaban abajo, en gris pequeño: «no los veo»)
        self.resumen = QLabel()
        self.resumen.setStyleSheet("font-size: 14px; color: #DDDDDD; padding-bottom: 2px;")
        self.resumen.setTextInteractionFlags(Qt.TextSelectableByMouse)
        iv.addWidget(self.resumen)
        fila = QHBoxLayout()
        fila.setSpacing(10)
        self.avatar = QLabel()
        self.avatar.setFixedSize(40, 40)
        self.avatar.setCursor(Qt.PointingHandCursor)
        self.avatar.mousePressEvent = lambda ev: self._ir_canal(ev)
        fila.addWidget(self.avatar)
        cv = QVBoxLayout()
        cv.setSpacing(0)
        self.canal = QLabel()
        self.canal.setStyleSheet("font-weight: bold; font-size: 15px;")
        self.canal.setCursor(Qt.PointingHandCursor)
        self.canal.mousePressEvent = lambda ev: self._ir_canal(ev)
        self.subs = QLabel()
        self.subs.setObjectName("gris")
        cv.addWidget(self.canal)
        cv.addWidget(self.subs)
        fila.addLayout(cv)
        self.suscribir = QPushButton()
        self.suscribir.clicked.connect(self._suscribir)
        fila.addSpacing(12)
        fila.addWidget(self.suscribir)
        self.fulminar = QPushButton("⊘  Fulminar canal"); self.fulminar.setToolTip("No volver a ver nada de este canal ni de su entorno")
        self.fulminar.clicked.connect(self._fulminar)
        fila.addSpacing(8)
        fila.addWidget(self.fulminar)
        fila.addStretch(1)
        iv.addLayout(fila)
        fila = QHBoxLayout()   # los botones, debajo del canal (en una sola fila no cabían sin ensanchar la ventana)
        fila.setSpacing(8)
        self.megusta = QPushButton("👍  Me gusta")
        self.megusta.setCheckable(True)
        self.megusta.clicked.connect(lambda: self._alternar("megusta", self.megusta, "Añadido a «Me gusta»", "Quitado de «Me gusta»"))
        self.megusta.setToolTip("Me gusta (solo en Cat-ode: no se manda a YouTube)")
        self.nomegusta = QPushButton("👎  No me gusta")   # 03/10/2026: local; resta a ese canal en «Para ti»
        self.nomegusta.setCheckable(True)
        self.nomegusta.setToolTip("No me gusta (solo en Cat-ode: no se manda a YouTube; ese canal sale menos en «Para ti»)")
        self.nomegusta.clicked.connect(lambda: self._alternar("nomegusta", self.nomegusta, "Marcado «No me gusta»", "Quitado «No me gusta»"))
        self.compartir = QPushButton("↗  Compartir")
        self.compartir.clicked.connect(self._compartir)
        self.despues = QPushButton("🕒  Ver más tarde")
        self.despues.setCheckable(True)
        self.despues.clicked.connect(lambda: self._alternar("despues", self.despues, "Guardado en «Ver más tarde»", "Quitado de «Ver más tarde»"))
        self.guardar = QPushButton("➕  Guardar")
        self.guardar.clicked.connect(self._menu_de_e)
        self.descargar = QPushButton("⬇  Descargar")
        self.descargar.clicked.connect(self._descargar)
        self.mas = QPushButton("⋯")
        self.mas.clicked.connect(lambda: self.e and menu_video(ventana, self.e).exec(self.mas.mapToGlobal(self.mas.rect().bottomLeft())))
        for b in (self.megusta, self.nomegusta, self.compartir, self.despues, self.guardar, self.descargar, self.mas):
            fila.addWidget(b)
        fila.addStretch(1)
        iv.addLayout(fila)
        caja = QFrame()
        caja.setObjectName("caja")
        cl = QVBoxLayout(caja)
        cl.setContentsMargins(14, 10, 14, 12)
        self.datos = fichas.PanelDatos(lambda u, **k: ventana.abrir_enlace(u, **k), self._desplegado)
        cl.addWidget(self.datos)
        self.descripcion = QLabel()
        self.descripcion.setWordWrap(True)
        self.descripcion.setTextFormat(Qt.RichText)
        self.descripcion.setTextInteractionFlags(Qt.TextSelectableByMouse | Qt.LinksAccessibleByMouse)
        self.descripcion.linkActivated.connect(lambda u: ventana.abrir_enlace(u))
        fichas.central_en_enlaces(self.descripcion, lambda u: ventana.abrir_enlace(u, nueva=True))
        cl.addWidget(self.descripcion)
        self.ver_desc = QPushButton("…más")
        self.ver_desc.setObjectName("icono")
        self.ver_desc.setStyleSheet("font-size: 14px; font-weight: bold;")
        self.ver_desc.clicked.connect(self._alternar_desc)
        cl.addWidget(self.ver_desc, 0, Qt.AlignLeft)
        iv.addWidget(caja)
        self.cap_titulo = QLabel("Capítulos")
        self.cap_titulo.setObjectName("seccion")
        iv.addWidget(self.cap_titulo)
        self.capitulos = QHBoxLayout()
        self.capitulos.setSpacing(8)
        capw = QWidget()
        capw.setLayout(self.capitulos)
        self.cap_caja = QScrollArea()
        self.cap_caja.setWidgetResizable(True)
        self.cap_caja.setFrameShape(QFrame.NoFrame)
        self.cap_caja.setFixedHeight(64)
        self.cap_caja.setWidget(capw)
        iv.addWidget(self.cap_caja)
        # 03/10/2026: transcripción (los subtítulos del vídeo como texto con su minuto, con buscador; clic = saltar ahí)
        self.tr_boton = QPushButton("▸  Transcripción")
        self.tr_boton.setStyleSheet("text-align: left; padding: 4px 10px;")
        self.tr_boton.clicked.connect(self._alternar_transcripcion)
        iv.addWidget(self.tr_boton, 0, Qt.AlignLeft)
        self.tr_caja = QWidget()
        tl = QVBoxLayout(self.tr_caja)
        tl.setContentsMargins(0, 0, 0, 0)
        tl.setSpacing(6)
        self.tr_buscar = QLineEdit()
        self.tr_buscar.setPlaceholderText("Buscar en la transcripción…")
        self.tr_buscar.setClearButtonEnabled(True)
        self.tr_buscar.textChanged.connect(self._filtrar_transcripcion)
        tl.addWidget(self.tr_buscar)
        self.tr_lista = QListWidget()
        self.tr_lista.setFixedHeight(300)
        self.tr_lista.setWordWrap(True)
        self.tr_lista.itemClicked.connect(lambda it: self.e and self.ventana.saltar(self.e.url, it.data(Qt.UserRole)))
        self.tr_lista.viewport().installEventFilter(self)   # 05/10/2026: botón central = ese minuto en pestaña nueva
        tl.addWidget(self.tr_lista)
        self.tr_aviso = QLabel()
        self.tr_aviso.setObjectName("gris")
        tl.addWidget(self.tr_aviso)
        self.tr_caja.hide()
        self._tr_url = None
        iv.addWidget(self.tr_caja)
        self.com_titulo = QLabel("Comentarios")
        self.com_titulo.setObjectName("seccion")
        iv.addWidget(self.com_titulo)
        self.comentarios = QVBoxLayout()
        self.comentarios.setSpacing(14)
        iv.addLayout(self.comentarios)
        self.com_mas = QPushButton("Cargar comentarios")
        self.com_mas.clicked.connect(self._cargar_comentarios)
        iv.addWidget(self.com_mas, 0, Qt.AlignLeft)
        iv.addStretch()
        self.info.setWidget(cont)
        self.lado = QWidget()
        self.lado.setMinimumWidth(380)
        self.lado.setMaximumWidth(460)
        dv = QVBoxLayout(self.lado)
        dv.setContentsMargins(0, 0, 0, 0)
        cab = QHBoxLayout()
        t = QLabel("A continuación")
        t.setObjectName("seccion")
        cab.addWidget(t)
        cab.addStretch()
        self.automatica = QCheckBox("Reproducción automática")
        self.automatica.setChecked(ventana.ajustes.get("automatica", True))
        self.automatica.toggled.connect(lambda s: (ventana.ajustes.__setitem__("automatica", s), ventana.guardar_ajustes()))
        cab.addWidget(self.automatica)
        dv.addLayout(cab)
        self.cola_titulo = QLabel()
        self.cola_titulo.setObjectName("gris")
        dv.addWidget(self.cola_titulo)
        self.cola = QListWidget()
        self.cola.setMaximumHeight(170)
        self.cola.itemClicked.connect(lambda it: ventana.rep.saltar_a(it.data(Qt.UserRole)))
        # 05/10/2026: la cola como en YouTube: se reordena arrastrando, Supr o clic derecho quita, central = pestaña nueva
        self.cola.setDragDropMode(QAbstractItemView.InternalMove)
        self.cola.model().rowsMoved.connect(lambda *_: self._cola_reordenada())
        self.cola.setContextMenuPolicy(Qt.CustomContextMenu)
        self.cola.customContextMenuRequested.connect(self._menu_cola)
        QShortcut(QKeySequence(Qt.Key_Delete), self.cola, activated=lambda: self.cola.currentItem() and self._quitar_de_cola(self.cola.currentItem()),
                  context=Qt.WidgetShortcut)
        self.cola.viewport().installEventFilter(self)
        dv.addWidget(self.cola)
        self.relacionados = Rejilla(ventana, filas=True)
        self.relacionados.ancho_img = 168
        self.relacionados.al_final.connect(self._mas_relacionados)   # 06/10/2026: «A continuación» no se acaba
        self.relacionados.v.setContentsMargins(0, 4, 4, 12)
        dv.addWidget(self.relacionados, 1)
        self.cine = False
        self.colocar_cine(ventana.ajustes.get("cine", False))
        self.ficha = None
        self.e = None
        self.cargando = None
        self.rel = []
        self.token_com = None
        self.desc_abierta = False

    # ---- cargar ----

    def _mas_relacionados(self):
        """06/10/2026 («la lista de vídeos a ver es cortísima, tiene que autogenerarse al ir haciendo scroll»): al llegar
        al final de «A continuación» se piden los relacionados de un vídeo de la propia lista que aún no se haya usado
        como semilla (en orden) y se añaden sin repetir. Tres tandas vacías seguidas: se acabó para este vídeo."""
        rel = getattr(self, "rel", None) or []
        i = getattr(self, "_rel_semilla", 0)
        if getattr(self, "_rel_vacias", 0) >= 3 or i >= len(rel):
            return
        self._rel_semilla = i + 1
        de = rel

        def listo(r, error):
            if self.rel is not de:   # ya es otro vídeo
                return
            ya = {x.url for x in self.rel}
            ocultos = self.ventana.datos.ocultos()
            nuevos = []
            for x in r or []:
                if x.url in ya or x.url in ocultos or getattr(x, "tipo", "VIDEO") != "VIDEO":
                    continue
                ya.add(x.url)
                nuevos.append(x)
            if nuevos:
                self._rel_vacias = 0
                self.rel.extend(nuevos)
                self.relacionados.anadir(nuevos)
            else:
                self._rel_vacias = getattr(self, "_rel_vacias", 0) + 1
                self.relacionados._pidiendo = False
                self._mas_relacionados()
        en_hilo(motor.relacionados, listo, rel[i].url)
    def paintEvent(self, ev):
        p = QPainter(self)
        p.fillRect(self.rect(), QColor("#0F0F0F"))
        self.ambiente.pintar(p, self.video.geometry())
        p.end()

    def colocar_cine(self, cine):
        """Normal: vídeo e info a la izquierda (7), «A continuación» a la derecha (3). Cine (03/10/2026, como la «t» de
        YouTube): el vídeo a todo el ancho y, debajo, la info a la izquierda y «A continuación» a la derecha."""
        lay = self.layout()
        for w in (self.col_video, self.info, self.lado):
            lay.removeWidget(w)
        if cine:
            lay.addWidget(self.col_video, 0, 0, 1, 2)
            lay.addWidget(self.info, 1, 0)
            lay.addWidget(self.lado, 1, 1)
            lay.setRowStretch(0, 6); lay.setRowStretch(1, 4)
        else:
            lay.addWidget(self.col_video, 0, 0)
            lay.addWidget(self.info, 1, 0)
            lay.addWidget(self.lado, 0, 1, 2, 1)
            lay.setRowStretch(0, 5); lay.setRowStretch(1, 4)
        lay.setColumnStretch(0, 7); lay.setColumnStretch(1, 3)
        lay.invalidate(); lay.activate()   # recolocar ya, sin esperar al siguiente cambio de tamaño
        self.cine = cine
        c = getattr(self.ventana, "controles", None)
        if c is not None:
            c.cine.setToolTip("Modo normal (t)" if cine else "Modo cine (t)")
            c.colocar()

    def a_pantalla(self, completa):
        """Pantalla completa: el vídeo se queda con TODO (03/10/2026: los pesos de filas y columnas de colocar_cine seguían
        guardando el sitio de la info y de «A continuación», ya ocultas, y el vídeo se quedaba en 1344×576 arriba a la izquierda)."""
        lay = self.layout()
        if completa:
            lay.setRowStretch(1, 0); lay.setColumnStretch(1, 0)
            lay.invalidate(); lay.activate()
        else:
            self.colocar_cine(self.cine)

    def nueva_zona(self):
        """Donde pinta el mpv de una pestaña; el ratón lo atiende Cat-ode (mpv lo deja pasar)."""
        z = ZonaVideo(self.ventana)
        z.setAttribute(Qt.WA_NativeWindow)
        z.setAttribute(Qt.WA_DontCreateNativeAncestors)
        z.setStyleSheet("background: black;")
        z.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.zonas.addWidget(z)
        if getattr(self.ventana, "controles", None) is not None:   # los mandos siguen también a esta zona
            z.installEventFilter(self.ventana.controles)
        return z

    def ver_zona(self, z):
        self.video = z
        if self.zonas.indexOf(z) >= 0:   # si está en la flotante (mini / imagen en imagen) no se puede enseñar aquí
            self.zonas.setCurrentWidget(z)

    def cargar(self, e):
        self.e = e
        url = e.url
        self.ambiente.poner(None)
        if e.miniatura:
            self.ventana.imagenes.poner(e.miniatura, self._receptor, 320, 180)
        self.cargando = url
        self.titulo.setText(e.titulo or "Cargando…")
        self.canal.setText(e.autor)
        self.subs.setText("")
        self.resumen.setText("")
        self.megusta.setText("👍  Me gusta"); self.nomegusta.setText("👎  No me gusta")
        self.avatar.clear()
        self.datos.limpiar()
        self.descripcion.setText("")
        self.desc_abierta = False
        self.ver_desc.hide()
        self.relacionados.poner([], aviso="Cargando…")
        self.rel = []
        _vaciar(self.capitulos)
        self.cap_titulo.hide()
        self.cap_caja.hide()
        _vaciar(self.comentarios)
        self.token_com = None
        self.com_mas.setText("Cargar comentarios")
        self.com_mas.show()
        self.com_titulo.setText("Comentarios")
        self._botones()
        self.refrescar_cola()

        def listo(f, error):
            if url != self.cargando:
                return
            if error or not f:
                self.titulo.setText(e.titulo or "No he podido cargar la ficha de este vídeo")
                self.relacionados.poner([], aviso="No he podido traer los relacionados.")
                return
            self.ficha = f
            if not self.e.titulo or not self.e.autor:   # abierto desde un enlace: el elemento se completa con la ficha
                for campo, valor in (("titulo", f["titulo"]), ("autor", f["autor"]), ("autorUrl", f["autorUrl"]),
                                     ("miniatura", self.e.miniatura or f["miniatura"])):
                    setattr(self.e, campo, valor)   # es el mismo objeto que está en la cola: la barra y el historial lo ven
                rep = self.ventana.rep
                if rep.actual is self.e:
                    self.ventana.datos.visto(self.e)
            self.titulo.setText(f["titulo"])
            self.canal.setText(f["autor"])
            self.subs.setText(f.get("canalSuscriptores", ""))
            self._pintar_resumen(f, None)
            if f.get("avatar"):
                self.ventana.imagenes.poner(f["avatar"], self.avatar, 40, 40, redonda=True)
            self.datos.poner_ficha(f)
            self._poner_desc(f.get("descripcionHtml") or f["descripcion"])
            self._botones()
            # 22/10/2026 (3.8): «la primera que sugiere es la misma que has buscado»: la misma canción, al final
            self.rel = cancion.ordenar(list(f["relacionados"]), {"url": f.get("url", ""), "titulo": f.get("titulo", ""),
                                                                 "autor": f.get("autor", "")}, getattr(self.ventana.rep, "sonados", []))
            self._rel_semilla, self._rel_vacias = 0, 0
            ocultos = self.ventana.datos.ocultos()
            self.relacionados.poner([r for r in self.rel if r.url not in ocultos])
            caps = f.get("capitulos") or []
            if caps:
                self.cap_titulo.setText(f"Capítulos ({len(caps)})")
                for s, nombre in caps:
                    b = QPushButton(f"{motor.tiempo(s)}\n{nombre[:38]}")
                    b.setObjectName("chip")
                    b.setToolTip(nombre)
                    b.clicked.connect(lambda _=False, s=s: self.ventana.saltar(url, s))
                    # 05/10/2026: botón central = ese minuto en pestaña nueva (en YouTube son enlaces con t=)
                    b.mousePressEvent = (lambda ev, b=b, s=s: self.ventana.minuto_en_pestana(url, s) if ev.button() == Qt.MiddleButton
                                         else QPushButton.mousePressEvent(b, ev))
                    b.setMinimumWidth(b.sizeHint().width())
                    self.capitulos.addWidget(b)
                self.capitulos.addStretch()
                self.cap_titulo.show()
                self.cap_caja.show()
            fichas.en_fondo(md.completo, lambda c: url == self.cargando and c and (self.datos.poner_completo(c), self._pintar_resumen(self.ficha, c)), url)
        en_hilo(motor.ficha, listo, url)

    def _poner_desc(self, html):
        self._desc = html or ""
        corto = len(re.sub("<[^>]+>", "", self._desc)) > 260 or self._desc.count("<br") > 3
        self.ver_desc.setVisible(corto)
        self._pintar_desc()

    def _pintar_desc(self):
        if self.desc_abierta or not self.ver_desc.isVisible():
            self.descripcion.setText(self._desc)
            self.ver_desc.setText("Mostrar menos")
        else:
            lineas = re.split(r"<br\s*/?>", self._desc)[:3]
            self.descripcion.setText("<br>".join(lineas))
            self.ver_desc.setText("…más")

    def _alternar_desc(self):
        self.desc_abierta = not self.desc_abierta
        self._pintar_desc()

    def _desplegado(self, abierto):
        """Con «Datos» abierto, la descripción ya va dentro: no se repite debajo."""
        self.descripcion.setVisible(not abierto)
        self.ver_desc.setVisible(not abierto and bool(getattr(self, "_desc", "")) and len(self._desc) > 260)

    # ---- comentarios ----
    def _cargar_comentarios(self):
        url, token = self.cargando, self.token_com
        self.com_mas.setText("Cargando…")

        def listo(r, error):
            if url != self.cargando:
                return
            if error or not r:
                self.com_mas.setText("No he podido traer los comentarios · reintentar")
                return
            lista, self.token_com = r
            for c in lista:
                self.comentarios.addWidget(self._comentario(c))
            self.com_mas.setText("Más comentarios")
            self.com_mas.setVisible(bool(self.token_com))
            if not lista and not self.comentarios.count():
                self.comentarios.addWidget(QLabel("Este vídeo no tiene comentarios (o están desactivados)."))
        en_hilo(motor.comentarios, listo, url, token)

    def _comentario(self, c):
        w = QWidget()
        h = QHBoxLayout(w)
        h.setContentsMargins(0, 0, 0, 0)
        foto = QLabel()
        foto.setFixedSize(36, 36)
        self.ventana.imagenes.poner(c.get("foto", ""), foto, 36, 36, redonda=True)
        h.addWidget(foto, 0, Qt.AlignTop)
        v = QVBoxLayout()
        v.setSpacing(2)
        cab = QLabel(f"<b>{fichas._e(c.get('autor', ''))}</b>  <span style='color:#AAAAAA'>{fichas._e(c.get('cuando', ''))}</span>")
        v.addWidget(cab)
        t = QLabel(fichas._texto_con_enlaces(c.get("texto", "")))
        t.setWordWrap(True)
        t.setTextFormat(Qt.RichText)
        t.setTextInteractionFlags(Qt.TextSelectableByMouse | Qt.LinksAccessibleByMouse)
        t.linkActivated.connect(lambda u: self.ventana.abrir_enlace(u))
        fichas.central_en_enlaces(t, lambda u: self.ventana.abrir_enlace(u, nueva=True))
        v.addWidget(t)
        pie = []
        if c.get("megusta"):
            pie.append(f"Me gusta: {c['megusta']}")
        if c.get("respuestas"):
            pie.append(f"{c['respuestas']} respuestas")
        if pie:
            p = QLabel("   ".join(str(x) for x in pie))
            p.setObjectName("gris")
            v.addWidget(p)
        h.addLayout(v, 1)
        return w

    # ---- botones ----
    def _botones(self):
        d = self.ventana.datos
        url = (self.ficha or {}).get("autorUrl") if self.ficha and self.ficha.get("url") == self.cargando else (self.e.autorUrl if self.e else "")
        si = bool(url) and d.suscrito(url)
        self.suscribir.setText("Suscrito" if si else "Suscribirse")
        self.suscribir.setIcon(icono("campana") if si else icono("mas_uno", "#0F0F0F"))
        self.suscribir.setObjectName("" if si else "principal")
        self.suscribir.style().unpolish(self.suscribir); self.suscribir.style().polish(self.suscribir)   # que coja el estilo nuevo
        self.suscribir.style().unpolish(self.suscribir)
        self.suscribir.style().polish(self.suscribir)
        self.suscribir.setVisible(bool(url))
        if self.e:
            self.megusta.setChecked(d.contiene("megusta", self.e.url))
            self.nomegusta.setChecked(d.contiene("nomegusta", self.e.url))
            self.despues.setChecked(d.contiene("despues", self.e.url))

    # ---- transcripción ----
    def _alternar_transcripcion(self):
        abierta = not self.tr_caja.isVisible()
        self.tr_caja.setVisible(abierta)
        self.tr_boton.setText(("▾" if abierta else "▸") + "  Transcripción")
        if abierta and self.e and self._tr_url != self.e.url:
            self._cargar_transcripcion()

    def _cargar_transcripcion(self):
        e, rep = self.e, self.ventana.rep
        self._tr_url = e.url
        self.tr_lista.clear()
        self.tr_aviso.setText("Cargando la transcripción…")
        x = rep.resolutor.guardado(e.url, rep.alto()) or {}
        subs = x.get("subs") or []
        # la pista: español sin traducir, luego la original, luego la primera
        url = next((u for u, n, l in subs if l == "es" and "tlang=" not in u), None) or \
            next((u for u, n, l in subs if "tlang=" not in u), None) or (subs[0][0] if subs else None)
        if not url:
            self.tr_aviso.setText("Este vídeo no tiene subtítulos: no hay transcripción.")
            return

        def bajar():
            import urllib.request
            try:
                return urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": motor.AGENTE}), timeout=20).read().decode("utf-8", "replace")
            except Exception:   # noqa: BLE001
                return ""

        def listo(texto, error):
            if self._tr_url != e.url:
                return
            lineas = _vtt_a_lineas(texto or "")
            if not lineas:
                self.tr_aviso.setText("No he podido leer los subtítulos de este vídeo.")
                return
            for s, t in lineas:
                it = QListWidgetItem(f"{motor.tiempo(s)}   {t}")
                it.setData(Qt.UserRole, s)
                self.tr_lista.addItem(it)
            self.tr_aviso.setText(f"{len(lineas)} líneas · clic en una para ir a ese momento")
            self._filtrar_transcripcion(self.tr_buscar.text())
        en_hilo(bajar, listo)

    def _filtrar_transcripcion(self, q):
        q = (q or "").strip().lower()
        for i in range(self.tr_lista.count()):
            it = self.tr_lista.item(i)
            it.setHidden(bool(q) and q not in it.text().lower())

    def _ir_canal(self, ev=None):
        url = (self.ficha or {}).get("autorUrl") or (self.e.autorUrl if self.e else "")
        if url:
            self.ventana.ir_al_canal(url, ev, (self.ficha or {}).get("autor") or (self.e.autor if self.e else ""))

    def _fulminar(self):
        f = self.ficha or {}
        url = f.get("autorUrl") or (self.e.autorUrl if self.e else "")
        nombre = f.get("autor") or (self.e.autor if self.e else "")
        self.ventana.rep.parar()
        self.ventana.fulminar(motor.Elemento("CANAL", url, nombre))
        self.ventana.volver()

    def _suscribir(self):
        url = (self.ficha or {}).get("autorUrl") or (self.e.autorUrl if self.e else "")
        if not url:
            return
        d = self.ventana.datos
        if d.suscrito(url):
            d.quitar(url)
            self.ventana.avisar("Suscripción anulada")
        else:
            d.suscribir(motor.Elemento("CANAL", url, self.canal.text(), miniatura=(self.ficha or {}).get("avatar", "")))
            self.ventana.avisar("Suscrito")
        self._botones()
        self.ventana.pintar_canales()

    def _alternar(self, col, boton, si, no):
        if not self.e:
            return
        d = self.ventana.datos
        boton.setChecked(d.alternar(col, self.e))
        if boton.isChecked() and col in ("megusta", "nomegusta"):   # 👍 y 👎 se excluyen, como en YouTube
            otro, otro_boton = ("nomegusta", self.nomegusta) if col == "megusta" else ("megusta", self.megusta)
            if d.contiene(otro, self.e.url):
                d.poner(otro, self.e.url, self.e, activo=False)
            otro_boton.setChecked(False)
        self.ventana.avisar(si if boton.isChecked() else no)

    def _pintar_resumen(self, f, c):
        """Bajo el título: visualizaciones · fecha; y los números en 👍 👎 (03/10/2026: antes abajo, en gris, «no los veo»)."""
        if not f:
            return
        e = (c or {}).get("extra") or {}
        v = (c or {}).get("votos") or {}
        vistas = e.get("vistas", f.get("vistasExactas", -1))
        partes = [f"{md.miles(vistas)} visualizaciones" if vistas is not None and vistas >= 0 else f.get("vistas", "")]
        if e.get("publicado"):
            partes.append(f"{md.fecha_hora(e['publicado'])} ({md.hace(e['publicado'])})")
        elif f.get("textoFecha"):
            partes.append(f["textoFecha"])
        self.resumen.setText("   ·   ".join(p for p in partes if p))
        mg = e.get("meGusta", -1)
        mg = mg if mg is not None and mg >= 0 else v.get("meGusta", -1)
        self.megusta.setText(f"👍  {md.miles(mg)}" if mg is not None and mg >= 0 else "👍  Me gusta")
        nmg = v.get("noMeGusta", -1)
        self.nomegusta.setText(f"👎  ≈ {md.miles(nmg)}" if nmg is not None and nmg >= 0 else "👎  No me gusta")

    def _compartir(self):
        if not self.e:
            return
        rep = self.ventana.rep
        segundos = rep.pos if rep.actual is not None and motor.id_video(rep.actual.url) == motor.id_video(self.e.url) else 0
        menu_compartir(self.ventana, self.e, segundos, self).exec(self.compartir.mapToGlobal(self.compartir.rect().bottomLeft()))

    def _menu_de_e(self):
        if not self.e:
            return
        m = menu_video(self.ventana, self.e)
        listas = next((a.menu() for a in m.actions() if a.menu() and "lista" in a.text().lower()), None)
        (listas or m).exec(self.guardar.mapToGlobal(self.guardar.rect().bottomLeft()))

    def _descargar(self):
        if not self.e:
            return
        m = QMenu(self)
        for alto in (360, 720, 1080):
            m.addAction(f"Vídeo {alto}p", lambda a=alto: self.ventana.descargar(self.e, False, a))
        m.addAction("Solo el sonido (m4a)", lambda: self.ventana.descargar(self.e, True))
        m.exec(self.descargar.mapToGlobal(self.descargar.rect().bottomLeft()))

    def eventFilter(self, obj, ev):
        from PySide6.QtCore import QEvent
        if ev.type() != QEvent.MouseButtonPress or ev.button() != Qt.MiddleButton or not hasattr(self, "cola"):
            return super().eventFilter(obj, ev)
        if obj is self.tr_lista.viewport():
            it = self.tr_lista.itemAt(ev.position().toPoint())
            if it is not None and self.e:
                self.ventana.minuto_en_pestana(self.e.url, it.data(Qt.UserRole))
            return True
        if obj is self.cola.viewport():
            it = self.cola.itemAt(ev.position().toPoint())
            rep = self.ventana.rep
            if it is not None and 0 <= it.data(Qt.UserRole) < len(rep.cola):
                self.ventana.nueva_pestana(rep.cola[it.data(Qt.UserRole)])
            return True
        return super().eventFilter(obj, ev)

    def _cola_reordenada(self):
        """Tras arrastrar: la cola del reproductor en el orden nuevo (el que suena sigue siendo el mismo)."""
        rep = self.ventana.rep
        orden = [self.cola.item(j).data(Qt.UserRole) for j in range(self.cola.count())]
        if sorted(orden) != list(range(len(rep.cola))):
            return self.refrescar_cola()
        actual = rep.cola[rep.i] if 0 <= rep.i < len(rep.cola) else None
        rep.cola[:] = [rep.cola[j] for j in orden]
        if actual is not None:
            rep.i = next(j for j, e in enumerate(rep.cola) if e is actual)
        QTimer.singleShot(0, self.refrescar_cola)

    def _quitar_de_cola(self, it):
        rep = self.ventana.rep
        j = it.data(Qt.UserRole)
        if not 0 <= j < len(rep.cola) or j == rep.i:   # el que suena no se quita (para eso, el siguiente)
            return
        rep.cola.pop(j)
        if j < rep.i:
            rep.i -= 1
        self.refrescar_cola()

    def _menu_cola(self, pos):
        it = self.cola.itemAt(pos)
        if it is None:
            return
        rep = self.ventana.rep
        j = it.data(Qt.UserRole)
        m = QMenu(self)
        m.addAction("Quitar de la cola", lambda: self._quitar_de_cola(it)).setEnabled(j != rep.i)
        if 0 <= j < len(rep.cola):
            m.addAction("Abrir en pestaña nueva", lambda: self.ventana.nueva_pestana(rep.cola[j]))
        m.exec(self.cola.viewport().mapToGlobal(pos))

    def refrescar_cola(self):
        rep = self.ventana.rep
        self.cola.clear()
        if rep.actual is None or len(rep.cola) < 2:
            self.cola.hide()
            self.cola_titulo.hide()
            return
        i0 = max(0, rep.i)
        self.cola_titulo.setText(f"Cola · {i0 + 1} de {len(rep.cola)}")
        for i, e in enumerate(rep.cola):
            it = QListWidgetItem(("▶  " if i == i0 else f"{i + 1}.  ") + e.titulo)
            it.setData(Qt.UserRole, i)
            if i == i0:
                it.setForeground(QColor(NARANJA))
            self.cola.addItem(it)
        self.cola.show()
        self.cola_titulo.show()


class Deslizador(QSlider):
    """Barra en la que un clic lleva directamente al punto pulsado (como YouTube), no a saltos."""
    def mousePressEvent(self, ev):
        from PySide6.QtWidgets import QStyle
        if ev.button() == Qt.LeftButton:
            v = QStyle.sliderValueFromPosition(self.minimum(), self.maximum(), int(ev.position().x()), self.width())
            self.setValue(v)
            self.sliderMoved.emit(v)
            self.clic.emit(v)
        super().mousePressEvent(ev)

    clic = Signal(int)
    pasa = Signal(int, object)   # 03/10/2026: valor bajo el ratón y punto global (la miniatura de ese momento)
    sale = Signal()
    texto = None   # función valor → texto: al pasar el ratón, la hora de ese punto

    def mouseMoveEvent(self, ev):
        from PySide6.QtWidgets import QStyle, QToolTip
        if self.texto:
            v = QStyle.sliderValueFromPosition(self.minimum(), self.maximum(), int(ev.position().x()), self.width())
            self.pasa.emit(v, ev.globalPosition().toPoint())
            t = self.texto(v)
            if t:
                QToolTip.showText(ev.globalPosition().toPoint(), t, self)
        super().mouseMoveEvent(ev)

    def leaveEvent(self, ev):
        self.sale.emit()
        super().leaveEvent(ev)


class Barra(QFrame):
    """La barra del reproductor: lo que suena y todos los mandos."""
    rep = property(lambda self: self.ventana.rep)   # el de la pestaña activa (cada pestaña tiene el suyo)
    def __init__(self, ventana):
        super().__init__()
        self.setObjectName("barra")
        self.ventana = ventana
        v = QVBoxLayout(self)
        v.setContentsMargins(12, 2, 12, 6)
        v.setSpacing(0)
        self.posicion = Deslizador(Qt.Horizontal)
        self.posicion.setRange(0, 1000)
        self.posicion.sliderReleased.connect(lambda: self.rep.dur and self.rep.ir_a(self.posicion.value() / 1000 * self.rep.dur))
        self.posicion.clic.connect(lambda x: self.rep.dur and self.rep.ir_a(x / 1000 * self.rep.dur))
        self.posicion.setMouseTracking(True)
        self.posicion.texto = lambda x: motor.tiempo(x / 1000 * self.rep.dur) if self.rep.dur else ""
        from .controles import VistaPrevia
        self.vista = VistaPrevia(ventana)   # 03/10/2026: la miniatura del momento al pasar por la barra de abajo
        self.posicion.pasa.connect(lambda v, p: self.vista.mostrar(self.rep, v / 1000, p))
        self.posicion.sale.connect(self.vista.hide)
        v.addWidget(self.posicion)
        h = QHBoxLayout()
        h.setSpacing(4)
        v.addLayout(h)
        self.img = QLabel()
        self.img.setFixedSize(80, 45)
        self.img.setCursor(Qt.PointingHandCursor)
        self.img.mousePressEvent = lambda ev: ventana.ir_a_lo_que_suena()
        self.texto = QLabel()
        self.texto.setFixedWidth(280)
        self.texto.setCursor(Qt.PointingHandCursor)
        self.texto.mousePressEvent = lambda ev: ventana.ir_a_lo_que_suena()
        h.addWidget(self.img)
        h.addWidget(self.texto)
        # siempre el reproductor de la pestaña activa (03/10/2026: atados al primero, mandaban en el primer vídeo)
        for texto, accion, ayuda in (("⏮", lambda: self.rep.anterior(), "Anterior (Mayús+P)"), ("⏯", lambda: self.rep.alternar(), "Pausa / seguir (espacio o k)"),
                                     ("⏭", lambda: self.rep.siguiente(), "Siguiente (Mayús+N)")):
            b = QPushButton(texto)
            b.setObjectName("icono")
            b.setToolTip(ayuda)
            b.clicked.connect(accion)
            h.addWidget(b)
            if texto == "⏯":
                self.play = b
        self.tiempo = QLabel("0:00 / 0:00")
        self.tiempo.setObjectName("gris")
        h.addWidget(self.tiempo)
        self.capitulo = QLabel()
        self.capitulo.setObjectName("gris")
        h.addWidget(self.capitulo, 1)

        def boton(texto, ayuda, menu=None, marcable=False, accion=None):
            b = QPushButton(texto)
            b.setObjectName("icono")
            b.setToolTip(ayuda)
            b.setCheckable(marcable)
            if menu:
                b.clicked.connect(lambda: menu().exec(b.mapToGlobal(b.rect().topLeft())))
            elif accion:
                b.clicked.connect(accion)
            h.addWidget(b)
            return b
        boton("⏱", "Velocidad", self._menu_velocidad)
        boton("CC", "Subtítulos", self._menu_subtitulos)
        boton("⚙", "Calidad", self._menu_calidad)
        self.bucle = boton("🔁", "Repetir este vídeo", marcable=True, accion=lambda: self.rep.bucle(self.bucle.isChecked()))
        self.sonido = boton("🎧", "Solo sonido (sin imagen: gasta mucho menos)", marcable=True,
                            accion=lambda: self.rep.solo_sonido(self.sonido.isChecked()))
        boton("☾", "Temporizador de apagado", self._menu_apagado)
        boton("☰", "Cola de reproducción", self._menu_cola)
        boton("↗", "Compartir (desde el minuto actual)", accion=self._compartir)
        self.mute = boton("🔊", "Silenciar (m)", accion=self._silencio)
        self.vol = Deslizador(Qt.Horizontal)
        self.vol.setObjectName("volumen")
        self.vol.setRange(0, 130)
        self.vol.setValue(ventana.ajustes.get("volumen", 80))
        self.vol.setFixedWidth(100)
        self.vol.valueChanged.connect(lambda x: self.rep.volumen(x))
        h.addWidget(self.vol)
        boton("⛶", "Pantalla completa (f)", accion=ventana.pantalla_completa)
        boton("✕", "Parar", accion=lambda: self.rep.parar())
        self.reloj = QTimer(self)
        self.reloj.timeout.connect(self.refrescar)
        self.reloj.start(500)
        self.hide()

    def _menu_velocidad(self):
        m = QMenu(self)
        actual = getattr(self.rep.mpv, "speed", 1.0) or 1.0
        for x in (0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0, 3.0):
            a = m.addAction(("✓ " if abs(actual - x) < 0.01 else "   ") + ("Normal" if x == 1 else f"{x:g}×"))
            a.triggered.connect(lambda _=False, x=x: self.rep.velocidad(x))
        return m

    def _menu_subtitulos(self):
        m = QMenu(self)
        m.addAction("Desactivados", lambda: self.rep.poner_subtitulos(None))
        pistas = self.rep.subtitulos()
        for sid, nombre in pistas:
            m.addAction(nombre, lambda s=sid: self.rep.poner_subtitulos(s))
        if not pistas:
            a = m.addAction("Este vídeo no tiene subtítulos")
            a.setEnabled(False)
        return m

    def _menu_calidad(self):
        """22/10/2026 (encargo 3.6): lo que dice el selector es lo que se ve (lo dice mpv), solo con las calidades que tiene
        el vídeo, y si lo que se ve no es lo elegido, el porqué."""
        m = QMenu(self)
        actual = self.ventana.ajustes.get("calidad", "auto")
        visto, motivo = self.rep.calidad_vista() if hasattr(self.rep, "calidad_vista") else (0, "")
        se_ve = f"se ve {visto}p" if visto else f"ahora {self.rep.alto_auto}p"
        a = m.addAction(("✓ " if actual == "auto" else "   ") + f"Automática ({se_ve}, según el tamaño)")
        a.triggered.connect(lambda: (self.rep.calidad("auto"), self.ventana.guardar_ajustes()))
        m.addSeparator()
        hay = getattr(self.rep, "niveles", None) or [144, 240, 360, 480, 720, 1080, 1440, 2160]
        if actual != "auto" and str(actual).isdigit() and int(actual) not in hay:
            a = m.addAction(f"✓ {actual}p · este vídeo no la tiene" + (f": se ve {visto}p" if visto else ""))
            a.setEnabled(False)
        for alto in hay:
            texto = f"{alto}p" + (" (4K)" if alto == 2160 else " HD" if alto >= 720 else "")
            if visto == alto and motivo:
                texto += f" · se ve ahora ({motivo})"
            a = m.addAction(("✓ " if alto == actual else "   ") + texto)
            a.triggered.connect(lambda _=False, h=alto: (self.rep.calidad(h), self.ventana.guardar_ajustes()))
        return m

    def _menu_apagado(self):
        m = QMenu(self)
        for x in (10, 15, 30, 45, 60, 90):
            m.addAction(f"Dentro de {x} min", lambda x=x: self.rep.apagar_en(x))
        m.addAction("Al acabar este vídeo", lambda: self.rep.apagar_en(-1))
        m.addSeparator()
        m.addAction("Quitar el temporizador", lambda: (self.rep.apagar_en(0), self.ventana.avisar("Temporizador quitado")))
        return m

    def _menu_cola(self):
        m = QMenu(self)
        rep = self.rep
        if not rep.cola:
            a = m.addAction("La cola está vacía")
            a.setEnabled(False)
        for i, e in enumerate(rep.cola):
            a = m.addAction(("▶ " if i == rep.i else f"{i + 1}. ") + e.titulo[:70])
            a.triggered.connect(lambda _=False, i=i: rep.saltar_a(i))
        if len(rep.cola) > 1:
            m.addSeparator()
            m.addAction("Guardar la cola como lista…", self.ventana.guardar_cola)
        return m

    def _compartir(self):
        if self.rep.actual:
            menu_compartir(self.ventana, self.rep.actual, self.rep.pos, self).exec(self.mapToGlobal(self.rect().topRight()))

    def _silencio(self):
        self.mute.setIcon(icono("silencio" if self.rep.silencio() else "volumen"))

    def refrescar(self):
        e = self.rep.actual
        if not self.ventana.isFullScreen():
            # en la página del vídeo los mandos van dentro del vídeo; en las demás, esta barra es el reproductor pequeño
            self.setVisible(e is not None and self.ventana.paginas.currentWidget() is not self.ventana.video)
        if e is None:
            return
        if self.texto.property("url") != e.url + e.titulo:
            self.texto.setProperty("url", e.url + e.titulo)
            t = fichas._e(e.titulo if len(e.titulo) < 70 else e.titulo[:68] + "…")
            self.texto.setText(f"<b>{t}</b><br><span style='color:#AAAAAA'>{fichas._e(e.autor)}</span>")
            self.ventana.imagenes.poner(e.miniatura, self.img, 80, 45)
        nombre = "play" if self.rep.pausa else "pausa"
        if self.play.property("icono") != nombre:
            self.play.setProperty("icono", nombre)
            self.play.setIcon(icono(nombre))
        self.tiempo.setText(f"{motor.tiempo(self.rep.pos)} / {motor.tiempo(self.rep.dur)}")
        caps = self.ventana.capitulos_de(e.url)
        nombre = ""
        for s, n in caps:
            if s <= self.rep.pos:
                nombre = n
        self.capitulo.setText(f"·  {nombre}" if nombre else "")
        if not self.posicion.isSliderDown() and self.rep.dur:
            self.posicion.setValue(int(self.rep.pos / self.rep.dur * 1000))


# ================================================================ la ventana
MENU = (("🏠  Inicio", "inicio"), ("⚡  Shorts", "shorts"), ("📺  Suscripciones", "suscripciones"),
        ("🧭  Explorar", "explorar"), None, ("Tú", None), ("🕘  Historial", "historial"), ("🕒  Ver más tarde", "despues"),
        ("👍  Vídeos que me gustan", "megusta"), ("☰  Listas", "listas"), ("🎵  Música", "musica"), ("⬇  Descargas", "descargas"), None,
        ("🐾  Para Nut", "nut"),
        ("⚙  Ajustes", "ajustes"))


class MenuLateral(QListWidget):
    """El panel de la izquierda (Inicio… Para Nut, Ajustes y los canales suscritos). 05/10/2026 (el autor: «no entiendo cómo
    no estaba contemplado»): el botón central del ratón, o Ctrl+clic, abre esa sección en una PESTAÑA NUEVA, como en el
    navegador; el clic normal sigue abriéndola en la pestaña actual."""
    def __init__(self, ventana):
        super().__init__()
        self.ventana = ventana

    def mousePressEvent(self, ev):
        if ev.button() == Qt.MiddleButton or (ev.button() == Qt.LeftButton and ev.modifiers() & Qt.ControlModifier):
            it = self.itemAt(ev.position().toPoint())
            clave = it.data(Qt.UserRole) if it is not None else None
            if clave:
                self.ventana.nueva_pestana()
                self.ventana.ir_seccion(clave)
                return ev.accept()
        super().mousePressEvent(ev)


class _FiltroSugerencias(QObject):
    """05/10/2026: las sugerencias del buscador como en el navegador: Ctrl+Enter o botón central = esa búsqueda en pestaña
    nueva; Mayús+Supr borra una búsqueda tuya (las «⟲») de la lista y del historial de búsquedas."""
    def __init__(self, ventana, completador):
        super().__init__(ventana)
        self.ventana, self.c = ventana, completador
        self.pop, self.vp = completador.popup(), completador.popup().viewport()
        self.pop.installEventFilter(self)
        self.vp.installEventFilter(self)
        ventana.campo.installEventFilter(self)   # en Windows las teclas llegan al campo, no al desplegable

    def _texto(self, indice):
        return indice.data() if indice is not None and indice.isValid() else ""

    def _en_pestana(self, t):
        self.pop.hide()
        if t:
            self.ventana.nueva_pestana(vacia=True)
            self.ventana.buscar(t)

    def eventFilter(self, obj, ev):
        from PySide6.QtCore import QEvent
        t = ev.type()
        if t not in (QEvent.KeyPress, QEvent.MouseButtonPress):
            return False
        pop = self.pop
        if t == QEvent.KeyPress and (obj is pop or (obj is self.ventana.campo and pop.isVisible())):
            k, mod = ev.key(), ev.modifiers()
            if k in (Qt.Key_Return, Qt.Key_Enter) and mod & Qt.ControlModifier:
                self._en_pestana(self._texto(pop.currentIndex()) or self.ventana.campo.text())
                return True
            if k == Qt.Key_Delete and mod & Qt.ShiftModifier:
                i = pop.currentIndex(); t = self._texto(i)
                if t.startswith("⟲  "):
                    self.ventana.datos.quitar(t.removeprefix("⟲  ").strip().lower(), "busquedas")
                    lista = self.ventana.modelo.stringList(); lista.remove(t); self.ventana.modelo.setStringList(lista)
                return True
        elif t == QEvent.MouseButtonPress and obj is self.vp and ev.button() == Qt.MiddleButton:
            self._en_pestana(self._texto(pop.indexAt(ev.position().toPoint())))
            return True
        return False


class BarraPestanas(QTabBar):
    """Las pestañas, como en el navegador: el botón central de la rueda sobre una la cierra (03/10/2026: el autor no podía)."""
    def __init__(self, ventana):
        super().__init__()
        self.ventana = ventana

    def mousePressEvent(self, ev):
        if ev.button() == Qt.MiddleButton:
            i = self.tabAt(ev.position().toPoint())
            from .reproductor import registro
            registro(f"botón central sobre la pestaña {i} de {self.count()} (en {ev.position().toPoint().x()},{ev.position().toPoint().y()})")
            if i >= 0:
                self.ventana.cerrar_pestana(i)
            return ev.accept()
        if ev.button() == Qt.LeftButton:
            # 05/10/2026: clic en el altavoz de la pestaña = silenciarla o devolverle el sonido, como en Chrome y Firefox
            p = ev.position().toPoint(); i = self.tabAt(p)
            if i >= 0 and not self.tabIcon(i).isNull():
                r = self.tabRect(i)
                if r.left() <= p.x() <= r.left() + 26:
                    self.ventana.silenciar_pestana(i)
                    return ev.accept()
        super().mousePressEvent(ev)

    def mouseDoubleClickEvent(self, ev):
        # 05/10/2026: doble clic en el hueco libre de la barra = pestaña nueva, como en el navegador
        if self.tabAt(ev.position().toPoint()) < 0:
            self.ventana.nueva_pestana()
            return ev.accept()
        super().mouseDoubleClickEvent(ev)

    def contextMenuEvent(self, ev):
        """05/10/2026: clic derecho en una pestaña: el menú de siempre del navegador (antes no había ninguno)."""
        i = self.tabAt(ev.pos())
        if i < 0:
            return
        v = self.ventana
        m = QMenu(self)
        m.addAction("Cerrar pestaña", lambda: v.cerrar_pestana(i))
        m.addAction("Cerrar las otras", lambda: v.cerrar_otras(i))
        m.addAction("Cerrar las de la derecha", lambda: v.cerrar_derecha(i))
        m.addSeparator()
        m.addAction("Duplicar", lambda: v.duplicar_pestana(i))
        m.addAction("Activar sonido" if getattr(v.reps[i], "_mute", False) else "Silenciar pestaña", lambda: v.silenciar_pestana(i))
        m.addSeparator()
        m.addAction("Reabrir pestaña cerrada  (Ctrl+Mayús+T)", v.reabrir_cerrada).setEnabled(bool(getattr(v, "_cerradas", None)))
        m.exec(ev.globalPos())


def _vtt_a_lineas(texto):
    """De un WebVTT a [(segundos, frase)], sin etiquetas ni repeticiones (los automáticos de YouTube repiten cada línea)."""
    lineas, ultimo = [], ""
    bloque_t = None
    for cruda in texto.splitlines():
        linea = cruda.strip()
        m = re.match(r"(\d+):(\d\d):(\d\d)[.,](\d{3})\s+-->", linea) or re.match(r"(\d\d):(\d\d)[.,](\d{3})\s+-->", linea)
        if m:
            g = m.groups()
            bloque_t = (int(g[0]) * 3600 + int(g[1]) * 60 + int(g[2]) + int(g[3]) / 1000) if len(g) == 4 else (int(g[0]) * 60 + int(g[1]) + int(g[2]) / 1000)
            continue
        if not linea or linea.startswith(("WEBVTT", "Kind:", "Language:", "NOTE")) or linea.isdigit() or bloque_t is None:
            continue
        frase = re.sub(r"<[^>]+>", "", linea).replace("&nbsp;", " ").replace("&amp;", "&").replace("&gt;", ">").replace("&lt;", "<").strip()
        if not frase or frase == ultimo:
            continue
        lineas.append((bloque_t, frase))
        ultimo = frase
    return lineas


class _ZonaPrevia(QWidget):
    """Donde pinta el mpv de la vista previa de una tarjeta: el ratón sigue contando como «dentro» de la tarjeta."""
    def __init__(self, previa):
        super().__init__(previa.ventana.centralWidget())
        self.previa = previa
        self.setAttribute(Qt.WA_NativeWindow)
        self.setAttribute(Qt.WA_DontCreateNativeAncestors)
        self.setStyleSheet("background: black;")
        self.setCursor(Qt.PointingHandCursor)
        self.setMouseTracking(True)

    def leaveEvent(self, ev):
        self.previa.comprobar()

    def mousePressEvent(self, ev):
        t = self.previa.tarjeta
        if ev.button() == Qt.LeftButton and t is not None:
            self.previa.parar()
            self.previa.ventana.abrir(t.e)
        elif ev.button() == Qt.MiddleButton and t is not None:
            self.previa.parar()
            self.previa.ventana.nueva_pestana(t.e)


class PreviaTarjeta:
    """Vista previa al posar el ratón sobre un vídeo (03/10/2026, como YouTube): tras un segundo quieto, un mpv aparte,
    sin sonido y a 360p, pinta el vídeo sobre la miniatura; al salir, se para. Se apaga en Ajustes."""
    def __init__(self, ventana):
        self.ventana = ventana
        self.zona = _ZonaPrevia(self)
        self.zona.hide()
        self.mpv = None
        self.tarjeta = None
        self._turno = 0
        self.reloj = QTimer(ventana, singleShot=True, interval=900)
        self.reloj.timeout.connect(self._empezar)

    def entrar(self, tarjeta):
        if not self.ventana.ajustes.get("vista_previa", True) or tarjeta.e.tipo != "VIDEO":
            return
        if self.tarjeta is not tarjeta:
            self.parar()
        self.tarjeta = tarjeta
        self.reloj.start()

    def comprobar(self):
        """El ratón ha salido de la tarjeta o de la zona: si no está en ninguna de las dos, se para."""
        t = self.tarjeta
        if t is None:
            return
        try:
            c = QCursor.pos()
            # underMouse(): lo que Qt sabe por los eventos de entrar/salir; QCursor.pos() no cuadra con el escalado de
            # pantalla de Linux (ProBook, Dell) y la vista previa se cancelaba sin decir nada (03/10/2026)
            dentro = t.underMouse() or self.zona.underMouse() or t.rect().contains(t.mapFromGlobal(c)) or \
                (self.zona.isVisible() and self.zona.rect().contains(self.zona.mapFromGlobal(c)))
        except RuntimeError:   # la tarjeta ya no existe
            dentro = False
        if not dentro:
            self.parar()

    def salir(self, tarjeta):
        if self.tarjeta is tarjeta:
            QTimer.singleShot(60, self.comprobar)   # un instante: el ratón puede haber pasado a la zona del vídeo

    def parar(self):
        self.reloj.stop()
        self._turno += 1
        self.tarjeta = None
        if self.mpv is not None:
            try:   # sin esperar: parar deshace la ventana de mpv y, en Windows, esperarlo colgaba la app (03/10/2026)
                self.mpv.command_async("stop")
            except Exception:   # noqa: BLE001
                pass
        self.zona.hide()

    def probar(self, tarjeta):
        """Para las pruebas: arranca la vista previa de esa tarjeta sin que el ratón esté encima."""
        self.parar()
        self.tarjeta = tarjeta
        self._empezar(forzar=True)

    def _empezar(self, forzar=False):
        try:
            self._empezar_de_verdad(forzar)
        except Exception as error:   # noqa: BLE001 (una tarjeta ya destruida, mpv sin arrancar…): nunca rompe la app
            from .reproductor import registro
            registro(f"vista previa: {repr(error)[:160]}")
            self.zona.hide()

    def _empezar_de_verdad(self, forzar):
        t = self.tarjeta
        if t is None:
            return
        try:
            if not t.isVisible() or (not forzar and not t.underMouse() and not t.rect().contains(t.mapFromGlobal(QCursor.pos()))):
                return
            r = t._rect_img()
            g = t.mapTo(self.ventana.centralWidget(), r.topLeft())
        except RuntimeError:
            return
        self.zona.setGeometry(QRect(g, r.size()))
        self.zona.show()
        self.zona.raise_()
        if self.mpv is None:
            from .reproductor import formato
            crudas = ["sub-langs=", "write-subs="]
            if motor.node():
                crudas.append(f"js-runtimes=node:{motor.node()}")
            ytdlp = os.path.join(os.path.dirname(sys.executable), "yt-dlp" + (".exe" if os.name == "nt" else ""))
            extra = {"ao": "null"} if os.environ.get("CATODE_MPV") == "ao=null" else {}
            if os.name != "nt":
                # 23/10/2026: como el reproductor (reproductor.py): la ventana es X11 (XWayland) y con el contexto de Wayland
                # mpv no pintaba en la miniatura sino en una ventana suya aparte («las quiero en la preview del vídeo»)
                extra.update(gpu_context="x11egl", hwdec_codecs="h264,hevc,vp8,vp9,mpeg2video,vc1")
            from .mpv_crear import crear_mpv   # 02/11/2026: también con un libmpv viejo (Debian 12)
            self.mpv = crear_mpv(wid=str(int(self.zona.winId())), ytdl=True, ytdl_format=formato(360), mute=True, osc=False,
                               input_cursor_passthrough="yes", input_vo_keyboard=False, hwdec="auto-safe", keep_open="no", idle="yes",
                               user_agent=motor.AGENTE, script_opts=f"ytdl_hook-ytdl_path={ytdlp},osc-idlescreen=no",
                               ytdl_raw_options=",".join(crudas), **extra)
        self._turno += 1
        turno = self._turno
        url, resolutor = t.e.url, self.ventana.rep.resolutor

        def resolver():
            try:
                x = resolutor.resolver(url, 360, fondo=True)
            except Exception:   # noqa: BLE001
                x = None
            fichas.en_ventana(lambda _: turno == self._turno and self.tarjeta is t and self._poner(x["ruta"] if x else url), None)
        threading.Thread(target=resolver, daemon=True).start()

    def _poner(self, ruta):
        try:
            self.mpv.command_async("loadfile", ruta, "replace")
            self.mpv.command_async("set", "pause", "no")
        except Exception:   # noqa: BLE001
            pass


class PaginaShorts(QWidget):
    """Shorts como YouTube (03/10/2026): uno a uno, en vertical, con la rueda o ↑ ↓ para pasar; al lado, título, canal,
    👍 👎, compartir y «ver como vídeo». La zona de mpv de la pestaña se trae aquí mientras dura y vuelve al salir."""
    def __init__(self, ventana):
        super().__init__()
        self.ventana, self.zona, self.e = ventana, None, None
        self._ultimo_giro = 0.0
        h = QHBoxLayout(self)
        h.setContentsMargins(20, 10, 20, 10)
        h.setSpacing(16)
        h.addStretch(1)
        self.marco = QWidget()
        self.marco.setStyleSheet("background: black; border-radius: 12px;")
        self.ml = QVBoxLayout(self.marco)
        self.ml.setContentsMargins(0, 0, 0, 0)
        h.addWidget(self.marco, 0)
        col = QVBoxLayout()
        col.setSpacing(8)
        self.titulo = QLabel()
        self.titulo.setWordWrap(True)
        self.titulo.setMaximumWidth(360)
        self.titulo.setStyleSheet("font-size: 16px; font-weight: 600;")
        self.canal = QLabel()
        self.canal.setObjectName("gris")
        self.canal.setCursor(Qt.PointingHandCursor)
        self.canal.mousePressEvent = lambda ev: self.e and self.e.autorUrl and self.ventana.ir_al_canal(self.e.autorUrl, ev, self.e.autor)
        self.aviso = QLabel("Cargando Shorts…")
        self.aviso.setObjectName("gris")
        self.aviso.setWordWrap(True)
        self.aviso.setMaximumWidth(360)
        col.addStretch(1)
        col.addWidget(self.titulo)
        col.addWidget(self.canal)
        col.addSpacing(6)
        fila = QHBoxLayout()
        self.megusta, self.nomegusta = QPushButton("👍"), QPushButton("👎")
        for b, col_ in ((self.megusta, "megusta"), (self.nomegusta, "nomegusta")):
            b.setCheckable(True)
            b.clicked.connect(lambda _=False, c=col_: self._voto(c))
            fila.addWidget(b)
        for texto, accion in (("↗  Compartir", self._compartir), ("▶  Ver como vídeo", self._como_video)):
            b = QPushButton(texto)
            b.clicked.connect(accion)
            fila.addWidget(b)
        fila.addStretch(1)
        col.addLayout(fila)
        nav = QHBoxLayout()
        for texto, accion in (("↑  Anterior", lambda: self.ventana.rep.anterior()), ("↓  Siguiente", lambda: self.ventana.rep.siguiente())):
            b = QPushButton(texto)
            b.clicked.connect(accion)
            nav.addWidget(b)
        nav.addStretch(1)
        col.addLayout(nav)
        col.addWidget(self.aviso)
        col.addStretch(1)
        h.addLayout(col, 0)
        h.addStretch(1)
        self.setFocusPolicy(Qt.StrongFocus)

    def tomar_zona(self, z):
        if self.zona is not None:
            return
        self.zona = z
        z.setParent(self.marco)
        self.ml.addWidget(z)
        z.show()

    def soltar_zona(self):
        z, self.zona = self.zona, None
        if z is not None:
            z.setParent(self.ventana.video.zonas)
            self.ventana.video.zonas.addWidget(z)
            if self.ventana.video.video is z:
                self.ventana.video.zonas.setCurrentWidget(z)
        return z

    def resizeEvent(self, ev):
        alto = max(240, self.height() - 24)
        self.marco.setFixedSize(int(alto * 9 / 16), alto)

    def poner(self, e):
        self.e = e
        self.titulo.setText(e.titulo or "")
        self.canal.setText(e.autor or "")
        d = self.ventana.datos
        self.megusta.setChecked(d.contiene("megusta", e.url))
        self.nomegusta.setChecked(d.contiene("nomegusta", e.url))

    def _voto(self, col):
        if not self.e:
            return
        d = self.ventana.datos
        si = d.alternar(col, self.e)
        otro = "nomegusta" if col == "megusta" else "megusta"
        if si and d.contiene(otro, self.e.url):
            d.poner(otro, self.e.url, self.e, activo=False)
        self.poner(self.e)

    def _compartir(self):
        if self.e:
            menu_compartir(self.ventana, self.e, self.ventana.rep.pos, self).exec(QCursor.pos())

    def _como_video(self):
        if self.e:
            self.ventana.abrir_video(self.e, sonar=False)

    def pasar(self, adelante):
        if time.time() - self._ultimo_giro < 0.4:   # un giro de rueda son varios eventos: uno por short
            return
        self._ultimo_giro = time.time()
        (self.ventana.rep.siguiente if adelante else self.ventana.rep.anterior)()

    def wheelEvent(self, ev):
        self.pasar(ev.angleDelta().y() < 0)

    def keyPressEvent(self, ev):
        if ev.key() in (Qt.Key_Down, Qt.Key_PageDown):
            self.pasar(True)
        elif ev.key() in (Qt.Key_Up, Qt.Key_PageUp):
            self.pasar(False)
        elif ev.key() in (Qt.Key_Space, Qt.Key_K):
            self.ventana.rep.alternar()
        else:
            super().keyPressEvent(ev)


class Flotante(QWidget):
    """El vídeo fuera de su sitio (03/10/2026): «mini» = minirreproductor en la esquina de la ventana al salir de la página
    del vídeo, como YouTube; «pip» = imagen en imagen, ventana del sistema sin marco siempre encima. La zona de mpv se
    reparenta aquí (conserva su ventana nativa: mpv sigue pintando) y vuelve a su sitio al cerrar o al volver al vídeo."""
    def __init__(self, ventana, zona, modo, pestana):
        if modo == "pip":
            super().__init__(None, Qt.Tool | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
        else:
            super().__init__(ventana.centralWidget())
        self.ventana, self.zona, self.modo, self.pestana = ventana, zona, modo, pestana
        self.setMouseTracking(True)
        self.setStyleSheet("background: black;")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        zona.setParent(self)
        lay.addWidget(zona)
        # los mandos, encima, al pasar el ratón: pausa, volver y cerrar
        self.mandos = QWidget(self)
        self.mandos.setStyleSheet("background: rgba(0,0,0,0.55); border-radius: 6px;")
        h = QHBoxLayout(self.mandos)
        h.setContentsMargins(6, 4, 6, 4)
        h.setSpacing(4)

        def b(nombre, ayuda, accion):
            x = QPushButton()
            x.setObjectName("controlVideo")
            x.setIcon(icono(nombre, "#FFFFFF"))
            x.setIconSize(QSize(20, 20))
            x.setFixedSize(30, 30)
            x.setToolTip(ayuda)
            x.setCursor(Qt.PointingHandCursor)
            x.setFocusPolicy(Qt.NoFocus)
            x.setStyleSheet("QPushButton { background: transparent; border: none; border-radius: 15px; } QPushButton:hover { background: rgba(255,255,255,0.2); }")
            x.clicked.connect(accion)
            h.addWidget(x)
            return x
        self.play = b("pausa", "Pausa / seguir", lambda: self.ventana.rep.alternar())
        b("completa", "Volver a Cat-ode", self.ventana.volver_de_flotante)
        b("parar", "Parar el vídeo", lambda: self.ventana.volver_de_flotante(parar=True))
        self.mandos.adjustSize()
        self.mandos.hide()
        # 22/10/2026 · orden del autor (20/10/2026): «cuando se quiere quitar el mini reproductor no hay manera de quitarlo
        # sin cerrarlo, busca una alternativa» (audio de Mateo: «si le doy a la X se me para todo»). Un ✕ que se ve SIEMPRE y
        # arrastrarla fuera de la ventana (más de media mini) la QUITAN y el vídeo SIGUE SONANDO; parar es el ■ de los mandos.
        self.quitar = None
        if modo == "mini":
            self.quitar = QPushButton("✕", self)
            self.quitar.setToolTip("Quitar el minirreproductor (sigue sonando); también arrastrándolo fuera")
            self.quitar.setCursor(Qt.PointingHandCursor)
            self.quitar.setFocusPolicy(Qt.NoFocus)
            self.quitar.setFixedSize(26, 26)
            self.quitar.setStyleSheet("QPushButton { background: rgba(0,0,0,0.6); color: white; border: none; border-radius: 13px; font-size: 14px; }"
                                      " QPushButton:hover { background: #FF7A00; color: black; }")
            self.quitar.clicked.connect(lambda: self.ventana.ocultar_flotante("✕"))
        self._fuera = False
        self._esconder = QTimer(self, singleShot=True, interval=2500)
        self._esconder.timeout.connect(self.mandos.hide)
        self._arrastre = None
        if modo == "pip":
            from PySide6.QtWidgets import QSizeGrip
            self.grip = QSizeGrip(self)
            self.grip.resize(16, 16)
            g = ventana.ajustes.get("pip_geometria")
            if g:
                from PySide6.QtCore import QByteArray
                self.restoreGeometry(QByteArray.fromBase64(g.encode()))
            else:
                self.resize(480, 270)
        else:
            self.resize(360, 203)
            self.recolocar()
        self._reloj = QTimer(self, interval=500)
        self._reloj.timeout.connect(lambda: self.play.setIcon(icono("play" if self.ventana.rep.pausa else "pausa", "#FFFFFF")))
        self._reloj.start()
        self.show()
        self.raise_()

    def recolocar(self):
        """La mini, en la esquina inferior derecha de la ventana (salvo que el usuario la haya movido a mano)."""
        if self.modo == "mini" and self.parent() is not None and not getattr(self, "_movido", False):
            p = self.parent()
            self.move(p.width() - self.width() - 16, p.height() - self.height() - 16)

    def resizeEvent(self, ev):
        if getattr(self, "mandos", None) is None:   # Windows: llega un resize mientras aún se construye
            return
        if self.modo == "pip":
            h = int(self.width() * 9 / 16)
            if abs(h - self.height()) > 2:
                self.resize(self.width(), h)
            if getattr(self, "grip", None) is not None:
                self.grip.move(self.width() - 16, self.height() - 16)
        self.mandos.move((self.width() - self.mandos.width()) // 2, self.height() - self.mandos.height() - 8)
        self.mandos.raise_()
        if getattr(self, "quitar", None) is not None:
            self.quitar.move(self.width() - self.quitar.width() - 6, 6)
            self.quitar.raise_()

    def mostrar_mandos(self):
        self.mandos.show()
        self.mandos.raise_()
        self._esconder.start()

    def mouseMoveEvent(self, ev):
        self.mostrar_mandos()
        if self._arrastre is not None:
            if self.modo == "pip":
                self.move(ev.globalPosition().toPoint() - self._arrastre)
            else:   # 06/10/2026: el mini también se mueve libremente dentro de la ventana, como en YouTube
                p = self.parent()
                destino = self.mapToParent(ev.position().toPoint()) - self._arrastre_local
                if p is not None:
                    # 22/10/2026 (3.9): más de media mini fuera por un lado = al soltar, se quita (no por un toque sin querer)
                    fuera = destino.x() < -self.width() // 2 or destino.x() > p.width() - self.width() // 2
                    if fuera != self._fuera:
                        self._fuera = fuera
                        self.mandos.setStyleSheet("background: rgba(200,30,30,0.8); border-radius: 6px;" if fuera
                                                  else "background: rgba(0,0,0,0.55); border-radius: 6px;")
                        self.setToolTip("Suelta para quitar el minirreproductor" if fuera else "")
                    destino.setX(max(0, min(p.width() - self.width(), destino.x())))
                    destino.setY(max(0, min(p.height() - self.height(), destino.y())))
                self.move(destino)
                self._movido = True

    def mousePressEvent(self, ev):
        if ev.button() == Qt.LeftButton:
            self._arrastre = ev.globalPosition().toPoint() - self.frameGeometry().topLeft()
            self._arrastre_local = ev.position().toPoint()

    def mouseReleaseEvent(self, ev):
        self._arrastre = None
        if self.modo == "mini" and self._fuera:   # 22/10/2026 (3.9): arrastrado fuera → quitado (sigue sonando)
            self._fuera = False
            return self.ventana.ocultar_flotante("arrastrándola fuera")
        if self.modo == "pip":
            self.ventana.ajustes["pip_geometria"] = bytes(self.saveGeometry().toBase64()).decode()
            self.ventana.guardar_ajustes()

    def mouseDoubleClickEvent(self, ev):
        self.ventana.volver_de_flotante()


class Ventana(QMainWindow):
    datos_cambian = Signal()   # la sincronización corre en otro hilo: la señal pasa el aviso al de la ventana

    def __init__(self):
        super().__init__()
        self.setWindowTitle("Cat-ode")
        self.resize(1440, 900)
        self.setMinimumSize(900, 540)   # 05/10/2026: más pequeña, la barra de arriba (buscador de 420 px + menú) se rompía
        self.ajustes = self._leer_ajustes()
        if not self.ajustes.get("avisos_apagados_0510"):   # 05/10/2026: notificaciones del sistema apagadas, una vez, para todos
            self.ajustes["avisos"] = False; self.ajustes["avisos_apagados_0510"] = True; self.guardar_ajustes()
        if self.ajustes.get("escala", 1.0) != 1.0:   # 05/10/2026: el tamaño elegido con Ctrl+rueda
            aplicar_escala(QApplication.instance(), self.ajustes["escala"])
        if self.ajustes.get("geometria"):   # tamaño, posición y si estaba maximizada, como se dejó
            from PySide6.QtCore import QByteArray
            self.restoreGeometry(QByteArray.fromBase64(self.ajustes["geometria"].encode()))
        self.datos = Datos()
        musica.al_resolver = lambda c, i: musica.apuntar(self.datos, c, i)   # 22/10/2026: lo encontrado, a la biblioteca
        self.datos.pausar_historial = self.ajustes.get("pausar_historial", False)
        self.imagenes = Imagenes()
        self.pila = []
        self.pestanas, self.pestana = [self.pila], 0   # 03/10/2026: pestañas, cada una con su propia pila
        self._sitios = {}   # clave de página → desplazamiento (volver al mismo sitio)
        self.aviso_vigilante = ""
        self._caps = {}
        self._locales = {}
        self._novedades = None
        self._parati = None
        self._hist_yt = None
        central = QWidget()
        raiz = QVBoxLayout(central)
        raiz.setContentsMargins(0, 0, 0, 0)
        raiz.setSpacing(0)
        self.arriba = self._barra_arriba()
        raiz.addWidget(self.arriba)
        h = QHBoxLayout()
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(0)
        raiz.addLayout(h, 1)
        self.menu = MenuLateral(self)
        self.menu.setObjectName("menu")
        self.menu.setFixedWidth(232)
        self.menu.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.menu.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.claves = []
        self.menu.itemClicked.connect(lambda it: it.data(Qt.UserRole) and self.ir_seccion(it.data(Qt.UserRole)))
        h.addWidget(self.menu)
        self.pintar_canales()
        self.paginas = QStackedWidget()
        # cada página entra con un fundido corto (la del vídeo no: mpv pinta en su propia ventana y no se funde)
        self.paginas.currentChanged.connect(lambda i: self.paginas.widget(i) is not self.video and fundido(self.paginas.widget(i)))
        self.pag = PaginaRejilla(self)
        self.video = PaginaVideo(self)
        self.opciones = self._pagina_ajustes()
        self.pshorts = PaginaShorts(self)   # 03/10/2026: Shorts en vertical, uno a uno
        for p in (self.pag, self.video, self.opciones, self.pshorts):
            self.paginas.addWidget(p)
        self.barra_pestanas = BarraPestanas(self)   # las pestañas, encima de las páginas, siempre a la vista con su «+», como en el navegador
        self.barra_pestanas.setMovable(True);   # 05/10/2026: se arrastran para reordenarlas (tabMoved mueve sus listas)
        self.barra_pestanas.setDocumentMode(True); self.barra_pestanas.setDrawBase(False)
        self.barra_pestanas.setExpanding(False); self.barra_pestanas.setElideMode(Qt.ElideRight); self.barra_pestanas.setUsesScrollButtons(True)
        self.barra_pestanas.setIconSize(QSize(16, 16)); self.barra_pestanas.setCursor(Qt.PointingHandCursor)
        self._anadir_pestana()
        self.barra_pestanas.currentChanged.connect(self.cambiar_pestana)
        self.barra_pestanas.tabMoved.connect(self._pestana_movida)
        self._reloj_nombres = QTimer(self, interval=700)   # el nombre de cada pestaña, al día (título del vídeo o de la lista)
        self._reloj_nombres.timeout.connect(self._nombrar_pestana)
        self._reloj_nombres.start()
        columna = QVBoxLayout(); columna.setContentsMargins(0, 0, 0, 0); columna.setSpacing(0)
        caja_pest = QWidget(); caja_pest.setObjectName("filaPestanas"); caja_pest.setAttribute(Qt.WA_StyledBackground)
        # 05/10/2026: doble clic en el hueco de la fila de pestañas = pestaña nueva (el hueco es esta caja, no la QTabBar)
        caja_pest.mouseDoubleClickEvent = lambda ev: ev.button() == Qt.LeftButton and self.nueva_pestana()
        fila_pest = QHBoxLayout(caja_pest); fila_pest.setContentsMargins(16, 0, 12, 0); fila_pest.setSpacing(2)
        mas = QPushButton(); mas.setIcon(icono("mas_uno", "#FFFFFF")); mas.setIconSize(QSize(18, 18))
        mas.setToolTip("Pestaña nueva (Ctrl+T)"); mas.setCursor(Qt.PointingHandCursor)
        mas.setFixedSize(32, 32); mas.setStyleSheet("QPushButton { border: none; border-radius: 16px; background: transparent; }"
                                                    "QPushButton:hover { background: rgba(255,255,255,0.12); }")
        mas.clicked.connect(lambda: self.nueva_pestana())
        # 03/10/2026: flechas atrás y adelante SIEMPRE a la vista, como en el navegador (el autor: «no has puesto un botón
        # para retroceder»; solo había Alt+← y el botón lateral del ratón)
        from PySide6.QtGui import QTransform
        self.b_atras, self.b_adelante = QPushButton(), QPushButton()
        self.b_atras.setIcon(icono("atras", "#FFFFFF"))
        pm = icono("atras", "#FFFFFF").pixmap(24, 24).transformed(QTransform().scale(-1, 1))
        self.b_adelante.setIcon(QIcon(pm))
        for b, ayuda, accion in ((self.b_atras, "Atrás (Alt+←)", self.volver), (self.b_adelante, "Adelante (Alt+→)", self.adelante)):
            b.setIconSize(QSize(22, 22)); b.setFixedSize(32, 32); b.setCursor(Qt.PointingHandCursor); b.setToolTip(ayuda)
            b.setFocusPolicy(Qt.NoFocus)   # nunca le quitan el teclado al vídeo (al deshabilitarse, Qt pasaba el foco a otro botón)
            b.setStyleSheet("QPushButton { border: none; border-radius: 16px; background: transparent; }"
                            "QPushButton:hover { background: rgba(255,255,255,0.12); } QPushButton:disabled { opacity: 0.3; }")
            b.clicked.connect(accion)
            # 05/10/2026: clic derecho o pulsación larga = lista del historial; botón central = esa página en pestaña nueva
            ade = b is self.b_adelante
            b.setContextMenuPolicy(Qt.CustomContextMenu)
            b.customContextMenuRequested.connect(lambda pos, ade=ade, b=b: self.menu_historial(ade, b.mapToGlobal(pos)))
            larga = QTimer(b, singleShot=True, interval=550)
            larga.timeout.connect(lambda ade=ade, b=b: (b.setDown(False), self.menu_historial(ade)))
            b.pressed.connect(larga.start); b.released.connect(larga.stop)
            def central_flecha(ev, ade=ade, b=b):
                if ev.button() == Qt.MiddleButton:
                    return self.historial_en_pestana(ade)
                QPushButton.mousePressEvent(b, ev)
            b.mousePressEvent = central_flecha
            fila_pest.addWidget(b)
        fila_pest.addSpacing(6)
        fila_pest.addWidget(self.barra_pestanas); fila_pest.addWidget(mas); fila_pest.addStretch(1)
        columna.addWidget(caja_pest); columna.addWidget(self.paginas, 1)
        self.caja_pest = caja_pest
        h.addLayout(columna, 1)
        self.ficha_canal = fichas.FichaCanal(self, self.abrir_enlace)
        self.ficha_canal.hide()
        self._canal_url = None
        self.setCentralWidget(central)
        self.show()   # mpv necesita la ventana ya creada para pintar dentro
        self.rep = self._nuevo_reproductor(self.video.video)
        self.reps, self.zonas_pestana = [self.rep], [self.video.video]   # uno por pestaña, en el mismo orden
        self.barra = Barra(self)
        raiz.addWidget(self.barra)
        from .controles import ControlesVideo
        self.controles = ControlesVideo(self)   # los mandos dentro del vídeo, como YouTube
        self.flotante = None   # 03/10/2026: el vídeo en la esquina (mini) o en imagen en imagen (pip)
        self.paginas.currentChanged.connect(self._pagina_cambiada)
        self._arrancar_avisos()   # 03/10/2026: la campana y los avisos de vídeos nuevos
        self.previa = PreviaTarjeta(self)   # 03/10/2026: vista previa al posar el ratón sobre una tarjeta
        self.paginas.currentChanged.connect(lambda _: self.previa.parar())
        self.pag.rejilla.verticalScrollBar().valueChanged.connect(lambda _: self.previa.parar())
        self.progreso = QProgressBar()
        self.progreso.setFixedWidth(220)
        self.progreso.hide()
        self.statusBar().addPermanentWidget(self.progreso)
        self.statusBar().setSizeGripEnabled(False)
        self.datos_cambian.connect(self._datos_cambiaron)
        self.datos.oyentes.append(self.datos_cambian.emit)
        # 22/10/2026 (cuenta única): los ajustes compartidos. Al abrir manda lo que haya en los otros equipos (gana lo más
        # reciente, que es lo que trae la colección); lo que aún no esté en ella, se pone desde aquí
        self.datos.al_ajustes.append(lambda d: fichas.en_ventana(lambda _: self._ajustes_de_fuera(d), None))
        self._ajustes_de_fuera(self.datos.ajustes_comunes(), avisar=False)
        self.datos.sembrar_ajustes(self.ajustes)
        self._atajos()
        if not self._reabrir_pestanas():   # 05/10/2026: las pestañas de la última vez, como el navegador
            self.ir_seccion("inicio")
        threading.Thread(target=self.datos.sincronizar, daemon=True).start()
        self.reloj_sincro = QTimer(self, interval=180_000)   # cada 3 minutos trae lo que se haya hecho en los otros equipos
        self.reloj_sincro.timeout.connect(lambda: threading.Thread(target=self.datos.sincronizar, daemon=True).start())
        self.reloj_sincro.start()
        # 03/10/2026 · al instante: el servidor avisa en cuanto otro equipo cambia algo; se trae y se repinta lo que haya en
        # pantalla (un canal fulminado en el móvil desaparece aquí en el acto)
        self.datos.escuchar(lambda: fichas.en_ventana(lambda _: self._repintar_vetos(), None))
        from . import reproductor as _rep, VERSION as _V
        def _fallo(url, error):
            if self.datos.conf:
                cuerpo = json.dumps({"app": "escritorio-" + os.name, "version": _V, "url": url, "error": error}).encode()
                from .datos import pedir as _pedir
                threading.Thread(target=lambda: _pedir(self.datos.conf, self.datos.conf["servidores"][0], "POST", "/fallo", cuerpo),
                                 daemon=True).start()
        _rep.al_fallar = _fallo
        self.reloj_pos = QTimer(self, interval=5000)   # dónde se deja cada vídeo, para reanudarlo y pintar la barra roja
        self.reloj_pos.timeout.connect(lambda: [self._con(r, self._guardar_posicion) for r in list(self.reps)])
        self.reloj_pos.start()
        from . import actualizar
        if "--prueba" in sys.argv:   # 06/10/2026: la instancia de prueba ni se actualiza ni se relanza (dejó zombis en el mini PC)
            actualizar.empezar = lambda *_a, **_k: None
        actualizar.empezar(self)
        self.reloj_version = QTimer(self, interval=20 * 60_000)   # 03/10/2026: versiones nuevas también con la app abierta
        self.reloj_version.timeout.connect(lambda: actualizar.empezar(self))
        self.reloj_version.start()

    # ---- piezas ----
    def _barra_arriba(self):
        f = QFrame()
        f.setObjectName("arriba")
        h = QHBoxLayout(f)
        h.setContentsMargins(12, 8, 20, 8)
        b = QPushButton("☰")
        b.setObjectName("icono")
        b.setToolTip("Menú")
        b.clicked.connect(lambda: self.menu.setVisible(not self.menu.isVisible()))
        h.addWidget(b)
        logo = QLabel(f"<span style='color:{NARANJA}'>▶</span> Cat-ode")
        logo.setObjectName("logo")
        logo.setCursor(Qt.PointingHandCursor)
        # 05/10/2026: botón central o Ctrl+clic en el logo = el Inicio en pestaña nueva
        logo.mousePressEvent = lambda ev: self.nueva_pestana() if self.pide_pestana(ev) else self.ir_seccion("inicio")
        h.addWidget(logo)
        h.addStretch(1)
        self.campo = QLineEdit()
        self.campo.setPlaceholderText("Buscar  ( / )  o pegar un enlace de YouTube")
        self.campo.setMinimumWidth(420)
        self.campo.setMaximumWidth(640)
        self.campo.setClearButtonEnabled(True)
        self.modelo = QStringListModel()
        c = QCompleter(self.modelo, self)
        c.setCaseSensitivity(Qt.CaseInsensitive)
        c.setCompletionMode(QCompleter.UnfilteredPopupCompletion)
        c.setMaxVisibleItems(12)
        self.campo.setCompleter(c)
        c.activated.connect(self.buscar)
        self._filtro_sugerencias = _FiltroSugerencias(self, c)   # 05/10/2026: Ctrl+Enter / central y Mayús+Supr
        self._espera = QTimer(self, singleShot=True, interval=200)
        self._espera.timeout.connect(self._sugerir)
        self.campo.textEdited.connect(lambda: self._espera.start())
        self.campo.returnPressed.connect(lambda: self.buscar(self.campo.text()))
        # 06/10/2026: buscar por voz: el micrófono enfoca el buscador, arranca el dictado del sistema (Windows: Win+H; Ubuntu:
        # el dictado del autor, ~/.local/bin/dictar) y busca solo cuando el texto deja de cambiar
        self.b_voz = QPushButton()
        self.b_voz.setIcon(icono("microfono"))
        self.b_voz.setToolTip("Buscar por voz: habla y se busca solo"); self.b_voz.setCursor(Qt.PointingHandCursor); self.b_voz.setFixedWidth(36)
        self.b_voz.clicked.connect(self.buscar_por_voz)
        self._voz_reloj = QTimer(self, singleShot=True, interval=1800); self._voz_reloj.timeout.connect(self._voz_fin)
        self._voz_activa = False
        h.addWidget(self.campo, 3)
        h.addWidget(self.b_voz)
        lupa = QPushButton("🔍")
        lupa.setToolTip("Buscar")
        lupa.clicked.connect(lambda: self.buscar(self.campo.text()))
        h.addWidget(lupa)
        h.addStretch(1)
        # 03/10/2026: la campana, como YouTube: cuántos vídeos nuevos de tus canales hay desde la última vez que miraste
        self.campana = QPushButton()
        self.campana.setObjectName("icono")
        self.campana.setIcon(icono("campana", "#FFFFFF"))
        self.campana.setIconSize(QSize(22, 22))
        self.campana.setToolTip("Vídeos nuevos de tus canales")
        self.campana.setCursor(Qt.PointingHandCursor)
        self.campana.setFocusPolicy(Qt.NoFocus)
        self.campana.setStyleSheet("QPushButton { color: #FF0033; font-weight: bold; }")
        self.campana.clicked.connect(self._abrir_campana)
        h.addWidget(self.campana)
        self.sincro_icono = QLabel()
        self.sincro_icono.setObjectName("gris")
        h.addWidget(self.sincro_icono)
        return f

    def pintar_canales(self):
        """El menú de la izquierda, con los canales suscritos al final (como YouTube)."""
        actual = self.menu.currentItem().data(Qt.UserRole) if self.menu.currentItem() else None
        self.menu.clear()
        for x in MENU:
            if x is None:
                it = QListWidgetItem("")
                it.setFlags(Qt.NoItemFlags)
                self.menu.addItem(it)
                continue
            texto, clave = x
            n, texto = separar(texto)
            it = QListWidgetItem(icono(n), texto) if n else QListWidgetItem(texto)
            it.setData(Qt.UserRole, clave)
            if clave is None:
                it.setFlags(Qt.NoItemFlags)
                f = it.font(); f.setBold(True); f.setPointSizeF(f.pointSizeF() * 1.1); it.setFont(f)
            self.menu.addItem(it)
        subs = self.datos.suscripciones()
        if subs:
            it = QListWidgetItem(f"Suscripciones ({len(subs)})")
            it.setFlags(Qt.NoItemFlags)
            f = it.font(); f.setBold(True); it.setFont(f)
            self.menu.addItem(it)
            for s in subs:
                it = QListWidgetItem(s.titulo)
                it.setData(Qt.UserRole, "canal:" + s.url)
                it.setToolTip(s.titulo)
                self.menu.addItem(it)
        for i in range(self.menu.count()):
            if actual and self.menu.item(i).data(Qt.UserRole) == actual:
                self.menu.setCurrentRow(i)

    def avisar(self, texto):
        self.statusBar().showMessage(str(texto), 3500)

    # ---- apagar el remoto (05/10/2026) ----
    # El autor ve Cat-ode en la Samsung del mini PC y a la vez tiene Moonlight conectado desde el portátil. Sunshine
    # captura y codifica la pantalla y la gráfica del N100 se satura (292-848 fotogramas perdidos; sin remoto, 0).
    # Medido el 05/10/2026: ni excluir la ventana de la captura (SetWindowDisplayAffinity), ni bajar la prioridad de
    # gráfica de Sunshine, ni congelarlo (Moonlight se desconecta a los 30 s) sirven. Lo que sí: cerrar la sesión por la
    # API de Sunshine (localhost:47990, credenciales en remoto.json) avisando antes al portátil con una línea en
    # C:\ProgramData\Cat-ode\remoto_catode.log (el lanzador «minipc» la lee por ssh al momento); el lanzador no se cierra,
    # espera, y al «encender» vuelve a conectar solo. Para el autor: F9
    # apaga, F9 enciende; él no toca nada en el portátil. Solo en Windows.
    def apagar_remoto(self, si, avisar=True):
        if os.name != "nt":
            return
        si = bool(si)
        self.ajustes["apagar_remoto"] = si
        self.guardar_ajustes()
        if hasattr(self, "_casilla_remoto") and self._casilla_remoto.isChecked() != si:
            self._casilla_remoto.setChecked(si)
        if avisar:
            self.avisar("Remoto apagado: la sesión de Moonlight se cierra y el portátil volverá a conectar cuando pulses F9"
                        if si else "Remoto encendido: el portátil se vuelve a conectar")
        if "--prueba" in sys.argv and not os.environ.get("CATODE_REMOTO_REAL"):   # la batería no cierra sesiones de verdad
            return registro(f"remoto {'apagado' if si else 'encendido'} (prueba: sin tocar Sunshine)")
        threading.Thread(target=self._remoto_hilo, args=(si,), daemon=True).start()

    def _remoto_conf(self):
        try:
            from .datos import carpeta_propia   # 18/10/2026: CATODE_CARPETA (pruebas aisladas)
            with open(os.path.join(carpeta_propia() or os.path.join(os.environ.get("LOCALAPPDATA", ""), "Cat-ode"), "remoto.json"), encoding="utf-8") as f:
                return json.load(f)
        except Exception:   # noqa: BLE001
            return {}

    def _remoto_avisar(self, texto):
        """Una línea en C:\\ProgramData\\Cat-ode\\remoto_catode.log. El lanzador «minipc» del portátil la lee al momento por una
        sesión ssh que deja abierta (remoto_esperar.ps1, por eventos del sistema de archivos). Los datagramas UDP no
        sirven: los cortafuegos de los dos equipos los paran (medido el 05/10/2026)."""
        try:
            with open(r"C:\ProgramData\Cat-ode\remoto_catode.log", "a", encoding="utf-8") as f:
                f.write(f"{texto} {time.strftime('%d/%m %H:%M:%S')}\n")
        except OSError as e:
            registro(f"remoto: no puedo escribir el aviso ({e})")

    _remoto_cerrojo = threading.Lock()

    def _remoto_hilo(self, si):
        import base64, ssl, urllib.request
        with self._remoto_cerrojo:   # apagar y encender, en orden: nunca un «encender» por delante de su «apagar»
            self._remoto_paso(si)

    def _remoto_paso(self, si):
        import base64, ssl, urllib.request
        c = self._remoto_conf()
        if si:
            self._remoto_avisar("apagar")
            if not c.get("clave"):
                return registro("apagar remoto: falta remoto.json con las credenciales de Sunshine")
            ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
            req = urllib.request.Request(f"https://localhost:{c.get('puerto', 47990)}/api/apps/close", method="POST", data=b"{}")
            req.add_header("Authorization", "Basic " + base64.b64encode(f"{c['usuario']}:{c['clave']}".encode()).decode())
            req.add_header("Content-Type", "application/json")
            try:
                with urllib.request.urlopen(req, timeout=8, context=ctx) as r:
                    registro(f"remoto apagado: sesión de Sunshine cerrada ({r.status})")
            except Exception as e:   # noqa: BLE001
                registro(f"apagar remoto: Sunshine no respondió ({e})")
        else:
            self._remoto_avisar("encender")
            registro("remoto encendido: aviso a los portátiles para que vuelvan a conectar")

    def revisar_calidad(self):
        """Calidad «auto»: la menor de las de YouTube que llene el reproductor (en píxeles reales), como hace YouTube.
        Así en ventana no se reduce un 1080p con el escalado rápido (dientes de sierra) y en pantalla completa sube."""
        z = self.video.video
        if not z.isVisible():
            return
        r = z.devicePixelRatioF()
        h = max(z.height() * r, z.width() * r * 9 / 16) * 1.1   # algo de margen, como YouTube (830×470 → 720p)
        alto = next((a for a in (360, 480, 720, 1080, 1440, 2160) if a >= h), 2160)
        alto = min(alto, 1080 if os.name == "nt" else 1440)   # el N100 del mini PC no da para más con fluidez
        detalle = f"(zona {z.width()}×{z.height()} ×{r:.2f} → {h:.0f} px{', pantalla completa' if self.isFullScreen() else ''})"
        if alto >= self.rep.alto_auto:
            self._bajar_a = None
            self.rep.poner_alto_auto(alto, detalle)
        elif getattr(self, "_bajar_a", None) != alto:
            # bajar espera 15 s: entrar y salir de pantalla completa no debe recargar el vídeo cada vez
            self._bajar_a = alto
            QTimer.singleShot(15000, lambda a=alto, d=detalle: self._bajar_a == a and (setattr(self, "_bajar_a", None), self.rep.poner_alto_auto(a, d)))

    def capitulos_de(self, url):
        f = self.video.ficha
        if f and motor.id_video(f.get("url", "")) == motor.id_video(url):
            return f.get("capitulos") or []
        return []

    def _atajos(self):
        def atajo(tecla, accion):
            QShortcut(QKeySequence(tecla), self, activated=accion)
        # en cualquier pantalla
        atajo(Qt.Key_F11, self.pantalla_completa)
        if os.name == "nt":
            atajo(Qt.Key_F9, lambda: self.apagar_remoto(not self.ajustes.get("apagar_remoto")))
            self.ajustes["apagar_remoto"] = False   # al abrir, el remoto se da por encendido: nada se cierra por sorpresa
        atajo("Ctrl+V", self._pegar_enlace)   # un enlace de YouTube copiado: Ctrl+V en cualquier pantalla y se abre
        atajo("Alt+Right", self.adelante)
        atajo("Ctrl+T", self.nueva_pestana)
        atajo("Ctrl+W", lambda: self.cerrar_pestana(self.pestana))
        atajo("Ctrl+Tab", lambda: self.barra_pestanas.setCurrentIndex((self.pestana + 1) % len(self.pestanas)))
        atajo("Ctrl+Shift+Tab", lambda: self.barra_pestanas.setCurrentIndex((self.pestana - 1) % len(self.pestanas)))
        # 05/10/2026: los demás atajos de pestañas del navegador: Ctrl+PgDn/PgUp, Ctrl+1..8, Ctrl+9 (la última) y Ctrl+Mayús+T
        atajo("Ctrl+PgDown", lambda: self.barra_pestanas.setCurrentIndex((self.pestana + 1) % len(self.pestanas)))
        atajo("Ctrl+PgUp", lambda: self.barra_pestanas.setCurrentIndex((self.pestana - 1) % len(self.pestanas)))
        for n in range(1, 9):
            atajo(f"Ctrl+{n}", lambda n=n: self.barra_pestanas.setCurrentIndex(min(n - 1, len(self.pestanas) - 1)))
        atajo("Ctrl+9", lambda: self.barra_pestanas.setCurrentIndex(len(self.pestanas) - 1))
        atajo("Ctrl+Shift+T", self.reabrir_cerrada)
        atajo(Qt.Key_MediaPlay, lambda: self.rep.alternar())   # el de la pestaña activa, no el primero
        atajo(Qt.Key_MediaTogglePlayPause, lambda: self.rep.alternar())
        atajo(Qt.Key_MediaNext, lambda: self.rep.siguiente("tecla multimedia del sistema (teclado, auriculares o mando)"))
        atajo(Qt.Key_MediaPrevious, lambda: self.rep.anterior())
        atajo("/", lambda: (self.campo.setFocus(), self.campo.selectAll()))
        atajo("Ctrl+L", lambda: (self.campo.setFocus(), self.campo.selectAll()))
        atajo("Alt+Left", self.volver)
        # 05/10/2026: más convenciones del navegador: recargar, buscar en la página, Ctrl+K/Ctrl+E al buscador y «?»
        atajo("F5", self.recargar)
        atajo("Ctrl+R", self.recargar)
        atajo("Ctrl+F", self._buscar_en_pagina)
        atajo("Ctrl+K", lambda: (self.campo.setFocus(), self.campo.selectAll()))
        atajo("Ctrl+E", lambda: (self.campo.setFocus(), self.campo.selectAll()))
        atajo("?", self.ver_atajos)
        # Esc en la caja de búsqueda le quita el teclado (y vuelve a mandar el vídeo), como en el navegador
        QShortcut(QKeySequence(Qt.Key_Escape), self.campo, activated=self.campo.clearFocus, context=Qt.WidgetShortcut)
        # los del reproductor (como YouTube): solo con el vídeo en pantalla y sin estar escribiendo; si no, la tecla hace
        # lo de siempre (las flechas desplazan la página, el espacio también)
        QApplication.instance().installEventFilter(self)

    def _tecla_video(self, ev):
        """Atajos de YouTube sobre el vídeo. Devuelve True si la tecla era suya."""
        from PySide6.QtWidgets import QLineEdit, QTextEdit, QComboBox, QAbstractSpinBox
        # 05/10/2026: también con el minirreproductor (o imagen en imagen) sobre otra página, y en los Shorts (M, J/L, 0-9)
        r = self.rep_de_teclado()
        if r is None or r.actual is None:
            return False
        if isinstance(QApplication.focusWidget(), (QLineEdit, QTextEdit, QComboBox, QAbstractSpinBox)):
            return False
        k, mod = ev.key(), ev.modifiers()
        if self.paginas.currentWidget() is self.pshorts and k in (Qt.Key_Up, Qt.Key_Down, Qt.Key_PageUp, Qt.Key_PageDown):
            return False   # en los Shorts, ↑/↓ pasan de short (PaginaShorts.keyPressEvent)
        mini = not (self.isFullScreen() or self.paginas.currentWidget() in (self.video, self.pshorts))
        if mini and k not in (Qt.Key_Space, Qt.Key_K, Qt.Key_M, Qt.Key_J, Qt.Key_L, Qt.Key_N, Qt.Key_P, Qt.Key_Escape):
            return False   # con el mini sobre una lista, las flechas y los números siguen siendo de la página
        if r is not self.rep:   # el del minirreproductor de otra pestaña: los atajos van a él
            return self._con(r, self._tecla_video_con, ev, k, mod, r)
        return self._tecla_video_con(ev, k, mod, r)

    def rep_de_teclado(self):
        """El reproductor al que van los atajos del vídeo, o None si en esta pantalla las teclas son de la página."""
        if self.isFullScreen() or self.paginas.currentWidget() in (self.video, self.pshorts):
            return self.rep
        if self.flotante is not None and 0 <= self.flotante.pestana < len(self.reps):
            return self.reps[self.flotante.pestana]
        return None

    def _tecla_video_con(self, ev, k, mod, r):
        if mod & (Qt.ControlModifier | Qt.AltModifier | Qt.MetaModifier):
            return False
        mayus = bool(mod & Qt.ShiftModifier)
        acciones = {
            Qt.Key_Space: r.alternar, Qt.Key_K: r.alternar,
            Qt.Key_J: lambda: r.mover(-10), Qt.Key_L: lambda: r.mover(10),
            Qt.Key_Left: lambda: r.mover(-5), Qt.Key_Right: lambda: r.mover(5),
            Qt.Key_Up: lambda: self.barra.vol.setValue(min(130, self.barra.vol.value() + 5)),
            Qt.Key_Down: lambda: self.barra.vol.setValue(max(0, self.barra.vol.value() - 5)),
            Qt.Key_F: self.pantalla_completa, Qt.Key_T: self.modo_cine, Qt.Key_I: self.imagen_en_imagen, Qt.Key_M: self.barra._silencio,
            # 05/10/2026: Esc también devuelve el minirreproductor / imagen en imagen a su sitio
            Qt.Key_Escape: lambda: self.pantalla_completa() if self.isFullScreen() else (self.flotante is not None and self.volver_de_flotante()),
            Qt.Key_Home: lambda: r.ir_a(0), Qt.Key_End: lambda: r.dur and r.ir_a(max(0, r.dur - 1)),
            Qt.Key_C: self._alternar_subtitulos,
            Qt.Key_Comma: lambda: r.pausa and r.mpv.command("frame-back-step"),
            Qt.Key_Period: lambda: r.pausa and r.mpv.command("frame-step"),
            Qt.Key_Less: lambda: self._velocidad(-0.25), Qt.Key_Greater: lambda: self._velocidad(0.25),
        }
        if mayus and k == Qt.Key_N:
            r.siguiente(); return True
        if mayus and k == Qt.Key_P:
            r.anterior(); return True
        if mayus and k in (Qt.Key_Comma, Qt.Key_Period):   # en teclados españoles «<» y «>» no son Mayús+«,»/«.»
            self._velocidad(-0.25 if k == Qt.Key_Comma else 0.25); return True
        if Qt.Key_0 <= k <= Qt.Key_9 and not mayus:
            if r.dur:
                r.ir_a(r.dur * (k - Qt.Key_0) / 10)
            return True
        f = acciones.get(k)
        if f is None:
            return False
        f()
        return True

    def _velocidad(self, paso):
        v = round(min(3.0, max(0.25, (getattr(self.rep.mpv, "speed", 1.0) or 1.0) + paso)), 2)
        self.rep.velocidad(v)
        self.avisar(f"Velocidad: {'normal' if v == 1 else f'{v:g}×'}")

    def _alternar_subtitulos(self):
        pistas = self.rep.subtitulos()
        if not pistas:
            return self.avisar("Este vídeo no tiene subtítulos")
        actual = self.rep._sid
        if actual in (False, "no", None):
            self.rep.poner_subtitulos(pistas[0][0]); self.avisar(f"Subtítulos: {pistas[0][1]}")
        else:
            self.rep.poner_subtitulos(None); self.avisar("Subtítulos desactivados")

    _DEPURAR_TECLAS = bool(os.environ.get("CATODE_DEPURAR_TECLAS"))

    def eventFilter(self, obj, ev):
        # pasa por aquí CADA evento de la app: lo que no es tecla ni botón lateral del ratón sale en la primera línea
        t = ev.type()
        if t not in _EVENTOS_VENTANA:
            return False
        from PySide6.QtCore import QEvent
        if self._DEPURAR_TECLAS and t in (QEvent.KeyPress, QEvent.ShortcutOverride):
            print(f"tecla {ev.key()} {t} a {type(obj).__name__} · teclado en {type(QApplication.focusWidget()).__name__} · "
                  f"ventana activa {type(QApplication.activeWindow()).__name__} · popup {type(QApplication.activePopupWidget()).__name__}", flush=True)
        if t == QEvent.KeyPress and obj is QApplication.focusWidget() or (t == QEvent.KeyPress and QApplication.focusWidget() is None):
            if self._tecla_video(ev):
                return True
            if ev.key() == Qt.Key_Escape and self.flotante is not None and not self.isFullScreen() and obj is not self.campo:
                self.volver_de_flotante()   # 05/10/2026: Esc cierra el mini / imagen en imagen (aunque ya no suene)
                return True
        elif t == QEvent.ShortcutOverride and self._es_tecla_de_video(ev):
            ev.accept()   # que la tecla llegue como KeyPress (y no la tome un botón o una lista)
        elif t == QEvent.Wheel:
            # 05/10/2026: Ctrl+rueda = tamaño de la interfaz, como el zoom del navegador (antes no hacía nada)
            if ev.modifiers() & Qt.ControlModifier and ev.angleDelta().y():
                self.poner_escala(self.ajustes.get("escala", 1.0) + (0.1 if ev.angleDelta().y() > 0 else -0.1))
                return True
            return False
        elif t == QEvent.MouseButtonPress and ev.button() in (Qt.BackButton, Qt.ForwardButton):
            if ev.button() == Qt.BackButton:
                self.volver()
            else:   # 05/10/2026: el botón 5 (adelante) se tragaba sin hacer nada; ahora va adelante, como en el navegador
                self.adelante()
            return True
        return False

    def _es_tecla_de_video(self, ev):
        from PySide6.QtWidgets import QLineEdit, QTextEdit, QComboBox, QAbstractSpinBox
        r = self.rep_de_teclado()
        teclas = (Qt.Key_Space, Qt.Key_Left, Qt.Key_Right, Qt.Key_Home, Qt.Key_End)
        if not (self.isFullScreen() or self.paginas.currentWidget() in (self.video, self.pshorts)):
            teclas = (Qt.Key_Space,)   # con el mini sobre una lista, solo el espacio deja de desplazar la página
        elif self.paginas.currentWidget() is not self.pshorts:
            teclas += (Qt.Key_Up, Qt.Key_Down)
        return (r is not None and r.actual is not None
                and not isinstance(QApplication.focusWidget(), (QLineEdit, QTextEdit, QComboBox, QAbstractSpinBox))
                and ev.key() in teclas)

    # ---- ajustes ----
    def _archivo_ajustes(self):
        from .datos import carpeta_propia   # 18/10/2026: CATODE_CARPETA (pruebas aisladas del instalador)
        d = carpeta_datos() if os.name == "nt" else (carpeta_propia() or os.path.expanduser("~/.config/catode"))
        return os.path.join(d, "escritorio-ajustes.json")

    def _leer_ajustes(self):
        base = {"calidad": "auto", "volumen": 80, "automatica": True, "patrocinios": True, "reanudar": True}
        try:
            with open(self._archivo_ajustes()) as f:
                a = {**base, **json.load(f)}
            if not a.get("calidad_auto_migrada"):   # antes no existía «automática»: se pasa a ella una vez
                a["calidad"], a["calidad_auto_migrada"] = "auto", True
            return a
        except Exception:
            return base

    def guardar_ajustes(self, compartir=True):
        try:
            from . import ajustes as _aj
            _aj.guardar_conservando(self.ajustes)   # 06/10/2026: sin pisar interfaz_remota (bucle de reinicios)
        except Exception:
            pass
        if compartir and getattr(self, "datos", None) is not None:   # 22/10/2026: los compartidos, a los otros equipos
            self.datos.poner_ajustes(self.ajustes)

    def _ajustes_de_fuera(self, d, avisar=True):
        """22/10/2026 (cuenta única) · ajustes cambiados en otro equipo (o los compartidos al abrir): se aplican aquí."""
        cambia = {k: v for k, v in (d or {}).items() if self.ajustes.get(k) != v}
        if not cambia:
            return
        self.ajustes.update(cambia)
        if "pausar_historial" in cambia:
            self.datos.pausar_historial = bool(cambia["pausar_historial"])
        if "automatica" in cambia and getattr(getattr(self, "video", None), "automatica", None) is not None:
            c = self.video.automatica
            c.blockSignals(True); c.setChecked(bool(cambia["automatica"])); c.blockSignals(False)
        for r in getattr(self, "reps", []):
            if "patrocinios" in cambia:
                r.saltar_patrocinios = bool(cambia["patrocinios"])
        self.guardar_ajustes(compartir=False)
        registro(f"ajustes de otro equipo: {cambia}")
        if avisar:
            self.avisar("Ajustes cambiados en otro equipo: " + ", ".join(sorted(cambia)))

    def ver_a_la_vez(self, e):
        """El segundo vídeo, flotante (segundo.py)."""
        if getattr(self, "segundo", None) is not None:
            self.segundo.close()
        from .segundo import SegundoVideo
        self.segundo = SegundoVideo(self, e)

    @staticmethod
    def pide_pestana(ev=None):
        """05/10/2026: botón central o Ctrl+clic = pestaña nueva, como en el navegador (en enlaces, canales y tarjetas)."""
        if ev is not None and ev.button() == Qt.MiddleButton:
            return True
        return bool(QApplication.keyboardModifiers() & Qt.ControlModifier)

    def ir_al_canal(self, url, ev=None, nombre=""):
        """El nombre del canal pulsado: en la misma pestaña o, con central o Ctrl, en una nueva (05/10/2026)."""
        if self.pide_pestana(ev):
            self.nueva_pestana(motor.Elemento("CANAL", url, nombre or "Canal"))
        else:
            self.abrir_canal(url)

    # ---- pestañas ----
    def nueva_pestana(self, e=None, vacia=False):
        self._guardar_sitio()
        self.pestanas.append([])
        z = self.video.nueva_zona()
        self.reps.append(self._nuevo_reproductor(z)); self.zonas_pestana.append(z)
        self.barra_pestanas.blockSignals(True)
        self._anadir_pestana(); self.barra_pestanas.setCurrentIndex(len(self.pestanas) - 1)
        self.barra_pestanas.blockSignals(False)
        self.pestana = len(self.pestanas) - 1; self.pila = self.pestanas[self.pestana]
        self._activar_reproductor()
        self.barra_pestanas.show()
        if e is not None:
            self.abrir(e)
        elif not vacia:   # 05/10/2026: «vacia» = lo que se abra a continuación (un enlace) es lo primero de su historial
            self.ir_seccion("inicio")

    def cambiar_pestana(self, i):
        if i < 0 or i >= len(self.pestanas) or i == self.pestana:
            return
        self._guardar_sitio()
        self.pestana, self.pila = i, self.pestanas[i]
        self._activar_reproductor()
        if self.pila:   # lo último de esa pestaña, en su sitio (sin apilarlo otra vez)
            que, args = self.pila[-1]
            que(*args)
            QTimer.singleShot(150, lambda c=self._clave(self.pila[-1]): self._volver_al_sitio(c))
        else:
            self.ir_seccion("inicio")

    def _anadir_pestana(self):
        """Una pestaña con su ✕ propia (la del sistema salía como un cuadradito gris o rojo sobre el fondo oscuro)."""
        i = self.barra_pestanas.addTab("Inicio")
        x = QPushButton(); x.setObjectName("cerrarPestana"); x.setIcon(icono("cerrar", "#AAAAAA")); x.setIconSize(QSize(14, 14))
        x.setFixedSize(20, 20); x.setCursor(Qt.PointingHandCursor); x.setToolTip("Cerrar pestaña (Ctrl+W)")
        x.clicked.connect(lambda: self.cerrar_pestana(next((j for j in range(self.barra_pestanas.count())
                                                           if self.barra_pestanas.tabButton(j, QTabBar.RightSide) is x), -1)))
        self.barra_pestanas.setTabButton(i, QTabBar.RightSide, x)
        self._botones_cerrar()

    def _botones_cerrar(self):
        """La ✕ de cada pestaña, siempre (la última se cierra dejándola limpia en el Inicio, 03/10/2026)."""
        for j in range(self.barra_pestanas.count()):
            b = self.barra_pestanas.tabButton(j, QTabBar.RightSide)
            if b is not None:
                b.setVisible(True)

    def _nuevo_reproductor(self, zona):
        """El reproductor de una pestaña (su propio mpv). Lo que avisa se atiende con él como reproductor «activo»
        un momento (la reproducción automática, el vídeo que empieza), sea o no la pestaña que se ve."""
        r = Reproductor(zona, self.ajustes)
        r.saltar_patrocinios = self.ajustes.get("patrocinios", True)
        r.empieza.connect(lambda e, r=r: self._con(r, self._empieza, e))
        r.empieza.connect(lambda e, r=r: r is self.rep and self.paginas.currentWidget() is self.pshorts and self.pshorts.poner(e))
        r.pide_mas.connect(lambda u, r=r: self._con(r, self._automatica, u))
        r.aviso.connect(lambda t, r=r: r is self.rep and self.avisar(t))
        r.pide_pantalla.connect(lambda r=r: r is self.rep and self.pantalla_completa())
        r.pide_menu.connect(lambda r=r: r is self.rep and self._menu_video_reproductor())
        r.volumen_cambia.connect(lambda v, r=r: r is self.rep and self._volumen_en_mandos(v))
        return r

    def _con(self, r, funcion, *args):
        self.rep = r
        try:
            return funcion(*args)
        finally:
            self.rep = self.reps[self.pestana] if 0 <= self.pestana < len(self.reps) else r

    def _volumen_en_mandos(self, v):
        for w in (getattr(getattr(self, "barra", None), "vol", None), getattr(getattr(self, "controles", None), "vol", None)):
            if w is not None and w.value() != v:
                w.blockSignals(True); w.setValue(v); w.blockSignals(False)

    def _activar_reproductor(self):
        """Al cambiar de pestaña: su reproductor manda en la barra, los mandos y el teclado; los demás siguen sonando."""
        self.rep = self.reps[self.pestana]
        self._vid_pestanas()
        self.video.ver_zona(self.zonas_pestana[self.pestana])
        try:
            self._volumen_en_mandos(int(self.rep._vol))
        except Exception:   # noqa: BLE001 (mpv aún sin volumen)
            pass
        if hasattr(self, "barra"):
            self.barra.refrescar()
        if getattr(self, "controles", None) is not None:   # los mandos, sobre el vídeo de ESTA pestaña (o fuera si no hay)
            self.controles.refrescar()
            self.controles.colocar()
        self._marcada = None

    def _esperar_parado(self, r, tope=4.0):
        """Windows (03/10/2026, vigía de cuelgues): al parar, mpv deshace su ventana de vídeo y para eso le manda mensajes
        a la de Cat-ode; si mientras tanto Cat-ode mueve sus ventanas (los mandos, la zona), cada una espera a la otra y
        la app se queda colgada para siempre. Se atienden los mensajes hasta que mpv ha parado y luego se sigue."""
        if os.name != "nt":
            return
        from PySide6.QtCore import QEventLoop
        t0 = time.time()
        while not getattr(r, "_idle", True) and time.time() - t0 < tope:
            QApplication.processEvents(QEventLoop.AllEvents, 50)
            time.sleep(0.02)
        QApplication.processEvents(QEventLoop.AllEvents, 50)

    def _vid_pestanas(self):
        """Solo se descodifica la imagen de la pestaña que se ve (y la del vídeo en la esquina o en imagen en imagen); las
        demás siguen sonando sin imagen: con varias a la vez, el N100 del mini PC iba a saltos (03/10/2026)."""
        # DESACTIVADO (03/10/2026): quitar y devolver la imagen rehace la ventana de mpv dentro de la de Cat-ode y en Windows
        # eso bloqueaba la app (tres pestañas con el remoto: «dejó de responder»; la prueba, al cerrar la activa). Las
        # pestañas de fondo vuelven a ser como en la 1.0.19, que nunca se colgó.
        return

    def reproducir_aqui(self, e):
        """Clic en la portada: este vídeo, a sonar en esta pestaña."""
        self.abrir_video(e)

    def ir_a_lo_que_suena(self):
        """Clic en la barra de abajo: al vídeo que suena en esta pestaña."""
        if self.rep.actual is not None:
            self.abrir_video(self.rep.actual, sonar=False)

    def _marcar_pestanas(self):
        """El altavoz en cada pestaña que está sonando, como en el navegador."""
        estado = tuple((r.actual is not None and not r.pausa) and (2 if getattr(r, "_mute", False) else 1) for r in self.reps)
        if getattr(self, "_marcada", None) == estado:
            return
        self._marcada = estado
        for i, suena in enumerate(estado):
            if i < self.barra_pestanas.count():
                self.barra_pestanas.setTabIcon(i, (icono("silencio", "#AAAAAA") if suena == 2 else icono("volumen", "#FF0033")) if suena else QIcon())

    def cerrar_pestana(self, i):
        if i < 0 or i >= len(self.pestanas):
            return
        if len(self.pestanas) == 1:
            # 03/10/2026: la última también se cierra (el autor: «la última pestaña nunca me deja cerrarla»): se para lo
            # que suena y la pestaña queda limpia en el Inicio
            self._con(self.rep, self._guardar_posicion)
            self._apuntar_cerrada(0)
            self.rep.parar()
            self._esperar_parado(self.rep)
            self.pila.clear(); self._ade().clear()
            self.ir_seccion("inicio")
            self._marcada = None
            return
        actual = self.pestana
        self._apuntar_cerrada(i)
        self.pestanas.pop(i)
        r, z = self.reps.pop(i), self.zonas_pestana.pop(i)   # como en el navegador: se cierra y deja de sonar
        if self.flotante is not None and self.flotante.zona is z:   # su vídeo estaba en la mini o en imagen en imagen
            f, self.flotante = self.flotante, None
            z.setParent(self.video.zonas); f.close(); f.deleteLater()
        if self.pshorts.zona is z:
            self.pshorts.zona = None
        elif self.flotante is not None and self.flotante.pestana > i:
            self.flotante.pestana -= 1
        self._con(r, self._guardar_posicion)
        if getattr(r, "_vigia", None) is not None:
            r._vigia.stop()
        r.cerrar()
        self._esperar_parado(r)
        self.video.zonas.removeWidget(z)
        if os.name == "nt":   # en Windows mpv solo se para (no se puede terminar con su ventana dentro): la zona, escondida
            z.hide()
        else:
            z.deleteLater()
        self.barra_pestanas.blockSignals(True); self.barra_pestanas.removeTab(i); self.barra_pestanas.blockSignals(False)
        nueva = actual - 1 if i < actual else min(actual, len(self.pestanas) - 1)
        self.pestana = -1
        self.barra_pestanas.blockSignals(True); self.barra_pestanas.setCurrentIndex(nueva); self.barra_pestanas.blockSignals(False)
        self.cambiar_pestana(nueva)
        self._marcada = None
        self._botones_cerrar()

    def _pestanas_guardables(self):
        """05/10/2026: lo último de cada pestaña (función y argumentos, un vídeo por su ficha), para reabrirlas mañana."""
        import dataclasses
        def valor(x):
            if isinstance(x, motor.Elemento):
                return {"_e": dataclasses.asdict(x)}
            if x is None or isinstance(x, (str, int, float, bool)):
                return x
            raise TypeError
        lista = []
        for i, p in enumerate(self.pestanas):
            try:
                que, args = p[-1]
                nombre = getattr(que, "__name__", "")
                if not nombre or getattr(self, nombre, None) is None:
                    raise TypeError
                lista.append({"f": nombre, "a": [valor(x) for x in args], "t": self.barra_pestanas.tabText(i)})
            except (IndexError, TypeError, ValueError):
                lista.append({"f": "inicio", "a": [], "t": "Inicio"})
        return lista

    def _reabrir_pestanas(self):
        """Al arrancar: las pestañas guardadas, sin reproducir nada (un vídeo sale con su portada hasta que se pulse);
        solo se pinta la activa, las demás cargan al cambiar a ellas (cambiar_pestana)."""
        entradas = []
        for g in self.ajustes.get("pestanas") or []:
            try:
                que = getattr(self, g["f"])
                args = tuple(motor.Elemento(**x["_e"]) if isinstance(x, dict) and "_e" in x else x for x in g.get("a", []))
                entradas.append(((que, args), g.get("t") or "Inicio"))
            except Exception:   # noqa: BLE001 (una versión vieja o una función que ya no existe: esa pestaña no vuelve)
                continue
        if not entradas or (len(entradas) == 1 and entradas[0][0][0] == self.inicio):
            return False
        for n, (entrada, titulo) in enumerate(entradas):
            if n:
                self.nueva_pestana(vacia=True)
            self.pila.append(entrada)
            self.barra_pestanas.setTabText(self.pestana, titulo[:40]); self.barra_pestanas.setTabToolTip(self.pestana, titulo)
        activa = min(max(0, int(self.ajustes.get("pestana_activa", 0) or 0)), len(entradas) - 1)
        if activa == self.pestana:
            que, args = self.pila[-1]
            que(*args)
            self._refrescar_flechas()
        else:
            self.barra_pestanas.setCurrentIndex(activa)
        return True

    def poner_escala(self, escala):
        """Ctrl+rueda: factor de la letra de la interfaz (0,8-1,6), guardado; se aplica un momento después (repintar el
        estilo de toda la app con cada paso de rueda la frenaba)."""
        escala = round(min(1.6, max(0.8, escala)), 2)
        if escala == self.ajustes.get("escala", 1.0):
            return
        self.ajustes["escala"] = escala
        self.guardar_ajustes()
        if not hasattr(self, "_reloj_escala"):
            self._reloj_escala = QTimer(self, singleShot=True, interval=180)
            self._reloj_escala.timeout.connect(lambda: aplicar_escala(QApplication.instance(), self.ajustes.get("escala", 1.0)))
        self._reloj_escala.start()
        self.avisar(f"Tamaño: {round(escala * 100)} %")

    def minuto_en_pestana(self, url, s):
        """05/10/2026: botón central en un capítulo o una línea de la transcripción: ese minuto, en una pestaña nueva."""
        self.abrir_enlace(f"{motor.url_video(motor.id_video(url))}&t={int(s)}", nueva=True)

    def recargar(self):
        """05/10/2026: F5 / Ctrl+R vuelven a pintar la página que se ve (el Inicio, con «Para ti» nuevo)."""
        if not self.pila:
            return self.ir_seccion("inicio")
        que, args = self.pila[-1]
        if que == self.inicio:
            self.inicio(*(args[:1] or ("Todo",)), recargar=True)
        else:
            que(*args)
        self.avisar("Recargado")

    def _buscar_en_pagina(self):
        """05/10/2026: Ctrl+F al filtro de la transcripción si está a la vista; si no, al buscador."""
        f = getattr(self.video, "tr_buscar", None)
        if self.paginas.currentWidget() is self.video and f is not None and f.isVisible():
            f.setFocus(); f.selectAll()
        else:
            self.campo.setFocus(); self.campo.selectAll()

    def ver_atajos(self):
        """05/10/2026: «?» enseña los atajos, como en YouTube."""
        from PySide6.QtWidgets import QDialog
        if getattr(self, "_dialogo_atajos", None) is not None and self._dialogo_atajos.isVisible():
            return self._dialogo_atajos.raise_()
        filas = (("Vídeo", "Espacio / K: pausa y sigue · J / L: −10 / +10 s · ← / →: −5 / +5 s · ↑ / ↓: volumen · 0-9: ir al 0-90 %"),
                 ("", "F: pantalla completa · T: modo cine · I: imagen en imagen · M: silencio · C: subtítulos · Esc: salir"),
                 ("", "Mayús+N / Mayús+P: siguiente / anterior · , / .: fotograma (en pausa) · < / >: velocidad · Inicio / Fin"),
                 ("Pestañas", "Ctrl+T: nueva · Ctrl+W: cerrar · Ctrl+Mayús+T: reabrir la cerrada · Ctrl+Tab / Ctrl+AvPág: siguiente"),
                 ("", "Ctrl+Mayús+Tab / Ctrl+RePág: anterior · Ctrl+1…8: esa pestaña · Ctrl+9: la última"),
                 ("", "Botón central o Ctrl+clic: abrir en pestaña nueva · Mayús+clic en un vídeo: ventana aparte"),
                 ("Navegar", "Alt+← / Alt+→ y botones 4 / 5 del ratón: atrás / adelante · F5 / Ctrl+R: recargar"),
                 ("", "/ · Ctrl+L · Ctrl+K · Ctrl+E: al buscador · Ctrl+F: buscar en la transcripción · Ctrl+V: abrir un enlace"),
                 ("", "Ctrl+rueda: tamaño de la interfaz · F11: pantalla completa · ?: esta lista"))
        d = QDialog(self); d.setWindowTitle("Atajos de teclado"); d.setObjectName("dialogoAtajos")
        lay = QVBoxLayout(d); lay.setContentsMargins(24, 20, 24, 20); lay.setSpacing(6)
        for grupo, texto in filas:
            if grupo:
                g = QLabel(grupo); g.setObjectName("seccion"); lay.addWidget(g)
            t = QLabel(texto); t.setWordWrap(True); lay.addWidget(t)
        cerrar = QPushButton("Cerrar"); cerrar.clicked.connect(d.close); lay.addWidget(cerrar, 0, Qt.AlignRight)
        d.resize(720, 420)
        self._dialogo_atajos = d
        d.show()

    def _titulo_entrada(self, entrada):
        """El nombre de una página del historial (para el menú de las flechas atrás/adelante)."""
        que, args = entrada
        n = getattr(que, "__name__", "")
        if n == "_mostrar_video" and args:
            return args[0].titulo or "Vídeo"
        nombres = {"inicio": "Inicio", "shorts": "Shorts", "suscripciones": "Suscripciones", "explorar": "Explorar",
                   "historial": "Historial", "despues": "Ver más tarde", "megusta": "Me gusta", "listas": "Listas", "musica": "Música",
                   "descargas": "Descargas", "nut": "Nut", "ajustes_pagina": "Ajustes", "_canal": "Canal"}
        if n == "_resultados" and args:
            return f"Búsqueda: {args[0]}"
        if n == "_lista_yt" and len(args) > 1:
            return str(args[1])
        if n == "_lista_musica" and args:
            return musica.lista(self.datos, args[0])[0]
        return nombres.get(n, n.strip("_").capitalize() or "Página")

    def saltar_historial(self, n):
        """05/10/2026: n pasos atrás (negativo) o adelante (positivo) de una vez, desde el menú de las flechas."""
        if n == 0:
            return
        self._guardar_sitio()
        ade = self._ade()
        for _ in range(abs(n)):
            if n < 0 and len(self.pila) > 1:
                ade.append(self.pila.pop())
            elif n > 0 and ade:
                self.pila.append(ade.pop())
        que, args = self.pila[-1]
        que(*args)
        QTimer.singleShot(150, lambda c=self._clave(self.pila[-1]): self._volver_al_sitio(c))
        self._refrescar_flechas()

    def menu_historial(self, adelante, donde=None):
        """Clic derecho (o pulsación larga) en las flechas: las páginas de ese lado, como en el navegador."""
        m = QMenu(self)
        if adelante:
            for k, entrada in enumerate(reversed(self._ade())):
                m.addAction(self._titulo_entrada(entrada), lambda k=k: self.saltar_historial(k + 1))
        else:
            for k, entrada in enumerate(reversed(self.pila[:-1])):
                m.addAction(self._titulo_entrada(entrada), lambda k=k: self.saltar_historial(-(k + 1)))
        if m.isEmpty():
            return
        b = self.b_adelante if adelante else self.b_atras
        m.exec(donde or b.mapToGlobal(b.rect().bottomLeft()))

    def historial_en_pestana(self, adelante):
        """Botón central en las flechas: la página de ese lado, en una pestaña nueva (con su historial hasta ahí)."""
        if adelante and self._ade():
            self._pestana_con(list(self.pila) + [self._ade()[-1]])
        elif not adelante and len(self.pila) > 1:
            self._pestana_con(list(self.pila[:-1]))

    def _apuntar_cerrada(self, i):
        """05/10/2026: lo que tenía la pestaña que se cierra, para Ctrl+Mayús+T (antes la pila se tiraba)."""
        if not hasattr(self, "_cerradas"):
            self._cerradas = []
        if self.pestanas[i]:
            self._cerradas.append((list(self.pestanas[i]), self.barra_pestanas.tabText(i)))
            del self._cerradas[:-20]

    def _pestana_con(self, pila, titulo=""):
        """Una pestaña nueva con ese historial, en su última página (sin reproducir: un vídeo sale con su portada)."""
        self.nueva_pestana(vacia=True)
        self.pila.extend(pila)
        if titulo:
            self.barra_pestanas.setTabText(self.pestana, titulo[:40])
        que, args = self.pila[-1]
        que(*args)
        self._refrescar_flechas()

    def reabrir_cerrada(self):
        if getattr(self, "_cerradas", None):
            self._pestana_con(*self._cerradas.pop())

    def duplicar_pestana(self, i):
        if 0 <= i < len(self.pestanas) and self.pestanas[i]:
            self._pestana_con(list(self.pestanas[i]), self.barra_pestanas.tabText(i))
        else:
            self.nueva_pestana()

    def cerrar_otras(self, i):
        self.cerrar_derecha(i)
        for _ in range(i):
            self.cerrar_pestana(0)

    def cerrar_derecha(self, i):
        for j in range(len(self.pestanas) - 1, i, -1):
            self.cerrar_pestana(j)

    def silenciar_pestana(self, i):
        """05/10/2026: silenciar solo esa pestaña (menú de la pestaña o clic en su altavoz), como en el navegador."""
        if not 0 <= i < len(self.reps):
            return
        m = self.reps[i].silencio()
        if i == self.pestana:
            for w, color in ((getattr(getattr(self, "barra", None), "mute", None), None),
                             (getattr(getattr(self, "controles", None), "mute", None), "#FFFFFF")):
                if w is not None:
                    w.setIcon(icono("silencio" if m else "volumen", *([color] if color else [])))
        self._marcada = None
        self._marcar_pestanas()

    def _pestana_movida(self, de, a):
        """05/10/2026: pestaña arrastrada a otro sitio: sus listas (historial, reproductor, zona) se mueven con ella."""
        for lista in (self.pestanas, self.reps, self.zonas_pestana):
            lista.insert(a, lista.pop(de))
        if self.flotante is not None:
            orden = list(range(len(self.pestanas))); orden.insert(a, orden.pop(de))
            self.flotante.pestana = orden.index(self.flotante.pestana)
        self.pestana = next(j for j, p in enumerate(self.pestanas) if p is self.pila)
        self._marcada = None

    def _nombrar_pestana(self):
        """El nombre de la pestaña: el título del vídeo o de la lista que tiene a la vista."""
        self._marcar_pestanas()
        self._refrescar_flechas()
        if self.paginas.currentWidget() is self.video:
            t = self.video.titulo.text()
        elif self.paginas.currentWidget() is self.pag:
            t = self.pag.titulo.text() or "Inicio"
        else:
            t = "Ajustes"
        titulo = f"{t} · Cat-ode" if t else "Cat-ode"   # 05/10/2026: el título de lo que se ve (Alt+Tab, barra de tareas)
        if self.windowTitle() != titulo:
            self.setWindowTitle(titulo)
        if self.barra_pestanas.tabText(self.pestana) == t[:40]:
            return
        self.barra_pestanas.setTabText(self.pestana, t[:40])
        self.barra_pestanas.setTabToolTip(self.pestana, t)

    # ---- navegación ----
    def ir_seccion(self, clave):
        # 03/10/2026: cambiar de sección ya no borra el historial de la pestaña: «atrás» vuelve a donde estabas, como en el
        # navegador (antes la pila se vaciaba y la flecha no servía). Si ya estás en esa sección, no se apila dos veces.
        if self.pila and self._clave(self.pila[-1]) == self._clave((self.ir_seccion, (clave,))):
            if clave == "inicio":   # 24/10/2026: Inicio pulsado estando en Inicio = otra mezcla, como en la web
                self.inicio("Todo", True)
            return
        if clave == "inicio":   # 24/10/2026 («siguen saliéndome siempre los mismos»): ir al Inicio = mezcla nueva; «atrás», no
            self._inicio_fresco = True
        for i in range(self.menu.count()):
            if self.menu.item(i).data(Qt.UserRole) == clave:
                self.menu.setCurrentRow(i)
        if clave.startswith("canal:"):
            return self.ir(self._canal, clave[6:], "videos")
        funcion = {"inicio": self.inicio, "shorts": self.shorts, "suscripciones": self.suscripciones,
                   "explorar": self.explorar, "historial": self.historial, "despues": self.despues,
                   "megusta": self.megusta, "listas": self.listas, "musica": self.musica, "descargas": self.descargas,
                   "nut": self.nut, "ajustes": self.ajustes_pagina}[clave]
        self.ir(funcion)

    def _clave(self, entrada):
        que, args = entrada
        return (getattr(que, "__name__", str(que)), repr(args))

    def _guardar_sitio(self):
        """Antes de irse de una lista: dónde estaba y cuántas tarjetas había (para volver al mismo sitio, como YouTube)."""
        if self.pila and self.paginas.currentWidget() is self.pag:
            self._sitios[self._clave(self.pila[-1])] = (self.pag.rejilla.verticalScrollBar().value(), len(self.pag.rejilla.widgets))

    def reiniciar_cuando_libre(self):
        """Versión nueva ya descargada: se reinicia sola en cuanto no suena nada (vuelve a abrirse en dos segundos)."""
        if any(r.actual is not None and not r.pausa for r in self.reps):
            return QTimer.singleShot(30_000, self.reiniciar_cuando_libre)
        if getattr(self, "_reiniciando", False):   # 06/10/2026: dos avisos seguidos relanzaban la app dos veces (dos ventanas)
            return
        self._reiniciando = True
        import sys
        from PySide6.QtCore import QProcess
        pyw = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "catode.pyw")
        QProcess.startDetached(sys.executable, [pyw, "--reinicio"])
        self.guardar_ajustes()
        QApplication.instance().quit()

    def _repintar_vetos(self):
        for r in (getattr(self.pag, "rejilla", None), getattr(self.video, "relacionados", None)):
            if r is not None:
                r.refiltrar()

    def _al_reponer(self, r):
        """La lista se ha vuelto a pintar (llegó lo actualizado de la red) justo al volver atrás: al sitio otra vez."""
        x = getattr(self, "_restaurando", None)
        if x and time.time() - x[1] < 6 and r is self.pag.rejilla and self.pila and self._clave(self.pila[-1]) == x[0]:
            QTimer.singleShot(60, lambda: self._volver_al_sitio(x[0], marcar=False))

    def _volver_al_sitio(self, clave, intentos=25, marcar=True):
        if marcar:
            self._restaurando = (clave, time.time())
        sitio = self._sitios.get(clave)
        if not sitio or self.paginas.currentWidget() is not self.pag:
            return
        valor, n = sitio
        r = self.pag.rejilla
        if len(r.widgets) == 0 and intentos:   # la página aún se está pintando
            return QTimer.singleShot(100, lambda: self._volver_al_sitio(clave, intentos - 1, False))
        while len(r.widgets) < n:   # las tandas que ya están en memoria, de golpe (sin esperar a la red)
            mas = self.pag.mas
            if mas is None or getattr(mas, "__name__", "") != "siguiente":
                break
            t = mas()
            self.pag.mas = t[2] if t else None
            if not t:
                break
            r.anadir(t[0], t[1])
        barra = r.verticalScrollBar()

        def colocar(veces=30):
            # al llegar abajo, la propia lista pide la tanda siguiente (si lo de antes venía de la red): se insiste hasta 4 s
            barra.setValue(min(valor, barra.maximum()))
            if os.environ.get("CATODE_DEPURAR"):
                print(f"depura colocar: quiero {valor} max {barra.maximum()} tarjetas {len(r.widgets)} veces {veces}", flush=True)
            if barra.value() < valor and veces and self.paginas.currentWidget() is self.pag and r is self.pag.rejilla:
                QTimer.singleShot(130, lambda: colocar(veces - 1))
        QTimer.singleShot(50, colocar)

    def ir(self, que, *args):
        self._restaurando = None
        if self.isFullScreen():
            self.pantalla_completa()
        self._guardar_sitio()
        self.pila.append((que, args))
        if len(self.pila) > 60:
            del self.pila[:20]
        self._ade().clear()   # una página nueva borra el «adelante», como en el navegador
        que(*args)
        self._refrescar_flechas()

    def _ade(self):
        """Lo que se ha dejado atrás con «volver» en esta pestaña (para «adelante»)."""
        if not hasattr(self, "_adelantes"):
            self._adelantes = {}
        return self._adelantes.setdefault(id(self.pila), [])

    def _refrescar_flechas(self):
        if hasattr(self, "b_adelante"):
            self.b_adelante.setEnabled(bool(self._ade()))
            self.b_atras.setEnabled(len(self.pila) > 1 or self.paginas.currentWidget() is not self.pag or not self.pila
                                    or self.pila[-1][0] is not self.inicio)

    def volver(self):
        if len(self.pila) > 1:
            self._guardar_sitio()
            self._ade().append(self.pila.pop())
            que, args = self.pila[-1]
            que(*args)
            QTimer.singleShot(150, lambda c=self._clave(self.pila[-1]): self._volver_al_sitio(c))
        else:
            self.ir_seccion("inicio")
        self._refrescar_flechas()

    def adelante(self):
        """Deshace el último «volver» de esta pestaña."""
        if not self._ade():
            return
        self._guardar_sitio()
        self.pila.append(self._ade().pop())
        que, args = self.pila[-1]
        que(*args)
        QTimer.singleShot(150, lambda c=self._clave(self.pila[-1]): self._volver_al_sitio(c))
        self._refrescar_flechas()

    def abrir(self, e):
        if e.url in self._locales:
            self.rep.reproducir_local(self._locales[e.url], e)
            self.abrir_video(e, sonar=False)
        elif e.tipo == "VIDEO":
            self.abrir_video(e)
        elif e.tipo == "CANAL":
            self.abrir_canal(e.url)
        elif e.url.startswith("propia:"):
            self.ir(self._lista_propia, e.url)
        elif e.url.startswith("biblioteca:"):   # 22/10/2026: una lista del modo Música
            self.ir(self._lista_musica, e.url[11:])
        else:
            self.ir(self._lista_yt, e.url, e.titulo)

    def abrir_video(self, e, sonar=True, desde=None):
        if sonar:
            if desde is None:
                s, d = self.datos.posicion(e.url)
                desde = s if self.ajustes.get("reanudar", True) and d and 15 < s < d - 20 else 0
                if desde:
                    self.avisar(f"Sigue donde lo dejaste ({motor.tiempo(desde)})")
            self.rep.reproducir(e, desde)
        self._guardar_sitio()
        # sin repetir: si arriba ya está este mismo vídeo, «atrás» volvía a él y parecía que no hacía nada
        if not (self.pila and self.pila[-1][0] == self._mostrar_video and self.pila[-1][1]
                and motor.id_video(self.pila[-1][1][0].url) == motor.id_video(e.url)):
            self.pila.append((self._mostrar_video, (e,)))
        self._mostrar_video(e)

    def _mostrar_video(self, e):
        self.paginas.setCurrentWidget(self.video)
        # el reproductor de esta pestaña si suena este vídeo; si no (se paró, se cerró…), su portada para ponerlo
        a = self.rep.actual
        suena = a is not None and motor.id_video(a.url) == motor.id_video(e.url)
        if not suena:
            self.video.cartel.poner(e)
        self.video.cartel.setVisible(not suena)
        self.video.zonas.setVisible(suena)
        if hasattr(self, "controles"):
            self.controles.colocar()
            if suena:
                self.controles.mostrar()
        (self.video.video if suena else self.video.cartel).setFocus()   # el teclado, al vídeo: el espacio pausa, no escribe en el buscador
        if self.video.cargando != e.url:
            self.video.cargar(e)

    def abrir_canal(self, url):
        self.ir(self._canal, url, "videos")

    def saltar(self, url, segundos):
        """Un capítulo o un minuto del vídeo de la página: si es el que suena, salta; si no, lo pone desde ahí."""
        if self.rep.actual is not None and motor.id_video(self.rep.actual.url) == motor.id_video(url):
            self.rep.ir_a(segundos)
        elif self.video.e:
            self.rep.reproducir(self.video.e, segundos)

    def encolar(self, e):
        self.rep.encolar(e)
        self.avisar(f"Añadido a la cola: {e.titulo}")
        self.video.refrescar_cola()

    def a_continuacion(self, e):
        self.rep.insertar_siguiente(e)
        self.avisar(f"Sonará a continuación: {e.titulo}")
        self.video.refrescar_cola()

    def fulminar(self, e):
        """Fuera el canal para siempre (en todos los Cat-ode) y, después, su entorno: los canales que YouTube pone a su
        lado y viven en su misma burbuja (lo mismo que el móvil; los de ≥35 % salen ya marcados)."""
        url = e.url if e.tipo == "CANAL" else e.autorUrl
        nombre = e.titulo if e.tipo == "CANAL" else e.autor
        if not (url or nombre):
            return
        self.datos.fulminar(url, nombre)
        self._repintar_vetos()
        self.avisar(f"«{nombre}» fulminado: no volverá a salir. Buscando su entorno…")
        if not url:
            return

        def entorno():
            import concurrent.futures as cf

            def rel(canal, n):
                try:
                    vids = [v for v in motor.canal(canal)[1] if v.tipo == "VIDEO"][:n]
                except Exception:   # noqa: BLE001
                    return []
                with cf.ThreadPoolExecutor(4) as ex:
                    return [r for lista in ex.map(motor.relacionados, [v.url for v in vids]) for r in (lista or [])]
            cuenta = {}
            for r in rel(url, 6):
                if r.tipo == "VIDEO" and r.autorUrl and r.autorUrl != url and not self.datos.vetado(r):
                    n0 = cuenta.get(r.autorUrl, (r.autor, 0))
                    cuenta[r.autorUrl] = (r.autor, n0[1] + 1)
            cand = sorted(((u, a, n) for u, (a, n) in cuenta.items() if n >= 2), key=lambda x: -x[2])[:15]
            grupo = {u for u, _, _ in cand} | {url}

            def burbuja(c):
                rs = [r for r in rel(c[0], 3) if r.tipo == "VIDEO" and r.autorUrl != c[0]]
                dentro = sum(1 for r in rs if r.autorUrl in grupo or self.datos.vetado(r))
                return (c[0], c[1], c[2], dentro * 100 // len(rs) if rs else 0)
            with cf.ThreadPoolExecutor(4) as ex:
                res = sorted(ex.map(burbuja, cand), key=lambda x: -x[3])
            fichas.en_ventana(lambda r: self._dialogo_entorno(nombre, r), res)
        threading.Thread(target=entorno, daemon=True).start()

    def _dialogo_entorno(self, nombre, res):
        if not res:
            self.avisar(f"«{nombre}» fulminado (no tiene un entorno claro)")
            return
        from PySide6.QtWidgets import QDialog, QDialogButtonBox
        d = QDialog(self); d.setWindowTitle(f"Fulminar también el entorno de «{nombre}»")
        v = QVBoxLayout(d)
        t = QLabel("Canales que YouTube pone a su lado. Marcados, los de su misma burbuja (comparten audiencia).\n"
                   "Desmarca los que quieras conservar."); t.setWordWrap(True); v.addWidget(t)
        cajas = []
        for u, a, n, pct in res:
            c = QCheckBox(f"{a}   ·   burbuja {pct} %"); c.setChecked(pct >= 35 and not self.datos.suscrito(u))
            v.addWidget(c); cajas.append((c, u, a))
        b = QDialogButtonBox(); ok = b.addButton("Fulminar los marcados", QDialogButtonBox.AcceptRole)
        ok.setObjectName("principal"); b.addButton("Ninguno", QDialogButtonBox.RejectRole)
        b.accepted.connect(d.accept); b.rejected.connect(d.reject); v.addWidget(b)
        if d.exec():
            marcados = [(u, a) for c, u, a in cajas if c.isChecked()]
            for u, a in marcados:
                self.datos.fulminar(u, a)
            self._repintar_vetos()
            if marcados:
                self.avisar(f"{len(marcados)} canales más fulminados")

    def _pintar_vetos_ajustes(self):
        for caja in (self._caja_temas, self._caja_fulminados):
            while caja.count():
                w = caja.takeAt(0).widget()
                if w:
                    w.hide(); w.deleteLater()

        def fila(texto, boton, accion):
            w = QWidget(); h = QHBoxLayout(w); h.setContentsMargins(0, 0, 0, 0)
            t = QLabel(texto); t.setWordWrap(True); h.addWidget(t, 1)
            b = QPushButton(boton); b.clicked.connect(accion); h.addWidget(b)
            return w
        for nombre, pal in self.datos.temas():
            self._caja_temas.addWidget(fila(f"<b>{nombre}</b> · {', '.join(pal)}", "Quitar",
                                            lambda _=False, n=nombre: (self.datos.quitar_tema(n), self._pintar_vetos_ajustes(), self._repintar_vetos())))
        fs = self.datos.fulminados()
        if not fs:
            g = QLabel("Ninguno. Se fulmina desde el menú de cada vídeo, la página del vídeo o la del canal."); g.setObjectName("gris")
            self._caja_fulminados.addWidget(g)
        for url, nombre in fs:
            self._caja_fulminados.addWidget(fila(nombre, "Indultar",
                                                 lambda _=False, u=url, n=nombre: (self.datos.indultar(u), self._pintar_vetos_ajustes(),
                                                                                    self.avisar(f"«{n}» indultado"))))

    def _nuevo_tema(self):
        nombre, ok = QInputDialog.getText(self, "Tema filtrado", "Nombre del tema (p. ej. «fachas»):")
        if not ok or not nombre.strip():
            return
        pal, ok = QInputDialog.getText(self, "Tema filtrado", f"Palabras de «{nombre.strip()}», separadas por comas:")
        if not ok:
            return
        self.datos.poner_tema(nombre, pal.split(","))
        self._pintar_vetos_ajustes(); self._repintar_vetos()
        self.avisar(f"Tema «{nombre.strip()}» filtrado en todos tus Cat-ode")

    def no_me_interesa(self, e):
        self.datos.poner("ocultos", e.url, e)
        r = self.pag.rejilla
        if e in r.elementos:
            quedan = [x for x in r.elementos if x is not e]
            r.poner(quedan, r.motivos)
        self.avisar("Vale: no te lo volveré a enseñar")

    def nueva_lista(self, e=None):
        nombre, ok = QInputDialog.getText(self, "Nueva lista", "Nombre de la lista:")
        if ok and nombre.strip():
            clave = self.datos.nueva_lista(nombre.strip())
            if e is not None:
                self.datos.lista_poner(clave, e)
            self.avisar(f"Lista «{nombre.strip()}» creada")
            return clave

    def guardar_cola(self):
        clave = self.nueva_lista()
        if clave:
            for e in self.rep.cola:
                self.datos.lista_poner(clave, e)

    def descargar(self, e, solo_audio=False, alto=720):
        self.progreso.setValue(0)
        self.progreso.setFormat(("♪ " if solo_audio else "") + e.titulo[:30] + "  %p %")
        self.progreso.show()

        def progreso(x, texto=""):
            fichas.en_ventana(lambda v: self.progreso.setValue(int(v * 100)), x)

        def listo(ruta, error):
            self.progreso.hide()
            self.avisar(f"No he podido descargarlo: {error}" if error else f"Descargado: {e.titulo}")
        en_hilo(motor.descargar, listo, e, solo_audio, alto, progreso)
        self.avisar("Descargando…")

    # ---- secciones ----
    def _cargar(self, turno, funcion, al_acabar, *args):
        def listo(r, error):
            if turno != self.pag.turno:
                return
            if error:
                self.pag.poner([], aviso=f"No he podido cargarlo ({error.__class__.__name__}). Lo vuelvo a intentar solo en unos segundos…")
                self._reintentar(turno)
                return
            al_acabar(r)
        en_hilo(funcion, listo, *args)

    def _reintentar(self, turno, segundos=15):
        """Sin red (03/10/2026: un corte dejó Inicio y Suscripciones vacíos hasta reiniciar): la misma página otra vez,
        sola, mientras sigas en ella."""
        def otra_vez():
            if turno == self.pag.turno and self.paginas.currentWidget() is self.pag and self.pila:
                que, args = self.pila[-1]
                que(*args)
        QTimer.singleShot(segundos * 1000, otra_vez)

    def _por_tandas(self, elementos, motivos=None, aviso="", mas_red=None):
        """Pinta las primeras tarjetas y deja el resto para cuando se baje. «mas_red» (06/10/2026): función que, acabadas
        las locales, trae otra tanda de la red ((elementos, motivos)); corre en otro hilo (PaginaRejilla._al_final)."""
        if self.paginas.currentWidget() is self.pag and hasattr(self, "rep"):
            self.rep.precalentar(elementos)   # los primeros, resueltos por detrás: empiezan al pulsarlos
        resto = list(elementos[POR_TANDA:])

        def siguiente():
            nonlocal resto
            tanda, resto = resto[:POR_TANDA], resto[POR_TANDA:]
            if tanda:
                return (tanda, motivos, siguiente if (resto or mas_red) else None)
            for _ in range(3 if mas_red else 0):   # el Inicio no se acaba: a la tercera tanda vacía, se deja
                r = mas_red()
                if r and r[0]:
                    return (r[0], r[1], siguiente)
            return None
        self.pag.poner(elementos[:POR_TANDA], motivos, aviso, siguiente if (resto or mas_red) else None)

    _cerrojo_dsc = threading.Lock()

    def _dsc(self):
        """28/10/2026 · Inicio, Suscripciones, Explorar y la campana se calculan aquí (descubrir.py), sin el servidor de casa
        (orden del autor: «que la app funcione bien para cualquiera, en local y sin servicios … en segundo plano»)."""
        with self._cerrojo_dsc:
            if getattr(self, "_descubrir", None) is None:
                from .descubrir import Descubrir
                self._descubrir = Descubrir(self.datos, estilo=self.ajustes.get("estilo", True))
            return self._descubrir

    def inicio(self, tema="Todo", recargar=False):
        if getattr(self, "_inicio_fresco", False):   # se ha llegado por el menú o el logo (ir_seccion), no por «atrás»
            self._inicio_fresco, recargar = False, True
        self.paginas.setCurrentWidget(self.pag)
        sin_temas = not (self._parati or {}).get("temas")
        temas = ["Todo"] + [t for t in ((self._parati or {}).get("temas") or []) if not self.datos.vetado(motor.Elemento("CANAL", "", t))][:14] + ["Novedades de tus canales", "Ya vistos"]
        turno = self.pag.preparar("", chips=temas, activo=tema, al_chip=lambda t: self.inicio(t),
                                  botones=(("▶  Reproducir todo", lambda: self.rep.todo(self.pag.rejilla.elementos)),
                                           ("🔀", lambda: self.rep.todo(self.pag.rejilla.elementos, True)),
                                           ("⟳  Actualizar", lambda: self.inicio(tema, True))),
                                  aviso=self.aviso_vigilante)

        def pintar(p):
            if not p.get("videos"):   # sin red: nada guardado (se volvería a ver vacío hasta reiniciar) y otra vez en 15 s
                self._parati = None
                self.pag.poner([], aviso="Sin conexión con YouTube: lo vuelvo a intentar solo…")
                return self._reintentar(turno)
            from .mezcla import Ensenado
            nueva = p is not self._parati
            if nueva:   # 06/10/2026: recién traído y mezclado (mezcla.py): vale 10 min
                self._parati_t = time.time()
                self._vistos_inicio = None
            self._parati = p
            if getattr(self, "_ensenado", None) is None:
                self._ensenado = Ensenado()
            ocultos = self.datos.ocultos()
            # lo visto al cargar las recomendaciones; lo que se ve ahora se queda en su sitio (con su barra roja), como YouTube
            if recargar or getattr(self, "_vistos_inicio", None) is None:
                self._vistos_inicio = {motor.id_video(e.url) for e in self.datos.historial(3000)}
                self._cansados_inicio = self._ensenado.cansados()   # 24/10/2026: lo enseñado 3 veces sin abrirlo (mezcla.Ensenado)
            vistos = self._vistos_inicio
            cansados = getattr(self, "_cansados_inicio", set())
            videos = [x for x in p.get("videos", []) if x.get("url") not in ocultos and not motor.programado(x)]
            if tema == "Ya vistos":
                lista = [x.dict() for x in self.datos.historial(200)]
            elif tema == "Novedades de tus canales":
                lista = [x for x in videos if "suscri" in (x.get("motivo") or "").lower()]
            else:
                lista = [x for x in videos if motor.id_video(x.get("url", "")) not in vistos]
                if tema != "Todo":
                    lista = [x for x in lista if x.get("autor") == tema or tema.lower() in (x.get("motivo") or "").lower()]
                lista = self._ensenado.apartar(lista, cansados, lambda x: motor.id_video(x.get("url", "")))
                if nueva and tema == "Todo":
                    self._ensenado.apuntar([motor.id_video(x.get("url", "")) for x in lista[:Ensenado.PRIMEROS]])
            motivos = {x["url"]: x.get("motivo", "") for x in lista if x.get("motivo")}
            elementos = [motor.elemento_de_dict(x) for x in lista]
            if tema == "Todo":   # 03/10/2026: «Continuar viendo» primero, como YouTube (06/10: 4, no 8: fila y media siempre igual)
                seguir = self.datos.continuar_viendo(4)
                urls = {e.url for e, _, _ in seguir}
                for e, s, d in seguir:
                    motivos[e.url] = f"Continuar viendo · {int(100 * s / d)} % visto"
                elementos = [e for e, _, _ in seguir] + [e for e in elementos if e.url not in urls]
            if sin_temas and p.get("temas") and turno == self.pag.turno:
                self.pila.pop() if self.pila else None
                return self.ir(self.inicio, tema)   # la primera vez aún no había temas para las fichas
            mas_red = None
            if tema != "Ya vistos":   # 06/10/2026: al llegar al final, más alrededor de lo suyo (mezcla.mas_para_ti)
                from .mezcla import mas_para_ti
                ya = {motor.id_video(e.url) for e in elementos}
                mas_red = lambda: mas_para_ti(self.datos, ya, tema, p.get("videos", []), vistos | cansados)   # noqa: E731
            self._por_tandas(elementos, motivos, mas_red=mas_red)

        # 06/10/2026 («el feed no puede ser siempre el mismo»): la lista guardada vale 10 min; después, o con Actualizar,
        # se vuelve a pedir y se mezcla de nuevo (mezcla.py)
        if self._parati and not recargar and time.time() - getattr(self, "_parati_t", 0) < 600:
            return pintar(self._parati)

        def traer():
            # 28/10/2026: la portada se calcula aquí (descubrir.py: semillas que rotan, lo nuevo de tus canales y lo
            # descubierto; lo que estaba arriba la vez anterior no vuelve arriba), no en el servidor (parati.json)
            from .mezcla import Ensenado
            if getattr(self, "_ensenado", None) is None:
                self._ensenado = Ensenado()
            lista, temas = self._dsc().inicio(self._ensenado.veces(), self._ensenado.cansados())
            if not lista and self._parati:   # sin red: lo que había
                return self._parati
            return {"videos": [dict(e.dict(), motivo=m) for e, m in lista], "temas": temas}
        self._cargar(turno, traer, pintar)

    def shorts(self):
        """Shorts como YouTube: uno a uno en vertical, en bucle, con la rueda o ↑ ↓ (03/10/2026; antes, una cuadrícula)."""
        self.paginas.setCurrentWidget(self.pshorts)
        self.pshorts.setFocus()
        subs = self.datos.suscripciones()
        if not subs:
            self.pshorts.aviso.setText("Los Shorts salen de los canales que sigues: suscríbete a alguno.")
            return
        self._turno_shorts = turno = getattr(self, "_turno_shorts", 0) + 1
        self.pshorts.aviso.setText("Cargando Shorts…")

        def listo(r, error):
            if turno != self._turno_shorts or self.paginas.currentWidget() is not self.pshorts:
                return
            if error or not r:
                self.pshorts.aviso.setText("No he podido cargar los Shorts" + (f" ({error.__class__.__name__})" if error else ""))
                return
            ocultos = self.datos.ocultos()
            lista = [e for e in r if e.url not in ocultos and not self.datos.vetado(e)]
            self.pshorts.aviso.setText(f"{len(lista)} Shorts de tus canales · rueda o ↑ ↓ para pasar")
            self.rep.bucle(True)
            self.rep.todo(lista)
        en_hilo(motor.shorts, listo, subs)

    def suscripciones(self, filtro="Todo", forzar=False):
        self.paginas.setCurrentWidget(self.pag)
        subs = self.datos.suscripciones()
        turno = self.pag.preparar("Suscripciones", chips=("Todo", "Hoy", "Esta semana", "No vistos"), activo=filtro,
                                  al_chip=lambda f: self.suscripciones(f),
                                  botones=(("Gestionar", lambda: self.ir(self._gestionar)),
                                           ("▶  Reproducir todo", lambda: self.rep.todo(self.pag.rejilla.elementos)),
                                           ("⟳", lambda: (setattr(self, "_novedades", None), self.suscripciones(filtro, True)))))
        if not subs:
            self.pag.poner([], aviso="Aún no sigues ningún canal: búscalo y pulsa «Suscribirse».")
            return

        def pintar(r):
            if not r:   # sin red: nada guardado y otra vez en 15 s
                self._novedades = None
                self.pag.poner([], aviso="Sin conexión: no he podido mirar lo nuevo de tus canales. Lo vuelvo a intentar solo…")
                return self._reintentar(turno)
            self._novedades = (time.time(), r)
            ahora = time.time() * 1000
            lista = r
            if filtro == "Hoy":
                lista = [e for e in r if e.fecha and ahora - e.fecha < 86_400_000]
            elif filtro == "Esta semana":
                lista = [e for e in r if e.fecha and ahora - e.fecha < 7 * 86_400_000]
            elif filtro == "No vistos":
                vistos = {motor.id_video(e.url) for e in self.datos.historial(3000)}
                lista = [e for e in r if motor.id_video(e.url) not in vistos]
            self._por_tandas(lista, aviso="" if lista else "Nada nuevo con este filtro.")
        if not forzar and self._novedades and time.time() - self._novedades[0] < 120:
            return pintar(self._novedades[1])
        self.pag.rejilla.aviso.setText(f"Mirando lo nuevo de tus {len(subs)} canales…")

        def traer():
            # 28/10/2026: el RSS de cada canal, aquí (descubrir.py: guardado 30 min; ⟳ lo vuelve a pedir de verdad); antes,
            # la lista del servidor de hasta 6 h (el ⟳ devolvía la misma y solo traía 76 de 149 canales)
            return self._dsc().suscripciones(forzar=forzar)
        self._cargar(turno, traer, pintar)

    def _gestionar(self):
        self.paginas.setCurrentWidget(self.pag)
        subs = self.datos.suscripciones()
        self.pag.preparar(f"Tus canales ({len(subs)})", atras=True, filas=True,
                          quitar=lambda e: (self.datos.quitar(e.url), self.pintar_canales(), self._gestionar()))
        self.pag.rejilla.ancho_img = 72
        self._por_tandas(subs)

    NUT = {"Juegos para gatos": "cat games for cats to watch", "TV para gatos": "cat tv birds squirrels for cats to watch",
           "Música para gatos": "relaxing music for cats"}

    def nut(self, que=None):
        """El espacio de Nut (como en el móvil): juegos, tele y música para gatos; no cuenta en el historial ni en
        «Para ti». Lo suyo es «Poner en la tele» (menú de cada vídeo)."""
        self.paginas.setCurrentWidget(self.pag)
        que = que or next(iter(self.NUT))
        turno = self.pag.preparar("Para Nut", chips=list(self.NUT), activo=que, al_chip=lambda c: self.nut(c),
                                  botones=(("📺  Poner en la tele", lambda: self.poner_en_tele(
                                      next((x for x in self.pag.rejilla.elementos if x.tipo == "VIDEO"), None))),))

        def buscar(q):
            r = [x for x in motor.buscar(q) if x.tipo == "VIDEO"][:40]
            self.datos.sin_historial = getattr(self.datos, "sin_historial", set()) | {x.url for x in r}
            return r
        self._cargar(turno, buscar, lambda r: self._por_tandas(r), self.NUT[que])

    def poner_en_tele(self, e):
        if e is None:
            return
        self.avisar("Buscando la tele…")

        def trabajo():
            from . import tele
            teles = tele.buscar()
            fichas.en_ventana(lambda t: self._elegir_tele(e, t), teles)
        threading.Thread(target=trabajo, daemon=True).start()

    def _elegir_tele(self, e, teles):
        if not teles:
            self.avisar("No encuentro ninguna tele encendida en la red de casa")
            return
        if len(teles) == 1:
            nombre, app = teles[0]
        else:
            nombre, ok = QInputDialog.getItem(self, "Poner en la tele", "¿En cuál?", [n for n, _ in teles], 0, False)
            if not ok:
                return
            app = dict(teles)[nombre]

        def trabajo():
            from . import tele
            bien = tele.poner(app, e.url)
            fichas.en_ventana(lambda b: self.avisar(f"En «{nombre}»: {e.titulo}" if b else f"La tele «{nombre}» no lo ha aceptado"), bien)
        threading.Thread(target=trabajo, daemon=True).start()

    def explorar(self, categoria=None, forzar=False):
        """28/10/2026 («explorar me pone vídeos populares de mierda y nada relacionado con las temáticas de mis canales pero
        distintos, para ampliar mi catálogo de intereses y canales»): canales que no sigues cerca de los tuyos, con su
        porqué (descubrir.py), ⟳ y sin final. Sin canales ni «me gusta», o con una categoría de antes, lo de antes."""
        self.paginas.setCurrentWidget(self.pag)
        cats = list(motor.EXPLORAR)
        dsc = self._dsc()
        fichas_ = dsc.fichas_explorar()
        if categoria in motor.EXPLORAR or not fichas_:
            categoria = categoria if categoria in motor.EXPLORAR else cats[0]
            turno = self.pag.preparar("Explorar", chips=cats, activo=categoria, al_chip=lambda c: self.explorar(c))
            aviso = "" if fichas_ else "Sigue algún canal o dale a «Me gusta» a algún vídeo y aquí saldrán canales nuevos cerca de los tuyos."
            self._cargar(turno, motor.explorar, lambda r: self._por_tandas(r, aviso=aviso), categoria)
            return
        tema = categoria or "Todo"
        ya = set()   # los canales ya enseñados en esta visita: las tandas de más no los repiten
        turno = self.pag.preparar("Explorar", chips=fichas_, activo=tema, al_chip=lambda c: self.explorar(c),
                                  botones=(("⟳  Actualizar", lambda: self.explorar(tema, True)),))
        self.pag.rejilla.aviso.setText("Buscando canales cerca de los tuyos…")

        def mas():
            r = dsc.explorar(tema, mas=True, ya=ya) or {}
            return r.get("elementos", []), r.get("motivos", {})

        def pintar(r):
            if r is None:
                return self.explorar(cats[0])
            self._por_tandas(r["elementos"], r["motivos"], r["aviso"], mas_red=mas)
        self._cargar(turno, lambda: dsc.explorar(tema, forzar=forzar, ya=ya), pintar)

    def historial(self, filtro=""):
        self.paginas.setCurrentWidget(self.pag)
        pausado = self.datos.pausar_historial
        buscar = QLineEdit()
        buscar.setPlaceholderText("Buscar en el historial")
        buscar.setText(filtro)
        buscar.setFixedWidth(260)
        buscar.returnPressed.connect(lambda: self.historial(buscar.text()))
        self.pag.preparar("Historial", filas=True,
                          botones=(buscar, ("▶  Reanudar historial" if pausado else "⏸  Pausar historial", self._pausar_historial),
                                   ("🗑  Borrar todo", self._borrar_historial)),
                          aviso="El historial está en pausa: lo que veas no se apunta." if pausado else "",
                          quitar=lambda e: (self.datos.quitar(e.url, "historial"), self.datos.poner("ocultos", e.url, e),
                                            self.historial(filtro)))
        h = self.datos.historial(20000)
        # detrás de lo visto en Cat-ode, el historial entero de la cuenta de YouTube (lo publica el recomendador)
        if self._hist_yt is None:
            self._hist_yt = []
            en_hilo(lambda: self.datos.del_servidor("/app/historial.json") or {}, lambda r, e: r and r.get("videos") and (
                setattr(self, "_hist_yt", [motor.elemento_de_dict(x) for x in r["videos"]]),
                self.paginas.currentWidget() is self.pag and self.pag.titulo.text() == "Historial" and self.historial(filtro)))
        ya = {motor.id_video(e.url) for e in h} | {motor.id_video(u) for u in self.datos.ocultos()}
        if not self.datos.borrado:
            h = h + [e for e in self._hist_yt if motor.id_video(e.url) not in ya]
        if filtro:
            f = filtro.lower()
            h = [e for e in h if f in e.titulo.lower() or f in (e.autor or "").lower()]
        self._por_tandas(h, aviso="" if h else "Nada en el historial.")

    def _pausar_historial(self):
        self.datos.pausar_historial = not self.datos.pausar_historial
        self.ajustes["pausar_historial"] = self.datos.pausar_historial
        self.guardar_ajustes()
        self.historial()

    def _borrar_historial(self):
        if QMessageBox.question(self, "Borrar el historial", "¿Borrar todo el historial de reproducciones, en todos tus equipos?") == QMessageBox.Yes:
            self.datos.borrar_historial()
            self.historial()

    def _coleccion(self, col, titulo, vacio):
        self.paginas.setCurrentWidget(self.pag)
        lista = self.datos.coleccion(col)
        self.pag.preparar(f"{titulo} ({len(lista)})", filas=True,
                          botones=(("▶  Reproducir todo", lambda: self.rep.todo(lista)), ("🔀", lambda: self.rep.todo(lista, True))),
                          quitar=lambda e: (self.datos.quitar(e.url, col), self._coleccion(col, titulo, vacio)))
        self._por_tandas(lista, aviso="" if lista else vacio)

    def despues(self):
        self._coleccion("despues", "Ver más tarde", "Nada guardado. En el menú «⋮» de cada vídeo: «Guardar para ver más tarde».")

    def megusta(self):
        self._coleccion("megusta", "Vídeos que me gustan", "Aún no has marcado ninguno con «Me gusta».")

    def listas(self):
        self.paginas.setCurrentWidget(self.pag)
        self.pag.preparar("Listas", botones=(("➕  Nueva lista", lambda: (self.nueva_lista(), self.listas())),))
        elementos = []
        for clave, x in self.datos.listas_propias():
            vids = x.get("videos", [])
            if x.get("yt"):
                elementos.append(motor.Elemento("LISTA", x["yt"], x.get("nombre", "Lista"), x.get("autor", ""), "",
                                                x.get("miniatura", ""), detalle="de YouTube"))
            else:
                elementos.append(motor.Elemento("LISTA", clave, x.get("nombre", "Lista"), "", "",
                                                vids[0].get("miniatura", "") if vids else "", detalle=f"{len(vids)} vídeos"))
        self._por_tandas(elementos, aviso="" if elementos else "Aún no tienes listas. Crea una aquí o desde el menú «⋮» de un vídeo.")

    def _lista_propia(self, clave):
        self.paginas.setCurrentWidget(self.pag)
        x = self.datos.extra("listas", clave) or {}
        vids = [motor.elemento_de_dict(v) for v in x.get("videos", [])]
        self.pag.preparar(x.get("nombre", "Lista"), atras=True, filas=True,
                          botones=(("▶  Reproducir todo", lambda: self.rep.todo(vids)), ("🔀", lambda: self.rep.todo(vids, True)),
                                   ("✏  Renombrar", lambda: self._renombrar(clave)),
                                   ("🗑  Borrar lista", lambda: (self.datos.borrar_lista(clave), self.listas()))),
                          quitar=lambda e: (self.datos.lista_poner(clave, e, False), self._lista_propia(clave)))
        self._por_tandas(vids, aviso="" if vids else "Lista vacía.")

    # ---------------------------------------------------------------- novedades de versión (22/10/2026)
    def novedades_version(self, capa=None, intentos=40):
        """El autor: «ni hay mensaje con novedades de versión, el modo música era relevante avisarlo». Lo nuevo de esta versión
        (novedades.json), UNA vez por aparato y cuando ya se ha ido el logo de arranque."""
        try:
            if capa is not None and capa.isVisible() and intentos > 0:
                QTimer.singleShot(250, lambda: self.novedades_version(capa, intentos - 1))
                return
        except RuntimeError:   # la capa del logo ya no existe
            pass
        from . import novedades_version as nv
        import html
        puntos = nv.pendientes(self.ajustes.get("novedades_vista"), VERSION, musica.hay(self.datos))
        if not puntos:
            return
        caja = QMessageBox(self)
        caja.setWindowTitle("Novedades")
        caja.setTextFormat(Qt.RichText)
        caja.setText(f"<h3>Novedades de Cat-ode {VERSION}</h3><ul>" +
                     "".join(f"<li style='margin-bottom:8px'>{html.escape(t)}</li>" for t in puntos) + "</ul>")
        caja.addButton("Entendido", QMessageBox.AcceptRole)
        caja.exec()
        self.ajustes["novedades_vista"] = VERSION
        self.guardar_ajustes()

    # ---------------------------------------------------------------- modo Música (22/10/2026; lo mismo que la web: musica.py)
    def musica(self, grupo="Todo"):
        self.paginas.setCurrentWidget(self.pag)
        elementos, chips = musica.pagina(self.datos, grupo)
        self.pag.preparar("Música", chips=chips, activo=grupo, al_chip=lambda g: self.musica(g),
                          botones=(("📥  Importar tu música", self.importar_musica),))
        self._por_tandas(elementos, aviso="" if elementos else "Aún no tienes música aquí: pulsa «📥 Importar tu música» (YouTube Music, Spotify, Amazon Music…).")

    VIAS_MUSICA = (("youtube", "YouTube Music (con tu cuenta de Google)"),
                   ("spotify_archivo", "Spotify: el archivo de «Descargar tus datos» (todo: listas, me gusta, álbumes)"),
                   ("spotify_enlace", "Spotify: el enlace de una lista pública (hasta 100 canciones)"),
                   ("carpeta", "Una carpeta con tu música (lo comprado en Amazon Music, tus discos…)"),
                   ("csv", "Un CSV con tus canciones (Amazon Music por TuneMyMusic, u otro)"))

    def importar_musica(self):
        """«Importar tu música» (22/10/2026, orden del autor para la redistribuible): todo en este aparato (importar_musica.py,
        por el servicio de cuenta, en su hilo)."""
        textos = [t for _, t in self.VIAS_MUSICA]
        t, ok = QInputDialog.getItem(self, "Importar tu música", "¿De dónde la traigo? Se queda en este Cat-ode; las canciones se "
                                     "buscan en YouTube al sonar.", textos, 0, False)
        if not ok:
            return
        via, valor = self.VIAS_MUSICA[textos.index(t)][0], ""
        if via == "spotify_enlace":
            valor, ok = QInputDialog.getText(self, "Lista de Spotify", "Pega el enlace (open.spotify.com/playlist/…):")
            if not ok or not valor.strip():
                return
        elif via == "carpeta":
            valor = QFileDialog.getExistingDirectory(self, "La carpeta de tu música", os.path.expanduser("~"))
        elif via in ("spotify_archivo", "csv"):
            if via == "spotify_archivo":
                QMessageBox.information(self, "Spotify", "Pide tus datos en spotify.com → Cuenta → Privacidad → «Descargar tus "
                                        "datos». Spotify te manda un correo en unos días con un ZIP: elígelo ahora.")
            valor, _ = QFileDialog.getOpenFileName(self, "Elegir archivo", os.path.expanduser("~"),
                                                   "CSV (*.csv);;Todo (*)" if via == "csv" else "Datos de Spotify (*.zip *.json);;Todo (*)")
        if via != "youtube" and not valor:
            return
        if getattr(self, "_musica_cuenta", None) is None:
            from .cuenta_servicio import CuentaServicio
            fichas.preparar()
            self._musica_cuenta = CuentaServicio(self.datos, lambda _tipo, d: fichas.en_ventana(self._musica_evento, d))
        r = self._musica_cuenta.accion("importar_musica", via=via, valor=valor.strip())
        self.avisar("Ya estoy importando: espera a que acabe" if (r or {}).get("ocupado") else "Importando tu música…")

    def _musica_evento(self, d):
        d = d or {}
        if d.get("fase") != "musica":
            return
        if not d.get("hecho"):
            if d.get("texto"):
                self.avisar(d["texto"])
            return
        if d.get("error"):
            QMessageBox.warning(self, "Importar tu música", d["error"])
            return
        self.avisar(d.get("resumen") or "Música importada")
        self.pintar_canales()
        self.musica()

    def _lista_musica(self, clave):
        self.paginas.setCurrentWidget(self.pag)
        nombre, cs = musica.lista(self.datos, clave)

        def solo_sonido():
            self.rep.todo(cs)
            self.barra.sonido.setChecked(True)
            self.rep.solo_sonido(True)
        self.pag.preparar(nombre, atras=True, filas=True,
                          botones=(("▶  Reproducir todo", lambda: self.rep.todo(cs)), ("🔀", lambda: self.rep.todo(cs, True)),
                                   ("🎧  Solo el sonido", solo_sonido)))
        self._por_tandas(cs, aviso="" if cs else "Esta lista no tiene canciones aquí.")

    def _renombrar(self, clave):
        x = dict(self.datos.extra("listas", clave) or {})
        nombre, ok = QInputDialog.getText(self, "Renombrar", "Nombre nuevo:", text=x.get("nombre", ""))
        if ok and nombre.strip():
            x["nombre"] = nombre.strip()
            self.datos.poner("listas", clave, None, x)
            self._lista_propia(clave)

    def _lista_yt(self, url, titulo="Lista"):
        self.paginas.setCurrentWidget(self.pag)
        guardada = any(x.get("yt") == url for _, x in self.datos.listas_propias())
        turno = self.pag.preparar(titulo or "Lista", atras=True, filas=True,
                                  botones=(("▶  Reproducir todo", lambda: self.rep.todo(self.pag.rejilla.elementos)),
                                           ("🔀", lambda: self.rep.todo(self.pag.rejilla.elementos, True)),
                                           ("✓ Guardada" if guardada else "➕  Guardar lista", lambda: self._guardar_lista_yt(url, titulo))))

        def pintar(r):
            cab, elementos = r if isinstance(r, tuple) else (None, r)
            nombre = cab if isinstance(cab, str) else getattr(cab, "titulo", "")
            if nombre:
                self.pag.titulo.setText(nombre)
            self._por_tandas(elementos)
        self._cargar(turno, motor.lista, pintar, url)

    def _guardar_lista_yt(self, url, titulo):
        for clave, x in self.datos.listas_propias():
            if x.get("yt") == url:
                self.datos.borrar_lista(clave)
                self.avisar("Lista quitada de tus listas")
                return self._lista_yt(url, titulo)
        primero = self.pag.rejilla.elementos[0] if self.pag.rejilla.elementos else None
        self.datos.poner("listas", f"yt:{url}", None, {"nombre": self.pag.titulo.text() or titulo, "yt": url,
                                                       "miniatura": primero.miniatura if primero else "",
                                                       "autor": primero.autor if primero else ""})
        self.avisar("Lista guardada en «Listas»")
        self._lista_yt(url, titulo)

    def descargas(self):
        self.paginas.setCurrentWidget(self.pag)
        self.pag.preparar("Descargas", filas=True,
                          botones=(("📂  Abrir la carpeta", lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(motor.carpeta_descargas()))),),
                          quitar=self._borrar_descarga)
        self._locales = {}
        elementos = []
        for ruta, titulo, vid in motor.descargados():
            e = motor.Elemento("VIDEO", motor.url_video(vid) if vid else "file:" + ruta, titulo, "", "",
                               motor.miniatura(vid) if vid else "",
                               detalle=("Solo sonido · " if ruta.lower().endswith((".m4a", ".mp3", ".opus")) else "") + f"{os.path.getsize(ruta) / 1e6:.0f} MB")
            self._locales[e.url] = ruta
            elementos.append(e)
        self._por_tandas(elementos, aviso="" if elementos else "Nada descargado. En el menú «⋮» de cada vídeo: «Descargar».")

    def _borrar_descarga(self, e):
        ruta = self._locales.get(e.url)
        if ruta and QMessageBox.question(self, "Borrar descarga", f"¿Borrar «{e.titulo}» del disco?") == QMessageBox.Yes:
            try:
                os.remove(ruta)
            except OSError:
                pass
            self.descargas()

    def _canal(self, url, pestana="videos"):
        """El canal: su ficha (fichas.FichaCanal) y sus pestañas: Vídeos, Shorts, Directos y Listas."""
        self.paginas.setCurrentWidget(self.pag)
        fc = self.ficha_canal
        nuevo = self._canal_url != url
        if nuevo:
            fc.empezar(url)
        self._canal_url = url
        nombres = {"videos": "Vídeos", "shorts": "Shorts", "streams": "Directos", "playlists": "Listas"}
        sub = QPushButton("Suscrito" if self.datos.suscrito(url) else "Suscribirse")
        if self.datos.suscrito(url):
            sub.setIcon(icono("campana"))
        sub.setObjectName("" if self.datos.suscrito(url) else "principal")
        sub.clicked.connect(lambda: self._alternar_sub(url, pestana))
        turno = self.pag.preparar("" if nuevo else getattr(self, "_canal_nombre", ""), atras=True, cabecera=fc,
                                  chips=list(nombres.values()), activo=nombres[pestana],
                                  al_chip=lambda n: self._canal(url, next(k for k, v in nombres.items() if v == n)),
                                  vertical=pestana == "shorts",
                                  botones=(("▶  Reproducir todo", lambda: self.rep.todo(self.pag.rejilla.elementos)),
                                           ("🔀", lambda: self.rep.todo(self.pag.rejilla.elementos, True)), sub,
                                           ("⊘  Fulminar canal", lambda: (self.fulminar(motor.Elemento("CANAL", url, getattr(self, "_canal_nombre", "") or url)), self.volver()))))
        if pestana != "videos":
            self._cargar(turno, motor.canal_pestana, lambda r: self._por_tandas(r, aviso="" if r else "Este canal no tiene nada aquí."), url, pestana)
            return

        def pintar(r):
            cab, videos, info = r
            self._canal_nombre = cab.titulo
            self.pag.titulo.setText(cab.titulo + ("  ✔" if info.get("verificado") else ""))
            self.pag.titulo.show()
            self._canal_avatar = cab.miniatura
            self._por_tandas(videos)
            if nuevo or not getattr(fc, "_info_puesta", False):
                fc.poner_info(info)
                fc._info_puesta = True
                fichas.en_fondo(md.acerca_de, lambda a: self._canal_url == url and fc.poner_acerca(a), cab.url, info.get("cabecera"))
                urls = [e.url for e in videos if e.tipo == "VIDEO"]

                def valorar():
                    def aviso(v):
                        fichas.en_ventana(lambda d: self._canal_url == url and fc.poner_valoracion(d), v)
                    try:
                        aviso(md.valoracion(urls, aviso))
                    except Exception:
                        aviso({"hechos": 0, "total": 0, "conVotos": 0, "mediaMeGusta": -1, "mediaNoMeGusta": -1})
                threading.Thread(target=valorar, daemon=True).start()
        if nuevo:
            fc._info_puesta = False
        self._cargar(turno, motor.canal_completo, pintar, url)

    def _alternar_sub(self, url, pestana):
        if self.datos.suscrito(url):
            self.datos.quitar(url)
            self.avisar("Suscripción anulada")
        else:
            self.datos.suscribir(motor.Elemento("CANAL", url, getattr(self, "_canal_nombre", "") or "Canal",
                                                miniatura=getattr(self, "_canal_avatar", "")))
            self.avisar("Suscrito")
        self.pintar_canales()
        self._canal(url, pestana)

    # ---- buscar ----
    def buscar_por_voz(self):
        """Micrófono del buscador (06/10/2026): dictado del sistema sobre el campo y búsqueda automática al callar."""
        self.campo.setFocus(); self.campo.selectAll(); self._voz_activa = True; self._voz_texto = self.campo.text()
        self.campo.textChanged.connect(self._voz_cambio)
        try:
            if getattr(self, "_voz_sin_dictado", False):   # la prueba automática: sin abrir el dictado del sistema
                pass
            elif os.name == "nt":
                import ctypes
                u = ctypes.windll.user32
                u.keybd_event(0x5B, 0, 0, 0); u.keybd_event(0x48, 0, 0, 0); u.keybd_event(0x48, 0, 2, 0); u.keybd_event(0x5B, 0, 2, 0)   # Win+H
            else:
                d = os.path.expanduser("~/.local/bin/dictar")
                if os.path.exists(d):
                    import subprocess
                    subprocess.Popen([d], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                else:
                    self.avisar("No hay dictado en este equipo: escribe y pulsa Intro")
        except Exception as e:   # noqa: BLE001
            registro(f"voz: {e!r}")
        self.avisar("Habla: se buscará en cuanto te calles")

    def _voz_cambio(self, texto):
        if self._voz_activa and texto.strip():
            self._voz_reloj.start()

    def _voz_fin(self):
        if not self._voz_activa:
            return
        self._voz_activa = False
        try:
            self.campo.textChanged.disconnect(self._voz_cambio)
        except Exception:   # noqa: BLE001
            pass
        if os.name != "nt":
            d = os.path.expanduser("~/.local/bin/dictar")   # parar el dictado (pulsar otra vez)
            if os.path.exists(d):
                import subprocess
                subprocess.Popen([d], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        q = self.campo.text().strip()
        if q:
            self.buscar(q)

    def _sugerir(self):
        q = self.campo.text()
        previas = [b for b in self.datos.busquedas(40) if q.lower() in b.lower()][:5] if q else self.datos.busquedas(10)
        self.modelo.setStringList(["⟲  " + b for b in previas])
        if q.strip():
            en_hilo(motor.sugerencias, lambda r, e: r and q == self.campo.text() and
                    self.modelo.setStringList(["⟲  " + b for b in previas] + [x for x in r if x not in previas]), q)

    def buscar(self, q, filtros=None):
        q = (q or "").removeprefix("⟲  ").strip()
        if not q:
            return
        if self.campo.text() != q:
            self.campo.setText(q)
        if re.search(r"(youtube\.com|youtu\.be)/", q):   # un enlace pegado: se abre
            return self.abrir_enlace(q)
        self.datos.buscado(q)
        self.ir(self._resultados, q, dict(filtros or {}))

    def _resultados(self, q, filtros):
        self.paginas.setCurrentWidget(self.pag)
        combos = []
        for clave, nombre in (("tipo", "Tipo"), ("fecha", "Fecha de subida"), ("duracion", "Duración"), ("orden", "Ordenar por")):
            c = QComboBox()
            c.addItem(nombre + ": cualquiera", None)
            for k in motor.FILTROS[clave]:
                c.addItem(k, k)
            if filtros.get(clave):
                c.setCurrentIndex(c.findData(filtros[clave]))
            c.currentIndexChanged.connect(lambda _=0, clave=clave, c=c: self._refiltrar(q, filtros, clave, c.currentData()))
            combos.append(c)
        turno = self.pag.preparar(f"«{q}»", filas=True, botones=combos)

        def pintar(r):
            elementos, token = r
            ocultos = self.datos.ocultos()

            def siguiente(token=token):
                if not token:
                    return None
                mas, t2 = motor.buscar_filtrada(q, filtros, token)
                return ([e for e in mas if e.url not in ocultos], None, (lambda: siguiente(t2)) if t2 else None)
            self.pag.poner([e for e in elementos if e.url not in ocultos], aviso="" if elementos else "Sin resultados.",
                           mas=(lambda: siguiente()) if token else None)
        self._cargar(turno, motor.buscar_filtrada, pintar, q, filtros)

    def _refiltrar(self, q, filtros, clave, valor):
        f = dict(filtros)
        if valor:
            f[clave] = valor
        else:
            f.pop(clave, None)
        self.pila.pop() if self.pila else None
        self.ir(self._resultados, q, f)

    def _pegar_enlace(self):
        """Ctrl+V fuera de un campo de texto (en los campos, Qt deja que peguen ellos): abre el enlace del portapapeles."""
        t = QApplication.clipboard().text().strip()
        if re.search(r"(youtube\.com|youtu\.be)/", t):
            self.abrir_enlace(t if t.startswith("http") else "https://" + t)
        else:
            self.avisar("Copia un enlace de YouTube y pulsa Ctrl+V para abrirlo aquí")

    def abrir_enlace(self, url, *_, nueva=None):
        """Un enlace pulsado en una descripción, pegado en el buscador o recibido al abrir Cat-ode: los de YouTube se
        abren aquí (un minuto del vídeo que suena salta a ese minuto) y los demás, en el navegador."""
        url = url.strip()
        if url.startswith("/"):
            url = "https://www.youtube.com" + url
        es_yt = re.search(r"https?://(www\.|m\.|music\.)?(youtube\.com|youtu\.be)/", url) is not None or url.startswith(("youtube.com", "youtu.be", "www.youtube"))
        if es_yt and not url.startswith("http"):
            url = "https://" + url
        # 05/10/2026: Ctrl+clic (o botón central, que llega con nueva=True) en un enlace de YouTube = pestaña nueva, como en
        # el navegador; antes todo iba a la misma pestaña y cortaba lo que se estaba viendo
        if nueva is None:
            nueva = bool(QApplication.keyboardModifiers() & Qt.ControlModifier)
        if nueva and es_yt and re.search(r"(watch|shorts/|live/|youtu\.be/|channel/|/@|/c/|user/|list=|/results\?|hashtag/)", url):
            self.nueva_pestana(vacia=True)
        t = re.search(r"[?&#]t=(\d+)", url)
        if es_yt and re.search(r"(youtube\.com/(watch|shorts/|live/)|youtu\.be/)", url):
            vid = motor.id_video(url)
            actual = self.rep.actual
            if t and actual is not None and motor.id_video(actual.url) == vid:
                self.rep.ir_a(int(t.group(1)))
                return
            e = motor.Elemento("VIDEO", motor.url_video(vid), "", "", "", motor.miniatura(vid))
            self.abrir_video(e, desde=int(t.group(1)) if t else None)
            return
        h = fichas.hashtag(url)
        if es_yt and h:
            return self.buscar("#" + h)
        if es_yt and re.search(r"youtube\.com/(channel/|@|c/|user/)", url):
            return self.abrir_canal(url)
        if es_yt and "list=" in url:
            return self.ir(self._lista_yt, url, "Lista")
        if es_yt and "/results?" in url:
            m = re.search(r"search_query=([^&]+)", url)
            if m:
                import urllib.parse
                return self.buscar(urllib.parse.unquote_plus(m.group(1)))
        fichas.abrir_fuera(url)

    # ---- ajustes ----
    def ajustes_pagina(self):
        self._refrescar_ajustes()
        self._pintar_vetos_ajustes()   # temas y fulminados al día (también los puestos desde el móvil)
        self.paginas.setCurrentWidget(self.opciones)

    def _pagina_ajustes(self):
        caja = QScrollArea()
        caja.setWidgetResizable(True)
        caja.setFrameShape(QFrame.NoFrame)
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(32, 16, 32, 24)
        v.setSpacing(8)
        t = QLabel("Ajustes")
        t.setObjectName("titulo")
        v.addWidget(t)

        def seccion(texto):
            v.addSpacing(10)
            s = QLabel(texto)
            s.setObjectName("seccion")
            v.addWidget(s)

        def casilla(texto, clave, al_cambiar=None, por_defecto=True):
            c = QCheckBox(texto)
            c.setChecked(self.ajustes.get(clave, por_defecto))
            c.toggled.connect(lambda s: (self.ajustes.__setitem__(clave, s), self.guardar_ajustes(), al_cambiar and al_cambiar(s)))
            v.addWidget(c)
            return c
        seccion("Reproducción")
        fila = QHBoxLayout()
        fila.addWidget(QLabel("Calidad por defecto"))
        cal = QComboBox()
        cal.addItem("Automática (según el tamaño del vídeo)", "auto")
        for alto in (360, 480, 720, 1080, 1440, 2160):
            cal.addItem(f"{alto}p", alto)
        cal.setCurrentIndex(max(0, cal.findData(self.ajustes.get("calidad", "auto"))))
        cal.currentIndexChanged.connect(lambda: (self.rep.calidad(cal.currentData()), self.guardar_ajustes()))
        fila.addWidget(cal)
        fila.addStretch()
        v.addLayout(fila)
        casilla("Reproducción automática: al acabar, sigue con un vídeo relacionado", "automatica",
                lambda s: self.video.automatica.setChecked(s))
        casilla("Seguir donde lo dejé al volver a abrir un vídeo", "reanudar")
        casilla("Vista previa sin sonido al posar el ratón sobre un vídeo", "vista_previa")
        casilla("Avisarme (aviso del sistema) cuando mis canales suban vídeos nuevos", "avisos", por_defecto=False)
        casilla("Saltar patrocinios, autopromociones y «suscríbete» (SponsorBlock)", "patrocinios",
                lambda s: setattr(self.rep, "saltar_patrocinios", s))
        if os.name == "nt":
            seccion("Escritorio remoto")
            v.addWidget(QLabel("Si manejas este equipo por Moonlight y a la vez ves Cat-ode en su pantalla, el remoto le quita "
                               "fluidez al vídeo. «Apagar» cierra la sesión del remoto; el portátil se queda esperando y "
                               "vuelve a conectar solo al «encender». También con F9."))
            self._casilla_remoto = QCheckBox("Apagar el remoto (el portátil reconecta solo al encenderlo)")
            self._casilla_remoto.setChecked(bool(self.ajustes.get("apagar_remoto")))
            self._casilla_remoto.toggled.connect(lambda s: s != bool(self.ajustes.get("apagar_remoto")) and self.apagar_remoto(s))
            v.addWidget(self._casilla_remoto)
        seccion("Sincronización con tus dispositivos")
        v.addWidget(QLabel("Suscripciones, historial, ver más tarde, me gusta, listas y por dónde vas en cada vídeo, "
                           "a través de tu servidor."))
        self.sincro = QLabel()
        self.sincro.setObjectName("gris")
        v.addWidget(self.sincro)
        b = QPushButton("Sincronizar ahora")
        b.clicked.connect(lambda: threading.Thread(target=self.datos.sincronizar, daemon=True).start())
        v.addWidget(b, 0, Qt.AlignLeft)
        seccion("Temas filtrados")
        v.addWidget(QLabel("Nada cuyo título, canal o descripción tenga estas palabras («ultra*» vale para lo que empieza así)."))
        self._caja_temas = QVBoxLayout(); v.addLayout(self._caja_temas)
        bt = QPushButton("＋  Añadir un tema…"); bt.clicked.connect(self._nuevo_tema); v.addWidget(bt, 0, Qt.AlignLeft)
        seccion("Canales fulminados")
        self._caja_fulminados = QVBoxLayout(); v.addLayout(self._caja_fulminados)
        self._pintar_vetos_ajustes()
        seccion("Vídeos solo para miembros")
        v.addWidget(QLabel("Los vídeos de miembros se piden con la sesión de YouTube de tu navegador y esta cuenta (solo esos: "
                           "nunca para buscar, para el Inicio ni para descargar)."))
        fila_m = QHBoxLayout()
        fila_m.addWidget(QLabel("Cuenta"))
        self.cuenta_miembros = QComboBox()
        self.cuenta_miembros.addItem("Ninguna", None)
        actual = self.ajustes.get("cuenta_miembros") or {}
        if actual.get("nombre"):
            from .cuenta import NOMBRES
            self.cuenta_miembros.addItem(f"{actual['nombre']} ({NOMBRES.get(actual.get('navegador'), actual.get('navegador') or '')})", actual)
            self.cuenta_miembros.setCurrentIndex(1)
        self.cuenta_miembros.setMinimumWidth(320)
        fila_m.addWidget(self.cuenta_miembros)
        fila_m.addStretch()
        v.addLayout(fila_m)
        self._aviso_miembros = QLabel("Buscando las cuentas abiertas en tus navegadores…")
        self._aviso_miembros.setObjectName("gris")
        v.addWidget(self._aviso_miembros)

        def elegir(i):
            d = self.cuenta_miembros.itemData(i)
            self.ajustes["cuenta_miembros"] = {"navegador": d["navegador"], "nombre": d["nombre"]} if d else None
            self.guardar_ajustes()
        self.cuenta_miembros.currentIndexChanged.connect(elegir)

        def cuentas_listas(lista):
            self.cuenta_miembros.blockSignals(True)
            while self.cuenta_miembros.count() > 1:
                self.cuenta_miembros.removeItem(1)
            for navegador, nombre_nav, _, _, nombre in lista:
                self.cuenta_miembros.addItem(f"{nombre} ({nombre_nav})", {"navegador": navegador, "nombre": nombre})
            k = next((j for j in range(1, self.cuenta_miembros.count())
                      if (self.cuenta_miembros.itemData(j) or {}).get("nombre", "").lower() == (actual.get("nombre") or "").lower()), 0)
            self.cuenta_miembros.setCurrentIndex(k)
            self.cuenta_miembros.blockSignals(False)
            self._aviso_miembros.setText(f"{len(lista)} cuentas y canales abiertos en tus navegadores" if lista
                                         else "No hay ninguna sesión de YouTube abierta en Firefox, Chrome, Edge o Brave")

        def buscar_cuentas():
            from . import miembros
            try:
                lista = miembros.cuentas()
            except Exception:   # noqa: BLE001
                lista = []
            fichas.en_ventana(lambda _: cuentas_listas(lista), None)
        threading.Thread(target=buscar_cuentas, daemon=True).start()
        # 18/10/2026 · «Traer mi YouTube» en dos sentidos (orden del autor: «"actualizar cuenta desde youtube", por si se han
        # suscrito nuevos canales y otra de "actualizar youtube desde cat-ode"»). En la Qt, con la sesión del navegador
        # (cuenta.navegadores(): Firefox primero), sin ventana de Google; la lógica es la de la web (cuenta_servicio)
        seccion("Traer mi YouTube")
        t_c = QLabel("Con la sesión de YouTube de tu navegador (Firefox), Cat-ode trae lo nuevo de tu cuenta (canales que has "
                     "seguido allí, vídeos vistos, «Me gusta»…) sin borrar nada, o lleva a YouTube lo que hagas aquí.")
        t_c.setWordWrap(True)
        v.addWidget(t_c)
        fila_c = QHBoxLayout()
        self._cuenta_traer = QPushButton("Actualizar cuenta desde YouTube")
        self._cuenta_llevar = QPushButton("Actualizar YouTube desde Cat-ode")
        self._cuenta_cancelar = QPushButton("Cancelar")
        self._cuenta_cancelar.hide()
        for b_c in (self._cuenta_traer, self._cuenta_llevar, self._cuenta_cancelar):
            fila_c.addWidget(b_c)
        fila_c.addStretch()
        v.addLayout(fila_c)
        self._cuenta_progreso = QLabel("")
        self._cuenta_progreso.setObjectName("gris")
        self._cuenta_progreso.setWordWrap(True)
        v.addWidget(self._cuenta_progreso)
        self._cuenta_resumen = QLabel("")
        self._cuenta_resumen.setWordWrap(True)
        v.addWidget(self._cuenta_resumen)
        from .cuenta_servicio import CuentaServicio
        fichas.preparar()   # el mensajero de los hilos a la ventana (los avisos de la cuenta llegan de su hilo)
        self._cuenta = CuentaServicio(self.datos, lambda _tipo, d: fichas.en_ventana(self._cuenta_evento, d))
        self._cuenta_traer.clicked.connect(lambda: self._cuenta_pedir("actualizar_cuenta"))
        self._cuenta_llevar.clicked.connect(lambda: self._cuenta_pedir("plan"))
        self._cuenta_cancelar.clicked.connect(lambda: self._cuenta.accion("cancelar"))
        seccion("Importar de YouTube")
        v.addWidget(QLabel("El archivo «suscripciones.csv» de Google Takeout"))
        b2 = QPushButton("Importar suscripciones…")
        b2.clicked.connect(self._importar)
        v.addWidget(b2, 0, Qt.AlignLeft)
        seccion("Descargas")
        d = QLabel(motor.carpeta_descargas())
        d.setObjectName("gris")
        v.addWidget(d)
        seccion("Actualizaciones")
        self.actualizacion = QLabel()
        self.actualizacion.setObjectName("gris")
        self.actualizacion.setWordWrap(True)
        v.addWidget(self.actualizacion)
        seccion("Atajos de teclado")
        a = QLabel("Espacio o K: pausa · J / L: 10 s atrás / adelante · ← / →: 5 s · ↑ / ↓: volumen · 0-9: ir al 0-90 % · "
                   "F: pantalla completa · M: silenciar · Mayús+N / Mayús+P: siguiente / anterior · /: buscar · Alt+←: atrás")
        a.setObjectName("gris")
        a.setWordWrap(True)
        v.addWidget(a)
        v.addStretch()
        v.addWidget(QLabel(f"Cat-ode {VERSION} · sin anuncios ni pausas"))
        caja.setWidget(w)
        return caja

    def _refrescar_ajustes(self):
        self.sincro.setText(self.datos.estado_sincro)
        self.actualizacion.setText(getattr(self, "estado_actualizacion", "") or "Al día")

    def _importar(self):
        f, _ = QFileDialog.getOpenFileName(self, "suscripciones.csv de Google Takeout", os.path.expanduser("~"), "CSV (*.csv);;Todo (*)")
        if f:
            with open(f, encoding="utf-8") as fh:
                n = self.datos.importar_takeout(fh.read())
            self.avisar(f"Importados {n} canales")
            self.pintar_canales()

    # ---- Traer mi YouTube (18/10/2026, cuenta_servicio) ----
    def _cuenta_ocupada(self, si, fase=""):
        self._cuenta_traer.setEnabled(not si)
        self._cuenta_llevar.setEnabled(not si)
        self._cuenta_cancelar.setVisible(bool(si))   # 18/10/2026 (hallazgo 4): también mientras lee (A)
        if not si:
            self._cuenta_progreso.setText("")

    def _cuenta_pedir(self, accion, **k):
        self._cuenta_resumen.setText("")
        r = self._cuenta.accion(accion, **k) or {}
        if r.get("ocupado"):
            return self.avisar("Ya estoy con ello: espera a que acabe")
        if r.get("error"):
            self._cuenta_resumen.setText(r["error"])
            return
        self._cuenta_ocupada(True, {"actualizar_cuenta": "leer"}.get(accion, accion))
        self._cuenta_progreso.setText("Leyendo tu YouTube…" if accion == "actualizar_cuenta" else
                                      "Mirando qué falta en YouTube…" if accion == "plan" else "Aplicando…")

    def _cuenta_evento(self, d):
        d = d or {}
        if not d.get("hecho"):
            self._cuenta_ocupada(True, d.get("fase", ""))
            txt = d.get("texto") or ""
            if isinstance(d.get("fraccion"), (int, float)):
                txt = f"{int(100 * d['fraccion'])} % · {txt}"
            if txt:
                self._cuenta_progreso.setText(txt)
            return
        self._cuenta_ocupada(False)
        if d.get("error"):
            self._cuenta_resumen.setText(d["error"])
            return
        if d.get("fase") == "plan":
            return self._cuenta_confirmar(d.get("plan") or {})
        self._cuenta_resumen.setText(d.get("resumen") or "")
        if d.get("resumen"):
            self.avisar(d["resumen"])
        if d.get("fase") == "leer":
            self.pintar_canales()

    def _cuenta_confirmar(self, plan):
        """El diálogo de «Actualizar YouTube desde Cat-ode»: números, nombres de los canales y la cuenta destino."""
        from PySide6.QtWidgets import QDialog, QDialogButtonBox, QPlainTextEdit
        n = plan.get("numeros") or {}
        dlg = QDialog(self)
        dlg.setWindowTitle("Actualizar YouTube desde Cat-ode")
        dlg.setMinimumWidth(520)
        lay = QVBoxLayout(dlg)
        ids = plan.get("identidades") or []
        combo = None
        if len(ids) > 1:
            lay.addWidget(QLabel("En qué cuenta o canal de YouTube"))
            combo = QComboBox()
            for i in ids:
                combo.addItem(i.get("nombre") or i.get("clave"), i.get("clave"))
            k = next((j for j, i in enumerate(ids) if i.get("clave") == (plan.get("identidad") or {}).get("clave")), 0)
            combo.setCurrentIndex(k)
            lay.addWidget(combo)
        partes = []
        if n.get("suscribir"):
            partes.append(f"suscribirse a {n['suscribir']} canal{'es' if n['suscribir'] != 1 else ''}")
        if n.get("quitar"):
            partes.append(f"quitar {n['quitar']} canal{'es' if n['quitar'] != 1 else ''}")
        if n.get("megusta"):
            partes.append(f"{n['megusta']} «Me gusta»")
        if n.get("despues"):
            partes.append(f"{n['despues']} en «Ver más tarde»")
        cab = QLabel(("Voy a " + ", ".join(partes) + ".") if partes else "Nada que llevar: tu YouTube ya tiene lo de Cat-ode.")
        cab.setWordWrap(True)
        lay.addWidget(cab)
        lineas = []
        if plan.get("suscribir"):
            lineas += ["Suscribirse a:"] + [f"  · {x}" for x in plan["suscribir"]]
        if plan.get("quitar"):
            lineas += ["Quitar la suscripción a:"] + [f"  · {x}" for x in plan["quitar"]]
        if n.get("quedan_megusta") or n.get("quedan_despues"):
            lineas.append(f"Como mucho 150 de cada en cada pasada: quedan {n.get('quedan_megusta', 0)} «Me gusta» y "
                          f"{n.get('quedan_despues', 0)} «Ver más tarde» para la siguiente.")
        if n.get("sin_identificar"):
            lineas.append(f"{n['sin_identificar']} canal(es) sin identificar: se saltan.")
        if lineas:
            caja_t = QPlainTextEdit("\n".join(lineas))
            caja_t.setReadOnly(True)
            caja_t.setMinimumHeight(160)
            lay.addWidget(caja_t)
        botones = QDialogButtonBox()
        b_aplicar = botones.addButton("Aplicar", QDialogButtonBox.AcceptRole) if partes else None
        botones.addButton("Cancelar" if partes else "Cerrar", QDialogButtonBox.RejectRole)
        botones.accepted.connect(dlg.accept)
        botones.rejected.connect(dlg.reject)
        lay.addWidget(botones)
        otra = {"clave": None}
        if combo is not None:
            def cambiar(_i):
                otra["clave"] = combo.currentData()
                dlg.done(2)
            combo.currentIndexChanged.connect(cambiar)
        r = dlg.exec()
        if r == 2 and otra["clave"]:
            return self._cuenta_pedir("plan", destino=otra["clave"])
        if r == QDialog.Accepted and b_aplicar is not None:
            return self._cuenta_pedir("aplicar", plan=plan.get("id"))
        self._cuenta.accion("olvidar_plan")
        self._cuenta_resumen.setText("Cancelado: no he tocado tu YouTube" if partes else "Nada que llevar a YouTube")

    # ---- reproducción ----
    def _empieza(self, e):
        self.datos.visto(e)
        n = self.reps.index(self.rep) if self.rep in self.reps else None
        if n is not None and n < len(self.pestanas):   # su pestaña apunta al vídeo nuevo (automática, cola), se vea o no
            pila = self.pestanas[n]
            if pila and pila[-1][0] == self._mostrar_video:
                pila[-1] = (self._mostrar_video, (e,))
        if n != self.pestana:
            return
        if self.paginas.currentWidget() is self.video:
            if self.video.cargando and motor.id_video(self.video.cargando) != motor.id_video(e.url):
                self.video.cargar(e)   # la página del vídeo sigue al que suena
            if self.video.cartel.isVisible():
                self._mostrar_video(e)
        self.video.refrescar_cola()

    def _guardar_posicion(self):
        r = self.rep
        if r.actual is not None and r.dur and r.pos > 5 and r.actual.url.startswith("http") and not r.directo:   # un directo no se «reanuda»
            self.datos.guardar_posicion(r.actual.url, r.pos, r.dur)

    def _automatica(self, ultimo):
        if not self.ajustes.get("automatica", True):
            return
        vistos = {motor.id_video(e.url) for e in self.datos.historial(300)} | {motor.id_video(e.url) for e in self.rep.cola}
        ocultos = self.datos.ocultos()

        sonados = list(getattr(self.rep, "sonados", []))

        def elegir(rel, relleno=True):
            rel = [e for e in (rel or []) if not self.datos.vetado(e)]   # nunca uno fulminado o de un tema filtrado
            # 22/10/2026 (encargo 3.8): otra canción, nunca la misma en otra subida ni lo ya sonado (cancion.py)
            sig = cancion.siguiente(rel, ultimo, sonados, vistos=vistos, ocultos=ocultos)
            if sig is None and relleno and cancion.es_cancion(ultimo):   # una canción y ninguna otra suelta: el Mix de YouTube
                registro(f"automática: «{ultimo.titulo[:40]}» sin otra canción suelta entre los relacionados: el Mix")
                return en_hilo(lambda: cancion.mezcla(ultimo, sonados, vistos, ocultos, lambda u: motor.lista(u)[1]),
                               lambda s2, error: poner(s2 or next((e for e in rel if motor.id_video(e.url) != motor.id_video(ultimo.url)), None)))
            if sig is None and relleno and rel:   # todo era la misma canción: relleno con los relacionados de uno de ellos
                registro(f"automática: todo era la misma canción que «{ultimo.titulo[:40]}»: relleno")
                return en_hilo(motor.relacionados, lambda r2, error: elegir(r2, relleno=False), rel[-1].url)
            poner(sig or next((e for e in rel if motor.id_video(e.url) != motor.id_video(ultimo.url)), None))

        def poner(sig):
            if sig:
                registro(f"automática: «{ultimo.titulo[:40]}» → «{sig.titulo[:40]}»")
                self.rep.encolar(sig)
                self.rep.siguiente("reproducción automática")
        if self.video.e and motor.id_video(self.video.e.url) == motor.id_video(ultimo.url) and self.video.rel:
            return elegir(self.video.rel)
        en_hilo(motor.relacionados, lambda rel, error: elegir(rel), ultimo.url)

    def _datos_cambiaron(self):
        self.sincro_icono.setText("⟳ " + self.datos.estado_sincro.replace("Sincronizado a las", "sincronizado").split(" (")[0])
        if self.paginas.currentWidget() is self.opciones:
            self._refrescar_ajustes()
        if self.paginas.currentWidget() is self.video:
            self.video._botones()
        n = sum(1 for i in range(self.menu.count()) if str(self.menu.item(i).data(Qt.UserRole) or "").startswith("canal:"))
        if n != len(self.datos.suscripciones()):
            self.pintar_canales()

    def _menu_video_reproductor(self):
        """Clic derecho sobre el vídeo: lo de la rueda dentada de YouTube y compartir."""
        from PySide6.QtGui import QCursor
        e = self.rep.actual
        m = QMenu(self)
        m.addAction("⏸  Pausa / seguir  (espacio)", self.rep.alternar)
        m.addAction("⛶  Salir de pantalla completa  (Esc)" if self.isFullScreen() else "⛶  Pantalla completa  (F)", self.pantalla_completa)
        m.addMenu(self.barra._menu_velocidad()).setText("⏱  Velocidad")
        m.addMenu(self.barra._menu_calidad()).setText("⚙  Calidad")
        m.addMenu(self.barra._menu_subtitulos()).setText("CC  Subtítulos")
        a = m.addAction("🔁  Repetir este vídeo")
        a.setCheckable(True)
        a.setChecked(self.barra.bucle.isChecked())
        a.triggered.connect(lambda si: (self.barra.bucle.setChecked(si), self.rep.bucle(si)))
        if e is not None:
            m.addSeparator()
            m.addMenu(menu_compartir(self, e, self.rep.pos, m))
        m.exec(QCursor.pos())

    # ---- avisos de vídeos nuevos de tus canales (03/10/2026) ----
    def _arrancar_avisos(self):
        """Cada 15 minutos, con la app abierta, mira las novedades de tus canales (28/10/2026: descubrir.campana, los 10
        canales que más publican; antes, /app/novedades.json del ProBook): lo que no se había visto antes cuenta en la
        campana y, si está activado en Ajustes, sale un aviso del sistema."""
        self._nuevos = []
        self.bandeja = None
        try:
            from PySide6.QtWidgets import QSystemTrayIcon
            if QSystemTrayIcon.isSystemTrayAvailable():
                ruta = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "catode.svg")
                self.bandeja = QSystemTrayIcon(QIcon(ruta), self)
                self.bandeja.setToolTip("Cat-ode")
                self.bandeja.messageClicked.connect(self._abrir_campana)
                self.bandeja.activated.connect(lambda motivo: motivo != QSystemTrayIcon.Context and self._mostrar_desde_bandeja())
                self.bandeja.setContextMenu(self._menu_bandeja())
                self.bandeja.show()
        except Exception:   # noqa: BLE001
            self.bandeja = None
        self._reloj_avisos = QTimer(self, interval=15 * 60_000)
        self._reloj_avisos.timeout.connect(self._mirar_novedades)
        self._reloj_avisos.start()
        QTimer.singleShot(20_000, self._mirar_novedades)

    def _mirar_novedades(self):
        subs = {s.url for s in self.datos.suscripciones()}
        if not subs:
            return

        def traer():   # 28/10/2026: de descubrir.py (los 10 canales que más publican, cada 15 min), no del servidor
            return self._dsc().campana() or None

        def listo(lista, error):
            if not lista:
                return
            conocidos = set(self.ajustes.get("avisados") or [])
            ids = [motor.id_video(e.url) for e in lista]
            if not conocidos:   # la primera vez no se avisa de nada: se parte de lo que hay
                self.ajustes["avisados"] = ids[:600]
                return self.guardar_ajustes()
            vistos = {motor.id_video(e.url) for e in self.datos.historial(400)}
            nuevos = [e for e, i in zip(lista, ids) if i not in conocidos and i not in vistos]
            self.ajustes["avisados"] = (ids + [i for i in conocidos if i not in ids])[:600]
            self.guardar_ajustes()
            if not nuevos:
                return
            self._nuevos = nuevos + [e for e in self._nuevos if e.url not in {n.url for n in nuevos}]
            self.campana.setText(str(len(self._nuevos)))
            if self.ajustes.get("avisos", False) and self.bandeja is not None:   # 05/10/2026: apagados por defecto («las odio»)
                lineas = "\n".join(f"{e.autor}: {e.titulo[:60]}" for e in nuevos[:3]) + ("\n…" if len(nuevos) > 3 else "")
                self.bandeja.showMessage(f"{len(nuevos)} vídeo{'s' if len(nuevos) > 1 else ''} nuevo{'s' if len(nuevos) > 1 else ''} de tus canales", lineas, QIcon(), 8000)
        en_hilo(traer, listo)

    def _abrir_campana(self):
        self._nuevos = []
        self.campana.setText("")
        self.showNormal()
        self.activateWindow()
        self.ir(self.suscripciones, "No vistos")

    # ---- el vídeo fuera de su sitio: mini (esquina) e imagen en imagen (ventana flotante) ----
    def imagen_en_imagen(self):
        """La «i» de YouTube: el vídeo que suena, en una ventana flotante siempre encima; otra vez, vuelve."""
        if self.flotante is not None:
            return self.volver_de_flotante()
        if self.rep.actual is None:
            return self.avisar("No hay ningún vídeo sonando")
        if self.isFullScreen():
            self.pantalla_completa()
        self._a_flotante("pip")

    def _a_flotante(self, modo):
        z = self.zonas_pestana[self.pestana]
        if self.flotante is not None or self.video.zonas.indexOf(z) < 0:
            return
        self.video.zonas.removeWidget(z)
        self.flotante = Flotante(self, z, modo, self.pestana)
        self.controles.colocar()

    def ocultar_flotante(self, como=""):
        """22/10/2026 (3.9) · quitar la mini SIN pararla: la zona vuelve a la página del vídeo (que no se ve) y sigue sonando;
        no vuelve a salir sola hasta que se abra la página del vídeo."""
        f = self.flotante
        if f is None:
            return
        self.flotante = None
        self._mini_quitada = True
        self._vid_pestanas()
        z = f.zona
        z.setParent(self.video.zonas)
        self.video.zonas.addWidget(z)
        f.close()
        f.deleteLater()
        registro(f"mini: quitada con {como} (sigue sonando)")
        self.avisar("Sigue sonando. Para volver a verlo, abre el vídeo")
        self.controles.colocar()

    def volver_de_flotante(self, parar=False):
        """La zona vuelve al stack de la página del vídeo; sin «parar», se abre la página de ese vídeo (como YouTube)."""
        f = self.flotante
        if f is None:
            return
        self.flotante = None
        self._vid_pestanas()
        z = f.zona
        z.setParent(self.video.zonas)
        self.video.zonas.addWidget(z)
        f.close()
        f.deleteLater()
        if parar:
            self._con(self.reps[f.pestana], lambda: (self._guardar_posicion(), self.reps[f.pestana].parar()))
            self.controles.colocar()
            return
        if f.pestana != self.pestana and 0 <= f.pestana < len(self.pestanas):
            self.barra_pestanas.setCurrentIndex(f.pestana)
        self.video.ver_zona(z)
        if self.rep.actual is not None:
            self.abrir_video(self.rep.actual, sonar=False)
        self.controles.colocar()

    def _pagina_cambiada(self, _i=None):
        """Como YouTube: al salir de la página del vídeo con algo sonando, el minirreproductor en la esquina; al volver,
        el vídeo a su sitio."""
        f = self.flotante
        actual = self.paginas.currentWidget()
        ps = self.pshorts
        if actual is not ps and ps.zona is not None:   # se sale de los Shorts: su vídeo se para (como YouTube) y la zona vuelve
            z = ps.zona
            if z in self.zonas_pestana:
                r = self.reps[self.zonas_pestana.index(z)]
                self._con(r, r.parar)
                r.bucle(False)
            ps.soltar_zona()
        if actual is ps:
            if f is not None:
                self.volver_de_flotante(parar=True)
            z = self.zonas_pestana[self.pestana]
            if self.video.zonas.indexOf(z) >= 0:
                self.video.zonas.removeWidget(z)
                ps.tomar_zona(z)
            return
        if actual is self.video:
            self._mini_quitada = False   # 22/10/2026 (3.9): vuelve a la página del vídeo: la mini puede volver a salir
            if f is not None and f.modo == "mini" and f.pestana == self.pestana:
                self.volver_de_flotante()
        elif f is None and self.rep.actual is not None and not self.rep.pausa and not self.isFullScreen() \
                and not getattr(self, "_mini_quitada", False):
            self._a_flotante("mini")

    def resizeEvent(self, ev):
        super().resizeEvent(ev)
        if getattr(self, "flotante", None) is not None:
            self.flotante.recolocar()

    def modo_cine(self):
        """La «t» de YouTube: vídeo a todo el ancho sin salir a pantalla completa. Se recuerda."""
        if self.isFullScreen():
            return
        self.video.colocar_cine(not self.video.cine)
        self.ajustes["cine"] = self.video.cine
        self.guardar_ajustes()

    def pantalla_completa(self):
        completa = not self.isFullScreen()
        if completa:
            # 03/10/2026 (el autor: «no se pone a pantalla completa en el mini PC»): antes se negaba en silencio con el vídeo
            # en la esquina / imagen en imagen o con la portada a la vista; ahora se trae el vídeo que suena y se agranda
            if self.flotante is not None:
                self.volver_de_flotante()
            if self.paginas.currentWidget() is self.pshorts:
                return registro("pantalla completa: no en Shorts")
            if (self.paginas.currentWidget() is not self.video or self.video.cartel.isVisible()) and self.rep.actual is not None:
                self._mostrar_video(self.rep.actual)
            if self.video.cartel.isVisible() or self.rep.actual is None:
                return registro("pantalla completa: no hay vídeo sonando")
        for w in (self.menu, self.arriba, self.caja_pest, self.video.info, self.video.lado):
            w.setVisible(not completa)
        self.video.a_pantalla(completa)
        self.video.layout().setContentsMargins(*((0, 0, 0, 0) if completa else (20, 10, 12, 0)))
        self.statusBar().setVisible(not completa)
        if completa:
            self.paginas.setCurrentWidget(self.video)
            self.barra.hide()
            # 05/10/2026 (el autor: al salir, la ventana «se reduce», «insultante»): se recuerda si estaba maximizada
            self._maximizada_antes = self.isMaximized()
            self.showFullScreen()
            self.controles.mostrar()
            QTimer.singleShot(400, self._asegurar_completa)
        else:
            if getattr(self, "_maximizada_antes", False):
                self.showMaximized()
            else:
                self.showNormal()
            self.video.video.unsetCursor()
            self.barra.refrescar()

    def _asegurar_completa(self):
        """Windows a veces no obedece a showFullScreen (ventana maximizada o restaurada de otra pantalla): se insiste."""
        if self.isFullScreen() or self.barra.isVisible():
            return
        registro("pantalla completa: Windows no la puso a la primera; se insiste")
        self.showNormal()
        self.setWindowState((self.windowState() & ~Qt.WindowMaximized) | Qt.WindowFullScreen)
        self.show()

    def suena_algo(self):
        return any(r.actual is not None and not r.pausa for r in self.reps)

    def salir(self):
        """Salir de verdad (menú de la bandeja): sin esconderse aunque suene algo."""
        self._saliendo = True
        self.close()

    def _mostrar_desde_bandeja(self):
        self.showNormal(); self.raise_(); self.activateWindow()

    def _menu_bandeja(self):
        """05/10/2026: menú de la bandeja (antes no tenía): Mostrar · Pausar/Seguir · Salir."""
        m = QMenu(self)
        m.addAction("Mostrar Cat-ode", self._mostrar_desde_bandeja)
        self._accion_pausa = m.addAction("Pausar", lambda: self.rep.alternar())
        m.addSeparator()
        m.addAction("Salir", self.salir)
        m.aboutToShow.connect(lambda: self._accion_pausa.setText("Pausar" if self.suena_algo() else "Seguir"))
        return m

    def closeEvent(self, ev):
        # 06/10/2026: cerrar es cerrar. Lo de «esconderse en la bandeja y seguir sonando» (05/10) se retira: el autor se
        # encontró Cat-ode cerrada y un vídeo sonando sin ventana («¿qué está pasando?»). Nada sigue vivo al cerrar.
        if self.isFullScreen():
            self.pantalla_completa()
        self.ajustes["geometria"] = bytes(self.saveGeometry().toBase64()).decode()
        self.ajustes["pestanas"] = self._pestanas_guardables()   # 05/10/2026: se reabren al arrancar
        self.ajustes["pestana_activa"] = self.pestana
        for r in self.reps:
            self._con(r, self._guardar_posicion)
        self.guardar_ajustes()
        threading.Thread(target=self.datos.sincronizar, daemon=True).start()
        for r in self.reps:
            r.cerrar()
        p = getattr(self, "previa", None)   # el mpv de la vista previa también se para (en Windows reventaba al salir)
        if p is not None and p.mpv is not None:
            try:
                if os.name == "nt":
                    p.mpv.command_async("stop")
                else:
                    p.mpv.command("stop")
                    p.mpv.terminate()
            except Exception:   # noqa: BLE001
                pass
        # 03/10/2026 (vigía de cuelgues): en Windows, cerrar la ventana mientras un mpv aún carga o para la dejaba colgada;
        # se atienden los mensajes hasta que todos han parado (como mucho 3 s en total)
        t0 = time.time()
        for r in self.reps:
            self._esperar_parado(r, tope=max(0.1, 3 - (time.time() - t0)))
        self.datos.esperar_guardado()
        if os.name == "nt":
            # 04/10/2026 (vigía de cuelgues): destruir la ventana con las de vídeo de mpv aún vivas colgaba Windows al cerrar;
            # todo está guardado: se sale ya (catode.pyw ya salía así, sin finalizadores, justo después)
            from .reproductor import registro as _r
            _r("cerrar: guardado y fuera")
            codigo = getattr(self, "codigo_salida", 0)
            try:   # sin descargar las librerías (la de mpv reventaba al soltarse: 0xC0000005 y aviso de error de Windows)
                import ctypes
                k = ctypes.windll.kernel32
                k.GetCurrentProcess.restype = ctypes.c_void_p
                k.TerminateProcess(ctypes.c_void_p(k.GetCurrentProcess()), codigo)
            finally:
                os._exit(codigo)
        super().closeEvent(ev)


_iconizador = None


def tema(app):
    global _iconizador
    from .efectos import Estilo
    app.setStyle(Estilo())   # Fusion, con las casillas como interruptores (como YouTube)
    # Roboto (la de YouTube) dentro de la app: la misma letra en Windows y en Linux
    from PySide6.QtGui import QFontDatabase, QFont
    carpeta = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fuentes")
    for n in ("Roboto-400.ttf", "Roboto-500.ttf", "Roboto-700.ttf"):
        QFontDatabase.addApplicationFont(os.path.join(carpeta, n))
    f = QFont("Roboto")
    f.setPixelSize(14)
    f.setHintingPreference(QFont.PreferVerticalHinting)
    f.setStyleStrategy(QFont.PreferAntialias)
    app.setFont(f)
    _iconizador = Iconizador()
    app.installEventFilter(_iconizador)
    p = QPalette()
    for rol, color in ((QPalette.Window, "#0F0F0F"), (QPalette.WindowText, "#F1F1F1"), (QPalette.Base, "#121212"),
                       (QPalette.Text, "#F1F1F1"), (QPalette.Button, "#272727"), (QPalette.ButtonText, "#F1F1F1"),
                       (QPalette.Highlight, "#3F3F3F"), (QPalette.HighlightedText, "#FFFFFF"), (QPalette.ToolTipBase, "#272727"),
                       (QPalette.ToolTipText, "#F1F1F1")):
        p.setColor(rol, QColor(color))
    app.setPalette(p)
    app.setStyleSheet(ESTILO)


def aplicar_escala(app, escala):
    """05/10/2026: Ctrl+rueda: la letra de la app y los font-size del estilo, por el factor (1 = como siempre)."""
    f = app.font()
    f.setPixelSize(round(14 * escala))
    app.setFont(f)
    app.setStyleSheet(ESTILO if escala == 1 else
                      re.sub(r"font-size:\s*(\d+)px", lambda m: f"font-size: {round(int(m.group(1)) * escala)}px", ESTILO))
