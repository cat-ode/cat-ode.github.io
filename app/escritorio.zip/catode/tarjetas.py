"""Cat-ode escritorio · las piezas de la interfaz al estilo YouTube (1.0.0, 02/10/2026): la tarjeta de vídeo (miniatura
con duración y barra roja de lo visto, título en dos líneas, canal y datos, menú «⋮»), la fila compacta de
«A continuación», la cuadrícula que se adapta al ancho y pide más al llegar abajo, y el menú de compartir."""
import os

from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtGui import QGuiApplication, QPainter, QColor, QFont, QFontMetrics
from PySide6.QtWidgets import (QWidget, QLabel, QVBoxLayout, QHBoxLayout, QPushButton, QMenu, QScrollArea, QGridLayout,
                               QFrame)

from . import compartir, motor, metadatos as md
from .efectos import Aparicion, suavizar

ROJO = "#FF2D2D"
# 09/11/2026 · tema «iPhone con rollo linuxero» (como web/css/tema.css): negro de fondo, grises de sistema de iOS, el naranja
# de Cat-ode para lo visto y lo que se elige, Ubuntu Sans para el texto y Ubuntu Sans Mono (la del terminal) para los datos
ACENTO = "#FF7A00"
LETRA, MONO = "Ubuntu Sans", "Ubuntu Sans Mono"
FONDO, PANEL, PANEL_2 = "#000000", "#1C1C1E", "#2C2C2E"


def pie(e, motivo=False):
    """Canal · visualizaciones · hace X, sin repetir lo que ya diga el detalle."""
    partes = []
    det = e.detalle or ""
    if e.tipo == "LISTA":
        partes.append("Lista" + (f" · {det}" if det else ""))
    elif e.tipo == "CANAL":
        partes.append(det)
    else:
        if det:
            partes.append(det)
        if e.fecha:
            partes.append(motor.hace(e.fecha))
    return " · ".join(p for p in partes if p)


def nitida(url, vertical=False, ancho=320):
    """La miniatura a la resolución que pide su sitio: los Shorts en vertical a 1080×1920 (antes se recortaba la de
    320×180 y salían pixelados) y las tarjetas grandes a 1280×720. Si YouTube no la tiene, Imagenes vuelve a la pequeña."""
    if "/mqdefault." not in (url or "") and "/hqdefault." not in (url or ""):
        return url
    base = url.rsplit("/", 1)[0]
    if vertical:
        return base + "/oardefault.jpg"
    return base + "/hq720.jpg" if ancho >= 200 else url


class Miniatura(Aparicion, QLabel):
    """La miniatura con la duración abajo a la derecha y, si se dejó a medias, la barra roja de lo visto."""
    def __init__(self, ancho, alto, redonda=False):
        super().__init__()
        self.setFixedSize(ancho, alto)
        self.duracion, self.visto, self.redonda = "", 0.0, redonda
        self.setStyleSheet(f"background: {PANEL}; border-radius: 12px;" if not redonda else "background: transparent;")

    def paintEvent(self, ev):
        if getattr(self, "_nueva", None) is None:
            super().paintEvent(ev)
        else:   # fondo + la imagen que está apareciendo
            q = QPainter(self); q.setRenderHint(QPainter.Antialiasing); q.setPen(Qt.NoPen)
            if not self.redonda:
                q.setBrush(QColor(PANEL)); q.drawRoundedRect(self.rect(), 12, 12)
            self.pintar_aparicion(q); q.end()
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        if self.duracion:
            f = QFont(MONO); f.setPointSizeF(max(8.0, self.font().pointSizeF() * 0.85)); f.setBold(True)
            p.setFont(f)
            m = QFontMetrics(f)
            w, h = m.horizontalAdvance(self.duracion) + 12, m.height() + 2
            x, y = self.width() - w - 7, self.height() - h - 7
            p.setPen(Qt.NoPen); p.setBrush(QColor(0, 0, 0, 185)); p.drawRoundedRect(x, y, w, h, 7, 7)
            p.setPen(QColor("white")); p.drawText(x, y, w, h, Qt.AlignCenter, self.duracion)
        if self.visto > 0.02:
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(255, 255, 255, 56)); p.drawRect(0, self.height() - 3, self.width(), 3)
            p.setBrush(QColor(ACENTO)); p.drawRect(0, self.height() - 3, int(self.width() * min(1.0, self.visto)), 3)
        p.end()


class _Fuentes:
    """Las letras de las tarjetas, creadas una sola vez (crear QFont y medir en cada tarjeta también cuesta)."""
    hechas = None

    @classmethod
    def dar(cls):
        if cls.hechas is None:
            def f(px, peso=QFont.Normal, familia=LETRA):
                x = QFont(familia); x.setPixelSize(px); x.setWeight(peso); return x
            cls.hechas = {"titulo": f(15, QFont.DemiBold), "titulo_fila": f(14, QFont.DemiBold), "gris": f(13), "motivo": f(12, QFont.Medium),
                          "duracion": f(11, QFont.Bold, MONO), "mas": f(18, QFont.Bold)}
            cls.hechas["m"] = {k: QFontMetrics(v) for k, v in cls.hechas.items() if isinstance(v, QFont)}
        return cls.hechas


def _lineas(texto, fm, ancho, maximo):
    """Parte el texto en líneas que caben (como mucho «maximo»; la última, con «…» si sobra)."""
    palabras, lineas, actual = (texto or "").split(), [], ""
    for i, p in enumerate(palabras):
        prueba = (actual + " " + p).strip()
        if fm.horizontalAdvance(prueba) <= ancho or not actual:
            actual = prueba
        else:
            lineas.append(actual)
            actual = p
            if len(lineas) == maximo:
                actual = ""
                lineas[-1] = fm.elidedText(lineas[-1] + " " + " ".join(palabras[i:]), Qt.ElideRight, ancho)
                break
    if actual:
        lineas.append(actual)
    return [fm.elidedText(x, Qt.ElideRight, ancho) for x in lineas[:maximo]]


class Tarjeta(Aparicion, QWidget):
    """Un vídeo, canal o lista como UNA sola pieza que se dibuja entera (02/10/2026: con etiquetas y botones sueltos,
    48 tarjetas tardaban 3 s en salir en el mini PC con Windows). Dos formas: «rejilla» (miniatura arriba, como el
    Inicio de YouTube; vertical = Shorts) y «fila» (miniatura a la izquierda: «A continuación», historial, búsquedas)."""
    pulsada = Signal(object)
    GRIS, BLANCO, NARANJA_M = QColor("#98989F"), QColor("#F5F5F7"), QColor("#FF9F45")

    def __init__(self, ventana, e, ancho=320, vertical=False, motivo="", fila=False, ancho_img=168, quitar=None):
        super().__init__()
        self.ventana, self.e, self.fila, self.quitar_fn = ventana, e, fila, quitar
        self.motivo = motivo
        self.setCursor(Qt.PointingHandCursor)
        self.setMouseTracking(True)
        self.setAttribute(Qt.WA_OpaquePaintEvent)   # se pinta entera (fondo incluido): nada debajo que repintar
        self.setFocusPolicy(Qt.StrongFocus)   # 05/10/2026: las rejillas se recorren con Tab y flechas, como en YouTube
        self.canal = e.tipo == "CANAL"
        self.encima = None   # qué zona tiene el ratón: None, "tarjeta", "mas", "quitar", "autor"
        self.pix = None
        F = _Fuentes.dar()
        if fila:
            self.iw = ancho_img
            self.ih = min(136, int(ancho_img * 0.55)) if self.canal else int(ancho_img * 9 / 16)
            self.av = self.ih if self.canal else self.iw   # ancho real de la imagen (el avatar es redondo)
        else:
            self.iw = ancho
            self.ih = int(ancho * 16 / 9) if vertical else int(ancho * 9 / 16)
            if self.canal:
                self.iw = self.ih = min(ancho, 160)
            self.av = self.iw
        self.ancho = ancho
        url = e.miniatura if self.canal else nitida(e.miniatura, vertical, self.iw)
        if not fila and vertical and not self.canal:
            url = nitida(e.miniatura, True, self.iw)
        ventana.imagenes.poner(url, self, self.av, self.ih, redonda=self.canal)
        self.duracion = motor.tiempo(e.duracion) if e.duracion and e.duracion > 0 else ("LISTA" if e.tipo == "LISTA" else "")
        s, d = ventana.datos.posicion(e.url) if e.tipo == "VIDEO" else (0, 0)
        self.visto = (s / d) if d else 0.0
        self.meta = pie(e)
        self._maquetar()
        if not fila:
            self.setFixedWidth(ancho)
        self.setMinimumHeight(self.alto)

    # ---- medidas ----
    def _maquetar(self):
        F = _Fuentes.dar(); m = F["m"]
        if self.fila:
            x0 = self.iw + 12
            ancho_txt = max(80, (self.width() if self.width() > 200 else 420) - x0 - 34 - (30 if self.quitar_fn else 0))
            self.lin_titulo = _lineas(self.e.titulo, m["titulo_fila"], ancho_txt, 3)
            alto_txt = len(self.lin_titulo) * 19 + 4 + (18 if self.e.autor else 0) + 18 + (16 if self.motivo else 0)
            self.alto = max(self.ih, alto_txt) + 8
            self.ancho_txt = ancho_txt
        else:
            ancho_txt = self.ancho - 34
            self.lin_titulo = _lineas(self.e.titulo, m["titulo"], ancho_txt, 2)
            self.alto = self.ih + 10 + len(self.lin_titulo) * 21 + (19 if self.e.autor and not self.canal else 0) + 19 + (17 if self.motivo else 0) + 10
            self.ancho_txt = ancho_txt

    def sizeHint(self):
        from PySide6.QtCore import QSize
        return QSize(self.ancho if not self.fila else 420, self.alto)

    def resizeEvent(self, ev):
        if self.fila:
            antes = self.alto
            self._maquetar()
            if self.alto != antes:
                self.setMinimumHeight(self.alto)
        super().resizeEvent(ev)

    def _rect_img(self):
        from PySide6.QtCore import QRect
        if self.fila:
            x = 4 + (self.iw - self.av) // 2
            return QRect(x, 4, self.av, self.ih)
        if self.canal:
            return QRect((self.width() - self.iw) // 2, 0, self.iw, self.ih)
        return QRect(0, 0, self.iw, self.ih)

    def _zonas(self):
        from PySide6.QtCore import QRect
        z = {}
        if self.e.tipo == "VIDEO":
            if self.fila:
                z["mas"] = QRect(self.width() - 32 - (30 if self.quitar_fn else 0), 4, 28, 28)
            else:
                z["mas"] = QRect(self.width() - 30, self.ih + 8, 28, 28)
        if self.quitar_fn:
            z["quitar"] = QRect(self.width() - 32, 4, 28, 28)
        if self.e.autor and self.e.autorUrl and not self.canal:
            y = (4 if self.fila else self.ih + 10) + len(self.lin_titulo) * (19 if self.fila else 21) + (4 if self.fila else 0)
            x = (self.iw + 16) if self.fila else 2
            w = _Fuentes.dar()["m"]["gris"].horizontalAdvance(self.e.autor)
            z["autor"] = QRect(x, y, w, 18)
        return z

    # ---- imagen (Imagenes la entrega aquí) ----
    def setPixmap(self, p):
        self.pix = p
        self._nueva = None
        self.update()

    def pintar_aparicion(self, p):   # la imagen que llega se funde (Aparicion anima _opacidad)
        return False

    # ---- pintar ----
    def paintEvent(self, ev):
        from PySide6.QtCore import QRect, QRectF
        F = _Fuentes.dar(); m = F["m"]
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setRenderHint(QPainter.SmoothPixmapTransform)
        p.fillRect(self.rect(), QColor(FONDO))
        if self.encima and self.fila:
            p.setPen(Qt.NoPen); p.setBrush(QColor("#121214")); p.drawRoundedRect(QRectF(self.rect()), 14, 14)
        ri = self._rect_img()
        nueva = getattr(self, "_nueva", None)
        img = nueva or self.pix
        if img is None or (nueva is not None and getattr(self, "_opacidad", 1) < 1):
            p.setPen(Qt.NoPen); p.setBrush(QColor(PANEL))
            if self.canal:
                p.drawEllipse(ri)
            else:
                p.drawRoundedRect(QRectF(ri), 12, 12)
        if img is not None:
            if nueva is not None:
                p.setOpacity(getattr(self, "_opacidad", 1.0))
            p.drawPixmap(ri, img)
            p.setOpacity(1.0)
        if self.duracion and not self.canal:
            p.setFont(F["duracion"])
            w = m["duracion"].horizontalAdvance(self.duracion) + 10
            r = QRect(ri.right() - w - 6, ri.bottom() - 25, w, 19)
            p.setPen(Qt.NoPen); p.setBrush(QColor(0, 0, 0, 185)); p.drawRoundedRect(QRectF(r), 7, 7)
            p.setPen(QColor("white")); p.drawText(r, Qt.AlignCenter, self.duracion)
        if self.visto > 0.02 and not self.canal:
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(255, 255, 255, 56)); p.drawRect(ri.left(), ri.bottom() - 2, ri.width(), 3)
            p.setBrush(QColor(ACENTO)); p.drawRect(ri.left(), ri.bottom() - 2, int(ri.width() * min(1.0, self.visto)), 3)
        # textos
        if self.fila:
            x, y, alto_t, ft = self.iw + 16, 4, 19, F["titulo_fila"]
        else:
            x, y, alto_t, ft = 2, self.ih + 10, 21, F["titulo"]
        p.setFont(ft); p.setPen(self.BLANCO)
        for linea in self.lin_titulo:
            p.drawText(QRect(x, y, self.ancho_txt, alto_t), Qt.AlignLeft | Qt.AlignVCenter, linea)
            y += alto_t
        if self.fila:
            y += 4
        p.setFont(F["gris"])
        if self.e.autor and not self.canal:
            p.setPen(self.BLANCO if self.encima == "autor" else self.GRIS)
            p.drawText(QRect(x, y, self.ancho_txt, 18), Qt.AlignLeft | Qt.AlignVCenter, m["gris"].elidedText(self.e.autor, Qt.ElideRight, self.ancho_txt))
            y += 19 if not self.fila else 18
        if self.meta:
            p.setPen(self.GRIS)
            p.drawText(QRect(x, y, self.ancho_txt, 18), Qt.AlignLeft | Qt.AlignVCenter, m["gris"].elidedText(self.meta, Qt.ElideRight, self.ancho_txt))
            y += 19 if not self.fila else 18
        if self.motivo:
            p.setFont(F["motivo"]); p.setPen(self.NARANJA_M)
            p.drawText(QRect(x, y, self.ancho_txt, 16), Qt.AlignLeft | Qt.AlignVCenter, m["motivo"].elidedText(self.motivo, Qt.ElideRight, self.ancho_txt))
        # ⋮ y ✕
        z = self._zonas()
        for clave, signo in (("mas", "mas"), ("quitar", "x")):
            r = z.get(clave)
            if r is None:
                continue
            if self.encima == clave:
                p.setPen(Qt.NoPen); p.setBrush(QColor(PANEL_2)); p.drawRoundedRect(QRectF(r), 10, 10)
            p.setPen(Qt.NoPen); p.setBrush(self.BLANCO)
            c = r.center()
            if signo == "mas":
                for dy in (-6, 0, 6):
                    p.drawEllipse(QRectF(c.x() - 2, c.y() + dy - 2, 4, 4))
            else:
                from PySide6.QtGui import QPen
                p.setPen(QPen(self.BLANCO, 2)); p.drawLine(c.x() - 5, c.y() - 5, c.x() + 5, c.y() + 5); p.drawLine(c.x() - 5, c.y() + 5, c.x() + 5, c.y() - 5)
        if self.hasFocus() and getattr(self, "_foco_teclado", False):   # 05/10/2026: la tarjeta con el teclado, con borde (sin él no se ve dónde está)
            from PySide6.QtGui import QPen
            p.setPen(QPen(self.BLANCO, 2)); p.setBrush(Qt.NoBrush); p.drawRoundedRect(QRectF(self.rect()).adjusted(1, 1, -1, -1), 12, 12)
        p.end()

    # ---- ratón ----
    def _zona_en(self, pos):
        for k, r in self._zonas().items():
            if r.adjusted(-4, -4, 4, 4).contains(pos):
                return k
        return "tarjeta"

    def mouseMoveEvent(self, ev):
        z = self._zona_en(ev.position().toPoint())
        if z != self.encima:
            self.encima = z
            self.update()

    def enterEvent(self, ev):
        """Con el ratón encima, el vídeo se resuelve por detrás: al pulsarlo empieza enseguida (como YouTube)."""
        self.encima = "tarjeta"
        self.update()
        if self.e.tipo == "VIDEO" and hasattr(self.ventana, "rep"):
            self.ventana.rep.precalentar([self.e])
        if hasattr(self.ventana, "previa"):   # 03/10/2026: vista previa tras un segundo quieto
            self.ventana.previa.entrar(self)
        super().enterEvent(ev)

    def leaveEvent(self, ev):
        self.encima = None
        self.update()
        if hasattr(self.ventana, "previa"):
            self.ventana.previa.salir(self)
        super().leaveEvent(ev)

    def focusInEvent(self, ev):
        self._foco_teclado = ev.reason() != Qt.MouseFocusReason   # el borde, solo al llegar con el teclado (como el navegador)
        self.update(); super().focusInEvent(ev)

    def focusOutEvent(self, ev):
        self.update(); super().focusOutEvent(ev)

    def keyPressEvent(self, ev):
        """05/10/2026: Enter abre, Supr quita (de la lista o del historial a la vista), tecla Menú = su menú y las flechas
        van a la tarjeta de al lado, encima o debajo."""
        k = ev.key()
        if k in (Qt.Key_Return, Qt.Key_Enter):
            return self.ventana.nueva_pestana(self.e) if ev.modifiers() & Qt.ControlModifier else self.ventana.abrir(self.e)
        if k == Qt.Key_Delete and self.quitar_fn:
            return self.quitar_fn(self.e)
        if k == Qt.Key_Menu and self.e.tipo == "VIDEO":
            return menu_video(self.ventana, self.e).exec(self.mapToGlobal(self.rect().center()))
        if k in (Qt.Key_Left, Qt.Key_Right, Qt.Key_Up, Qt.Key_Down) and not ev.modifiers():
            otra = self._vecina(k)
            if otra is not None:
                otra.setFocus(Qt.OtherFocusReason)
                p = self.parentWidget()
                while p is not None and not isinstance(p, QScrollArea):
                    p = p.parentWidget()
                if p is not None:
                    p.ensureWidgetVisible(otra, 0, 40)
                return
        super().keyPressEvent(ev)

    def _vecina(self, k):
        """La tarjeta más cercana en esa dirección, entre las hermanas visibles de la rejilla."""
        p = self.parentWidget()
        if p is None:
            return None
        c = self.geometry().center()
        mejor, dist = None, None
        for w in p.findChildren(Tarjeta):
            if w is self or not w.isVisible() or w.parentWidget() is not p:
                continue
            d = w.geometry().center() - c
            dx, dy = d.x(), d.y()
            ok = {Qt.Key_Left: dx < -5 and abs(dy) < self.height() / 2, Qt.Key_Right: dx > 5 and abs(dy) < self.height() / 2,
                  Qt.Key_Up: dy < -5, Qt.Key_Down: dy > 5}[k]
            if ok:
                m = abs(dx) + abs(dy) * 2 if k in (Qt.Key_Left, Qt.Key_Right) else abs(dy) + abs(dx) * 3
                if dist is None or m < dist:
                    mejor, dist = w, m
        return mejor

    def mousePressEvent(self, ev):
        z = self._zona_en(ev.position().toPoint())
        g = ev.globalPosition().toPoint()
        # 05/10/2026: central o Ctrl+clic = pestaña nueva (sobre el autor, la del CANAL, no la del vídeo); Mayús+clic = el
        # vídeo en la ventana aparte (ver_a_la_vez), como «ventana nueva» en el navegador
        nueva = ev.button() == Qt.MiddleButton or (ev.button() == Qt.LeftButton and ev.modifiers() & Qt.ControlModifier)
        if nueva and z == "autor" and self.e.autorUrl and hasattr(self.ventana, "ir_al_canal"):
            return self.ventana.nueva_pestana(motor.Elemento("CANAL", self.e.autorUrl, self.e.autor))
        if nueva and z not in ("mas", "quitar"):   # rueda del ratón: en una pestaña nueva, como en el navegador
            return self.ventana.nueva_pestana(self.e)
        if (ev.button() == Qt.LeftButton and ev.modifiers() & Qt.ShiftModifier and self.e.tipo == "VIDEO"
                and z not in ("mas", "quitar", "autor") and hasattr(self.ventana, "ver_a_la_vez")):
            return self.ventana.ver_a_la_vez(self.e)
        if ev.button() == Qt.LeftButton:
            if z == "mas":
                r = self._zonas()["mas"]
                menu_video(self.ventana, self.e).exec(self.mapToGlobal(r.bottomLeft()))
            elif z == "quitar":
                self.quitar_fn(self.e)
            elif z == "autor":
                self.ventana.abrir_canal(self.e.autorUrl)
            else:
                self.ventana.abrir(self.e)
        elif ev.button() == Qt.RightButton and self.e.tipo == "VIDEO":
            menu_video(self.ventana, self.e).exec(g)

    def completar(self, r):
        """Lo que la lista no trajo (visualizaciones, fecha, duración), por detrás (fichas.Relleno)."""
        e = self.e
        if not r or motor.programado(e):   # 24/10/2026: un estreno que aún no ha empezado salía con «0 visualizaciones»
            return
        if (not e.duracion or e.duracion < 0) and r.get("duracion", -1) > 0:
            self.duracion = motor.tiempo(r["duracion"])
        partes = [self.meta] if self.meta else []
        if r.get("vistas", -1) >= 0 and "visualiz" not in self.meta:
            partes.insert(0, f"{md.miles(r['vistas'])} visualizaciones")
        if not e.fecha and r.get("publicado") and "hace" not in self.meta:
            partes.append(motor.hace(r["publicado"]))
        self.meta = " · ".join(partes)
        self.update()


def FilaCompacta(ventana, e, ancho_img=168, quitar=None, motivo=""):
    """«A continuación», historial y búsquedas: la misma tarjeta, en fila (miniatura a la izquierda)."""
    return Tarjeta(ventana, e, motivo=motivo, fila=True, ancho_img=ancho_img, quitar=quitar)


class Rejilla(QScrollArea):
    """Una cuadrícula de tarjetas que reparte las columnas según el ancho y avisa al llegar al final (para pedir más)."""
    al_final = Signal()

    def __init__(self, ventana, vertical=False, filas=False):
        super().__init__()
        self.ventana, self.vertical, self.filas = ventana, vertical, filas
        self.ancho_img, self.quitar = 246, None   # filas: ancho de la miniatura y, si se puede, la «✕» de quitar
        self.setWidgetResizable(True)
        self.setFrameShape(QFrame.NoFrame)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.dentro = QWidget()
        self.v = QVBoxLayout(self.dentro)
        self.v.setContentsMargins(24, 8, 24, 24)
        self.cabecera = QVBoxLayout()
        self.v.addLayout(self.cabecera)
        self.rejilla = QGridLayout()
        self.rejilla.setHorizontalSpacing(16)
        self.rejilla.setVerticalSpacing(24)
        self.rejilla.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        self.v.addLayout(self.rejilla)
        self.aviso = QLabel()
        self.aviso.setObjectName("gris")
        self.aviso.setAlignment(Qt.AlignCenter)
        self.v.addWidget(self.aviso)
        self.v.addStretch()
        self.setWidget(self.dentro)
        self.elementos, self.motivos, self.widgets = [], {}, []
        suavizar(self)
        self._columnas = 0
        self._pidiendo = False
        self.verticalScrollBar().valueChanged.connect(self._mirar_final)
        self._relayout = QTimer(self, singleShot=True, interval=120)
        self._relayout.timeout.connect(self._recolocar)
        from . import fichas
        self.relleno = fichas.Relleno()

    def ancho_tarjeta(self):
        disponible = self.viewport().width() - 52
        if self.filas:
            return disponible, 1
        minimo = 200 if self.vertical else 300
        cols = max(1, disponible // (minimo + 16))
        return int((disponible - (cols - 1) * 16) / cols), cols

    def limpiar(self, aviso=""):
        if os.environ.get("CATODE_DEPURAR"):
            import traceback
            print("depura limpiar:", " < ".join(f"{f.name}:{f.lineno}" for f in traceback.extract_stack()[-5:-1]), flush=True)
        for w in self.widgets:
            w.hide()
            w.deleteLater()
        self.widgets, self.elementos, self.motivos = [], [], {}
        self.aviso.setText(aviso)
        self.verticalScrollBar().setValue(0)

    def refiltrar(self):
        """Quita lo que ahora esté fulminado o filtrado (cambio llegado de otro equipo), sin perder el sitio."""
        quedan = [e for e in self.elementos if not self.ventana.datos.vetado(e)]
        if len(quedan) == len(self.elementos):
            return
        b = self.verticalScrollBar(); pos = b.value(); motivos = dict(self.motivos)
        self.limpiar(); self.anadir(quedan, motivos)
        QTimer.singleShot(60, lambda: b.setValue(min(pos, b.maximum())))

    def poner(self, elementos, motivos=None, aviso=""):
        self.limpiar(aviso)
        self.anadir(elementos, motivos)
        if hasattr(self.ventana, "_al_reponer"):   # si se estaba volviendo a un sitio, se vuelve otra vez (llegó lo nuevo)
            self.ventana._al_reponer(self)

    def anadir(self, elementos, motivos=None):
        self._pidiendo = False
        elementos = [e for e in elementos if not self.ventana.datos.vetado(e)]   # canales fulminados y temas filtrados
        self.motivos.update(motivos or {})
        ancho, cols = self.ancho_tarjeta()
        self._columnas = cols
        nuevos = []
        for e in elementos:
            if self.filas:
                w = FilaCompacta(self.ventana, e, self.ancho_img, quitar=self.quitar, motivo=self.motivos.get(e.url, ""))
            else:
                w = Tarjeta(self.ventana, e, ancho, self.vertical, self.motivos.get(e.url, ""))
            i = len(self.widgets)
            self.rejilla.addWidget(w, i // cols, i % cols)
            self.widgets.append(w)
            self.elementos.append(e)
            nuevos.append(w)
        self.relleno.empezar(nuevos)
        if not self.widgets and not self.aviso.text():
            self.aviso.setText("No hay nada que enseñar aquí todavía.")
        elif self.widgets:
            self.aviso.setText("")

    def resizeEvent(self, ev):
        super().resizeEvent(ev)
        self._relayout.start()

    def _recolocar(self):
        ancho, cols = self.ancho_tarjeta()
        if cols == self._columnas and (self.filas or not self.widgets or abs(self.widgets[0].width() - ancho) < 24):
            return
        elementos, motivos = list(self.elementos), dict(self.motivos)
        b = self.verticalScrollBar()
        pos = getattr(self, "_destino_pos", None) or b.value()
        self.limpiar()
        self.anadir(elementos, motivos)
        self._destino_pos = pos

        def volver(veces=8):   # el diseño nuevo tarda un poco en tener su altura: se insiste hasta llegar
            b.setValue(min(pos, b.maximum()))
            if b.value() < pos and veces:
                return QTimer.singleShot(80, lambda: volver(veces - 1))
            self._destino_pos = None
        volver()

    def _mirar_final(self, v):
        b = self.verticalScrollBar()
        if not self._pidiendo and b.maximum() > 0 and v >= b.maximum() - 600:
            self._pidiendo = True
            self.al_final.emit()


# ---------------------------------------------------------------- menús
def enlace(e, segundos=0):
    # 19/10/2026: www.youtube.com/watch, no youtu.be («los enlaces que comparto en whatsapp con enlace de youtu.be no se
    # muestra la previsualización»)
    vid = motor.id_video(e.url)
    return compartir.enlace_video(vid, segundos) if vid else e.url


def menu_compartir(ventana, e, segundos=0, padre=None):
    m = QMenu("Compartir", padre)
    url = enlace(e, segundos)
    def copiar(u, aviso):
        QGuiApplication.clipboard().setText(u)
        ventana.avisar(aviso)
    m.addAction("🔗  Copiar enlace", lambda: copiar(enlace(e), "Enlace copiado"))
    if segundos:
        m.addAction(f"⏱  Copiar enlace en el minuto {motor.tiempo(segundos)}", lambda: copiar(url, "Enlace con el minuto copiado"))
    m.addSeparator()
    # 19/10/2026 («tienen que abrirse directamente en las apps»): WhatsApp y Telegram en su app, sin pasar por wa.me
    for nombre, app in compartir.APPS:
        m.addAction(nombre, lambda a=app: compartir.compartir(a, url, e.titulo))
    m.addSeparator()
    m.addAction("🌐  Abrir en el navegador", lambda: compartir.al_navegador(url))
    return m


def menu_video(ventana, e):
    m = QMenu(ventana)
    d = ventana.datos
    m.addAction("▶  Reproducir", lambda: ventana.abrir(e))
    m.addAction("⧉  Abrir en pestaña nueva", lambda: ventana.nueva_pestana(e))
    m.addAction("▣  Ver a la vez (segundo vídeo)", lambda: ventana.ver_a_la_vez(e))
    m.addAction("📺  Poner en la tele", lambda: ventana.poner_en_tele(e))
    m.addAction("⏭  Reproducir a continuación", lambda: ventana.a_continuacion(e))
    m.addAction("☰  Añadir a la cola", lambda: ventana.encolar(e))
    m.addSeparator()
    m.addAction("✓  Quitar de «Ver más tarde»" if d.contiene("despues", e.url) else "🕒  Guardar para ver más tarde",
                lambda: ventana.avisar("Guardado en «Ver más tarde»" if d.alternar("despues", e) else "Quitado de «Ver más tarde»"))
    m.addAction("👍  Quitar de «Me gusta»" if d.contiene("megusta", e.url) else "👍  Me gusta",
                lambda: ventana.avisar("Añadido a «Me gusta»" if d.alternar("megusta", e) else "Quitado de «Me gusta»"))
    listas = m.addMenu("➕  Guardar en una lista")
    for clave, x in d.listas_propias():
        dentro = any(v.get("url") == e.url for v in x.get("videos", []))
        a = listas.addAction(("✓ " if dentro else "") + x.get("nombre", "Lista"))
        a.triggered.connect(lambda _=False, c=clave, dn=dentro: (d.lista_poner(c, e, not dn), ventana.avisar("Lista actualizada")))
    listas.addSeparator()
    listas.addAction("Nueva lista…", lambda: ventana.nueva_lista(e))
    descargar = m.addMenu("⬇  Descargar")
    for alto in (360, 720, 1080):
        descargar.addAction(f"Vídeo {alto}p", lambda a=alto: ventana.descargar(e, False, a))
    descargar.addAction("Solo el sonido (m4a)", lambda: ventana.descargar(e, True))
    m.addMenu(menu_compartir(ventana, e, padre=m))
    m.addSeparator()
    if e.autorUrl:
        m.addAction("👤  Ir al canal", lambda: ventana.abrir_canal(e.autorUrl))
    m.addAction("🚫  No me interesa", lambda: ventana.no_me_interesa(e))
    m.addAction(f"⊘  Fulminar «{e.autor if e.tipo != 'CANAL' else e.titulo}» y su entorno", lambda: ventana.fulminar(e))
    return m
