"""Cat-ode escritorio · los filtros «Sin contenido hecho con IA» y «Sin clickbait» (21/11/2026).

Orden del autor (literal en ~/Cat-ode/ENCARGO_catode_21nov_filtros.md): un interruptor que quite todo lo hecho con IA, «sobre
todo el basuriento creado industrialmente», muy duro, con todos los criterios posibles, para que lo que se cuele sea solo
contenido de calidad y contrastado; y otro que quite el clickbait (caras de sorpresa y titulares gancho). Los dos, opcionales.

Cómo decide (las mismas reglas que Filtros.kt del móvil, leídas del mismo filtros.json; casos en pruebas/filtros_casos.json):
- Confianza del canal: 2 = suscrito, 1 = verificado (insignia de YouTube o canal oficial de artista), 0 = el resto.
- IA, fuera siempre: lo dicen el título, el canal, el detalle o el fragmento de la búsqueda (frases explícitas, etiquetas #ai…,
  «(IA)»), el canal está en AiSList con su @ exacto, o este aparato ya lo aprendió (su descripción o la etiqueta de YouTube
  «contenido alterado o sintético» lo decían, o varios de sus títulos). Si el canal no es de confianza, además: herramientas
  de IA, el tema IA, las siglas AI/IA, los géneros de basura (historias de gatos, mensajes de Dios, tráileres falsos, Reddit
  leído por una voz, brainrot…), el relleno de etiquetas (#viral #fyp…), el nombre del canal en AiSList y el ritmo de fábrica
  (8 o más vídeos en 24 h en una misma lista).
- Clickbait: puntos del título (frases gancho, MAYÚSCULAS, «!!», 😱…; con 4, fuera), cara de sorpresa en la miniatura
  (caras.py) o canal aprendido (3 vídeos cazados).
Las frases se buscan por palabras (texto en minúsculas y sin tildes, cortado en letras y números): en cada sitio, la frase más
larga, sin solaparse. Nada pide nada nuevo a YouTube: todo sale de lo que ya llega. Con los interruptores apagados no se carga
nada.
"""
# COMPROBACIONES (~/.claude/COMPROBACIONES.md)
# C1 datos y red: no pide nada nuevo a YouTube; lee lo que ya llega; AiSList va dentro de la app; solo caras.py baja miniaturas (i.ytimg.com) con el filtro de clickbait encendido.
# C2 su presencia: no suena ni se abre nada; dos interruptores en Ajustes, apagados de serie, que cada uno enciende y apaga.
# C3 fallo y bucle: un error dentro de un filtro deja ver el vídeo (nunca vacía una lista); sin bucles ni reintentos.
# C4 aviso: el motivo de cada vídeo quitado va al registro de Cat-ode y la interfaz dice cuántos quita; nada falla en silencio.
# C5 irreversible: nada; no borra ni envía; lo aprendido es un JSON de la caché de cada aparato.
# C6 gasto: sin tokens, sin API y sin dinero; todo local.
# C7 recursos: frases indexadas por palabra una vez, memoria por elemento, la lista en dos tablas de 64 bits (~1 MB) cargada solo con el filtro de IA encendido.
# C8 cambios de contexto: fuera de casa, sin red o en llamada hace lo mismo (todo es local y ligero).
# C9 equipos y prueba: dentro de Cat-ode en Windows y Linux (Filtros.kt en Android); pruebas/filtros_sin_red.py con pruebas/filtros_casos.json y las baterías web y Qt.
# C10 lo que ya existe: se suma a Datos.vetado (fulminados y temas), descubrir.cebo y motor.VERIFICADOS, sin cambiarlos.
import json
import os
import re
import struct
import sys
import threading
import time
import unicodedata
from array import array
from bisect import bisect_left
from urllib.parse import unquote

AQUI = os.path.dirname(os.path.abspath(__file__))
REGLAS = os.path.join(AQUI, "filtros.json")
LISTA_IA = os.path.join(AQUI, "ia_canales.bin")

estado = {"ia": False, "cebo": False}
firma = [0]               # sube con todo lo que cambia un resultado (interruptores, aprendidos, caras)
al_cambiar = []           # f(urls): algo nuevo ha quedado fuera (la web y la Qt refiltran lo que se ve)
VERIFICADOS = set()       # verificados y artistas oficiales que han pasado por aquí, y los del almacén de descubrir
MANGOS = {}               # https://www.youtube.com/channel/UC… → «@mango» (lo que pasa por las respuestas de YouTube)
FRAGMENTOS = {}           # url del vídeo → fragmento de la descripción que da la búsqueda
_cerrojo = threading.RLock()


def configurar(ajustes):
    """Los interruptores (filtro_ia y filtro_cebo de escritorio-ajustes.json). Devuelve si ha cambiado algo."""
    ia, cebo = bool((ajustes or {}).get("filtro_ia")), bool((ajustes or {}).get("filtro_cebo"))
    if (ia, cebo) == (estado["ia"], estado["cebo"]):
        return False
    estado["ia"], estado["cebo"] = ia, cebo
    _memo.clear()
    firma[0] += 1
    if ia or cebo:
        threading.Thread(target=_precargar, args=(ia, cebo), daemon=True, name="filtros").start()
    return True


def _precargar(ia, cebo):
    try:
        reglas()
        if ia:
            lista_ia()
        aprendidos()
        if cebo:
            from . import caras
            caras.preparar()
    except Exception as ex:   # noqa: BLE001
        _registro(f"filtros: no se pudo preparar: {ex!r}"[:300])


def activo():
    return estado["ia"] or estado["cebo"]


# ------------------------------------------------------------------------------------------------ texto
_COMILLAS = str.maketrans({"’": "'", "‘": "'", "´": "'", "`": "'", "“": '"', "”": '"', "«": '"', "»": '"'})


def _sin_marcas(t):
    t = unicodedata.normalize("NFD", (t or "").translate(_COMILLAS))
    return "".join(c for c in t if unicodedata.category(c) != "Mn")


def normalizar(t):
    """Minúsculas, sin tildes y con las comillas de siempre (lo mismo que Filtros.normalizar del móvil)."""
    return _sin_marcas((t or "").lower())


def tokens(t):
    """Las palabras de un texto ya normalizado: tramos de letras y números (el «_» corta, como en el móvil)."""
    r, w = [], []
    for c in t:
        if c.isalnum():
            w.append(c)
        elif w:
            r.append("".join(w))
            w = []
    if w:
        r.append("".join(w))
    return r


def _token_frase(w):
    """Una palabra de una frase: «#» = un número, «#am» = un número seguido de «am», «abc*» = empieza por «abc»."""
    if w == "#":
        return ("num", "")
    if w.startswith("#"):
        return ("numsuf", w[1:])
    if w.endswith("*") and len(w) > 1:
        return ("pre", w[:-1])
    return ("lit", w)


def _digitos(s):
    return bool(s) and all("0" <= c <= "9" for c in s)


def _casa(p, tok):
    k, v = p
    if k == "lit":
        return tok == v
    if k == "num":
        return _digitos(tok)
    if k == "numsuf":
        return len(tok) > len(v) and tok.endswith(v) and _digitos(tok[:-len(v)])
    return tok.startswith(v)


def palabras_de_frase(f):
    """Las palabras de una frase de filtros.json (con sus comodines «#» y «*»)."""
    partes = []
    w = []
    for c in normalizar(f) + " ":
        if c.isalnum() or c in "#*":
            w.append(c)
            continue
        if w:
            partes.append("".join(w))
            w = []
    r = []
    for p in partes:
        # «#» solo vale delante (comodín de número) y «*» solo detrás (comodín de final): el resto se quita
        nucleo = p.strip("#*")
        if not nucleo and p != "#":
            continue
        if p == "#" or p.startswith("#"):
            r.append(_token_frase("#" + nucleo if nucleo else "#"))
        elif p.endswith("*"):
            r.append(_token_frase(nucleo + "*"))
        else:
            r.append(_token_frase(nucleo))
    return tuple(r)


class Frases:
    """Un grupo de frases indexado por su primera palabra (las que empiezan por un comodín, aparte)."""

    def __init__(self, frases):
        self.indice, self.comodines, vistas = {}, [], set()
        for f in frases:
            if not f or not f.strip():
                continue
            tup = palabras_de_frase(f)
            if not tup or tup in vistas:
                continue
            vistas.add(tup)
            if tup[0][0] == "lit":
                self.indice.setdefault(tup[0][1], []).append((tup, f))
            else:
                self.comodines.append((tup, f))

    def buscar(self, toks, todas=False):
        """[(sitio, palabras, frase)] de las frases que aparecen, de izquierda a derecha y sin solaparse (en cada sitio, la
        más larga; con «todas» = False, solo la primera)."""
        res, i, n = [], 0, len(toks)
        while i < n:
            mejor = None
            for lista in (self.indice.get(toks[i], ()), self.comodines):
                for tup, f in lista:
                    largo = len(tup)
                    if largo > n - i or (mejor is not None and largo <= mejor[0]):
                        continue
                    if all(_casa(tup[k], toks[i + k]) for k in range(largo)):
                        mejor = (largo, f)
            if mejor is None:
                i += 1
                continue
            res.append((i, mejor[0], mejor[1]))
            if not todas:
                break
            i += mejor[0]
        return res

    def primera(self, *listas_de_tokens):
        for toks in listas_de_tokens:
            r = self.buscar(toks)
            if r:
                return r[0][2]
        return ""

    def distintas(self, toks):
        vistas = []
        for _, _, f in self.buscar(toks, todas=True):
            if f not in vistas:
                vistas.append(f)
        return vistas


AMBIGUAS = ("ai", "ki")   # «ai» es «a los» en italiano y «ahí» en portugués; «ki» es «de» en hindi


class _Reglas:
    def __init__(self, ruta=REGLAS):
        with open(ruta, encoding="utf-8") as f:
            d = json.load(f)
        ia, cb = d["ia"], d["cebo"]
        self.version = d.get("version", 0)
        self.ia_explicito = Frases(ia["explicito"])
        self.ia_subcadenas = [normalizar(s) for s in ia.get("subcadenas", []) if s]
        self.ia_herramientas = Frases(ia["herramientas"])
        self.ia_tema = Frases(ia["tema"])
        self.ia_generos = Frases(ia["generos"])
        self.ia_descripcion = Frases(ia["descripcion"])
        self.ia_siglas = sorted((s for s in ia.get("siglas", []) if s), key=len, reverse=True)
        self.etiquetas_ia = {normalizar(x) for x in ia["etiquetas_explicitas"]}
        self.etiquetas_tema = {normalizar(x) for x in ia.get("etiquetas_tema", [])}
        self.ia_negaciones = Frases(ia.get("negaciones", []))
        self.etiquetas_relleno = {normalizar(x) for x in ia["etiquetas_relleno"]}
        self.muy = Frases(cb["muy"])
        self.fuertes = Frases(cb["fuertes"])
        self.medias = Frases(cb["medias"])
        self.emojis_fuertes = {c for c in cb["emojis_fuertes"] if c not in "️‍"}
        self.emojis_suaves = {c for c in cb["emojis_suaves"] if c not in "️‍"}
        self.siglas = {normalizar(x) for x in cb["siglas"]}
        self.umbral = {int(k): int(v) for k, v in cb.get("umbral", {}).items() if k.isdigit()}
        self.musica = Frases(cb["musica"])
        self.musica_canal = [normalizar(x) for x in cb["musica_canal"]]
        self.caras = d.get("caras", {})
        self.aprender = d.get("aprender", {})


_reglas = None


def reglas():
    global _reglas
    if _reglas is None:
        with _cerrojo:
            if _reglas is None:
                _reglas = _Reglas()
    return _reglas


def etiquetas(texto):
    """Las etiquetas (#algo) de un texto, normalizadas: tras «#», una letra o número y después letras, números o «_»."""
    r, t = [], texto or ""
    i, n = 0, len(t)
    while i < n:
        if t[i] == "#" and i + 1 < n and t[i + 1].isalnum():
            j = i + 1
            while j < n and (t[j].isalnum() or t[j] == "_"):
                j += 1
            r.append(normalizar(t[i + 1:j]))
            i = j
        else:
            i += 1
    return r


def _tokens_con_caja(t):
    """Las palabras normalizadas, pero «ai»/«ki» solo valen como tales si en el original iban en MAYÚSCULAS."""
    bajas = tokens(normalizar(t))
    tal_cual = tokens(_sin_marcas(t))
    if len(bajas) != len(tal_cual):
        return [w + "~" if w in AMBIGUAS else w for w in bajas]
    return [w if w not in AMBIGUAS or o.isupper() else w + "~" for w, o in zip(bajas, tal_cual)]


_CORCHETE_IA = ("ai", "ia", "a.i", "a.i.", "i.a", "i.a.")


def _entre_corchetes_ia(n):
    """«(IA)», «[AI]», «| A.I. |»… en un texto normalizado."""
    abre, cierra = "([{|", ")]}|"
    for i, c in enumerate(n):
        if c not in abre:
            continue
        j = i + 1
        while j < len(n) and n[j] == " ":
            j += 1
        k = j
        while k < len(n) and n[k] not in cierra and k - j <= 6:
            k += 1
        if k < len(n) and n[k] in cierra and n[j:k].rstrip(" ") in _CORCHETE_IA:
            return True
    return False


def _siglas_ia(crudo, siglas):
    """«AI», «IA», «A.I.», «KI», «ИИ» como sigla suelta en el texto original, si no va casi todo en mayúsculas."""
    letras = [c for c in crudo if c.isalpha()]
    if letras and sum(1 for c in letras if c.isupper()) / len(letras) >= 0.5:
        return False
    for s in siglas:
        i = crudo.find(s)
        while i >= 0:
            antes = crudo[i - 1] if i > 0 else " "
            despues = crudo[i + len(s)] if i + len(s) < len(crudo) else " "
            if not (antes.isalnum() or antes in "_.") and not (despues.isalnum() or despues == "_"):
                return True
            i = crudo.find(s, i + 1)
    return False


# ------------------------------------------------------------------------------------------------ AiSList
def fnv64(s):
    """FNV-1a de 64 bits sobre UTF-8, con signo (igual que Filtros.fnv64 del móvil)."""
    h = 0xcbf29ce484222325
    for b in s.encode("utf-8"):
        h = ((h ^ b) * 0x100000001b3) & 0xFFFFFFFFFFFFFFFF
    return h - (1 << 64) if h >= (1 << 63) else h


def _alnum(t):
    return "".join(c for c in normalizar(t) if c.isalnum())


def _quitar_sufijo(h):
    """«nombre-x8k» → «nombre» (el sufijo de 1 a 5 letras o números que pone YouTube cuando el mango ya existe)."""
    i = h.rfind("-")
    if i > 0 and 1 <= len(h) - i - 1 <= 5 and all(c in "abcdefghijklmnopqrstuvwxyz0123456789" for c in h[i + 1:]):
        return h[:i]
    return h


def clave_mango(h):
    """«@ChickofHonor-l» → «chickofhonor-l» (el mango entero, en minúsculas, sin @)."""
    return normalizar(unquote(h or "")).strip().lstrip("@")


def base_mango(h):
    """La raíz de un mango para casarlo con el nombre de un canal: sus letras y números («@Divine_Harmony» → «divineharmony»).
    Un mango con el sufijo que pone YouTube cuando el nombre ya estaba cogido («@celeste-x8k») no da raíz (""): el nombre es
    de otro canal, muchas veces el auténtico (la cantante Celeste, medido el 21/11 con su historial)."""
    c = clave_mango(h)
    return "" if _quitar_sufijo(c) != c else _alnum(c)


def base_nombre(n):
    return _alnum(n or "")


class _ListaIA:
    """AiSList (aisloplist.com, CC BY-NC 4.0) en dos tablas de huellas ordenadas (vigia/lista_ia.py las hace): los mangos
    enteros y las raíces de 6 letras o más. ia_canales.bin: «CATIA1», 2 bytes a 0, fecha (aaaammdd), canales, nº de mangos
    y nº de raíces (enteros de 32 bits) y después las huellas (64 bits con signo), todo en little-endian."""

    def __init__(self, ruta=LISTA_IA):
        self.fecha, self.n = 0, 0
        self.mangos, self.bases = array("q"), array("q")
        try:
            with open(ruta, "rb") as f:
                b = f.read()
            if b[:8] != b"CATIA1\x00\x00":
                raise ValueError("cabecera")
            self.fecha, self.n, nm, nb = struct.unpack_from("<IIII", b, 8)
            ini = 24
            self.mangos.frombytes(b[ini:ini + 8 * nm])
            self.bases.frombytes(b[ini + 8 * nm:ini + 8 * (nm + nb)])
            if sys.byteorder != "little":
                self.mangos.byteswap()
                self.bases.byteswap()
        except (OSError, ValueError, struct.error) as ex:
            _registro(f"filtros: sin la lista de canales de IA ({ex!r})"[:200])

    @staticmethod
    def _en(tabla, h):
        i = bisect_left(tabla, h)
        return i < len(tabla) and tabla[i] == h

    def mango(self, h):
        return bool(h) and self._en(self.mangos, fnv64(clave_mango(h)))

    def nombre(self, n):
        b = base_nombre(n)
        return len(b) >= 6 and self._en(self.bases, fnv64(b))


_lista = None


def lista_ia():
    global _lista
    if _lista is None:
        with _cerrojo:
            if _lista is None:
                _lista = _ListaIA()
    return _lista


_MANGO_EN_JSON = re.compile(r'"browseId"\s*:\s*"(UC[\w-]{22})"\s*,\s*"canonicalBaseUrl"\s*:\s*"/(@[^"]+)"')


def mangos_de_texto(texto):
    """Apunta el «@mango» de cada canal que sale en una respuesta de YouTube (solo con el filtro de IA encendido)."""
    if not estado["ia"] or not texto:
        return
    try:
        if isinstance(texto, (bytes, bytearray)):
            texto = texto.decode("utf-8", "replace")
        for cid, h in _MANGO_EN_JSON.findall(texto):
            MANGOS[f"https://www.youtube.com/channel/{cid}"] = unquote(h)
        if len(MANGOS) > 50000:
            for k in list(MANGOS)[:10000]:
                MANGOS.pop(k, None)
    except Exception:   # noqa: BLE001
        pass


def anotar_fragmento(url, texto):
    """El fragmento de la descripción que trae la búsqueda (solo con el filtro de IA encendido)."""
    if estado["ia"] and url and texto:
        FRAGMENTOS[url] = texto[:400]
        if len(FRAGMENTOS) > 5000:
            for k in list(FRAGMENTOS)[:1000]:
                FRAGMENTOS.pop(k, None)


# ------------------------------------------------------------------------------------------------ lo aprendido
def _carpeta():
    try:
        from .metadatos import _carpeta_cache
        return _carpeta_cache()
    except Exception:   # noqa: BLE001
        return os.path.expanduser("~/.cache/catode")


class Aprendidos:
    """Lo que este aparato ha ido sabiendo (no se sincroniza): canales de IA, de clickbait y de fábrica, y las caras."""

    def __init__(self, ruta=None):
        self.ruta = ruta or os.path.join(_carpeta(), "filtros_aprendidos.json")
        self.d = {"ia": {}, "cebo": {}, "fabrica": {}, "caras": {}}
        self.pistas = {"ia": {}, "cebo": {}}
        self._sucio = False
        try:
            with open(self.ruta, encoding="utf-8") as f:
                x = json.load(f)
            for k in self.d:
                if isinstance(x.get(k), dict):
                    self.d[k] = x[k]
        except (OSError, ValueError):
            pass

    def canal(self, tipo, url):
        a = self.d[tipo].get(url) if url else None
        if a and a.get("v") not in (None, reglas().version):
            return None
        return a

    def aprender(self, tipo, url, nombre, por, por_titulos=False):
        with _cerrojo:
            if not url or self.canal(tipo, url):
                return False
            self.d[tipo][url] = {"t": int(time.time()), "nombre": (nombre or "")[:80], "por": por[:160]}
            if por_titulos:
                self.d[tipo][url]["v"] = reglas().version
        _registro(f"filtros: canal aprendido ({tipo}): {nombre} {url} · {por}")
        self._guardar(cambia=True)
        avisar_cambio(canales=[url])
        return True

    def pista(self, tipo, url, nombre, vid, por, hacen_falta):
        """Un vídeo de un canal cazado por su título: con «hacen_falta» distintos, el canal entero queda aprendido."""
        if not url or not vid or self.canal(tipo, url):
            return False
        with _cerrojo:
            s = self.pistas[tipo].setdefault(url, set())
            s.add(vid)
            n = len(s)
        if n >= hacen_falta:
            return self.aprender(tipo, url, nombre, f"{n} vídeos: {por}", por_titulos=True)
        return False

    def cara(self, vid):
        return self.d["caras"].get(vid)

    def poner_cara(self, vid, r, positiva):
        with _cerrojo:
            self.d["caras"][vid] = r
            if len(self.d["caras"]) > 30000:
                for k in list(self.d["caras"])[:5000]:
                    self.d["caras"].pop(k, None)
        self._guardar(cambia=positiva)

    def _guardar(self, cambia):
        if cambia:
            firma[0] += 1
        if self._sucio:
            return
        self._sucio = True
        t = threading.Timer(10, self._guardar_ya)
        t.daemon = True
        t.start()

    def _guardar_ya(self):
        self._sucio = False
        try:
            os.makedirs(os.path.dirname(self.ruta), exist_ok=True)
            tmp = self.ruta + ".tmp"
            with _cerrojo:
                texto = json.dumps(self.d, ensure_ascii=False)
            with open(tmp, "w", encoding="utf-8") as f:
                f.write(texto)
            os.replace(tmp, self.ruta)
        except Exception:   # noqa: BLE001
            pass


_aprendidos = None


def aprendidos():
    global _aprendidos
    if _aprendidos is None:
        with _cerrojo:
            if _aprendidos is None:
                _aprendidos = Aprendidos()
    return _aprendidos


def _registro(texto):
    try:
        from .resolutor import registro
        registro(texto)
    except Exception:   # noqa: BLE001
        pass


# ------------------------------------------------------------------------------------------------ confianza
_subs = {"t": 0.0, "id": None, "urls": set(), "nombres": set()}


def _norm_url(u):
    return (u or "").lower().split("?")[0].rstrip("/").replace("://m.youtube", "://www.youtube")


def confianza(e, datos=None):
    """2 = canal suscrito, 1 = verificado o artista oficial, 0 = el resto."""
    canal = getattr(e, "tipo", "") == "CANAL"
    crudo = (e.url if canal else getattr(e, "autorUrl", "")) or ""
    url = _norm_url(crudo)
    nombre = ((e.titulo if canal else getattr(e, "autor", "")) or "").strip().lower()
    if datos is not None:
        ahora = time.time()
        if _subs["id"] is not datos or ahora - _subs["t"] > 30:
            try:
                ss = datos.suscripciones()
                _subs.update(t=ahora, id=datos, urls={_norm_url(s.url) for s in ss},
                             nombres={(s.titulo or "").strip().lower() for s in ss if s.titulo})
            except Exception:   # noqa: BLE001
                _subs.update(t=ahora, id=datos)
        if (url and url in _subs["urls"]) or (nombre and nombre in _subs["nombres"]):
            return 2
    if crudo:
        try:
            from . import motor
            ver = motor.VERIFICADOS
        except Exception:   # noqa: BLE001
            ver = ()
        if crudo in ver or crudo in VERIFICADOS:
            return 1
    return 0


# ------------------------------------------------------------------------------------------------ IA
def es_musica(titulo, autor):
    r = reglas()
    if r.musica.primera(tokens(normalizar(titulo))):
        return True
    a = normalizar(autor)
    return any(x in a for x in r.musica_canal)


# 22/11/2026 · una colaboración: YouTube junta los canales en el autor («A y B», «A and B», «A, B y C», «A y 2 más»). En la
# prueba real del 22/11 se coló «Mama Cat's Christmas Surprise…» de «CurioVex y PawHaven Stories» (CurioVex, verificado;
# PawHaven Stories, en AiSList). Espacios explícitos y cifras ASCII: Filtros.kt da lo mismo.
_COLAB_MAS = re.compile(r" +(?:y|and) +[0-9]+ +(?:más|mas|more) *$", re.I)
_COLAB = re.compile(r" +(?:y|and) +| *& *| *, +")


def colaboradores(autor):
    """Los nombres de los canales de una colaboración ([] si el autor es un solo canal)."""
    a0 = " ".join((autor or "").split())
    a = _COLAB_MAS.sub("", a0).strip()
    partes = [p.strip() for p in _COLAB.split(a) if p.strip()]
    return partes if len(partes) > 1 or a != a0 else []


def motivo_ia(e, conf, fragmento=""):
    """Por qué es contenido hecho con IA («» si no lo parece). conf: confianza() del canal.
    Para todos los canales: una etiqueta explícita (un trozo del título entre paréntesis o entre «|» que es «AI Generated»,
    «Hecho con IA»…, «(IA)», #aiart…), AiSList (por el @ exacto o, si no se sabe el @, por el nombre igual a un @ de la lista
    sin sufijo; el 21/11 dio 8 de sus 747 suscripciones, todas con pinta de canal de IA) y lo aprendido (salvo tus
    suscripciones). Solo si el canal no es de confianza: las frases explícitas en cualquier sitio, las herramientas, el tema
    IA, los géneros de relleno, las siglas y el relleno de etiquetas. Un trozo que dice «sin IA», «No AI»… no cuenta como IA."""
    r = reglas()
    canal = getattr(e, "tipo", "") == "CANAL"
    titulo = e.titulo or ""
    autor = (titulo if canal else getattr(e, "autor", "")) or ""
    url = (e.url if canal else getattr(e, "autorUrl", "")) or ""
    campos = [c for c in [titulo] + ([] if canal else [autor]) + [getattr(e, "detalle", "") or "", fragmento or ""] if c]
    normal = [normalizar(c) for c in campos]
    toks = [tokens(n) for n in normal]
    negado = [bool(r.ia_negaciones.primera(t)) for t in toks]
    for c, n, neg in zip(campos, normal, negado):
        if neg:
            continue
        f = _etiqueta_explicita(c, r)
        if f:
            return f"IA: «{f}»"
        if _entre_corchetes_ia(n):
            return "IA: lo pone entre paréntesis"
    tags = etiquetas(" \n ".join(campos))
    t_ia = [x for x in tags if x in r.etiquetas_ia]
    if t_ia:
        return f"IA: #{t_ia[0]}"
    lista = lista_ia()
    mango = MANGOS.get(url)
    if mango and lista.mango(mango):
        return f"IA: {mango} está en AiSList"
    if autor and not mango and lista.nombre(autor):
        return "IA: el canal está en AiSList"
    if not canal:   # 22/11/2026: cada canal de una colaboración, por su nombre
        for n in colaboradores(autor):
            if lista.nombre(n):
                return f"IA: {n} (en la colaboración) está en AiSList"
    if conf < 2:
        a = aprendidos().canal("ia", url) or aprendidos().canal("fabrica", url)
        if a:
            return f"IA: canal aprendido ({a.get('por', '')})"
    if conf >= 1:
        return ""
    for c, n, t, neg in zip(campos, normal, toks, negado):
        if neg:
            continue
        f = r.ia_explicito.primera(t)
        if f:
            return f"IA: «{f}»"
        s = next((s for s in r.ia_subcadenas if s in n), "")
        if s:
            return f"IA: «{s}»"
        for grupo, que in ((r.ia_herramientas, "herramienta de IA"), (r.ia_tema, "tema IA")):
            f = grupo.primera(t)
            if f:
                return f"IA ({que}): «{f}»"
    t_tema = [x for x in tags if x in r.etiquetas_tema]
    if t_tema:
        return f"IA (tema IA): #{t_tema[0]}"
    musica = es_musica(titulo, autor)
    if not musica:
        f = r.ia_generos.primera(*toks)
        if f:
            return f"IA (género de relleno): «{f}»"
    if _siglas_ia(" \n ".join(c for c, neg in zip(campos[:2], negado[:2]) if not neg), r.ia_siglas):
        return "IA: sigla AI/IA en el título o el canal"
    if not musica and sum(1 for x in tags if x in r.etiquetas_relleno) >= 3:
        return "IA: relleno de etiquetas"
    return ""


_SEPARADORES = ("|", "//", " - ", " – ", " — ", "•", " · ", "~")


def segmentos(t):
    """Los trozos de un título que suelen ser etiquetas: lo de dentro de paréntesis, corchetes o llaves y los trozos que
    quedan entre «|», « - », «//»…"""
    dentro, resto, prof, buf = [], [], 0, []
    for c in t or "":
        if c in "([{":
            if prof == 0:
                resto.append(" | ")
                buf = []
            else:
                buf.append(c)
            prof += 1
        elif c in ")]}" and prof > 0:
            prof -= 1
            if prof == 0:
                dentro.append("".join(buf))
                resto.append(" | ")
            else:
                buf.append(c)
        elif prof > 0:
            buf.append(c)
        else:
            resto.append(c)
    if prof > 0 and buf:
        dentro.append("".join(buf))
    fuera_ = "".join(resto)
    for s in _SEPARADORES:
        fuera_ = fuera_.replace(s, "\x00")
    return [x.strip() for x in dentro + fuera_.split("\x00") if x.strip()]


def _etiqueta_explicita(texto, r):
    """La frase explícita de IA si algún trozo del texto es esa etiqueta (la frase ocupa al menos la mitad del trozo)."""
    for seg in segmentos(texto):
        t = _tokens_con_caja(seg)
        if not t or r.ia_negaciones.primera(tokens(normalizar(seg))):
            continue
        hits = r.ia_explicito.buscar(t, todas=True)
        if hits and 2 * sum(largo for _, largo, _ in hits) >= len(t):
            return hits[0][2]
    return ""


def motivo_descripcion(texto, conf=0):
    """¿La descripción dice que el vídeo está hecho con IA? «» si no. Con cualquier canal: frases sobre el propio vídeo («este
    vídeo fue creado con IA», «contenido alterado o sintético»…) y etiquetas #aiart…; si no es una suscripción, también las
    frases explícitas; si no es de confianza, también las herramientas. Si la descripción dice «sin IA», nada."""
    if not texto:
        return ""
    r = reglas()
    n = normalizar(texto)
    t = tokens(n)
    if r.ia_negaciones.primera(t):
        return ""
    f = r.ia_descripcion.primera(_tokens_con_caja(texto))
    if f:
        return f"IA: la descripción dice «{f}»"
    t_ia = [x for x in etiquetas(texto) if x in r.etiquetas_ia]
    if t_ia:
        return f"IA: la descripción lleva #{t_ia[0]}"
    if conf <= 1:
        f = r.ia_explicito.primera(_tokens_con_caja(texto))
        if f:
            return f"IA: la descripción dice «{f}»"
        if _entre_corchetes_ia(n):
            return "IA: la descripción lo pone entre paréntesis"
    if conf == 0:
        f = r.ia_herramientas.primera(t)
        if f:
            return f"IA: la descripción nombra «{f}»"
    return ""


# ------------------------------------------------------------------------------------------------ clickbait
_SIGNOS_FUERTES = re.compile(r"[!¡][?¿]|[?¿][!¡]|‼|⁉|[!¡]{3,}|[?¿]{3,}")
_SIGNOS = re.compile(r"[!¡]{2}|[?¿]{2}")
_ROMANO = re.compile(r"^m{0,3}(cm|cd|d?c{0,3})(xc|xl|l?x{0,3})(ix|iv|v?i{0,3})$")
_MONEDA = "$€£"
_MONEDA_PALABRA = ("euro", "euros", "dolar", "dolares", "dollar", "dollars", "peso", "pesos")


def _palabras_letras(t):
    """Tramos de solo letras (como [^\\W\\d_]+)."""
    r, w = [], []
    for c in t:
        if c.isalpha():
            w.append(c)
        elif w:
            r.append("".join(w))
            w = []
    if w:
        r.append("".join(w))
    return r


def _cifra(s):
    s = s.replace(".", "").replace(",", "")
    return _digitos(s)


def _precio(tok):
    """«5$», «$5», «5€», «10k», «1.000$»… (un trozo sin espacios)."""
    if not tok:
        return False
    if tok[0] in _MONEDA:
        return _cifra(tok[1:])
    if tok[-1] in _MONEDA:
        return _cifra(tok[:-1])
    if tok[-1] == "k":
        return _cifra(tok[:-1])
    return False


_GANAR = ("gana", "ganas", "ganar", "gane", "gano", "ganamos", "ganan", "ganaste", "win", "wins", "won", "winning",
          "doy", "damos", "regalo", "regale", "regalamos", "give", "gave", "giving")   # 22/11/2026: «Les Doy $1,000,000…» (dar y regalar dinero, el mismo reto)
_POR_CADA = (("por", "cada"), ("for", "every"), ("for", "each"))


def _limpio(tok):
    """El trozo sin los signos de alrededor que no cambian nada («¡auto» → «auto», «$1,000,000!» → «$1,000,000»); los
    paréntesis se quedan: «Pixel ($499) vs iPhone ($599)» es una comparación de precios, no un reto."""
    return tok.lstrip("¡¿").rstrip("!?.,:;")


def _precio_en(trozos, i):
    """¿Hay un precio en trozos[i]? «$5», «5€», «10k», «1.000$» o un número con la moneda al lado: «5 €», «$ 5»,
    «5 euros» (22/11/2026)."""
    w = _limpio(trozos[i])
    if _precio(w):
        return True
    if not _cifra(w):
        return False
    sig = _limpio(trozos[i + 1]) if i + 1 < len(trozos) else ""
    ant = _limpio(trozos[i - 1]) if i >= 1 else ""
    return (sig != "" and (sig in _MONEDA or sig in _MONEDA_PALABRA)) or (ant != "" and ant in _MONEDA)


def _precio_contra_precio(n):
    """Un precio a cada lado de «vs», pegado o con dos palabras en medio como mucho: «1$ vs 1000$», «5 euros vs 500
    euros», «$1 vs $100», «10k vs 1k», «Yate de $1 vs Yate de $1,000,000,000» (22/11/2026: con YouTube de verdad, los de
    MrBeast se escapaban por las palabras de en medio y «1 € vs 1.000 €», por el espacio antes del €)."""
    trozos = n.replace("vs.", "vs").split()
    for i, w in enumerate(trozos):
        if w not in ("vs", "versus") or i == 0 or i + 1 >= len(trozos):
            continue
        if any(_precio_en(trozos, j) for j in range(max(0, i - 3), i)) and \
                any(_precio_en(trozos, j) for j in range(i + 1, min(len(trozos), i + 4))):
            return True
    return False


def _premio(n):
    """Un premio en dinero, el reto de youtuber: «y gana $500,000», «gana 100,000 dólares», «wins $10,000», «$10,000 por
    cada día», «$1 for every like» (22/11/2026). «por $456,000» o «cuesta 5 €» no cuentan (también lo dice una tienda)."""
    trozos = n.split()
    for i in range(len(trozos)):
        if _limpio(trozos[i]) in _GANAR and any(_precio_en(trozos, j) for j in range(i + 1, min(len(trozos), i + 3))):
            return True
        if _precio_en(trozos, i):
            for k in (i + 1, i + 2):   # «$10,000 por cada», «5 euros por cada»
                if k + 1 < len(trozos) and (_limpio(trozos[k]), _limpio(trozos[k + 1])) in _POR_CADA:
                    return True
    return False


def _gritos(t, r):
    """(letras, letras en mayúsculas, palabras gritadas) del título, sin siglas, sin números romanos y sin los trozos tras
    «|» o «//» que van enteros en mayúsculas (nombres de programa o de canal)."""
    trozos = t.replace("//", "|").split("|")
    letras = mayus = 0
    gritos = []
    for k, trozo in enumerate(trozos):
        ps = [w for w in _palabras_letras(trozo) if len(w) >= 2]
        normales = [w for w in ps if normalizar(w) not in r.siglas and not _ROMANO.match(normalizar(w))]
        if k > 0 and normales and all(w.isupper() for w in normales):
            continue
        letras += sum(len(w) for w in normales)
        mayus += sum(len(w) for w in normales if w.isupper())
        gritos += [w for w in normales if len(w) >= 4 and w.isupper()]
    return letras, mayus, gritos


def puntos_cebo(titulo, autor=""):
    """(puntos, [motivos]) de un título (la regla en filtros.json → cebo._)."""
    r = reglas()
    t = titulo or ""
    n = normalizar(t)
    toks = tokens(n)
    usados = [False] * len(toks)
    p, motivos = 0, []
    for grupo, base, otra in ((r.muy, 4, 0), (r.fuertes, 2, 1), (r.medias, 1, 1)):
        libres = ["\x00" if usados[i] else w for i, w in enumerate(toks)]
        vistas = []
        for i, largo, f in grupo.buscar(libres, todas=True):
            for k in range(i, i + largo):
                usados[k] = True
            if f not in vistas:
                vistas.append(f)
        if vistas:
            p += base + (otra if len(vistas) > 1 else 0)
            motivos.append(f"«{vistas[0]}»")
    if _precio_contra_precio(n):
        p += 4
        motivos.append("precio contra precio")
    elif _premio(n):
        p += 4   # 22/11/2026: antes 2; con YouTube de verdad, «Si Logran Acertar el Tiro Ganan $300,000» y así se quedaban
        motivos.append("premio en dinero")
    if not es_musica(t, autor):
        letras, mayus, gritos = _gritos(t, r)
        if letras >= 12 and mayus / letras >= 0.6:
            p += 1
            motivos.append("en MAYÚSCULAS")
        elif len(gritos) >= 3:
            p += 2 if len(gritos) >= 5 else 1
            motivos.append(f"{len(gritos)} palabras en MAYÚSCULAS")
    if _SIGNOS_FUERTES.search(t):
        p += 2
        motivos.append("signos de cebo")
    elif _SIGNOS.search(t) or t.count("!") >= 2:
        p += 1
    caras_ = sum(1 for c in t if c in r.emojis_fuertes)
    otros = sum(1 for c in t if c in r.emojis_suaves)
    if caras_:
        p += min(caras_, 3)
        motivos.append("emojis de susto")
    if otros >= 3:
        p += 1
    if t.rstrip().endswith(("...", "…")):
        p += 1
    return p, motivos


def umbral_cebo(conf):
    return reglas().umbral.get(conf, 4)


def id_video(url):
    m = re.search(r"(?:v=|youtu\.be/|shorts/)([A-Za-z0-9_-]{11})", url or "")
    return m.group(1) if m else ""


def cara_de_sorpresa(r_cara, puntos_titulo=0):
    """¿El resultado de caras.py ({"s": sorpresa+miedo de la cara grande más sorprendida, …}) es cara de sorpresa?"""
    if not isinstance(r_cara, dict):
        return False
    c = reglas().caras
    s = r_cara.get("s", 0)
    return s >= c.get("sorpresa", 0.9) or (s >= c.get("sorpresa_con_titulo", 0.75) and puntos_titulo >= c.get("titulo_minimo", 2))


def motivo_cebo(e, conf):
    """(motivo, fuerte): fuerte = 6 puntos o más o cara de sorpresa (cuenta para aprender el canal)."""
    if getattr(e, "tipo", "") != "VIDEO":
        url = e.url if getattr(e, "tipo", "") == "CANAL" else ""
        a = aprendidos().canal("cebo", url) if conf < 2 else None
        return (f"clickbait: canal aprendido ({a.get('por', '')})" if a else ""), False
    p, motivos = puntos_cebo(e.titulo, getattr(e, "autor", ""))
    fuerte = p >= reglas().aprender.get("cebo_puntos", 6)
    if p >= umbral_cebo(conf):
        return "clickbait: " + ", ".join(motivos[:3]), fuerte
    vid = id_video(e.url)
    rc = aprendidos().cara(vid) if vid else None
    if rc is not None and cara_de_sorpresa(rc, p):
        return "clickbait: cara de sorpresa en la miniatura", True
    if conf < 2:
        a = aprendidos().canal("cebo", getattr(e, "autorUrl", ""))
        if a:
            return f"clickbait: canal aprendido ({a.get('por', '')})", False
    return "", False


# ------------------------------------------------------------------------------------------------ la entrada
_memo = {}


def ensena_canal(motivo):
    """¿Ese motivo dice algo del CANAL (para aprenderlo entero)? Sí lo hecho con IA dicho o etiquetado, las herramientas, los
    géneros de relleno, la etiqueta de YouTube y la descripción; no tratar de IA (tema o sigla) ni el relleno de etiquetas,
    que también salen en canales normales que a veces hablan de IA (22/11/2026)."""
    return bool(motivo) and not any(x in motivo for x in ("(tema IA)", "sigla AI/IA", "relleno de etiquetas", "AiSList", "aprendido"))


def fuera(e, datos=None):
    """El motivo por el que «e» queda fuera con los filtros encendidos, o «» si se ve. Rápido: memoria por elemento."""
    if not activo() or e is None or not getattr(e, "url", ""):
        return ""
    clave = (getattr(e, "tipo", ""), e.url, e.titulo, getattr(e, "autor", ""), getattr(e, "autorUrl", ""))
    x = _memo.get(clave)
    if x is not None and x[0] == firma[0]:
        return x[1]
    f0 = firma[0]
    try:
        conf = confianza(e, datos)
        motivo = ""
        es_video = getattr(e, "tipo", "") == "VIDEO"
        if estado["ia"]:
            motivo = motivo_ia(e, conf, FRAGMENTOS.get(e.url, ""))
            if conf == 0 and es_video and ensena_canal(motivo):
                aprendidos().pista("ia", e.autorUrl, e.autor, id_video(e.url), motivo, reglas().aprender.get("ia_titulos", 2))
        if not motivo and estado["cebo"]:
            motivo, fuerte = motivo_cebo(e, conf)
            if motivo and fuerte and conf < 2 and es_video:
                aprendidos().pista("cebo", e.autorUrl, e.autor, id_video(e.url), motivo, reglas().aprender.get("cebo_videos", 3))
    except Exception as ex:   # noqa: BLE001 — un fallo del filtro nunca deja la lista vacía
        _registro(f"filtros: fallo con {getattr(e, 'url', '')}: {ex!r}"[:300])
        motivo = ""
    if len(_memo) > 30000:
        _memo.clear()
    _memo[clave] = (f0, motivo)
    return motivo


def mirar_caras(elementos):
    """Las miniaturas de lo que se va a enseñar (ya filtrado), para la cara de sorpresa: solo con «Sin clickbait» encendido
    y solo las que aún no se han mirado. Se piden de la última a la primera: la cola atiende antes lo último pedido, así que
    lo de arriba de la página (lo que se ve primero) se mira antes."""
    if not estado["cebo"]:
        return
    try:
        from . import caras
        ap = aprendidos()
        for e in reversed(list(elementos or ())):
            if isinstance(e, dict):
                tipo, url, titulo, autor = e.get("tipo", ""), e.get("url", ""), e.get("titulo", ""), e.get("autor", "")
            else:
                tipo, url, titulo, autor = getattr(e, "tipo", ""), getattr(e, "url", ""), getattr(e, "titulo", ""), getattr(e, "autor", "")
            vid = id_video(url) if tipo == "VIDEO" else ""
            if vid and ap.cara(vid) is None:
                caras.pedir(vid, url, puntos_cebo(titulo or "", autor or "")[0])
    except Exception as ex:   # noqa: BLE001
        _registro(f"filtros: caras: {ex!r}"[:300])


def de_canal(info, videos, datos=None):
    """La página de un canal: su @ (para AiSList), su insignia (verificado o artista = de confianza) y sus vídeos (fábrica)."""
    if not activo() or not isinstance(info, dict):
        return
    try:
        cid = str(info.get("id") or "")
        url = f"https://www.youtube.com/channel/{cid}" if cid.startswith("UC") else ""
        if url and estado["ia"] and str(info.get("handle") or "").startswith("@"):
            MANGOS[url] = info["handle"]
        if url and info.get("verificado"):
            VERIFICADOS.add(url)
        observar(videos, datos)
    except Exception:   # noqa: BLE001
        pass


def observar(elementos, datos=None):
    """Una lista entera (canal, búsqueda, novedades): canales de fábrica, con 8 o más vídeos publicados en 24 h (salvo
    música o vídeos largos). Devuelve los canales aprendidos ahora."""
    if not estado["ia"]:
        return []
    nuevos = []
    try:
        hace = (time.time() - 86400) * 1000
        cuenta = {}
        for e in elementos or ():
            if getattr(e, "tipo", "") == "VIDEO" and getattr(e, "autorUrl", "") and (getattr(e, "fecha", 0) or 0) >= hace:
                cuenta.setdefault(e.autorUrl, {})[e.url] = e
        ap = reglas().aprender
        tope, largo = ap.get("fabrica_24h", 8), ap.get("fabrica_largos_s", 1200)
        for url, es in cuenta.items():
            if len(es) < tope:
                continue
            vs = list(es.values())
            if sum(1 for e in vs if es_musica(e.titulo, e.autor)) * 2 > len(vs):
                continue
            if sum(1 for e in vs if (getattr(e, "duracion", -1) or -1) >= largo) * 2 >= len(vs):
                continue
            if confianza(vs[0], datos) == 0 and aprendidos().aprender("fabrica", url, vs[0].autor, f"{len(vs)} vídeos en 24 h"):
                nuevos.append(url)
    except Exception:   # noqa: BLE001
        pass
    return nuevos


def comprobar_ficha(f, datos=None):
    """Al abrir un vídeo (motor.ficha): el motivo si su título, su descripción o la etiqueta de YouTube dicen que está hecho
    con IA (y su canal, si no es de confianza, queda aprendido); «» si no, o con el filtro de IA apagado."""
    if not estado["ia"] or not f:
        return ""
    try:
        from .motor import Elemento
        e = Elemento("VIDEO", f.get("url", ""), f.get("titulo", ""), f.get("autor", ""), f.get("autorUrl", ""))
        conf = confianza(e, datos)
        motivo = "IA: YouTube lo marca como «contenido alterado o sintético»" if f.get("etiqueta_ia") else ""
        motivo = motivo or motivo_ia(e, conf) or motivo_descripcion(f.get("descripcion", ""), conf)
        if conf == 0 and e.autorUrl and ensena_canal(motivo):   # un verificado no se aprende entero por un vídeo
            aprendidos().aprender("ia", e.autorUrl, e.autor, motivo)
        if motivo:
            _registro(f"filtros: {e.url} hecho con IA · {motivo}")
        return motivo
    except Exception:   # noqa: BLE001
        return ""


_ETIQUETA_YT = ("alterado o sintetico", "altered or synthetic", "contenido sintetico", "synthetic content", "generado con ia",
                "generated with ai", "ai-generated", "generado digitalmente", "digitally generated")


def etiqueta_youtube(r):
    """¿La respuesta «next» de YouTube trae «Cómo se ha hecho este contenido» con contenido alterado o sintético?"""
    try:
        s = r if isinstance(r, str) else json.dumps(r, ensure_ascii=False)
    except Exception:   # noqa: BLE001
        return False
    i = s.find("howThisWasMadeSection")
    if i < 0:
        return False
    trozo = normalizar(s[i:i + 8000])
    return any(x in trozo for x in _ETIQUETA_YT)


def avisar_cambio(urls=(), canales=()):
    """Algo nuevo ha quedado fuera (un vídeo por su cara, un canal aprendido): la web y la Qt lo quitan de lo que se ve
    (al_cambiar: funciones f(urls de vídeos, urls de canales))."""
    firma[0] += 1
    for f in list(al_cambiar):
        try:
            f(list(urls or ()), list(canales or ()))
        except Exception:   # noqa: BLE001
            pass


# Los textos de Ajustes → Filtros (los mismos en la web, en la Qt y en Android, Filtros.TEXTOS, que dice «este móvil» en vez
# de «este equipo»)
TEXTOS = (
    ("filtro_ia", "Sin contenido hecho con IA",
     "Quita lo hecho con inteligencia artificial, sobre todo el de fábrica: los canales de la lista AiSList, los vídeos que lo "
     "dicen («AI generated», «hecho con IA», #aiart…), los que YouTube marca como contenido sintético, los géneros de relleno "
     "(historias de Reddit con voz sintética, tráilers falsos, «Jesús te dice»…) y los canales que suben como una fábrica. "
     "Es muy duro: de un canal que no sigues ni está verificado, también quita lo que trata de IA."),
    ("filtro_cebo", "Sin clickbait",
     "Quita los títulos gancho («NO VAS A CREER…», «Pasé 50 horas…», «1 € vs 1.000 €», gritos en mayúsculas y 😱) y las "
     "miniaturas con cara de sorpresa (las mira este equipo, sin mandarlas a nadie). Con tus suscripciones es más suave."),
)


def texto_resumen(r, html=False):
    """El resumen bajo las casillas: lo aprendido en este aparato y la cita de AiSList (CC BY-NC 4.0)."""
    partes = []
    if r.get("ia"):
        f = str(r.get("lista_fecha") or "")
        cuando = f" (lista del {f[6:8]}/{f[4:6]}/{f[:4]})" if len(f) == 8 else ""
        partes.append(f"IA: {r.get('lista', 0):,} canales en AiSList{cuando} y {r.get('canales_ia', 0)} aprendidos en este equipo."
                      .replace(",", "."))
    if r.get("cebo"):
        partes.append(f"Clickbait: {r.get('canales_cebo', 0)} canales aprendidos y {r.get('caras', 0)} miniaturas con cara de "
                      "sorpresa en este equipo.")
        fallo = (r.get("caras_estado") or {}).get("fallo")
        if fallo:
            partes.append("Las caras no se pueden mirar en este equipo: el filtro sigue con los títulos.")
    cita = ("La lista de canales de IA es AiSList (aisloplist.com, de Override92), con licencia CC BY-NC 4.0; Cat-ode la guarda "
            "en huellas para buscar rápido.")
    if html:
        import html as _h
        cita = cita.replace("aisloplist.com", '<a href="https://aisloplist.com" style="color:#9AA0A6">aisloplist.com</a>')
        return "<br>".join(_h.escape(p) for p in partes) + ("<br>" if partes else "") + cita
    return "\n".join(partes + [cita])


def resumen():
    """Para Ajustes: qué lleva aprendido este aparato."""
    a = aprendidos().d
    lista = lista_ia() if estado["ia"] else None
    return {"ia": estado["ia"], "cebo": estado["cebo"], "canales_ia": len(a["ia"]) + len(a["fabrica"]),
            "canales_cebo": len(a["cebo"]), "caras": sum(1 for v in a["caras"].values() if cara_de_sorpresa(v)),
            "lista": lista.n if lista else 0, "lista_fecha": lista.fecha if lista else 0}
