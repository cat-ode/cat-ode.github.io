"""Cat-ode escritorio · apagar el remoto (F9), sin Qt (06/10/2026, interfaz web).

Copia de Ventana.apagar_remoto/_remoto_* (interfaz.py 2173-2230): el autor ve Cat-ode en la Samsung del mini PC y a la
vez tiene Moonlight conectado desde el portátil; Sunshine satura la gráfica del N100. Apagar = cerrar la sesión por la
API de Sunshine (localhost:47990, credenciales en remoto.json) avisando antes al portátil con una línea en
C:\\ProgramData\\Cat-ode\\remoto_catode.log; encender = solo el aviso (el lanzador vuelve a conectar). Solo en Windows.
interfaz.py sigue usando lo suyo."""
import json
import os
import sys
import threading
import time

from .resolutor import registro

_cerrojo = threading.Lock()
AVISOS = r"C:\ProgramData\Cat-ode\remoto_catode.log"


def conf():
    # 18/10/2026: CATODE_CARPETA (instalación aislada de prueba) manda sobre %LOCALAPPDATA%\Cat-ode
    from .datos import carpeta_propia
    d = carpeta_propia() or os.path.join(os.environ.get("LOCALAPPDATA", ""), "Cat-ode")
    try:
        with open(os.path.join(d, "remoto.json"), encoding="utf-8") as f:
            return json.load(f)
    except Exception:   # noqa: BLE001
        return {}


def avisar(texto):
    """La línea que el lanzador «minipc» del portátil lee al momento (remoto_esperar.ps1)."""
    try:
        with open(AVISOS, "a", encoding="utf-8") as f:
            f.write(f"{texto} {time.strftime('%d/%m %H:%M:%S')}\n")
    except OSError as e:
        registro(f"remoto: no puedo escribir el aviso ({e})")


def apagar(si, ajustes=None, guardar=None):
    """Apaga (si=True) o enciende el remoto. Guarda ajustes["apagar_remoto"] con la función guardar(ajustes) si se da.
    Devuelve el texto del aviso para la interfaz ("" si no aplica)."""
    if os.name != "nt":
        return ""
    si = bool(si)
    if ajustes is not None:
        ajustes["apagar_remoto"] = si
        if guardar:
            guardar(ajustes)
    texto = ("Remoto apagado: la sesión de Moonlight se cierra y el portátil volverá a conectar cuando pulses F9"
             if si else "Remoto encendido: el portátil se vuelve a conectar")
    if ("--prueba" in sys.argv or os.environ.get("CATODE_PRUEBA_INTERFAZ")) and not os.environ.get("CATODE_REMOTO_REAL"):
        registro(f"remoto {'apagado' if si else 'encendido'} (prueba: sin tocar Sunshine)")
        return texto
    threading.Thread(target=_hilo, args=(si,), daemon=True).start()
    return texto


def _hilo(si):
    with _cerrojo:   # apagar y encender, en orden: nunca un «encender» por delante de su «apagar»
        _paso(si)


def _paso(si):
    import base64
    import ssl
    import urllib.request
    c = conf()
    if si:
        avisar("apagar")
        if not c.get("clave"):
            return registro("apagar remoto: falta remoto.json con las credenciales de Sunshine")
        ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
        req = urllib.request.Request(f"https://localhost:{c.get('puerto', 47990)}/api/apps/close", method="POST", data=b"{}")
        req.add_header("Authorization", "Basic " + base64.b64encode(f"{c['usuario']}:{c['clave']}".encode()).decode())
        req.add_header("Content-Type", "application/json")
        try:
            with urllib.request.urlopen(req, timeout=8, context=ctx) as r:
                registro(f"remoto apagado: sesión de Sunshine cerrada ({r.status})")
        except Exception as e:   # noqa: BLE001
            registro(f"apagar remoto: Sunshine no respondió ({e})")
    else:
        avisar("encender")
        registro("remoto encendido: aviso a los portátiles para que vuelvan a conectar")
