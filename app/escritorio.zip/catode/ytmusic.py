"""Cat-ode · leer la biblioteca de YouTube Music de una cuenta (22/10/2026): sus listas (también «Música que me gusta»), las
canciones guardadas, los álbumes y los artistas que sigue. Lo usan recomendador/ytmusic.py (la del autor, cada día, con su
Firefox del Dell) e importar_musica.youtube_music (cualquier usuario, con la ventana de Google de la app). Pocas peticiones
espaciadas (PAUSA), como mucho TOPE por pasada; para al primer freno de YouTube (Freno) o sin sesión (SinSesion); va por partes
(lo que no ha cambiado no se vuelve a pedir)."""
import hashlib, json, os, re, subprocess, sys, time, urllib.error, urllib.request

from . import cuenta

ORIGEN = "https://music.youtube.com"
CTX = {"client": {"clientName": "WEB_REMIX", "clientVersion": "1.20250929.01.00", "hl": "es", "gl": "ES"}}   # la del 08/10, probada
UA = "Mozilla/5.0 (X11; Linux x86_64; rv:143.0) Gecko/20100101 Firefox/143.0"
TOPE = int(os.environ.get("CATODE_YTM_TOPE", "40"))
PAUSA = 3.0


class Freno(Exception):
    pass


class SinSesion(Exception):
    pass


class Tope(Exception):
    """Se acabaron las peticiones de esta pasada (no StopIteration: dentro de un generador sería RuntimeError)."""


class Sesion:
    def __init__(self, navegador="firefox", galletas=None):
        """navegador: «firefox» (por defecto: la cuenta y la vía del 08/10; en el Dell la sesión vale, la copia del ProBook
        ya no), «chrome» o «chrome:RUTA_DEL_PERFIL» (Chrome necesita secretstorage para descifrar sus galletas)."""
        self.g = dict(galletas or {})   # galletas: {nombre: valor} de youtube.com (la ventana de Google de la app)
        if galletas is None:
            from yt_dlp.cookies import extract_cookies_from_browser
            nav, _, perfil = navegador.partition(":")
            for c in extract_cookies_from_browser(nav, perfil or None):
                dom = c.domain.lstrip(".")
                if "music.youtube.com" == dom or "music.youtube.com".endswith("." + dom):
                    self.g[c.name] = c.value
        self.cab = "; ".join(f"{k}={v}" for k, v in self.g.items())
        self.n, self._ultima = 0, 0.0

    def con_sesion(self):
        return bool(self.g.get("SAPISID") or self.g.get("__Secure-3PAPISID"))

    def _firma(self):
        ts = str(int(time.time()))
        return " ".join(f"{esq} {ts}_{hashlib.sha1(f'{ts} {self.g[n]} {ORIGEN}'.encode()).hexdigest()}"
                        for esq, n in (("SAPISIDHASH", "SAPISID"), ("SAPISID1PHASH", "__Secure-1PAPISID"),
                                       ("SAPISID3PHASH", "__Secure-3PAPISID")) if self.g.get(n))

    def browse(self, cuerpo):
        if self.n >= TOPE:
            raise Tope("tope de peticiones")
        falta = self._ultima + PAUSA - time.monotonic()
        if falta > 0:
            time.sleep(falta)
        self._ultima = time.monotonic()
        self.n += 1
        b = dict(cuerpo)
        b["context"] = CTX
        h = {"Content-Type": "application/json", "Cookie": self.cab, "Authorization": self._firma(), "Origin": ORIGEN,
             "X-Origin": ORIGEN, "X-Goog-AuthUser": "0", "User-Agent": UA}
        q = urllib.request.Request(f"{ORIGEN}/youtubei/v1/browse?prettyPrint=false", data=json.dumps(b).encode(), headers=h)
        try:
            r = json.load(urllib.request.urlopen(q, timeout=40))
        except Exception as e:   # noqa: BLE001
            if cuenta._es_bloqueo(e):
                raise Freno(f"YouTube ha frenado ({e})") from e
            raise
        if cuenta._freno_en(r):
            raise Freno("YouTube ha frenado (respuesta con freno)")
        dentro = next((d.get("value") for ps in cuenta._recorre(r.get("responseContext") or {}, "params") if isinstance(ps, list)
                       for d in ps if isinstance(d, dict) and d.get("key") == "logged_in"), None)
        if dentro == "0":
            raise SinSesion("YouTube no reconoce la sesión del navegador (logged_in=0)")
        return r

    def paginas(self, browse_id, estante=False):
        """Una página y sus continuaciones (las dos formas: continuationItemRenderer y nextContinuationData).
        estante=True (listas, álbumes, canciones guardadas): solo el estante principal y SU continuación; sin eso entraban
        las «Sugerencias» del final de cada lista (medido el 22/10: Mojácar 64 filas para 50 pistas)."""
        r = self.browse({"browseId": browse_id})
        while True:
            r = _estante(r) if estante else r
            yield r
            tok = next((x.get("continuationEndpoint", {}).get("continuationCommand", {}).get("token")
                        for x in cuenta._recorre(r, "continuationItemRenderer")), None) or \
                next((x.get("continuation") for x in cuenta._recorre(r, "nextContinuationData")), None)
            if not tok:
                return
            r = self.browse({"continuation": tok})


txt = cuenta._txt
ESTANTES = ("musicPlaylistShelfRenderer", "musicShelfRenderer", "appendContinuationItemsAction", "musicPlaylistShelfContinuation",
            "musicShelfContinuation")


def _estante(r):
    """El estante principal de una página (las pistas de la lista, del álbum o de la biblioteca) o de su continuación."""
    for k in ESTANTES:
        e = next(cuenta._recorre(r, k), None)
        if e is not None:
            return e
    return {}


def _seg(t):
    try:
        p = [int(x) for x in t.split(":")]
    except ValueError:
        return -1
    s = 0
    for x in p:
        s = s * 60 + x
    return s


def _filas(r):
    """Las canciones de una página de lista, álbum o biblioteca: [{id, titulo, artista, album, dur}]."""
    out = []
    for it in cuenta._recorre(r, "musicResponsiveListItemRenderer"):
        vid = (it.get("playlistItemData") or {}).get("videoId") or next(cuenta._recorre(it.get("overlay") or {}, "videoId"), None) \
            or next(cuenta._recorre(it, "videoId"), None)
        cols = [txt(c.get("musicResponsiveListItemFlexColumnRenderer", {}).get("text")) for c in it.get("flexColumns", [])]
        if not vid or not cols or not cols[0]:
            continue
        fijas = [txt(c.get("musicResponsiveListItemFixedColumnRenderer", {}).get("text")) for c in it.get("fixedColumns", [])]
        artista = (cols[1] if len(cols) > 1 else "").split(" • ")[0]
        out.append({"id": vid, "titulo": " ".join(cols[0].split()), "artista": " ".join(artista.split()),
                    "album": cols[2] if len(cols) > 2 else "", "dur": _seg(fijas[0]) if fijas and fijas[0] else -1})
    return out


def _tarjetas(r, prefijo):
    """Las tarjetas de una página de la biblioteca (listas o álbumes): [(titulo, browseId, subtitulo, miniatura)]."""
    out = []
    for it in cuenta._recorre(r, "musicTwoRowItemRenderer"):
        bid = next(cuenta._recorre(it.get("navigationEndpoint", {}), "browseId"), "")
        if bid.startswith(prefijo):
            mini = next((t[-1]["url"] for t in cuenta._recorre(it, "thumbnails") if t), "")
            out.append((txt(it.get("title")), bid, txt(it.get("subtitle")), mini))
    return out


def leer(s, viejo, aviso=print):
    """Lo nuevo de su biblioteca, partiendo de lo ya leído («viejo»). Para al tope sin perder lo hecho."""
    res = {"listas": dict(viejo.get("listas") or {}), "albumes": dict(viejo.get("albumes") or {}),
           "artistas": list(viejo.get("artistas") or []), "canciones": list(viejo.get("canciones") or []),
           "firmas": dict(viejo.get("firmas") or {}), "completo": False}
    try:
        # 1) los índices: listas, álbumes, artistas y canciones guardadas (una página cada uno; lo pesado va después)
        listas = [t for p in s.paginas("FEmusic_liked_playlists") for t in _tarjetas(p, "VL")]
        albumes = [t for p in s.paginas("FEmusic_liked_albums") for t in _tarjetas(p, "MPREb")]
        artistas = []
        for p in s.paginas("FEmusic_library_corpus_artists"):
            for it in cuenta._recorre(p, "musicResponsiveListItemRenderer"):
                bid = next(cuenta._recorre(it.get("navigationEndpoint", {}), "browseId"), "")
                cols = [txt(c.get("musicResponsiveListItemFlexColumnRenderer", {}).get("text")) for c in it.get("flexColumns", [])]
                if bid.startswith("UC") and cols:
                    mini = next((t[-1]["url"] for t in cuenta._recorre(it, "thumbnails") if t), "")
                    artistas.append({"nombre": cols[0], "id": bid, "miniatura": mini, "detalle": cols[1] if len(cols) > 1 else ""})
        if artistas:
            res["artistas"] = artistas
        aviso(f"biblioteca: {len(listas)} listas, {len(albumes)} álbumes, {len(artistas)} artistas")
        canciones = [c for p in s.paginas("FEmusic_liked_videos", estante=True) for c in _filas(p)]
        if canciones:
            res["canciones"] = canciones
        # 2) cada lista que haya cambiado (su línea «N canciones») y cada álbum que no tenga
        nombres = {n for n, _, _, _ in listas}
        res["listas"] = {n: v for n, v in res["listas"].items() if n in nombres}   # las que quitó de su biblioteca, fuera
        for nombre, bid, sub, mini in listas:
            if res["firmas"].get(bid) == sub and res["listas"].get(nombre):
                continue
            cs = [c for p in s.paginas(bid, estante=True) for c in _filas(p)]
            if cs:
                res["listas"][nombre] = cs
                res["firmas"][bid] = sub
                aviso(f"  lista {nombre}: {len(cs)}")
        claves = set()
        for titulo, bid, sub, mini in albumes:
            partes = [x for x in sub.split(" • ") if x]
            artista = partes[1] if len(partes) > 1 else ""
            clave = f"{titulo} — {artista}" if artista else titulo
            claves.add(clave)
            if res["albumes"].get(clave, {}).get("canciones"):
                continue
            cs = [c for p in s.paginas(bid, estante=True) for c in _filas(p)]
            for c in cs:
                c["artista"] = c["artista"] or artista
                c["album"] = c["album"] or titulo
            if cs:
                res["albumes"][clave] = {"titulo": titulo, "artista": artista, "anio": partes[2] if len(partes) > 2 else "",
                                         "miniatura": mini, "canciones": cs}
                aviso(f"  álbum {clave}: {len(cs)}")
        res["albumes"] = {k: v for k, v in res["albumes"].items() if k in claves}
        res["completo"] = True
    except Tope:
        aviso(f"tope de {TOPE} peticiones: sigo en la próxima pasada")
    return res


