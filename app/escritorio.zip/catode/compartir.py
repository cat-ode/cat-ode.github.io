"""Cat-ode · compartir y abrir fuera (19/10/2026). El autor: «el compartir enlace abre primero el navegador, tienen que
abrirse directamente en las apps» y «los enlaces que comparto en whatsapp con enlace de youtu.be no se muestra la
previsualización».
  · El enlace que se comparte es www.youtube.com/watch?v=… (con youtu.be WhatsApp a veces no saca la vista previa).
  · WhatsApp y Telegram se abren en su app (whatsapp://send, tg://msg_url) si está instalada; si no, su web directamente
    (web.whatsapp.com/send, t.me/share), sin la página intermedia de wa.me. En los Linux del autor WhatsApp es la app web
    «WhatsApp Web» de Chrome: la extensión «Cat-ode enlaces» lleva el envío a esa ventana (no abre otra) y aquí se trae
    delante con la extensión de GNOME de Ralph.
  · Lo que va al navegador va al navegador de verdad (navegador.json), no al «navegador» del sistema, que es Cat-ode para
    los enlaces de YouTube; y los de YouTube llevan «catode=navegador» para que la extensión no los devuelva a Cat-ode."""
import os
import re
import subprocess
import threading
import time
import urllib.parse

from . import enlace as _enlace

YT = _enlace.YT
MARCA = "catode=navegador"   # la extensión deja pasar al navegador los enlaces de YouTube que lo llevan


def enlace_video(vid, segundos=0):
    """El enlace que se comparte o se copia: el de siempre de YouTube (con youtu.be no salía la vista previa)."""
    return f"https://www.youtube.com/watch?v={vid}" + (f"&t={int(segundos)}s" if segundos else "")


def _q(s):
    return urllib.parse.quote(s or "", safe="")


def hay_protocolo(esquema):
    """¿Hay una app instalada para «esquema:»? (whatsapp: la app de WhatsApp; tg: Telegram)."""
    if os.name == "nt":
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, esquema) as k:
                winreg.QueryValueEx(k, "URL Protocol")
            return True
        except OSError:
            return False
    try:
        r = subprocess.run(["xdg-mime", "query", "default", f"x-scheme-handler/{esquema}"], capture_output=True, text=True,
                           timeout=5).stdout.strip()
    except (OSError, subprocess.SubprocessError):
        return False
    if not r:
        return False
    for base in (os.path.expanduser("~/.local/share/applications"), "/usr/local/share/applications", "/usr/share/applications",
                 "/var/lib/snapd/desktop/applications", "/var/lib/flatpak/exports/share/applications"):
        if os.path.exists(os.path.join(base, r)):
            return True
    return False


def _abrir_app(u):
    if os.name == "nt":
        os.startfile(u)   # noqa: S606 (protocolo de una app instalada)
    else:
        subprocess.Popen(["gio", "open", u], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         start_new_session=True)


def al_navegador(url):
    """El navegador de verdad, también para un enlace de YouTube («Abrir en el navegador»)."""
    if YT.match(url) and MARCA not in url:
        url += ("&" if "?" in url else "?") + MARCA
    if _enlace.al_navegador(url) is None and os.name == "nt":
        os.startfile(url)   # noqa: S606 (sin navegador conocido: el predeterminado de Windows)


def _traer(titulo, intentos=12):
    """Linux del autor: la ventana delante con la extensión de GNOME de Ralph (GNOME no deja que Chrome se ponga delante)."""
    if os.name == "nt":
        return
    def trabajo():
        for _ in range(intentos):
            time.sleep(0.5)
            try:
                r = subprocess.run(["gdbus", "call", "--session", "--dest", "org.sapoconcho.Ralph", "--object-path",
                                    "/org/sapoconcho/Ralph", "--method", "org.sapoconcho.Ralph.Activar", titulo],
                                   capture_output=True, text=True, timeout=5)
            except (OSError, subprocess.SubprocessError):
                return
            if r.returncode != 0 or "no hay" not in r.stdout:
                return
    threading.Thread(target=trabajo, daemon=True).start()


def _whatsapp_abierto():
    """Windows: ¿está WhatsApp de escritorio en marcha? (la app nueva es WhatsApp.Root.exe; la antigua, WhatsApp.exe)."""
    try:
        r = subprocess.run(["tasklist", "/NH", "/FO", "CSV"], capture_output=True, text=True, timeout=8,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except (OSError, subprocess.SubprocessError):
        return True
    return '"whatsapp.root.exe"' in r.stdout.lower() or '"whatsapp.exe"' in r.stdout.lower()


def _whatsapp_app(texto):
    """19/10/2026, medido en el mini PC: con WhatsApp ya abierto, whatsapp://send sale con «Envía un mensaje a» y el texto;
    con WhatsApp cerrado, el aviso llega mientras arranca y se pierde (se abre sin nada). Si está cerrado, primero se abre,
    se espera a que cargue y luego se le pasa el enlace."""
    u = "whatsapp://send?text=" + _q(texto)
    if os.name != "nt" or _whatsapp_abierto():
        return _abrir_app(u)
    _abrir_app("whatsapp:")
    def luego():
        for _ in range(40):
            time.sleep(0.5)
            if _whatsapp_abierto():
                break
        time.sleep(9)   # de la ventana a la lista de chats: ~8 s medidos en el mini PC (N100)
        _abrir_app(u)
    threading.Thread(target=luego, daemon=True).start()


def compartir(app, url, titulo=""):
    """Abre la app elegida con el enlace (y el título) listos para mandar. Devuelve por dónde ha ido."""
    texto = f"{titulo} {url}".strip()
    if app == "whatsapp":
        if hay_protocolo("whatsapp"):
            _whatsapp_app(texto)
            return "app"
        al_navegador("https://web.whatsapp.com/send?text=" + _q(texto))
        _traer("WhatsApp Web")
        return "web"
    if app == "telegram":
        if hay_protocolo("tg"):
            _abrir_app("tg://msg_url?url=" + _q(url) + "&text=" + _q(titulo))
            return "app"
        al_navegador("https://t.me/share/url?url=" + _q(url) + "&text=" + _q(titulo))
        return "web"
    if app == "correo":
        _abrir_app("mailto:?subject=" + _q(titulo) + "&body=" + _q(texto))
        return "app"
    web = {"x": "https://x.com/intent/post?text=" + _q(texto),
           "facebook": "https://www.facebook.com/sharer/sharer.php?u=" + _q(url),
           "reddit": "https://www.reddit.com/submit?url=" + _q(url) + "&title=" + _q(titulo)}.get(app)
    if web:
        al_navegador(web)
        return "web"
    return ""


APPS = (("WhatsApp", "whatsapp"), ("Telegram", "telegram"), ("Correo", "correo"), ("X (Twitter)", "x"),
        ("Facebook", "facebook"), ("Reddit", "reddit"))


def abrir_fuera(url):
    """Un enlace de fuera (descripción, «Abrir en el navegador»): las webs, al navegador de verdad; lo demás, a su app."""
    if re.match(r"^https?://", url or "", re.I):
        al_navegador(url)
    elif url:
        _abrir_app(url)
