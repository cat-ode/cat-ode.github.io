"""Cat-ode escritorio · se mantiene al día sola. yt-dlp (el que descifra YouTube) se actualiza al abrir si hace más de 20 h;
en Windows, además, la propia app se baja cuando hay versión nueva. Y si el vigilante del ProBook ha visto que YouTube
rompió algo, lo dice en «Para ti».

18/10/2026 · orden del autor: «la actualización de la app debe hacerse sola desde la URL de GDrive cuando la app se inicia o
cuando se detecta que youtube se ha cascado» (02/11/2026: desde su web propia, cat-ode.github.io/app). Al abrir (siempre) y cada 20 min: PRIMERO Drive (la carpeta pública
«Cat-ode», URL de descarga directa) y, si Drive falla o no trae nada más nuevo, el servidor del autor (solo en los equipos
con sincronización: los aparatos nuevos no la tienen y ya no se quedan sin actualizar). Lo que se mira: el aviso del
vigilante (estado.json), el motor (motor.json: «ya» = yt-dlp al momento, «ytdlp: prueba» = la versión de prueba) y, en
Windows, la app (escritorio.json + escritorio.zip, con su SHA-256). En Linux la app no se descarga (va desde ~/Cat-ode):
solo yt-dlp y los avisos. Si roto.py ve que YouTube se ha roto: empezar(v, ya=True), todo esto al momento."""
import hashlib
import io
import json
import os
import re
import subprocess
import sys
import threading
import time
import urllib.request
import zipfile

from . import VERSION, roto
from .datos import pedir

# 02/11/2026 · su web propia (orden del autor: «la cerré en GDrive para no exponer mi cuenta, quiero hacerla disponible en mi
# web, en todas sus versiones con web propia separada de mi alojamiento»): los mismos archivos, en https://cat-ode.github.io/app/
# (GitHub Pages; lo publica vigia/publicar_web.sh). Antes, la carpeta pública de Drive «Cat-ode». CATODE_DRIVE_URL cambia la
# dirección (pruebas con un canal de mentira); «drive» se queda en los nombres: es «el canal público».
PUBLICOS = ("escritorio.json", "escritorio.zip", "motor.json", "estado.json")
DRIVE_URL = "https://cat-ode.github.io/app"
YTDLP = "yt-dlp[default,curl-cffi]"
SIN_VENTANA = 0x08000000 if os.name == "nt" else 0

_cerrojo = threading.Lock()
_activo = False      # una sola comprobación a la vez
_urgente = None      # motivo de un «YouTube roto» llegado mientras otra comprobación ya iba: se hace al acabarla


def empezar(ventana, ya=False, motivo=""):
    """06/10/2026: una sola comprobación a la vez (al arrancar y cada hora coincidían y relanzaban la app dos veces).
    18/10/2026: ya=True (YouTube roto, lo pide roto.py): yt-dlp y la versión de la app al momento, sin esperar a nada."""
    global _activo, _urgente
    roto.al_roto = lambda m: empezar(ventana, ya=True, motivo=m)
    try:   # 22/10/2026: lo que el contador de aperturas no pudo mandar sin red, en cada comprobación (vuelve al momento)
        from . import recuento
        recuento.reintentar()
    except Exception:   # noqa: BLE001
        pass
    with _cerrojo:
        if _activo:
            if ya:
                _urgente = motivo or "YouTube roto"
            return
        _activo = True
    threading.Thread(target=_trabajo, args=(ventana, ya, motivo), daemon=True, name="actualizar").start()


def _apunta(t):
    try:
        from .resolutor import registro   # sin Qt (la web no carga reproductor.py)
        registro("actualizar: " + t)
    except Exception:   # noqa: BLE001
        pass


def _avisar(v, texto):
    """18/10/2026: aviso corto en pantalla (web: evento «aviso»; Qt: barra de estado) y en Ajustes («Actualizaciones»)."""
    _apunta(texto)
    try:
        v.estado_actualizacion = texto
    except Exception:   # noqa: BLE001
        pass
    try:
        if callable(getattr(v, "emitir", None)):
            v.emitir("aviso", {"texto": texto})
        elif callable(getattr(v, "avisar", None)):
            from . import fichas
            fichas.en_ventana(lambda _: v.avisar(texto), None)
    except Exception:   # noqa: BLE001
        pass


def _trabajo(v, ya, motivo):
    global _activo, _urgente
    while True:
        try:
            _trabajo2(v, ya, motivo)
        except Exception as e:   # noqa: BLE001
            _apunta(f"falló: {e!r}"[:300])
            if ya:
                _avisar(v, "No he podido buscar el arreglo: lo intento más tarde")
        with _cerrojo:
            if not _urgente:
                _activo = False
                return
            ya, motivo, _urgente = True, _urgente, None


# ---------------------------------------------------------------- de dónde: Drive primero, luego el servidor
def drive(nombre, espera=30):
    """Un archivo del canal público (su web; antes, la carpeta pública de Drive). Lanza la excepción si no llega."""
    if nombre not in PUBLICOS:
        raise KeyError(nombre)
    base = (os.environ.get("CATODE_DRIVE_URL") or DRIVE_URL).rstrip("/")
    req = urllib.request.Request(f"{base}/{nombre}", headers={"User-Agent": f"Cat-ode/{VERSION}"})
    with urllib.request.urlopen(req, timeout=espera) as r:
        datos = r.read()
    if datos[:200].lstrip().lower().startswith((b"<!doctype html", b"<html")):   # aviso de Drive (cuota, permiso) en vez del archivo
        raise ValueError("el canal ha devuelto una página, no el archivo")
    return datos


def leer_json(nombre, conf=None, mas_nuevo=None):
    """(datos, origen) de un JSON: de Drive; si Drive falla o (con mas_nuevo) no trae nada más nuevo, del servidor del
    autor (si hay sincronización). origen = «drive» o el servidor; (None, None) si no llega de ninguno."""
    j = None
    try:
        j = json.loads(drive(nombre, 30))
        if not isinstance(j, dict):
            raise ValueError("no es un objeto JSON")
    except Exception as e:   # noqa: BLE001
        _apunta(f"Drive, {nombre}: {e!r}"[:200])
        j = None
    if j is not None and (mas_nuevo is None or mas_nuevo(j)):
        return j, "drive"
    for s in (conf or {}).get("servidores") or []:
        try:
            r = pedir(conf, s, "GET", "/app/" + nombre, espera=30)
            if not r:
                break
            k = json.loads(r)
            if isinstance(k, dict) and (j is None or mas_nuevo(k)):
                return k, s
            break
        except Exception as e:   # noqa: BLE001
            _apunta(f"con {s}, {nombre}: {e!r}"[:200])
    return (j, "drive") if j is not None else (None, None)


def bajar(nombre, origen, conf=None):
    """Un archivo grande (el zip) del mismo sitio que su JSON (así su SHA-256 cuadra)."""
    if origen == "drive":
        return drive(nombre, 300)
    return pedir(conf, origen, "GET", "/app/" + nombre, espera=60)


# ---------------------------------------------------------------- el trabajo
def _trabajo2(v, ya=False, motivo=""):
    a = v.ajustes
    _apunta("comprobando" + (f" YA: {motivo}" if ya else ""))
    if ya:
        _avisar(v, "YouTube ha cambiado algo: buscando arreglo…")
    _ffmpeg()
    _curl()
    conf = getattr(getattr(v, "datos", None), "conf", None) or None   # 18/10/2026: sin sincronización ya no se sale aquí
    est, _ = leer_json("estado.json", conf)
    if est is not None:
        v.aviso_vigilante = est.get("aviso", "")
    m, _ = leer_json("motor.json", conf, lambda j: j.get("ya", 0) > a.get("ytdlp_ya", 0))
    m = m or {}
    prueba = m.get("ytdlp") == "prueba"   # el vigilante dice que solo la de prueba esquiva a YouTube
    pide_ya = m.get("ya", 0) > a.get("ytdlp_ya", 0)   # 03/10/2026: el arreglador pide actualizar yt-dlp YA
    antes = version_ytdlp()
    if ya or pide_ya or (prueba and a.get("ytdlp_canal") != "prueba") or time.time() - a.get("ytdlp_comprobado", 0) > 20 * 3600:
        bien = _pip_ytdlp(prueba)
        a["ytdlp_comprobado"] = time.time()
        a["ytdlp_canal"] = "prueba" if prueba else "estable"
        if pide_ya:
            a["ytdlp_ya"] = m["ya"]
        v.guardar_ajustes()
        v.estado_actualizacion = "Motor (yt-dlp) comprobado hoy" + ("" if bien else ": no se pudo actualizar")
    nuevo_motor = version_ytdlp()
    # 02/11/2026 · el paquete de Linux (.deb o AppImage, CATODE_PAQUETE) se actualiza como Windows: su lanzador copia la app en
    # ~/.local/share/catode/app y ahí se descomprime la versión nueva
    nueva_app = _app_windows(v, conf) if os.name == "nt" or os.environ.get("CATODE_PAQUETE") else _app_linux(v)
    if nueva_app:
        if ya:
            _avisar(v, f"Arreglo descargado (versión {nueva_app}): se aplica en cuanto no estés viendo nada")
        return
    if nuevo_motor and nuevo_motor != antes and (ya or pide_ya):
        # el yt-dlp nuevo solo vale al volver a abrir (el viejo ya está cargado): se reinicia sola cuando no suene nada
        _avisar(v, f"Motor de YouTube al día ({nuevo_motor}): Cat-ode se reinicia en cuanto no estés viendo nada")
        from . import fichas
        fichas.en_ventana(lambda _: v.reiniciar_cuando_libre(), None)
    elif ya:
        _avisar(v, "Aún no hay arreglo publicado: sigo atento")


def _app_linux(v):
    """19/10/2026 · en Linux la app va desde ~/Cat-ode: si el código en disco es de una versión más nueva que la que está
    abierta, se reinicia sola en cuanto no suene nada (como Windows al bajarse una versión). Antes, un arreglo no llegaba
    al Cat-ode abierto hasta cerrarlo a mano («los vídeos que se cortan pasa también en linux»)."""
    from . import VERSION
    try:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "__init__.py"), encoding="utf-8") as f:
            en_disco = re.search(r'VERSION = "([^"]+)"', f.read()).group(1)
        if _version(en_disco) <= _version(VERSION):
            return None
    except Exception:   # noqa: BLE001
        return None
    _apunta(f"versión {en_disco} en disco (abierta {VERSION}): reinicio cuando no suene nada")
    from . import fichas
    fichas.en_ventana(lambda _: v.reiniciar_cuando_libre(), None)
    return en_disco


def version_ytdlp():
    try:
        import importlib.metadata
        return importlib.metadata.version("yt-dlp")
    except Exception:   # noqa: BLE001
        return ""


def _pip_usuario():
    """02/11/2026 · en el paquete de Linux el Python va en /opt o dentro del AppImage (no se puede escribir): pip instala en la
    carpeta del usuario (PYTHONUSERBASE, que pone el lanzador), que va por delante en sys.path. En Windows y en un venv, nada."""
    import sysconfig
    try:
        return [] if os.access(sysconfig.get_paths()["purelib"], os.W_OK) else ["--user"]
    except Exception:   # noqa: BLE001
        return []


def _pip_ytdlp(prueba=False):
    r = subprocess.run([sys.executable, "-m", "pip", "install", "-U", "-q", "--disable-pip-version-check"] + _pip_usuario()
                       + (["--pre"] if prueba else []) + [YTDLP],
                       capture_output=True, text=True, timeout=600, creationflags=SIN_VENTANA)
    if r.returncode:
        _apunta(f"pip yt-dlp: {(r.stderr or r.stdout or '').strip()[-200:]}")
    return r.returncode == 0


def _ffmpeg():
    """Las descargas unen imagen y sonido con ffmpeg (yt-dlp lo exige). Si el equipo no lo tiene (Windows, casi siempre),
    se instala el paquete imageio-ffmpeg, que lo trae dentro (02/10/2026: «la descarga no funciona en Windows, pide ffmpeg»)."""
    from . import motor
    if motor.ffmpeg():
        return
    subprocess.run([sys.executable, "-m", "pip", "install", "-q", "--disable-pip-version-check", "imageio-ffmpeg"] + _pip_usuario(),
                   capture_output=True, timeout=900, creationflags=SIN_VENTANA)


def _curl():
    """15/10/2026: los subtítulos se piden como Chrome (anuncios.bajar_subtitulos); sin curl_cffi YouTube los niega con 429
    y no se encuentran los anuncios. Sin -U: no se cambia el yt-dlp que haya."""
    try:
        import curl_cffi  # noqa: F401
    except ImportError:
        subprocess.run([sys.executable, "-m", "pip", "install", "-q", "--disable-pip-version-check", YTDLP] + _pip_usuario(),
                       capture_output=True, timeout=900, creationflags=SIN_VENTANA)


def _version(t):
    return tuple(int(x) for x in str(t).split("."))


def carpeta_app():
    """La carpeta de catode.pyw (en la instalación nueva, %LOCALAPPDATA%\\Cat-ode\\app)."""
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def instalar_zip(z, sha256, destino):
    """El zip de la versión nueva, solo si su SHA-256 es el publicado y no escribe fuera de destino. True si se instaló."""
    if not z or hashlib.sha256(z).hexdigest() != str(sha256 or "").lower():
        _apunta("el zip no cuadra con su SHA-256: no se instala")
        return False
    raiz = os.path.realpath(destino)
    with zipfile.ZipFile(io.BytesIO(z)) as zf:
        for n in zf.namelist():
            p = os.path.realpath(os.path.join(raiz, n))
            if p != raiz and not p.startswith(raiz + os.sep):
                _apunta(f"el zip trae una ruta fuera de la app ({n}): no se instala")
                return False
        zf.extractall(raiz)
    return True


def _interfaz_remota(v, info):
    if info.get("interfaz") not in ("web", "qt"):   # 06/10/2026: interruptor remoto de la interfaz (web/qt) del autor
        return
    try:
        from . import ajustes as _aj
        a = _aj.leer()
        if a.get("interfaz_remota") != info["interfaz"]:
            a["interfaz_remota"] = info["interfaz"]
            _aj.guardar(a)
            if isinstance(getattr(v, "ajustes", None), dict):   # también en memoria: la ventana guarda su dict al cerrar
                v.ajustes["interfaz_remota"] = info["interfaz"]
            _apunta(f"interfaz remota: {info['interfaz']}: se reinicia en cuanto no suene nada")
            v.estado_actualizacion = "Interfaz nueva lista: se aplica en cuanto no estés viendo nada"
            from . import fichas
            fichas.en_ventana(lambda _: v.reiniciar_cuando_libre(), None)   # como una actualización: sin que el autor haga nada
    except Exception as e:   # noqa: BLE001
        _apunta(f"interfaz remota: no se pudo guardar: {e!r}"[:200])


def buscar_version(conf=None, destino=None):
    """La versión nueva de la app (Drive y, si no la trae, el servidor), descargada, comprobada e instalada en destino.
    (info de escritorio.json o None, versión instalada o None)."""
    info, origen = leer_json("escritorio.json", conf, lambda j: _version(j.get("version", "0")) > _version(VERSION))
    if not info or _version(info.get("version", "0")) <= _version(VERSION):
        return info, None
    _apunta(f"versión nueva {info['version']} en {origen} (tengo {VERSION})")
    z = bajar("escritorio.zip", origen, conf)
    if not instalar_zip(z, info.get("sha256"), destino or carpeta_app()):
        return info, None
    return info, info["version"]


def _app_windows(v, conf):
    info, nueva = buscar_version(conf)
    if info:
        _interfaz_remota(v, info)
    if not nueva:
        return None
    v.estado_actualizacion = f"Versión {nueva} descargada: se aplica en cuanto no estés viendo nada"
    from . import fichas
    fichas.en_ventana(lambda _: v.reiniciar_cuando_libre(), None)   # 03/10/2026: al momento, sin esperar a cerrarla
    return nueva
