"""Cat-ode escritorio · el segundo vídeo (03/10/2026: «que permita reproducir varios vídeos a la vez, al menos dos»).

Una ventanita flotante, siempre encima, con su propio mpv: se arrastra, se agranda con la esquina, empieza callada; sus
botones dan sonido, la pasan al reproductor principal (en el mismo punto) o la cierran. Clic en el vídeo = pausa."""
import os
import threading

from PySide6.QtCore import Qt, QTimer, QPoint, QSize
from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QSizeGrip, QLabel

from .iconos import icono


class SegundoVideo(QWidget):
    def __init__(self, ventana, e):
        super().__init__(None, Qt.Tool | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
        self.ventana, self.e = ventana, e
        self.setWindowTitle("Cat-ode · a la vez")
        self.setStyleSheet("QWidget { background: #000; } QPushButton { background: transparent; border: none; padding: 4px; }"
                           "QPushButton:hover { background: rgba(255,255,255,0.15); border-radius: 14px; }"
                           "QLabel { color: #DDD; font-size: 12px; background: transparent; }")
        v = QVBoxLayout(self); v.setContentsMargins(0, 0, 0, 0); v.setSpacing(0)
        self.video = QWidget(); self.video.setAttribute(Qt.WA_NativeWindow); self.video.setAttribute(Qt.WA_DontCreateNativeAncestors)
        self.video.setMinimumSize(240, 135)
        v.addWidget(self.video, 1)
        fila = QHBoxLayout(); fila.setContentsMargins(6, 2, 2, 2)
        t = QLabel(e.titulo); t.setMaximumWidth(260); fila.addWidget(t, 1)
        self.sonido = QPushButton(); self.sonido.setIcon(icono("silencio", "#FFFFFF")); self.sonido.setToolTip("Sonido")
        self.sonido.clicked.connect(self._sonido)
        pasar = QPushButton(); pasar.setIcon(icono("completa", "#FFFFFF")); pasar.setToolTip("Pasar al reproductor principal")
        pasar.clicked.connect(self._pasar)
        cerrar = QPushButton("✕"); cerrar.setStyleSheet("color: white; font-size: 14px;"); cerrar.setToolTip("Cerrar")
        cerrar.clicked.connect(self.close)
        for b in (self.sonido, pasar, cerrar):
            b.setFixedSize(QSize(30, 28)); b.setCursor(Qt.PointingHandCursor); fila.addWidget(b)
        fila.addWidget(QSizeGrip(self), 0, Qt.AlignBottom | Qt.AlignRight)
        v.addLayout(fila)
        self.resize(426, 270)
        g = ventana.geometry(); self.move(g.right() - 450, g.bottom() - 330)
        self._arrastre = None
        self.mpv = None
        self.show()
        QTimer.singleShot(50, self._arrancar)

    def _arrancar(self):
        from .mpv_crear import crear_mpv   # 02/11/2026: también con un libmpv viejo (Debian 12)
        self.mpv = crear_mpv(wid=str(int(self.video.winId())), mute=True, keep_open="yes", osc=False, input_default_bindings=False,
                           input_vo_keyboard=False, hwdec="auto-safe", ytdl=False, cursor_autohide="no", input_cursor_passthrough="yes",
                           **({"profile": "fast", "vo": "gpu", "gpu_api": "d3d11"} if os.name == "nt" else {"gpu_context": "x11egl"}))
        for t in ("MBTN_LEFT", "MBTN_LEFT_DBL", "MBTN_RIGHT", "WHEEL_UP", "WHEEL_DOWN"):
            try:
                self.mpv.command("keybind", t, "ignore")
            except Exception:   # noqa: BLE001
                pass

        def resolver():
            try:
                x = self.ventana.rep.resolutor.resolver(self.e.url, 480)
                self.mpv.play(x["ruta"])
            except Exception:   # noqa: BLE001
                pass
        threading.Thread(target=resolver, daemon=True).start()

    def _sonido(self):
        if self.mpv:
            self.mpv.mute = not self.mpv.mute
            self.sonido.setIcon(icono("silencio" if self.mpv.mute else "volumen", "#FFFFFF"))

    def _pasar(self):
        pos = (self.mpv.time_pos or 0) if self.mpv else 0
        self.close()
        self.ventana.abrir_video(self.e, desde=pos)

    # arrastrar la ventanita desde cualquier sitio; clic corto en el vídeo = pausa
    def mousePressEvent(self, ev):
        if ev.button() == Qt.LeftButton:
            self._arrastre = (ev.globalPosition().toPoint(), self.pos(), False)

    def mouseMoveEvent(self, ev):
        if self._arrastre:
            p0, w0, _ = self._arrastre
            d = ev.globalPosition().toPoint() - p0
            if d.manhattanLength() > 4:
                self._arrastre = (p0, w0, True)
                self.move(w0 + d)

    def mouseReleaseEvent(self, ev):
        if self._arrastre and not self._arrastre[2] and self.mpv:
            self.mpv.pause = not self.mpv.pause
        self._arrastre = None

    def closeEvent(self, ev):
        if self.mpv:
            try:
                self.mpv.terminate()
            except Exception:   # noqa: BLE001
                pass
            self.mpv = None
        if getattr(self.ventana, "segundo", None) is self:
            self.ventana.segundo = None
        super().closeEvent(ev)
