"""Cat-ode escritorio · prueba de la INTERFAZ WEB sin red y sin ventanas (módulo M8, DISENO_WEB.md §4), 06/10/2026.

Los pasos viven en catode/web/js/prueba_web.js (los mismos en Linux y en Windows) y escriben cada línea OK/FALLA por
POST /api/prueba con el formato de prueba.py. Este módulo los lanza:

- Linux (ProBook): `python -m catode.prueba_web` arranca el servidor web DENTRO de este proceso con fixtures
  (CATODE_PRUEBA_INTERFAZ=1, proxy inválido y el socket del motor falso, que rechaza todo lo que no sea 127.0.0.1), abre
  index.html en Chromium headless de Playwright e inyecta prueba_web.js. Después añade lo que solo se ve desde fuera:
  pestañas que se reabren tras recargar, cartel sin red con reintento a los 15 s, el interruptor de la vuelta atrás, cero
  errores de JS/CSP y cero peticiones fuera de 127.0.0.1. Lo llama pruebas/interfaz_web_linux.sh.
- Windows (mini PC): VentanaWeb --prueba llama a empezar(ventana) al llegar «lista»: inyecta prueba_web.js con
  ExecuteScriptAsync (sin entrada simulada), espera el final por /api/prueba y añade la pantalla completa real.

Al final: «--- n/m pruebas bien» y «fin 0|1»."""
import json
import os
import shutil
import subprocess
import sys
import time

AQUI = os.path.dirname(os.path.abspath(__file__))
ESCRITORIO = os.path.dirname(AQUI)
RAIZ = os.path.dirname(ESCRITORIO)
PROGRESO = os.path.expanduser("~/.local/bin/progreso")
_PID_PROGRESO = os.environ.get("CATODE_PROGRESO_ID") or "catode_web"


# 07/10/2026: una pestaña de VÍDEO recordada, como la del autor (su app arranca con el vídeo de ayer reanudado, no desde una
# tarjeta): sobre ese vídeo se prueba el doble clic al arrancar. En modo prueba cualquier URL resuelve al vídeo local.
PESTANA_VIDEO = {"f": "_mostrar_video", "a": [{"_e": {"tipo": "VIDEO", "url": "https://www.youtube.com/watch?v=jy0r-pA8C88",
                 "titulo": "Vídeo recordado (prueba)", "autor": "Prueba", "miniatura": "", "duracion": 60}}], "t": "Vídeo recordado (prueba)"}


def _linea(nombre, bien, detalle=""):
    print(f"{'OK    ' if bien else 'FALLA '} {str(nombre)[:60]:34s} {str(detalle)[:300]}", flush=True)


def _version():
    try:
        from .servidor_web import firma_web   # la misma clave de caché que la página (versión + huella del contenido)
        return firma_web()
    except Exception:   # noqa: BLE001
        return "0"


def _inyectar_js(pestanas=0, ronda=0):
    """El trozo que carga prueba_web.js en la página (un <script src> de 'self': la CSP lo deja) y la arranca. Pasa
    CATODE_PRUEBA_SOLO y si es la prueba de interfaz (sin red): «Reproducir un vídeo real» solo corre sin ella."""
    op = json.dumps({"pestanas": int(pestanas), "solo": os.environ.get("CATODE_PRUEBA_SOLO", ""),
                     "interfaz": bool(os.environ.get("CATODE_PRUEBA_INTERFAZ")),
                     "ronda": int(ronda)})
    return ("(function(){var s=document.createElement('script');"
            f"s.src='js/prueba_web.js?v={_version()}';"
            f"s.onload=function(){{window.catode.prueba.correr({op});}};"
            "document.body.appendChild(s);return 'inyectada';})()")


def _video_real():
    """06/10/2026: la pasada manual «Reproducir un vídeo real» (CON red): CATODE_PRUEBA_SOLO la nombra y no hay
    CATODE_PRUEBA_INTERFAZ (ni fixtures, ni motor falso, ni proxy). Sin tildes en la comparación (cmd no lee eñes)."""
    import unicodedata
    sin = lambda t: "".join(c for c in unicodedata.normalize("NFD", t.lower()) if unicodedata.category(c) != "Mn")   # noqa: E731
    return not os.environ.get("CATODE_PRUEBA_INTERFAZ") and any(
        "video real" in sin(x) for x in os.environ.get("CATODE_PRUEBA_SOLO", "").split(","))


# ==================================================================================================== Windows
def _es_perfil():
    return "perfil" in [x.strip().lower() for x in os.environ.get("CATODE_PRUEBA_SOLO", "").split(",")]


def _inicio_proceso():
    """La hora (epoch) en que Windows creó este proceso (GetProcessTimes); None fuera de Windows."""
    if os.name != "nt":
        return None
    try:
        import ctypes
        from ctypes import wintypes
        k = ctypes.windll.kernel32
        k.GetCurrentProcess.restype = wintypes.HANDLE
        k.GetProcessTimes.argtypes = [wintypes.HANDLE] + [ctypes.POINTER(wintypes.FILETIME)] * 4
        k.GetProcessTimes.restype = wintypes.BOOL
        ft = [wintypes.FILETIME() for _ in range(4)]
        if not k.GetProcessTimes(k.GetCurrentProcess(), *[ctypes.byref(x) for x in ft]):
            return None
        return ((ft[0].dwHighDateTime << 32) | ft[0].dwLowDateTime) / 1e7 - 11644473600
    except Exception:   # noqa: BLE001
        return None


def _filas_arranque(rondas, tiempos, t_proc):
    """Las filas «a arranque» de la tabla: la página en cada ronda y, en la 0 (el arranque en frío), los tramos de fuera."""
    filas = {}

    def ap(met, v):
        if v is not None and v >= 0:
            filas.setdefault("a arranque · " + met, []).append(round(float(v), 1))
    for c in sorted(rondas, key=lambda x: x.get("ronda", 0)):
        ap("página → tarjetas pintadas (ms)", c.get("tarjetas"))
        ap("página → «lista» (ms)", c.get("lista"))
        ap("página → DOMContentLoaded (ms)", c.get("dom"))
        ap("página → módulos JS bajados (ms)", c.get("js"))
        ap("página → fin /api/estado (ms)", c.get("estado"))
        ap("página → fin /api/pagina (ms)", c.get("inicio"))
        ap("tareas largas hasta tarjetas (n)", c.get("largas"))
        ap("peor tarea larga hasta tarjetas (ms)", c.get("largas_max"))
    frio = next((c for c in rondas if c.get("ronda") == 0), None)
    if frio and tiempos:
        nav = float(frio.get("epoch", 0)) / 1000.0
        tj = nav + float(frio.get("tarjetas", 0)) / 1000.0
        ms = lambda a, b: (b - a) * 1000 if a and b else None   # noqa: E731
        tr = {}
        for x in os.environ.get("CATODE_TRAMOS", "").split(";"):   # los de catode.pyw
            if "=" in x:
                tr[x.split("=")[0]] = float(x.split("=")[1])
        t0 = float(os.environ.get("CATODE_T0") or 0) or None
        pedido = tr.get("edge_pedido") or tiempos.get("edge_pedido")
        ap("FRÍO proceso → catode.pyw (arranque de Python) (ms)", ms(t_proc, t0))
        ap("FRÍO catode.pyw → PySide6 importado (ms)", ms(t0, tr.get("qt_importado")))
        ap("FRÍO PySide6 → QApplication (ms)", ms(tr.get("qt_importado"), tr.get("qapplication")))
        ap("FRÍO QApplication → entorno Edge pedido (ms)", ms(tr.get("qapplication"), tr.get("edge_pedido")))
        ap("FRÍO Edge pedido → interfaz importada (ms)", ms(tr.get("edge_pedido"), tr.get("interfaz_importada")))
        ap("FRÍO interfaz importada → VentanaWeb (ms)", ms(tr.get("interfaz_importada"), tiempos.get("init")))
        ap("FRÍO proceso → VentanaWeb (ms)", ms(t_proc, tiempos.get("init")))
        ap("FRÍO VentanaWeb → servicio y servidor listos (ms)", ms(tiempos.get("init"), tiempos.get("ventana")))
        ap("FRÍO Edge pedido → entorno Edge listo (ms)", ms(pedido, tiempos.get("entorno")))
        ap("FRÍO entorno → controlador (ms)", ms(tiempos.get("entorno"), tiempos.get("controlador")))
        ap("FRÍO controlador → página pedida (ms)", ms(tiempos.get("controlador"), tiempos.get("pedida")))
        ap("FRÍO pedida → empieza la página (ms)", ms(tiempos.get("pedida"), nav))
        ap("FRÍO VentanaWeb → tarjetas pintadas (ms)", ms(tiempos.get("init"), tj))
        ap("FRÍO proceso → tarjetas pintadas (ms)", ms(t_proc, tj))
    return filas


def _empezar_perfil(v):
    """06/10/2026 · CATODE_PRUEBA_SOLO=perfil: el modo perfil de prueba_web.js (3 rondas de arranque con recarga y los
    recorridos b-h), con la ventana maximizada como en la tele. Al final, la TABLA en el registro y se cierra la app."""
    from PySide6.QtCore import QTimer
    srv = v.servidor
    t_proc = _inicio_proceso()
    est = {"ronda": 0, "a": [], "esperando": False, "hecho": False}
    v.showMaximized()

    def inyectar():
        try:
            v._wv.ExecuteScriptAsync(_inyectar_js(0, est["ronda"]))
            print(f"web: perfil, ronda {est['ronda']} inyectada", flush=True)
        except Exception as error:   # noqa: BLE001
            _linea("inyectar prueba_web.js (perfil)", False, error)

    def imprimir(c):
        filas = _filas_arranque(est["a"], getattr(v, "_tiempos", {}), t_proc)
        print(f"PERFIL ===== tabla en {os.environ.get('COMPUTERNAME', '?')} (medida · mediana · máximo · n) =====", flush=True)
        todas = [(k, sorted(x)[len(x) // 2] if len(x) % 2 else (sorted(x)[len(x) // 2 - 1] + sorted(x)[len(x) // 2]) / 2, max(x), len(x))
                 for k, x in filas.items()]
        todas += [(f["k"], f["med"], f["max"], f["n"]) for f in c.get("filas", [])]
        for k, med, mx, n in todas:
            print(f"PERFIL {k[:58]:58s} {med:9.1f} {mx:9.1f}  n={n}", flush=True)
        try:   # 06/10/2026: el mensajero hilo → ventana que usa actualizar.py para reiniciar tras una versión nueva
            from . import fichas
            fichas.en_ventana(lambda _: print("PERFIL fichas.en_ventana: entregado en el hilo de la ventana", flush=True), None)
        except Exception as error:   # noqa: BLE001
            print(f"PERFIL fichas.en_ventana: FALLA {error!r}", flush=True)
        for rec, cs in (c.get("culpas") or {}).items():
            for x in cs:
                print(f"PERFIL culpa {rec}: {str(x)[:200]}", flush=True)

    def al_perfil(c):
        if c.get("rec") == "a":
            est["a"].append(c)
        elif c.get("recargar"):
            est["ronda"], est["esperando"] = int(c["recargar"]), True
        elif c.get("fin_perfil"):
            v._hilo.llega.emit(lambda: imprimir(c))
        return {}
    srv.al_prueba_perfil = al_perfil
    orig = srv.al_lista

    def otra_lista():   # tras cada recarga de la página, la siguiente ronda
        if est["esperando"]:
            est["esperando"] = False
            v._hilo.llega.emit(lambda: QTimer.singleShot(500, inyectar))
        elif orig:
            orig()
    srv.al_lista = otra_lista

    def terminar(c):
        if est["hecho"]:
            return
        est["hecho"] = True
        print(f"--- {int(c.get('bien', 0))}/{int(c.get('total', 0))} pruebas bien", flush=True)
        v.codigo_salida = 0 if c.get("bien") else 1
        QTimer.singleShot(1500, v.close)

    def sin_final():
        if not est["hecho"]:
            est["hecho"] = True
            _linea("perfil", False, "sin final en 480 s")
            print("--- 0/1 pruebas bien", flush=True)
            v.codigo_salida = 1
            v.close()
    srv.al_prueba_fin = lambda c: v._hilo.llega.emit(lambda: terminar(c))
    QTimer.singleShot(480_000, sin_final)
    QTimer.singleShot(300, inyectar)


def _empezar_cierre(v):
    """06/10/2026 · CATODE_PRUEBA_SOLO=cierre (pruebas/windows_cierre.sh): como lo vive el autor. La app se lanza con
    pythonw (sin consola), abre un vídeo, y a los 10 s se cierra la ventana: el proceso tiene que desaparecer."""
    from PySide6.QtCore import QTimer
    from .resolutor import registro
    registro("cierre: prueba de cierre con pythonw (stdout=%r)" % (None if sys.stdout is None else "hay"))

    def abrir():
        try:
            # en una pestaña limpia (la app reabre las de la pasada anterior, que puede ser la del vídeo: sin tarjetas);
            # a los 7 s apunta en el registro si de verdad suena
            v._wv.ExecuteScriptAsync(
                "(function(){catode.pestanas.crear();"
                "setTimeout(function(){(document.querySelector('.pestana-cuerpo.activa .tj')||{click(){}}).click();},2500);"
                "setTimeout(function(){var r=catode.reproductor;catode.api.post('/api/registro',{t:'cierre: '+(r&&r.actual?"
                "('suena «'+r.actual.titulo.slice(0,30)+'» pos '+Math.round(r.pos)+' pausa '+r.pausa):'NO hay vídeo')});},7000);})()")
        except Exception as error:   # noqa: BLE001
            registro(f"cierre: no se pudo abrir el vídeo: {error!r}"[:200])
    QTimer.singleShot(1500, abrir)
    seg = int(os.environ.get("CATODE_PRUEBA_SEGUNDOS", "10") or 10)   # windows_multimedia.sh la deja abierta más rato
    QTimer.singleShot(seg * 1000, lambda: (registro("cierre: se cierra la ventana"), v.close()))


def empezar(v):
    """VentanaWeb --prueba: la batería de la página por ExecuteScriptAsync y, al acabar, lo que solo hay en Windows."""
    from PySide6.QtCore import QTimer
    if _es_perfil():
        return _empezar_perfil(v)
    if "cierre" in [x.strip().lower() for x in os.environ.get("CATODE_PRUEBA_SOLO", "").split(",")]:
        return _empezar_cierre(v)
    srv = v.servidor
    estado = {"hecho": False}
    extra = [True]   # la línea «web: lista» que ya escribió VentanaWeb

    def anotar(nombre, bien, detalle=""):
        extra.append(bool(bien))
        _linea(nombre, bien, detalle)

    real = _video_real() or "completa" in [x.strip().lower() for x in os.environ.get("CATODE_PRUEBA_SOLO", "").split(",")]

    def terminar(c):
        if estado["hecho"]:
            return
        estado["hecho"] = True
        if real:   # la pasada del vídeo real: solo ese paso; se cierra la app sin tocar la ventana
            bien = int(c.get("bien", 0)) + sum(extra)
            total = int(c.get("total", 0)) + len(extra)
            print(f"--- {bien}/{total} pruebas bien", flush=True)
            v.codigo_salida = 0 if bien == total and total else 1
            QTimer.singleShot(800, v.close)
            return
        # pantalla completa REAL de la ventana (llena() de prueba.py) y vuelta, con el foco devuelto a la página. Por el
        # mismo camino que la página (POST /api/ventana → _ventana), con el segundo «completa» del reintento de 400 ms
        # (flotante.js) ya en pantalla completa: al volver tiene que seguir maximizada
        v.showMaximized()

        def a_completa():
            v._ventana("completa", None)
            QTimer.singleShot(400, lambda: v._ventana("completa", None))
            QTimer.singleShot(1300, mirar_completa)

        def mirar_completa():
            anotar("ventana: pantalla completa real", v.isFullScreen(), f"{v.width()}×{v.height()}")
            v._ventana("normal", None)
            QTimer.singleShot(800, mirar_normal)

        def mirar_normal():
            anotar("ventana: vuelta de pantalla completa (maximizada)", not v.isFullScreen() and v.isMaximized(),
                   f"{v.width()}×{v.height()}")
            bien = int(c.get("bien", 0)) + sum(extra)
            total = int(c.get("total", 0)) + len(extra)
            print(f"--- {bien}/{total} pruebas bien", flush=True)
            v.codigo_salida = 0 if bien == total and total else 1
            QTimer.singleShot(500, v.close)
        QTimer.singleShot(600, a_completa)

    def sin_final():
        if not estado["hecho"]:
            _linea("batería de la página", False, "sin final en 300 s")
            estado["hecho"] = True
            print("--- 0/1 pruebas bien", flush=True)
            v.codigo_salida = 1
            v.close()

    srv.al_prueba_fin = lambda c: v._hilo.llega.emit(lambda: terminar(c))
    QTimer.singleShot(300_000, sin_final)
    n = int(os.environ.get("CATODE_PRUEBA_PESTANAS", "0") or 0)
    try:
        v._wv.ExecuteScriptAsync(_inyectar_js(n))
        print("web: prueba_web.js inyectada (ExecuteScriptAsync)", flush=True)
    except Exception as error:   # noqa: BLE001
        _linea("inyectar prueba_web.js", False, error)
        sin_final()


# ==================================================================================================== Linux
def _progreso(hecho, total):
    if os.path.exists(PROGRESO):
        subprocess.run([PROGRESO, "set", _PID_PROGRESO, "Cat-ode web: prueba", str(hecho), str(total), "pasos"],
                       env={**os.environ, "PROGRESO_PID": str(os.getpid())}, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def _esperar(pg, expr, segundos=5.0):
    """La CSP prohíbe eval: wait_for_function no vale; se pregunta en bucle con evaluate."""
    fin = time.time() + segundos
    while time.time() < fin:
        try:
            if pg.evaluate(expr):
                return True
        except Exception:   # noqa: BLE001
            pass
        time.sleep(0.1)
    return False


def _interruptor():
    """La vuelta atrás y el interruptor (activa()): en Linux siempre False; en Windows, según ajustes y entorno."""
    from . import interfaz_web, motor_web
    detalle, bien = [], True
    r = interfaz_web.activa(["catode.pyw"])
    bien &= r is False
    detalle.append(f"Linux={r}")
    nombre, disp, entorno = os.name, motor_web.disponible, os.environ.get("CATODE_INTERFAZ")
    try:
        interfaz_web.os.name = "nt"
        motor_web.disponible = lambda: True
        # 1.1.3 (06/10/2026, orden del autor): en Windows la web es LA interfaz; la Qt solo con --clasica, CATODE_INTERFAZ=qt
        # o sin WebView2. Los ajustes, el vigía y el interruptor remoto ya no la cambian (interfaz_web.activa)
        casos = [("web", [], True), ("qt", [], False), ("web", ["--clasica"], False), ("", [], True)]
        for modo, args, esperado in casos:
            os.environ["CATODE_INTERFAZ"] = modo
            r = interfaz_web.activa(["catode.pyw"] + args)
            if esperado is None:   # 06/10/2026: sin variable, en Windows la web SIEMPRE (orden del autor); los ajustes no deciden
                esperado = True
            bien &= r is esperado
            detalle.append(f"{modo or 'ajustes'}{' '.join(args)}={r}")
        motor_web.disponible = lambda: False
        os.environ["CATODE_INTERFAZ"] = "web"
        r = interfaz_web.activa(["catode.pyw"])
        bien &= r is False
        detalle.append(f"sin WebView2={r}")
        # el vigía (3 arranques sin «lista») y el interruptor remoto (interfaz_remota), con la copia de ajustes de la prueba
        motor_web.disponible = lambda: True
        os.environ.pop("CATODE_INTERFAZ", None)
        from . import ajustes as aj
        copia = aj.leer()
        try:
            # 06/10/2026: ni el vigía ni el interruptor local/remoto apagan la web en Windows (solo --clasica / CATODE_INTERFAZ=qt)
            for extra, esperado, nombre in [({"web_sin_lista": 3, "interfaz": "web"}, True, "vigía 3 sin lista"),
                                            ({"interfaz_remota": "qt"}, True, "remoto qt"),
                                            ({"interfaz_remota": "web"}, True, "remoto web"),
                                            ({"interfaz": "qt", "interfaz_remota": "web"}, True, "local qt no apaga")]:
                a = {k: v for k, v in copia.items() if k not in ("interfaz", "interfaz_remota", "web_sin_lista")}
                a.update(extra)
                aj.guardar(a)
                r = interfaz_web.activa(["catode.pyw"])
                ok = r is esperado
                bien &= ok
                detalle.append(f"{nombre}={r}")
        finally:
            aj.guardar(copia)
    finally:
        interfaz_web.os.name = nombre
        motor_web.disponible = disp
        if entorno is None:
            os.environ.pop("CATODE_INTERFAZ", None)
        else:
            os.environ["CATODE_INTERFAZ"] = entorno
    return bien, ", ".join(detalle)


def main():
    obra = os.path.expanduser(os.environ.get("CATODE_OBRA_PRUEBA_WEB") or "~/.cache/obra/catode-prueba-web")
    datos = os.path.join(obra, "datos")
    os.environ.update({"CATODE_PRUEBA_INTERFAZ": "1", "CATODE_CARPETA_PRUEBA": datos,
                       "CATODE_FIXTURES_RETARDO": os.environ.get("CATODE_FIXTURES_RETARDO", "0.1"),
                       "CATODE_VIDEO_LOCAL": os.path.join(RAIZ, "pruebas", "video_prueba.mp4"),
                       "http_proxy": "http://127.0.0.1:9", "https_proxy": "http://127.0.0.1:9", "HTTP_PROXY": "http://127.0.0.1:9",
                       "HTTPS_PROXY": "http://127.0.0.1:9", "no_proxy": "127.0.0.1", "NO_PROXY": "127.0.0.1"})
    os.environ.pop("DISPLAY", None)   # nunca la pantalla del autor
    shutil.rmtree(obra, ignore_errors=True)
    os.makedirs(datos, exist_ok=True)
    # dos pestañas «recordadas» como en interfaz_linux.sh (Historial y Ver más tarde), en el formato de la Qt
    recordadas = [{"f": "historial", "a": [], "t": "Historial"}, {"f": "despues", "a": [], "t": "Ver más tarde"}, PESTANA_VIDEO]
    with open(os.path.join(datos, "escritorio-ajustes.json"), "w", encoding="utf-8") as f:
        json.dump({"pestanas": recordadas, "pestana_activa": len(recordadas) - 1, "automatica": False}, f, ensure_ascii=False)   # activa: la del vídeo
    como = os.environ.get("CATODE_PRUEBA_DATOS")   # diagnóstico: los datos y ajustes de otra prueba (p. ej. los del mini PC)
    if como:
        import glob
        import platform
        for x in glob.glob(os.path.join(como, "datos-*.json"))[:1]:
            shutil.copy(x, os.path.join(datos, f"datos-{platform.node()}.json"))
        if os.path.exists(os.path.join(como, "escritorio-ajustes.json")):
            with open(os.path.join(como, "escritorio-ajustes.json"), encoding="utf-8") as f:
                aj = json.load(f)
            aj["automatica"] = False
            recordadas = aj.get("pestanas") or recordadas
            with open(os.path.join(datos, "escritorio-ajustes.json"), "w", encoding="utf-8") as f:
                json.dump(aj, f, ensure_ascii=False)

    sys.path.insert(0, ESCRITORIO)
    from . import motor_falso
    from .servicio import Servicio
    from .servidor_web import ServidorWeb
    s = Servicio.instancia(fixtures=True)
    srv = ServidorWeb(s, puerto=0, solo=True, prueba=True).empezar()
    total_previsto = 68   # 18/10/2026: +6 pasos de «Traer mi YouTube» (cuenta falsa)
    cuenta = {"n": 0}
    api_orig = srv._api

    def contar(h, metodo, ruta, q):
        if ruta == "/api/prueba":
            cuenta["n"] += 1
            _progreso(cuenta["n"], total_previsto)
        return api_orig(h, metodo, ruta, q)
    srv._api = contar
    print(f"servidor: {srv.base} (fixtures={s.fixtures})", flush=True)
    extra = []

    def anotar(nombre, bien, detalle=""):
        extra.append(bool(bien))
        _linea(nombre, bien, detalle)
        cuenta["n"] += 1
        _progreso(cuenta["n"], total_previsto)

    from playwright.sync_api import sync_playwright
    import re
    fuera, errores = [], []
    res = {"bien": 0, "total": 0}
    try:
        with sync_playwright() as pw:
            nav = pw.chromium.launch(headless=True, args=["--autoplay-policy=no-user-gesture-required"])
            ctx = nav.new_context(viewport={"width": 1440, "height": 900})

            def ruta(r):
                fuera.append(r.request.url)
                return r.abort()
            # solo las de fuera: interceptarlas todas dejaría esperando las locales mientras este proceso duerme
            ctx.route(re.compile(r"^(?!http://127\.0\.0\.1:)"), ruta)
            pg = ctx.new_page()
            freno = float(os.environ.get("CATODE_PRUEBA_FRENO") or 0)   # diagnóstico: CPU frenada (CDP) solo en la rejilla
            cdp = ctx.new_cdp_session(pg) if freno > 1 else None

            def consola(m):
                if cdp is not None and m.text.startswith("CATODE_FRENO "):
                    try:
                        cdp.send("Emulation.setCPUThrottlingRate", {"rate": freno if m.text.endswith(" si") else 1})
                        print(f"freno: CPU ×{freno if m.text.endswith(' si') else 1}", flush=True)
                    except Exception as error:   # noqa: BLE001
                        print(f"freno: {error!r}", flush=True)
                    return
                # el 504 del fallo forzado (CATODE_FIXTURES_FALLO) lo apunta el navegador como error de red: no es de JS
                if m.type == "error" and not (forzado["si"] and "status of 504" in m.text):
                    errores.append(f"{m.text[:200]} @ {m.location.get('url', '')[-40:]}")
            forzado = {"si": False}
            pg.on("console", consola)
            pg.on("pageerror", lambda e: errores.append(f"pageerror {str(e)[:200]}"))
            t0 = time.time()
            pg.goto(srv.direccion())
            listo = _esperar(pg, "window.app && window.app.listo === true", 15)
            # «lista» sale justo DESPUÉS de app.listo (POST /api/lista): se espera a que llegue, no se mira en el mismo instante
            lista = srv.lista_recibida.wait(5)
            anotar("carga index.html y manda «lista»", listo and lista, f"{time.time() - t0:.2f} s")
            pg.add_script_tag(url=f"js/prueba_web.js?v={_version()}")
            r = pg.evaluate("catode.prueba.correr({pestanas: %d})" % len(recordadas))
            res = {"bien": r["bien"], "total": r["total"]}

            # ---- las pestañas guardadas se reabren al recargar (lo mismo que la Qt al arrancar con esa copia)
            with open(os.path.join(datos, "escritorio-ajustes.json"), encoding="utf-8") as f:
                aj = json.load(f)
            guardadas = [g["f"] for g in aj.get("pestanas", [])]
            pg.reload()
            _esperar(pg, "window.app && window.app.listo === true", 15)
            abiertas = pg.evaluate("catode.pestanas.lista.map(p => p.pila.at(-1).f)")
            act = pg.evaluate("catode.pestanas.actual()")
            anotar("pestañas: se reabren tras recargar", abiertas == guardadas and act == aj.get("pestana_activa"),
                   f"guardadas {guardadas} activa {aj.get('pestana_activa')} → abiertas {abiertas} activa {act}")
            anotar("pestañas: formato de la Qt {f, a, t}", all(set(g) == {"f", "a", "t"} for g in aj.get("pestanas", [])),
                   json.dumps(aj.get("pestanas", [])[:2], ensure_ascii=False)[:160])

            # ---- sin red: cartel con su clase y reintento solo a los 15 s
            os.environ["CATODE_FIXTURES_FALLO"] = "inicio"
            forzado["si"] = True
            s._parati = None   # el último Para ti guardado: que lo pida otra vez (y falle)
            pg.evaluate("catode.pestanas.crear()")
            # el aviso de la página de lista (Pagina.fallo de M5, como el aviso de la Qt) o el cartel de api.js
            sel = ".pestana-cuerpo.activa .pr-aviso.error, .pestana-cuerpo.activa .cartel"
            cartel = _esperar(pg, f"!!(document.querySelector('{sel}')||{{}}).textContent", 8)
            clase = pg.evaluate(f"(e => e ? e.className + ' · ' + e.textContent.slice(0, 70) : '')(document.querySelector('{sel}'))")
            os.environ.pop("CATODE_FIXTURES_FALLO", None)
            t1 = time.time()
            vuelve = _esperar(pg, "document.querySelectorAll('.pestana-cuerpo.activa .tj').length > 0", 20)
            anotar("sin red: cartel y reintento a los 15 s", cartel and ("sin_red" in clase or "error" in clase) and vuelve,
                   f"cartel={cartel} «{clase}» · tarjetas tras {time.time() - t1:.1f} s")

            # ---- el interruptor y la vuelta atrás
            bien, det = _interruptor()
            anotar("interruptor web/qt (activa) y --clasica", bien, det)

            # ---- medidas de la página → medidas.jsonl
            pg.evaluate("catode.medir && catode.medir.enviar && catode.medir.enviar()")
            time.sleep(1.0)
            med = os.path.join(datos, "medidas.jsonl")
            anotar("medidas.jsonl recibe marcas", os.path.exists(med) and os.path.getsize(med) > 0,
                   f"{os.path.getsize(med) if os.path.exists(med) else 0} bytes")
            anotar("sin errores de JS ni de CSP", not errores, "; ".join(errores[:4]) or "0 errores")
            anotar("ninguna petición fuera de 127.0.0.1", not fuera and not motor_falso.bloqueadas,
                   f"navegador {len(fuera)}, servidor {len(motor_falso.bloqueadas)} {fuera[:2]}")
            nav.close()
    except Exception as error:   # noqa: BLE001
        anotar("la batería termina", False, f"excepción: {error!r}"[:300])
    finally:
        srv.parar()
    bien = res["bien"] + sum(extra)
    total = res["total"] + len(extra)
    print(f"--- {bien}/{total} pruebas bien", flush=True)
    codigo = 0 if bien == total and total else 1
    if __name__ != "__main__":   # interfaz_web_linux.sh ya escribe «fin N»
        print(f"fin {codigo}", flush=True)
    if os.path.exists(PROGRESO):
        subprocess.run([PROGRESO, "fin", _PID_PROGRESO], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    if codigo == 0:
        shutil.rmtree(obra, ignore_errors=True)
    return codigo


if __name__ == "__main__":
    sys.exit(main())
