"""Cat-ode escritorio (interfaz Qt: Linux y la clásica de Windows) · el logo animado al abrir (22/10/2026).

Orden del autor (19/10/2026): «Haz un logotipo en blender para cuando se abre, como hemos hecho con Dos Gatos y Rosbel's
delight al iniciarla. Algo guapo, que mole» y (21/10/2026) «una figura giratoria en 3D con mucho brilli brilli». El mismo
vídeo que la interfaz web (arte/arranque/blender/giro.py), aquí como WebP animado (Qt lo lee con su complemento qwebp):
una capa sin marco encima de la ventana, del color de fondo de la app, que suena una vez, se queda un momento en el logo
quieto y se funde. Nunca estorba: no coge el foco ni los clics, y como mucho dura 7 s. No sale en las pruebas, al medir
ni al reiniciarse sola tras una actualización."""
import os
import sys

from PySide6.QtCore import Qt, QTimer, QPropertyAnimation, QSize
from PySide6.QtGui import QMovie
from PySide6.QtWidgets import QLabel, QVBoxLayout, QWidget

RUTA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "web", "arranque", "arranque.webp")


def mostrar(ventana):
    """Enseña el logo animado encima de «ventana» (ya visible). Devuelve la capa o None si no toca."""
    if (not os.path.exists(RUTA) or os.environ.get("CATODE_PRUEBA_INTERFAZ")
            or any(a in sys.argv for a in ("--prueba", "--reinicio", "--medir"))):
        return None
    capa = QWidget(None, Qt.Tool | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.WindowDoesNotAcceptFocus)
    capa.setAttribute(Qt.WA_ShowWithoutActivating)
    capa.setAttribute(Qt.WA_TransparentForMouseEvents)
    capa.setAttribute(Qt.WA_DeleteOnClose)
    capa.setStyleSheet("background: #0F0F0F;")
    capa.setGeometry(ventana.geometry())
    caja = QVBoxLayout(capa); caja.setContentsMargins(0, 0, 0, 0)
    imagen = QLabel(capa); imagen.setAlignment(Qt.AlignCenter); caja.addWidget(imagen)
    peli = QMovie(RUTA, parent=capa)
    lado = int(min(560, 0.52 * min(capa.width(), capa.height())))
    peli.setScaledSize(QSize(lado, lado))
    peli.setCacheMode(QMovie.CacheAll)
    imagen.setMovie(peli)
    estado = {"fuera": False}

    def fundir():
        if estado["fuera"]:
            return
        estado["fuera"] = True
        anim = QPropertyAnimation(capa, b"windowOpacity", capa)
        anim.setDuration(550); anim.setStartValue(1.0); anim.setEndValue(0.0)
        anim.finished.connect(capa.close)
        anim.start()

    def fotograma(n):   # en el último fotograma: quieto en el logo medio segundo y fuera
        if peli.frameCount() > 0 and n >= peli.frameCount() - 1:
            peli.setPaused(True)
            QTimer.singleShot(500, fundir)
    peli.frameChanged.connect(fotograma)
    peli.finished.connect(lambda: QTimer.singleShot(500, fundir))
    QTimer.singleShot(7000, fundir)
    capa.show()
    peli.start()
    return capa
