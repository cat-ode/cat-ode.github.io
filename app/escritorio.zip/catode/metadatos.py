"""Cat-ode escritorio · lo que YouTube esconde en su app (02/10/2026): «no me gusta» estimados (Return YouTube Dislike),
visualizaciones y «me gusta» exactos, fecha y hora de publicación, directos y estrenos, si es para niños, licencia,
restricción de edad, número exacto de comentarios, capítulos, idiomas de audio y subtítulos, todos los formatos, y la
ficha «Acerca de» de cada canal. Son llamadas propias a innertube (la API interna de YouTube), las mismas que hace el
móvil (Metadatos.kt), para que las dos versiones enseñen lo mismo. Todo lleva caché: no se repiten peticiones."""
import base64
import concurrent.futures as cf
import gzip
import html
import json
import os
import re
import threading
import time
import urllib.parse
import urllib.request
import uuid
from datetime import datetime

AGENTE = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0"
CLIENTES = {
    "WEB": {"clientName": "WEB", "clientVersion": "2.20250930.01.00"},
    # los clientes de móvil dan los formatos con todos sus datos (el WEB ya no los da sin «PoToken»)
    "IOS": {"clientName": "IOS", "clientVersion": "20.10.4", "deviceMake": "Apple", "deviceModel": "iPhone16,2",
            "osName": "iPhone", "osVersion": "18.3.2.22D82"},
    "ANDROID_VR": {"clientName": "ANDROID_VR", "clientVersion": "1.65.10", "deviceMake": "Oculus", "deviceModel": "Quest 3",
                   "androidSdkVersion": 32, "osName": "Android", "osVersion": "12L"},
    # 06/10/2026: el de las Apple Vision da la lista HLS sin JavaScript ni «token de prueba» (lo que usa la app de Android)
    "VISIONOS": {"clientName": "VISIONOS", "clientVersion": "1.02", "deviceMake": "Apple", "deviceModel": "RealityDevice17,1",
                 "osName": "visionOS", "osVersion": "26.5.23O471"},
}
AGENTES = {"IOS": "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)",
           "ANDROID_VR": "com.google.android.apps.youtube.vr.oculus/1.65.10 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip"}


# ---------------------------------------------------------------- innertube
def innertube(endpoint, cuerpo, cliente="WEB", visitante=None):
    datos = {"context": {"client": dict(CLIENTES[cliente], hl="es", gl="ES")}}
    if visitante:
        datos["context"]["client"]["visitorData"] = visitante
    datos.update(cuerpo)
    req = urllib.request.Request(f"https://www.youtube.com/youtubei/v1/{endpoint}?prettyPrint=false", json.dumps(datos).encode(),
                                 {"Content-Type": "application/json", "User-Agent": AGENTES.get(cliente, AGENTE),
                                  "Origin": "https://www.youtube.com", "Accept-Encoding": "gzip",
                                  **({"X-Goog-Visitor-Id": visitante} if visitante else {})})
    with urllib.request.urlopen(req, timeout=15) as r:
        cuerpo = r.read()
        if r.headers.get("Content-Encoding") == "gzip":
            cuerpo = gzip.decompress(cuerpo)
    return json.loads(cuerpo)


def buscar(o, clave):
    """El primer valor de «clave» en cualquier sitio del árbol."""
    if isinstance(o, dict):
        if clave in o:
            return o[clave]
        for v in o.values():
            r = buscar(v, clave)
            if r is not None:
                return r
    elif isinstance(o, list):
        for v in o:
            r = buscar(v, clave)
            if r is not None:
                return r
    return None


def todos(o, clave):
    if isinstance(o, dict):
        for k, v in o.items():
            if k == clave:
                yield v
            yield from todos(v, clave)
    elif isinstance(o, list):
        for v in o:
            yield from todos(v, clave)


def texto(t):
    if not t:
        return ""
    if isinstance(t, str):
        return t
    if "simpleText" in t:
        return t["simpleText"]
    if "content" in t:
        return t["content"]
    return "".join(r.get("text", "") for r in t.get("runs", []))


def numero(s):
    m = re.search(r"\d[\d.,  ]*", s or "")
    d = re.sub(r"\D", "", m.group(0)) if m else ""
    return int(d) if d else -1


def fecha_iso(s):
    """«2009-10-24T23:57:33-07:00» → milisegundos."""
    if not s:
        return 0
    try:
        return int(datetime.fromisoformat(s.replace("Z", "+00:00")).timestamp() * 1000)
    except ValueError:
        return 0


def id_video(url):
    m = re.search(r"(?:v=|youtu\.be/|shorts/|live/)([A-Za-z0-9_-]{11})", url or "")
    return m.group(1) if m else (url if url and len(url) == 11 else url)


def id_canal(url):
    m = re.search(r"(UC[A-Za-z0-9_-]{22})", url or "")
    return m.group(1) if m else ""


def enlace_real(url, visible=""):
    """Los enlaces de YouTube pasan por su redirección (youtube.com/redirect?q=…): se saca el de verdad."""
    q = re.search(r"[?&]q=([^&]+)", url or "")
    if url and "youtube.com/redirect" in url and q:
        return urllib.parse.unquote(q.group(1))
    if url and url.startswith("/"):
        return "https://www.youtube.com" + url
    if url:
        return url
    if visible:
        return visible if visible.startswith("http") else "https://" + visible
    return ""


def enlace_de_orden(c):
    """La dirección a la que lleva una orden de YouTube (enlace, vídeo con minuto, canal, hashtag…)."""
    c = c or {}
    if "urlEndpoint" in c:
        return enlace_real(c["urlEndpoint"].get("url", ""))
    if "watchEndpoint" in c:
        w = c["watchEndpoint"]
        t = w.get("startTimeSeconds")
        return f"https://www.youtube.com/watch?v={w.get('videoId', '')}" + (f"&t={t}s" if t else "")
    if "browseEndpoint" in c:
        b = c["browseEndpoint"]
        if str(b.get("browseId", "")).startswith("UC"):
            return f"https://www.youtube.com/channel/{b['browseId']}"
        if b.get("canonicalBaseUrl"):
            return "https://www.youtube.com" + b["canonicalBaseUrl"]
    u = buscar(c.get("commandMetadata", {}), "url")
    return enlace_real(u) if u else ""


# ---------------------------------------------------------------- traducciones y formatos de texto
CATEGORIAS = {
    "Film & Animation": "Cine y animación", "Autos & Vehicles": "Motor", "Music": "Música", "Pets & Animals": "Mascotas y animales",
    "Sports": "Deportes", "Travel & Events": "Viajes y eventos", "Gaming": "Videojuegos", "People & Blogs": "Gente y blogs",
    "Comedy": "Humor", "Entertainment": "Entretenimiento", "News & Politics": "Noticias y política",
    "Howto & Style": "Consejos y estilo", "Education": "Educación", "Science & Technology": "Ciencia y tecnología",
    "Nonprofits & Activism": "ONG y activismo", "Movies": "Películas", "Shows": "Programas", "Trailers": "Tráilers"}


def categoria(c):
    return CATEGORIAS.get(c, c or "")


def miles(n):
    return f"{n:,}".replace(",", ".") if isinstance(n, int) and n >= 0 else ""


def tres_cifras(n):
    """Como los redondea YouTube («4,55 M», «872 K»). Solo cuando YouTube no da su propio texto."""
    def tres(x):
        t = str(int(x)) if x >= 100 else f"{int(x * 10) / 10:.1f}" if x >= 10 else f"{int(x * 100) / 100:.2f}"
        t = t.replace(".", ",")
        return t.rstrip("0").rstrip(",") if "," in t else t
    if n is None or n < 0:
        return ""
    return tres(n / 1e9) + " mil M" if n >= 1e9 else tres(n / 1e6) + " M" if n >= 1e6 else tres(n / 1e3) + " K" if n >= 1e3 else str(n)


def fecha_hora(ms):
    return datetime.fromtimestamp(ms / 1000).strftime("%d/%m/%Y, %H:%M:%S") if ms and ms > 0 else ""


def hora(ms):
    return datetime.fromtimestamp(ms / 1000).strftime("%H:%M:%S") if ms and ms > 0 else ""


def hace(ms):
    if not ms or ms <= 0:
        return ""
    s = int((time.time() * 1000 - ms) / 1000)
    if s < 0:
        return "dentro de " + duracion_larga(-s)
    if s < 60:
        return "hace un momento"
    for lim, div, uno, varios in ((3600, 60, "minuto", "minutos"), (86400, 3600, "hora", "horas"), (86400 * 30, 86400, "día", "días"),
                                  (86400 * 365, 86400 * 30, "mes", "meses"), (10 ** 12, 86400 * 365, "año", "años")):
        if s < lim:
            x = s // div
            return f"hace {x} {uno if x == 1 else varios}"
    return ""


def tiempo(s):
    if s is None or s < 0:
        return ""
    s = int(s)
    return f"{s // 3600}:{s % 3600 // 60:02d}:{s % 60:02d}" if s >= 3600 else f"{s // 60}:{s % 60:02d}"


def duracion(s):
    return f"{tiempo(s)} ({miles(int(s))} segundos)" if s is not None and s >= 0 else ""


def duracion_larga(s):
    return (f"{s // 86400} d {s % 86400 // 3600} h" if s >= 86400 else f"{s // 3600} h {s % 3600 // 60} min" if s >= 3600
            else f"{s // 60} min" if s >= 60 else f"{s} s")


def _nombre_codec(c):
    x = c.lower()
    for pref, n in (("avc1", "H.264"), ("vp09", "VP9"), ("vp8", "VP8"), ("av01", "AV1"), ("hev1", "H.265"), ("hvc1", "H.265"), ("mp4a", "AAC")):
        if x.startswith(pref):
            return n
    return {"vp9": "VP9", "opus": "Opus", "vorbis": "Vorbis", "ec-3": "E-AC-3", "ac-3": "AC-3"}.get(x, c)


def codec(c):
    """«H.264 (avc1.640028)», «VP9», «Opus», «H.264 + AAC (avc1.42001E, mp4a.40.2)»."""
    partes = [p.strip() for p in (c or "").split(",") if p.strip()]
    nombre = " + ".join(_nombre_codec(p) for p in partes)
    crudo = ", ".join(partes)
    return nombre if not crudo or crudo.lower() == nombre.lower() else f"{nombre} ({crudo})"


def tasa(bps):
    return "" if not bps or bps <= 0 else f"{bps / 1e6:.1f} Mb/s".replace(".", ",") if bps >= 1e6 else f"{bps // 1000} kb/s"


def tamano(b):
    return "" if not b or b <= 0 else f"{b / 1073741824:.2f} GB".replace(".", ",") if b >= 1 << 30 else f"{b / 1048576:.1f} MB".replace(".", ",")


def linea_formato(f):
    """Una línea por formato: «2160p · 25 fps · VP9 · webm · SDR · 13,5 Mb/s · 342,0 MB» (igual que en el móvil)."""
    p = [f["calidad"] or None, f"{f['fps']} fps" if f["fps"] > 0 else None, codec(f["codec"]), f["contenedor"] or None,
         ("HDR" if f["hdr"] else "SDR") if f["clase"] != "audio" else None,
         (f"{f['muestreo'] / 1000:.1f} kHz".replace(".", ",").replace(",0 ", " ")) if f["muestreo"] > 0 else None,
         ("mono" if f["canales"] == 1 else "estéreo" if f["canales"] == 2 else f"{f['canales']} canales") if f["canales"] > 0 and f["clase"] != "vídeo" else None,
         f["pista"] or None, tasa(f["tasa"]) or None, (("≈ " if f["estimado"] else "") + tamano(f["tamano"])) if f["tamano"] > 0 else None]
    return " · ".join(x for x in p if x)


def formatos_visibles(lista):
    """Con doblajes, cada calidad de audio sale repetida por idioma: se enseñan las de la pista original."""
    pistas = list(dict.fromkeys(f["pista"] for f in lista if f["clase"] == "audio"))
    if len(pistas) <= 1:
        return lista, 0
    elegida = next((p for p in pistas if "original" in p), pistas[0])
    return [f for f in lista if f["clase"] != "audio" or f["pista"] == elegida], len(pistas) - 1


# ---------------------------------------------------------------- caché
def _carpeta_cache():
    # 18/10/2026: CATODE_CACHE la sustituye entera (pruebas aisladas de la instalación nueva, sin tocar la del autor)
    base = os.environ.get("LOCALAPPDATA", "") if os.name == "nt" else os.path.expanduser("~/.cache")
    d = os.environ.get("CATODE_CACHE") or os.path.join(base, "catode")
    os.makedirs(d, exist_ok=True)
    return d


_cerrojo = threading.RLock()
_memoria = {"extra": {}, "acerca": {}, "formatos": {}, "next": {}}
_disco = {"votos": {}, "resumen": {}}
_cargada = False
_guardar_pendiente = False
VIDA = {"votos": 12 * 3600, "resumen": 3 * 86400, "extra": 600, "acerca": 6 * 3600, "formatos": 600, "next": 600}


def _archivo():
    return os.path.join(_carpeta_cache(), "metadatos.json")


def _cargar():
    global _cargada
    if _cargada:
        return
    _cargada = True
    try:
        with open(_archivo(), encoding="utf-8") as f:
            d = json.load(f)
        for k in _disco:
            _disco[k].update(d.get(k, {}))
    except Exception:
        pass


def _leer(tipo, clave):
    with _cerrojo:
        _cargar()
        m = (_disco if tipo in _disco else _memoria)[tipo].get(clave)
        if m and time.time() - m["t"] < VIDA[tipo]:
            return m
    return None


def _apuntar(tipo, clave, valor):
    global _guardar_pendiente
    with _cerrojo:
        donde = _disco if tipo in _disco else _memoria
        donde[tipo][clave] = {"t": time.time(), "v": valor}
        if tipo == "next" and len(donde[tipo]) > 3:   # cada respuesta «next» ocupa varios MB en memoria: solo las últimas
            del donde[tipo][min(donde[tipo], key=lambda k: donde[tipo][k]["t"])]
        if tipo in _disco and not _guardar_pendiente:
            _guardar_pendiente = True
            threading.Timer(4, _guardar).start()


def _guardar():
    global _guardar_pendiente
    with _cerrojo:
        _guardar_pendiente = False
        ahora = time.time()
        d = {k: {c: m for c, m in v.items() if ahora - m["t"] < VIDA[k]} for k, v in _disco.items()}
        if len(d["resumen"]) > 4000:
            d["resumen"] = dict(sorted(d["resumen"].items(), key=lambda x: -x[1]["t"])[:4000])
    try:
        tmp = _archivo() + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(d, f)
        os.replace(tmp, _archivo())
    except Exception:
        pass


# ---------------------------------------------------------------- Return YouTube Dislike
_turno_ryd = threading.BoundedSemaphore(4)     # como mucho 4 peticiones a la vez
_horas_ryd = []                                # y no más de 90 por minuto (su límite es de unas 100)
_cerrojo_ryd = threading.Lock()


def _cupo_ryd():
    while True:
        with _cerrojo_ryd:
            ahora = time.time()
            while _horas_ryd and ahora - _horas_ryd[0] > 60:
                _horas_ryd.pop(0)
            if len(_horas_ryd) < 90:
                _horas_ryd.append(ahora)
                return
            espera = 60 - (ahora - _horas_ryd[0]) + 0.05
        time.sleep(espera)


def votos(url):
    """«No me gusta» estimados: {meGusta, noMeGusta, valoracion, vistas}, o None si Return YouTube Dislike no responde."""
    vid = id_video(url)
    m = _leer("votos", vid)
    if m:
        return m["v"]
    with _turno_ryd:
        _cupo_ryd()
        try:
            r = urllib.request.urlopen(urllib.request.Request(f"https://returnyoutubedislikeapi.com/votes?videoId={vid}",
                                                              headers={"User-Agent": AGENTE}), timeout=8)
            d = json.loads(r.read())
            v = {"meGusta": d.get("likes", -1), "noMeGusta": d.get("dislikes", -1), "valoracion": d.get("rating", 0), "vistas": d.get("viewCount", -1)}
        except urllib.error.HTTPError as e:
            if e.code not in (400, 404):
                return None         # caído o con prisa: la ficha sale sin esa línea
            v = None                # no lo tiene: se apunta para no volver a pedirlo
        except Exception:
            return None
    _apuntar("votos", vid, v)
    return v


def valoracion(urls, avance=None):
    """«Valoración de sus últimos vídeos (estimación)»: la media de los 15 últimos, con avance para la pantalla."""
    ids = list(dict.fromkeys(id_video(u) for u in urls))[:15]
    hechos, lista, cerrojo = [0], [], threading.Lock()

    def estado():
        v = [x for x in lista if x and x["meGusta"] >= 0 and x["noMeGusta"] >= 0]
        return {"hechos": hechos[0], "total": len(ids), "conVotos": len(v),
                "mediaMeGusta": sum(x["meGusta"] for x in v) // len(v) if v else -1,
                "mediaNoMeGusta": sum(x["noMeGusta"] for x in v) // len(v) if v else -1}

    def uno(vid):
        v = votos(vid)
        with cerrojo:
            hechos[0] += 1
            lista.append(v)
            e = estado()
        if avance:
            avance(e)
    with cf.ThreadPoolExecutor(4) as ex:
        list(ex.map(uno, ids))
    return estado()


# ---------------------------------------------------------------- ficha del vídeo
def siguiente(vid):
    """La respuesta «next» de un vídeo (la ficha de la web), guardada 10 minutos para no pedirla dos veces."""
    m = _leer("next", vid)
    if m:
        return m["v"]
    r = innertube("next", {"videoId": vid})
    _apuntar("next", vid, r)
    return r


def descripcion_html(attr):
    """La descripción con sus enlaces (los índices de YouTube cuentan en UTF-16, como en JavaScript)."""
    if not isinstance(attr, dict):
        return html.escape(texto(attr)).replace("\n", "<br>")
    u16 = attr.get("content", "").encode("utf-16-le")

    def corte(a, b):
        return u16[2 * a:2 * b].decode("utf-16-le", "replace")
    out, pos = [], 0
    for r in sorted(attr.get("commandRuns", []), key=lambda r: r.get("startIndex", 0)):
        ini, lar = r.get("startIndex", 0), r.get("length", 0)
        if ini < pos:
            continue
        out.append(html.escape(corte(pos, ini)))
        enlace = enlace_de_orden(r.get("onTap", {}).get("innertubeCommand", {}))
        t = html.escape(corte(ini, ini + lar))
        out.append(f'<a href="{html.escape(enlace, quote=True)}">{t}</a>' if enlace else t)
        pos = ini + lar
    out.append(html.escape(corte(pos, len(u16) // 2)))
    return "".join(out).replace("\n", "<br>")


def capitulos(n):
    """[(segundo, título)] de la barra del reproductor o, si no, del panel de «momentos clave»."""
    for m in todos(n, "markersMap"):
        for x in m or []:
            caps = [c.get("chapterRenderer", {}) for c in x.get("value", {}).get("chapters", [])]
            if caps:
                return [(int(c.get("timeRangeStartMillis", 0)) // 1000, texto(c.get("title"))) for c in caps]
    r = []
    for c in todos(n, "macroMarkersListItemRenderer"):
        s = buscar(c.get("onTap", {}), "startTimeSeconds")
        if s is not None:
            r.append((int(s), texto(c.get("title"))))
    return list(dict.fromkeys(r))


def _comentarios(n):
    """Número exacto de comentarios: la cabecera de la primera página («2.457.995 comentarios»)."""
    for s in todos(n, "itemSectionRenderer"):
        if s.get("sectionIdentifier") == "comment-item-section":
            tok = (buscar(s, "continuationCommand") or {}).get("token")
            if not tok:
                return -1
            try:
                cab = buscar(innertube("next", {"continuation": tok}), "commentsHeaderRenderer") or {}
                return numero(texto(cab.get("countText")))   # el exacto; «commentsCount» viene redondeado
            except Exception:
                return -1
    return -1


def leer_extra(p, n):
    """Lo mismo que Metadatos.leerExtra del móvil: microformato (player) + ficha de la web (next)."""
    vd = p.get("videoDetails", {})
    mf = p.get("microformat", {}).get("playerMicroformatRenderer", {})
    ps = p.get("playabilityStatus", {})
    prim = buscar(n, "videoPrimaryInfoRenderer") or {}
    sec = buscar(n, "videoSecondaryInfoRenderer") or {}
    dueno = sec.get("owner", {}).get("videoOwnerRenderer", {})
    filas = []
    for f in sec.get("metadataRowContainer", {}).get("metadataRowContainerRenderer", {}).get("rows", []):
        f = f.get("metadataRowRenderer")
        if f:
            t = ", ".join(texto(c) for c in f.get("contents", []))
            if texto(f.get("title")) and t:
                filas.append((texto(f.get("title")), t))
    lic = next((t for k, t in filas if k == "Licencia"), "Licencia estándar de YouTube")
    vistas = int(vd.get("viewCount") or mf.get("viewCount") or -1) if (vd.get("viewCount") or mf.get("viewCount")) else \
        numero(texto((buscar(prim, "videoViewCountRenderer") or {}).get("viewCount")))
    me_gusta = int(mf["likeCount"]) if mf.get("likeCount") else next(
        (numero(t) for t in todos(prim.get("videoActions", {}), "accessibilityText") if "Me gusta" in str(t) and re.search(r"\d", str(t))), -1)
    lb = mf.get("liveBroadcastDetails")
    texto_fecha = texto(prim.get("dateText"))
    programado = bool(vd.get("isUpcoming"))
    emision = None
    if lb or programado or vd.get("isLive"):
        directo = bool(vd.get("isLiveContent")) and "estreno" not in texto_fecha.lower()
        inicio = fecha_iso((lb or {}).get("startTimestamp")) or int(buscar(ps, "scheduledStartTime") or 0) * 1000
        emision = {"tipo": "directo" if directo else "estreno", "ahora": bool((lb or {}).get("isLiveNow") or vd.get("isLive")),
                   "programado": programado, "inicio": inicio, "fin": fecha_iso((lb or {}).get("endTimestamp"))}
    insignias = [str(x) for x in todos(dueno.get("badges", []), "style")]
    verificado = ("canal oficial de artista" if "BADGE_STYLE_TYPE_VERIFIED_ARTIST" in insignias
                  else "verificado" if "BADGE_STYLE_TYPE_VERIFIED" in insignias else "")
    resultados = buscar(n, "twoColumnWatchNextResults") or {}
    comentarios = -1
    for s in resultados.get("results", {}).get("results", {}).get("contents", []):
        m = buscar(s.get("itemSectionRenderer"), "messageRenderer")
        if m and "comentarios están desactivados" in texto(m.get("text")):
            comentarios = -2
    sec_txt = json.dumps(sec, ensure_ascii=False)
    return {
        "vistas": vistas, "meGusta": me_gusta,
        "publicado": fecha_iso(mf.get("publishDate")) or fecha_iso(mf.get("uploadDate")), "textoFecha": texto_fecha,
        "categoria": categoria(mf.get("category")), "etiquetas": vd.get("keywords", []), "licencia": lic,
        "paraNinos": "creado para niños" in sec_txt or "made for kids" in sec_txt.lower(),
        "edad": mf.get("isFamilySafe") is False or "desktopLegacyAgeGateReason" in ps,
        "oculto": bool(mf.get("isUnlisted")), "privado": bool(vd.get("isPrivate")), "emision": emision,
        "filas": [f for f in filas if f[0] != "Licencia"], "comentarios": comentarios,
        "canal": texto(dueno.get("title")) or vd.get("author", ""),
        "canalId": buscar(dueno.get("navigationEndpoint", {}), "browseId") or vd.get("channelId", ""),
        "canalSuscriptores": texto(dueno.get("subscriberCountText")).replace(" ", " "), "canalVerificado": verificado,
        "duracion": int(vd["lengthSeconds"]) if vd.get("lengthSeconds") else -1, "esShort": False,
    }


def extra(url):
    """Ficha extra: player (microformato) + next (reutilizado si ya se pidió) + número exacto de comentarios."""
    vid = id_video(url)
    m = _leer("extra", vid)
    if m:
        return m["v"]
    with cf.ThreadPoolExecutor(2) as ex:
        fp = ex.submit(innertube, "player", {"videoId": vid})
        n = siguiente(vid)
        try:
            p = fp.result()
        except Exception:
            p = {}
    e = leer_extra(p, n)
    if e["comentarios"] == -1:
        e["comentarios"] = _comentarios(n)
    e["capitulos"] = capitulos(n)
    _apuntar("extra", vid, e)
    return e


def _xtags(x):
    """Las «xtags» de un formato (protobuf en base64): {'acont': 'dubbed', 'lang': 'ar'}."""
    try:
        b = base64.urlsafe_b64decode(x + "=" * (-len(x) % 4))
    except Exception:
        return {}

    def campos(buf):
        i, r = 0, []
        while i < len(buf):
            clave = buf[i]
            i += 1
            if clave & 7 != 2:
                return r
            n, s = 0, 0
            while True:
                c = buf[i]
                i += 1
                n |= (c & 0x7f) << s
                s += 7
                if not c & 0x80:
                    break
            r.append((clave >> 3, buf[i:i + n]))
            i += n
        return r
    d = {}
    try:
        for num, par in campos(b):
            kv = dict(campos(par))
            d[kv.get(1, b"").decode()] = kv.get(2, b"").decode()
    except Exception:
        pass
    return d


TIPOS_AUDIO = {"original": "original", "dubbed": "doblado", "dubbed-auto": "doblado automático", "descriptive": "audiodescripción",
               "secondary": "secundario"}


def formatos(url, duracion_s=-1):
    """Formatos, subtítulos y pistas de audio (clientes de móvil de YouTube; si uno no lo da, el otro)."""
    vid = id_video(url)
    m = _leer("formatos", vid)
    if m:
        return m["v"]
    p, motivo = {}, ""
    for cliente in ("IOS", "ANDROID_VR"):
        try:
            p = innertube("player", {"videoId": vid, "contentCheckOk": True, "racyCheckOk": True}, cliente)
        except Exception as e:
            motivo = str(e)
            continue
        if p.get("streamingData", {}).get("adaptiveFormats"):
            break
        motivo = p.get("playabilityStatus", {}).get("reason") or motivo
    sd = p.get("streamingData", {})
    dur = duracion_s if duracion_s and duracion_s > 0 else int(p.get("videoDetails", {}).get("lengthSeconds") or 0)
    lista = []
    for f in sd.get("formats", []) + sd.get("adaptiveFormats", []):
        mime = f.get("mimeType", "")
        tipo = mime.split(";")[0].strip()
        c = re.search(r'codecs="([^"]+)"', mime)
        cod = c.group(1) if c else ""
        clase = "audio" if tipo.startswith("audio") else ("vídeo y audio" if "," in cod else "vídeo")
        largo = int(f.get("contentLength") or -1)
        ms = int(f.get("approxDurationMs") or dur * 1000)
        bps = largo * 8000 // ms if largo > 0 and ms > 0 else int(f.get("bitrate") or 0)
        pista = ""
        if f.get("audioTrack"):
            a = f["audioTrack"]
            nombre = a.get("displayName", "")
            t = TIPOS_AUDIO.get(_xtags(f.get("xtags", "")).get("acont", ""), "")
            if nombre.endswith(" original"):
                nombre, t = nombre[:-9].strip(), t or "original"
            pista = f"{nombre} ({t})" if t and t not in nombre else nombre
        lista.append({
            "clase": clase, "calidad": re.sub(r"p\d+", "p", f.get("qualityLabel", "")).split(" ")[0] if clase != "audio" else "",
            "fps": int(f.get("fps") or -1) if clase != "audio" else -1, "codec": cod,
            "contenedor": {"video/mp4": "mp4", "audio/mp4": "m4a", "video/webm": "webm", "audio/webm": "webm"}.get(tipo, tipo.split("/")[-1]),
            "hdr": "HDR" in f.get("qualityLabel", "") or cod.startswith("vp09.02") or f.get("colorInfo", {}).get("transferCharacteristics") in (
                "COLOR_TRANSFER_CHARACTERISTICS_SMPTEST2084", "COLOR_TRANSFER_CHARACTERISTICS_ARIB_STD_B67"),
            "tasa": bps, "tamano": largo if largo > 0 else (bps * dur // 8 if bps > 0 and dur > 0 else -1), "estimado": largo <= 0,
            "muestreo": int(f.get("audioSampleRate") or -1), "canales": int(f.get("audioChannels") or -1), "pista": pista})
    vistos, unicos = set(), []
    for f in lista:
        k = (f["clase"], f["calidad"], f["codec"], f["tasa"], f["pista"])
        if k not in vistos:
            vistos.add(k)
            unicos.append(f)
    cap = p.get("captions", {}).get("playerCaptionsTracklistRenderer", {})
    subs, auto = [], []
    for c in cap.get("captionTracks", []):
        nombre = texto(c.get("name"))
        if c.get("kind") == "asr":
            auto.append(re.sub(r"\s*\(generados automáticamente\)", "", nombre))
        else:
            subs.append(nombre)
    pistas = list(dict.fromkeys(f["pista"] for f in unicos if f["clase"] == "audio" and f["pista"]))
    r = {"formatos": unicos, "subtitulos": list(dict.fromkeys(subs)), "subtitulosAuto": list(dict.fromkeys(auto)), "audios": pistas,
         "motivo": "" if unicos else (motivo or "YouTube no los da")}
    if unicos:
        _apuntar("formatos", vid, r)
    return r


def completo(url, duracion_s=-1):
    """Todo lo de la sección «Datos» a la vez (ficha extra, formatos y votos), cada parte por su lado: si una falla,
    las demás salen igual."""
    with cf.ThreadPoolExecutor(3) as ex:
        fe, ff, fv = ex.submit(extra, url), ex.submit(formatos, url, duracion_s), ex.submit(votos, url)

        def seguro(f, defecto):
            try:
                return f.result()
            except Exception:
                return defecto
        return {"extra": seguro(fe, None), "formatos": seguro(ff, {"formatos": [], "subtitulos": [], "subtitulosAuto": [], "audios": [],
                                                                    "motivo": "no se pudieron pedir"}), "votos": seguro(fv, None)}


# ---------------------------------------------------------------- resumen para las listas
_turno_resumen = threading.BoundedSemaphore(4)


def resumen_en_cache(url):
    m = _leer("resumen", id_video(url))
    return m["v"] if m else None


def resumen(url, avisar_bloqueo=False):
    """Duración, visualizaciones exactas y fecha de un vídeo con la ficha ligera de YouTube (unos 4 KB).
    avisar_bloqueo (la web, /api/completar): un 429 o un «not a bot»/LOGIN_REQUIRED se lanzan como excepción para cortar
    la tanda y poner la marca (regla 24); sin él, None como siempre (la Qt, fichas.Relleno)."""
    vid = id_video(url)
    if len(vid) != 11:
        return None
    r = resumen_en_cache(vid)
    if r:
        return r
    with _turno_resumen:
        r = resumen_en_cache(vid)
        if r:
            return r
        try:
            p = innertube("player", {"videoId": vid})
        except Exception as error:
            if avisar_bloqueo and getattr(error, "code", None) == 429:
                raise RuntimeError(f"HTTP Error 429: Too Many Requests ({vid})") from error
            return None
        vd = p.get("videoDetails")
        if not vd:
            if avisar_bloqueo:
                ps = p.get("playabilityStatus") or {}
                motivo = str(ps.get("reason") or "")
                edad = re.search(r"\bage\b|edad|inappropriate", motivo, re.I)
                if re.search(r"not a bot", motivo, re.I) or (ps.get("status") == "LOGIN_REQUIRED" and not edad):
                    raise RuntimeError(f"not a bot: LOGIN_REQUIRED ({motivo[:80]})")
            return None
        mf = p.get("microformat", {}).get("playerMicroformatRenderer", {})
        r = {"duracion": int(vd.get("lengthSeconds") or -1), "vistas": int(vd.get("viewCount") or -1),
             "publicado": fecha_iso(mf.get("publishDate")) or fecha_iso(mf.get("uploadDate"))}
    _apuntar("resumen", vid, r)
    return r


# ---------------------------------------------------------------- canal: «Acerca de», cabecera y vídeos
def _varint(n):
    out = bytearray()
    while True:
        b = n & 0x7f
        n >>= 7
        out.append(b | (0x80 if n else 0))
        if not n:
            return bytes(out)


def _campo(num, datos):
    return _varint(num << 3 | 2) + _varint(len(datos)) + datos


def _testigo_acerca(cid):
    """La continuación del panel «Acerca de» (la que pide la web al pulsar «más»), con un UUID nuevo."""
    interior = _campo(110, _campo(3, _campo(19, _campo(1, str(uuid.uuid4()).encode()))))
    params = urllib.parse.quote(base64.urlsafe_b64encode(interior).decode())
    return base64.urlsafe_b64encode(_campo(80226972, _campo(2, cid.encode()) + _campo(3, params.encode()))).decode()


def acerca_de(canal_url, cabecera=None):
    """Visualizaciones totales, fecha de alta, país, enlaces, handle y suscriptores tal como los da YouTube."""
    cid = id_canal(canal_url)
    if not cid:
        return None
    m = _leer("acerca", cid)
    if m:
        return m["v"]
    a = None
    try:
        a = buscar(innertube("browse", {"continuation": _testigo_acerca(cid)}), "aboutChannelViewModel")
    except Exception:
        pass
    if not a:   # si YouTube cambia el testigo: el de la cabecera del canal
        try:
            cab = cabecera or innertube("browse", {"browseId": cid, "params": "EgVhYm91dPIGBAoCEgA="}).get("header")
            tok = next((c.get("token") for c in todos(cab, "continuationCommand")), None)
            a = buscar(innertube("browse", {"continuation": tok}), "aboutChannelViewModel") if tok else None
        except Exception:
            a = None
    if not a:
        return None
    enlaces = []
    for l in todos(a.get("links", []), "channelExternalLinkViewModel"):
        bruto = buscar(l.get("link", {}), "url") or ""
        enlaces.append((texto(l.get("title")), enlace_real(bruto, texto(l.get("link")))))
    canon = a.get("canonicalChannelUrl", "")
    r = {"canalId": a.get("channelId") or cid, "descripcion": a.get("description", ""), "pais": a.get("country", ""),
         "suscriptores": texto(a.get("subscriberCountText")).replace(" ", " "), "visualizaciones": numero(texto(a.get("viewCountText"))),
         "videos": texto(a.get("videoCountText")), "alta": texto(a.get("joinedDateText")).removeprefix("Se unió el ").strip(),
         "handle": canon.rsplit("/", 1)[-1] if "/@" in canon else "", "enlaces": enlaces}
    _apuntar("acerca", cid, r)
    return r


_RELATIVO = re.compile(r"(\d+)\s*(segundos?|seg|minutos?|min|horas?|días?|dias?|semanas?|sem|meses|mes|años?|h|d|s|a|m)(?![\wñ])", re.I)


def fecha_relativa(t):
    """«hace 8 días», «Emitido hace 2 años» o «hace 16 a» → milisegundos aproximados (como hace NewPipe en el móvil)."""
    t = (t or "").replace("\u00a0", " ")
    m = _RELATIVO.search(t) if "hace" in t.lower() else None
    if not m:
        return 0
    u = m.group(2).lower()
    seg = (1 if u.startswith("seg") or u == "s" else 60 if u.startswith("min") else 3600 if u.startswith("h") else
           86400 if u.startswith("d") else 7 * 86400 if u.startswith("sem") else 30 * 86400 if u.startswith("mes") or u == "m" else 365 * 86400)
    return int((time.time() - int(m.group(1)) * seg) * 1000)


def es_vistas(t):
    """«395.768 visualizaciones», «207 M» (así vienen en los relacionados), «1903 usuarios viéndolo ahora»."""
    t = (t or "").replace("\u00a0", " ").strip()
    return ("visualizaci" in t or "viendo" in t or "viéndolo" in t or "usuarios" in t
            or bool(re.fullmatch(r"\d+(?:[.,]\d+)*\s*(?:K|M|mil M|mil millones|mil)?", t)))


def texto_vistas(t):
    """Siempre con la palabra: «207 M» → «207 M visualizaciones»."""
    t = (t or "").replace("\u00a0", " ").strip()
    return t if not t or "visualizaci" in t or "viendo" in t or "viéndolo" in t or "usuarios" in t else t + " visualizaciones"


def resolver_canal(url):
    """El id del canal (UC…) de cualquier enlace de canal, también de los «@nombre»."""
    cid = id_canal(url)
    if cid:
        return cid
    try:
        r = innertube("navigation/resolve_url", {"url": url})
        return buscar(r, "browseId") or ""
    except Exception:
        return ""
