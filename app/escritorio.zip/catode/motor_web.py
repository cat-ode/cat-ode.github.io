"""Cat-ode en Windows · el vídeo con el motor de Edge (WebView2), el mismo que YouTube en Windows (04/10/2026).

Medido en el mini PC (N100) con un vídeo de Flavour Trip 1080p a pantalla completa: mpv perdía 250-700 fotogramas de 750
en 25 s y gastaba el 40-80 % del 3D de la gráfica; WebView2, 0 perdidos, con el 6 % del descodificador y 0 % de 3D (el
motor de Edge presenta el vídeo por la capa de vídeo de la pantalla, sin pintarlo).

MpvWeb habla como python-mpv (las órdenes, propiedades y avisos que usa Reproductor), así que todo lo demás de Cat-ode
(cola, recargas, subtítulos, mandos, pestañas, vigilantes) sigue igual. Lo que llega de otros hilos se pasa al hilo de la
ventana (WebView2 solo se deja tocar desde ahí)."""
import json
import os
import threading
import time
from pathlib import Path
from types import SimpleNamespace

from PySide6.QtCore import QAbstractNativeEventFilter, QEvent, QObject, QPoint, QPointF, QTimer, Signal, Qt
from PySide6.QtGui import QCursor, QWheelEvent
from PySide6.QtWidgets import QApplication

AQUI = Path(__file__).resolve().parent
_ENTORNO = {"env": None, "tarea": None}


def disponible():
    """¿Se puede usar WebView2 en este equipo? (pywebview trae pythonnet y las librerías de WebView2)."""
    if os.name != "nt" or os.environ.get("CATODE_MOTOR") == "mpv":
        return False
    try:
        _lib_webview()
        import clr  # noqa: F401
        return True
    except Exception:   # noqa: BLE001
        return False


def _lib_webview():
    """La carpeta lib de pywebview (DLL de WebView2) SIN importar pywebview: importarlo costaba ~130 ms en el N100 y solo
    hacía falta su ruta (06/10/2026, perfil del arranque)."""
    import importlib.util
    spec = importlib.util.find_spec("webview")
    if spec is None or not spec.submodule_search_locations:
        raise ImportError("sin pywebview")
    return Path(list(spec.submodule_search_locations)[0]) / "lib"


def _net():
    lib = _lib_webview()
    import clr
    clr.AddReference(str(lib / "Microsoft.Web.WebView2.Core.dll"))
    clr.AddReference("System.Drawing")
    from Microsoft.Web.WebView2.Core import CoreWebView2Environment
    cargador = next((p for p in lib.rglob("WebView2Loader.dll") if "x64" in str(p).lower()), None)
    if cargador is not None:
        try:
            CoreWebView2Environment.SetLoaderDllFolderPath(str(cargador.parent))
        except Exception:   # noqa: BLE001 (ya puesto)
            pass
    return CoreWebView2Environment


class _AlHilo(QObject):
    """Lleva una función al hilo de la ventana."""
    llega = Signal(object)

    def __init__(self):
        super().__init__()
        self.llega.connect(lambda f: f(), Qt.QueuedConnection)


class _ServidorLocal:
    """Sirve archivos locales (descargas) al motor de Edge por http://127.0.0.1:<puerto>/<id>, con saltos (Range)."""
    _unico = None

    @classmethod
    def instancia(cls):
        if cls._unico is None:
            cls._unico = cls()
        return cls._unico

    def __init__(self):
        import http.server, socketserver
        servidor = self

        class Peticion(http.server.BaseHTTPRequestHandler):
            disable_nagle_algorithm = True   # 06/10/2026: sin esperar al ACK retardado del cliente (ver servidor_web.py)

            def log_message(self, *_a):
                pass

            def _ruta(self):
                return servidor.rutas.get(self.path.lstrip("/").split("?")[0])

            def do_HEAD(self):
                self._servir(False)

            def do_GET(self):
                self._servir(True)

            def _servir(self, cuerpo):
                ruta = self._ruta()
                if not ruta or not os.path.exists(ruta):
                    self.send_response(404); self.end_headers(); return
                total = os.path.getsize(ruta); ini, fin = 0, total - 1
                rango = self.headers.get("Range")
                if rango and rango.startswith("bytes="):
                    a, _, b = rango[6:].partition("-")
                    ini = int(a) if a else max(0, total - int(b or 0)); fin = int(b) if (a and b) else total - 1
                    fin = min(fin, total - 1)
                    self.send_response(206); self.send_header("Content-Range", f"bytes {ini}-{fin}/{total}")
                else:
                    self.send_response(200)
                r = ruta.lower()
                tipo = ("video/webm" if r.endswith(".webm") else "audio/mp4" if r.endswith(".m4a") else "application/javascript" if r.endswith(".js")
                        else "video/mp4")
                self.send_header("Content-Type", tipo); self.send_header("Accept-Ranges", "bytes")
                if r.endswith(".js"):
                    self.send_header("Cache-Control", "max-age=86400")
                self.send_header("Content-Length", str(fin - ini + 1)); self.send_header("Access-Control-Allow-Origin", "*")
                self.end_headers()
                if not cuerpo:
                    return
                try:
                    with open(ruta, "rb") as f:
                        f.seek(ini); falta = fin - ini + 1
                        while falta > 0:
                            trozo = f.read(min(1 << 16, falta))
                            if not trozo:
                                break
                            self.wfile.write(trozo); falta -= len(trozo)
                except (BrokenPipeError, ConnectionResetError, OSError):
                    pass

        class Servidor(socketserver.ThreadingMixIn, http.server.HTTPServer):
            daemon_threads = True
            allow_reuse_address = True

        self.rutas = {}
        self._srv = Servidor(("127.0.0.1", 0), Peticion)
        self.puerto = self._srv.server_address[1]
        threading.Thread(target=self._srv.serve_forever, daemon=True, name="archivos-edge").start()

    def url(self, ruta):
        import hashlib
        clave = hashlib.sha1(ruta.encode("utf-8", "replace")).hexdigest()[:16] + os.path.splitext(ruta)[1].lower()
        self.rutas[clave] = ruta
        return f"http://127.0.0.1:{self.puerto}/{clave}"


class _FiltroRueda(QAbstractNativeEventFilter):
    """05/10/2026 · la rueda del ratón sobre el vídeo no bajaba el volumen con el motor de Edge: Windows manda
    WM_MOUSEWHEEL a la ventana con el foco y Qt lo reparte al widget bajo el cursor, pero ahí está la ventana nativa de
    Edge (hija de la zona) y Qt lo tira; cuando el foco lo tiene Edge, la página sí lo recibía y avisaba. Aquí se coge
    el mensaje antes que nadie y, si el cursor está sobre la zona del vídeo, se convierte en el QWheelEvent de siempre
    (ZonaVideo.wheelEvent: ±5 de volumen) y se consume, para que no llegue dos veces."""
    WM_MOUSEWHEEL = 0x020A

    def __init__(self, zona):
        super().__init__()
        self.zona = zona

    def nativeEventFilter(self, tipo, mensaje):
        try:
            if bytes(tipo) != b"windows_generic_MSG":
                return False, 0
            import ctypes.wintypes
            msg = ctypes.wintypes.MSG.from_address(int(mensaje))
            if msg.message != self.WM_MOUSEWHEEL:
                return False, 0
            z = self.zona
            if not z.isVisible():
                return False, 0
            glob = QCursor.pos()
            local = z.mapFromGlobal(glob)
            dentro = z.rect().contains(local)
            if not dentro:
                return False, 0
            delta = ctypes.c_short((msg.wParam >> 16) & 0xFFFF).value
            QApplication.sendEvent(z, QWheelEvent(QPointF(local), QPointF(glob), QPoint(), QPoint(0, delta), Qt.NoButton,
                                                      Qt.NoModifier, Qt.NoScrollPhase, False))
            return True, 0
        except Exception:   # noqa: BLE001
            return False, 0


ARGUMENTOS = "--disable-web-security --autoplay-policy=no-user-gesture-required"


def carpeta_app():
    """La carpeta de Cat-ode en Windows: %LOCALAPPDATA%\\Cat-ode, o CATODE_CARPETA (18/10/2026: pruebas aisladas del
    instalador nuevo; la misma que datos.carpeta_config). Dentro, «edge» (la página) y «cuenta» (la ventana de Google)."""
    propia = os.environ.get("CATODE_CARPETA", "").strip()
    if propia:
        return os.path.abspath(os.path.expanduser(propia))
    return os.path.join(os.environ.get("LOCALAPPDATA", str(Path.home())), "Cat-ode")


def vaciar_argumentos():
    """18/10/2026 · quita WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS del proceso (Python y Windows) antes de crear el entorno de
    la ventana de Google: esa variable manda sobre las opciones y le pondría --disable-web-security. Devuelve el valor que
    tenía (para devolverlo luego con poner_argumentos)."""
    viejo = os.environ.pop("WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS", None)
    if os.name == "nt":
        try:
            import ctypes
            ctypes.windll.kernel32.SetEnvironmentVariableW("WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS", None)
        except Exception:   # noqa: BLE001
            pass
    return viejo


def poner_argumentos(valor):
    if valor:
        os.environ["WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS"] = valor


def esperar(tarea, seguir, registro=print, tope=30.0):
    """Espera una tarea de .NET sin bloquear la ventana (mirando cada 20 ms con QTimer) y sigue con su resultado."""
    t0 = time.time()

    def mirar():
        if tarea.IsCompleted:
            try:
                seguir(tarea.Result)
            except Exception as error:   # noqa: BLE001
                registro(f"WebView2: {error!r}"[:200])
        elif time.time() - t0 < tope:
            QTimer.singleShot(20, mirar)
        else:
            registro("Edge: no responde (tiempo agotado al arrancar)")
    mirar()


def _argumentos():
    argumentos = ARGUMENTOS
    if os.environ.get("CATODE_PRUEBA_INTERFAZ"):   # 06/10/2026: en la prueba, Edge tampoco sale a la red (solo 127.0.0.1)
        argumentos += " --proxy-server=http://127.0.0.1:9"
    return argumentos


def precalentar(registro=print):
    """06/10/2026 (perfil en el mini PC: ventana → entorno 350 ms y entorno → controlador 550 ms en frío): pide el entorno
    de WebView2 (lanza msedgewebview2 y su proceso de la gráfica) lo antes posible, en el hilo de la ventana, para que
    arranque a la vez que el servicio, el servidor y la ventana Qt. crear_webview reutiliza la misma tarea. Nunca lanza."""
    try:
        if _ENTORNO["tarea"] is not None:
            return True
        Env = _net()
        argumentos = _argumentos()
        os.environ["WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS"] = argumentos
        datos = os.path.join(carpeta_app(), "edge")
        opciones = None
        try:
            from Microsoft.Web.WebView2.Core import CoreWebView2EnvironmentOptions
            opciones = CoreWebView2EnvironmentOptions()
            opciones.AdditionalBrowserArguments = argumentos
        except Exception as error:   # noqa: BLE001
            registro(f"Edge: opciones por variable de entorno ({error!r})"[:200])
            opciones = None
        _ENTORNO["tarea"] = Env.CreateAsync(None, datos, opciones)
        return True
    except Exception as error:   # noqa: BLE001
        registro(f"Edge: sin precalentar ({error!r})"[:200])
        return False


def crear_webview(hwnd, al_listo, registro=print, al_entorno=None):
    """06/10/2026 · extraído de MpvWeb._crear/_esperar/_con_entorno sin cambiar nada: crea (una vez por proceso) el entorno
    de WebView2 con los argumentos de siempre y un CoreWebView2Controller dentro de la ventana nativa «hwnd» (un entero o
    una función que lo da cuando el entorno está listo). al_entorno(env) se llama antes de crear el controlador;
    al_listo(controlador) al final. Todo asíncrono, en el hilo de la ventana. Si falla al empezar, lo dice por registro
    (como siempre) y lanza RuntimeError (la interfaz web vuelve entonces a la Qt; MpvWeb lo calla, como antes)."""
    try:
        Env = _net()
        from System import IntPtr
        argumentos = _argumentos()
        os.environ["WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS"] = argumentos
        if _ENTORNO["tarea"] is None:
            datos = os.path.join(carpeta_app(), "edge")
            opciones = None
            try:
                from Microsoft.Web.WebView2.Core import CoreWebView2EnvironmentOptions
                opciones = CoreWebView2EnvironmentOptions()
                opciones.AdditionalBrowserArguments = argumentos
            except Exception as error:   # noqa: BLE001
                registro(f"Edge: opciones por variable de entorno ({error!r})"[:200])
                opciones = None
            _ENTORNO["tarea"] = Env.CreateAsync(None, datos, opciones)

        def con_entorno(env):
            try:
                registro(f"Edge: entorno listo ({env.BrowserVersionString}, args={os.environ.get('WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS')})")
            except Exception:   # noqa: BLE001
                registro("Edge: entorno listo")
            _ENTORNO["env"] = env
            if al_entorno is not None:
                al_entorno(env)
            ventana = hwnd() if callable(hwnd) else hwnd
            esperar(env.CreateCoreWebView2ControllerAsync(IntPtr(int(ventana))), al_listo, registro)
        esperar(_ENTORNO["tarea"], con_entorno, registro)
    except Exception as error:   # noqa: BLE001
        registro(f"WebView2 no arranca: {error!r}"[:200])
        raise RuntimeError(f"WebView2 no arranca: {error!r}") from error


class MpvWeb(QObject):
    def __init__(self, zona, ajustes=None, registro=print):
        super().__init__(zona)
        self.zona = zona
        self._registro = registro
        self._hilo = _AlHilo()
        self._pendiente = []          # lo pedido antes de que WebView2 esté listo
        self._ctl = self._wv = None
        self._obs, self._ev, self._msg = {}, {}, {}
        self.s = {"vid": "auto", "time-pos": None, "duration": None, "pause": False, "volume": float((ajustes or {}).get("volumen", 80)),
                  "mute": False, "speed": 1.0, "idle-active": True, "sid": "no", "fullscreen": False, "width": 0, "height": 0,
                  "dropped": 0, "total": 0, "loop": False, "pistas": []}
        self._cargado = False
        self._inicio = 0.0
        self.fuente_web = None        # el manifiesto HLS de YouTube (lo pone Reproductor antes de loadfile)
        self.al_clic = self.al_doble = self.al_menu = self.al_tecla = self.al_rueda = None
        self._reloj = QTimer(self, interval=250)
        self._reloj.timeout.connect(self._preguntar)
        self._consulta = None
        zona.installEventFilter(self)
        self._t0 = time.time(); self._hitos = {}   # 06/10/2026: tiempos del arranque (ver «Edge: tiempos»)
        self._crear()

    # ---- arranque de WebView2 (asíncrono, sin bloquear la ventana): crear_webview, compartido con la interfaz web ----
    def _crear(self):
        try:
            crear_webview(lambda: int(self.zona.winId()), self._con_controlador, self._registro, al_entorno=self._con_entorno)
        except RuntimeError:   # ya registrado («WebView2 no arranca: …»), como antes
            pass

    def _esperar(self, tarea, seguir, tope=30.0):
        esperar(tarea, seguir, self._registro, tope)

    def _con_entorno(self, env):
        self._hitos['entorno'] = time.time() - self._t0
        self._filtro_rueda = _FiltroRueda(self.zona)   # ver la clase: la rueda sobre la ventana de Edge no llegaba a Qt
        QApplication.instance().installNativeEventFilter(self._filtro_rueda)
        self._registro("Edge: filtro de la rueda instalado")

    def _con_controlador(self, ctl):
        self._hitos["ventana"] = time.time() - self._t0
        self._registro("Edge: ventana lista")
        self._ctl, self._wv = ctl, ctl.CoreWebView2
        from Microsoft.Web.WebView2.Core import CoreWebView2HostResourceAccessKind
        self._acceso = CoreWebView2HostResourceAccessKind.Allow
        self._wv.SetVirtualHostNameToFolderMapping("catode.local", str(AQUI / "web"), self._acceso)
        self._wv.Settings.AreDefaultContextMenusEnabled = False
        self._wv.Settings.AreDevToolsEnabled = False
        self._wv.WebMessageReceived += self._mensaje
        self._wv.NavigationCompleted += self._navegada
        self._colocar()
        # la página se carga tal cual (sin dirección propia): desde https://catode.local, los servidores de YouTube rechazaban
        # el manifiesto por la política de orígenes del navegador (en el prototipo, cargada así, iba bien). hls.js va dentro.
        html = (AQUI / "web" / "reproductor.html").read_text(encoding="utf-8")
        hls = AQUI / "web" / "hls.min.js"
        if hls.exists():
            # 06/10/2026: hls.js (~1 MB) ya no va incrustado en la página (cada motor tardaba ~1,3 s en tragársela por
            # NavigateToString): se sirve desde el servidor interno y Edge lo guarda en su caché
            html = html.replace('<script src="hls.min.js"></script>', f'<script src="{_ServidorLocal.instancia().url(str(hls))}"></script>', 1)
        self._wv.NavigateToString(html)

    def _navegada(self, _remitente, args):
        self._hitos["pagina"] = time.time() - self._t0
        try:
            self._registro(f"Edge: página cargada (bien={args.IsSuccess}, estado={args.WebErrorStatus})")
        except Exception:   # noqa: BLE001
            pass
        self._lista()

    def _lista(self):
        self._listo = True
        self._js(f"cat.volumen({self.s['volume']}); cat.silencio({str(self.s['mute']).lower()})")
        for f in self._pendiente:
            f()
        self._pendiente = []
        self._reloj.start()

    # ---- de cualquier hilo al de la ventana ----
    def _ui(self, f):
        if threading.current_thread() is threading.main_thread():
            f()
        else:
            self._hilo.llega.emit(f)

    def _js(self, codigo):
        def hacer():
            if self._wv is None or not getattr(self, "_listo", False):
                self._pendiente.append(lambda: self._wv.ExecuteScriptAsync(codigo))
            else:
                self._wv.ExecuteScriptAsync(codigo)
        self._ui(hacer)

    # ---- tamaño y visibilidad: los de la zona de Cat-ode ----
    def eventFilter(self, obj, ev):
        if obj is self.zona and ev.type() in (QEvent.Resize, QEvent.Show, QEvent.Hide, QEvent.Move):
            self._colocar()
        elif obj is self.zona and ev.type() in (QEvent.ParentChange, QEvent.WinIdChange):
            # 06/10/2026: la zona cambia de padre (minirreproductor, imagen en imagen, vuelta a su sitio) y Qt le da otra
            # ventana nativa: la de Edge se quedaba huérfana (se oía, no se veía, y tapaba los mandos). Se reengancha.
            QTimer.singleShot(0, self._reparentar)
        return False

    def _reparentar(self):
        if self._ctl is None:
            return
        try:
            from System import IntPtr
            self._ctl.ParentWindow = IntPtr(int(self.zona.winId()))
            self._colocar()
            self._registro("Edge: ventana reenganchada a la zona")
        except Exception as error:   # noqa: BLE001
            self._registro(f"Edge: no se pudo reenganchar ({error!r})"[:160])

    def _colocar(self):
        if self._ctl is None:
            return
        from System.Drawing import Rectangle
        r = self.zona.devicePixelRatioF()
        self._ctl.Bounds = Rectangle(0, 0, int(self.zona.width() * r), int(self.zona.height() * r))
        # una pestaña nueva que se tapa enseguida: Edge no carga el vídeo de una página oculta; se deja «visible» hasta que arranca
        self._ctl.IsVisible = self.zona.isVisible() or not (self.s.get("time-pos") or 0) > 0

    # ---- avisos de la página (cada 250 ms el estado; y clics, teclas, rueda) ----
    def _preguntar(self):
        if self._wv is None or self._consulta is not None:
            return
        self._consulta = self._wv.ExecuteScriptAsync("cat.estado()")
        t = self._consulta

        def mirar():
            if not t.IsCompleted:
                return QTimer.singleShot(15, mirar)
            self._consulta = None
            try:
                r = json.loads(t.Result)
                self._estado(json.loads(r) if isinstance(r, str) else r)
            except Exception:   # noqa: BLE001
                pass
        mirar()

    def _estado(self, e):
        if not e:
            return
        if not getattr(self, "_visto", False):
            self._visto = True
            self._hitos["estado"] = time.time() - self._t0
            self._registro("Edge: tiempos " + " · ".join(f"{k} {v:.1f} s" for k, v in self._hitos.items()))
            self._registro(f"Edge: primer estado {json.dumps(e)[:160]}")
        for n in e.get("notas") or []:
            self._registro(f"Edge (página): {n}")
        cambios = {"time-pos": e.get("t"), "duration": e.get("d") or None, "pause": bool(e.get("p")),
                   "idle-active": bool(e.get("idle")), "width": e.get("w") or 0, "height": e.get("h") or 0,
                   "dropped": e.get("drop") or 0, "total": e.get("tot") or 0,
                   # 22/10/2026 (3.6): lo que se ve, como el «video-params» de mpv (para el selector de calidad)
                   "video-params": {"w": e.get("w") or 0, "h": e.get("h") or 0} if e.get("w") and e.get("h") else None}
        if e.get("listo") and not self._cargado and not e.get("idle"):
            self._cargado = True
            self._evento("file-loaded", None)
        if not (self.s.get("time-pos") or 0) > 0 and (e.get("t") or 0) > 0:
            QTimer.singleShot(0, self._colocar)
        if time.time() - self.__dict__.get("_t_pausa", 0) < 0.6:
            cambios.pop("pause")
        for k, v in cambios.items():
            if self.s.get(k) != v:
                self.s[k] = v
                for cb in self._obs.get(k, []):
                    try:
                        cb(k, v)
                    except Exception:   # noqa: BLE001
                        pass
        if e.get("fin"):
            import mpv
            self._evento("end-file", SimpleNamespace(reason=mpv.MpvEventEndFile.EOF, error=0))
        if e.get("error"):
            import mpv
            self._registro(f"vídeo (Edge): {e['error']}"[:200])
            self._evento("end-file", SimpleNamespace(reason=mpv.MpvEventEndFile.ERROR, error=e["error"]))

    def _evento(self, nombre, datos):
        for cb in self._ev.get(nombre, []):
            try:
                cb(SimpleNamespace(data=datos))
            except Exception:   # noqa: BLE001
                pass

    def _mensaje(self, _remitente, args):
        try:
            m = json.loads(args.TryGetWebMessageAsString())
        except Exception:   # noqa: BLE001
            return
        try:
            self._raton_teclado(m)
        except Exception as error:   # noqa: BLE001
            self._registro(f"Edge, ratón/teclado: {error!r}"[:160])

    _TECLAS = {" ": Qt.Key_Space, "ArrowLeft": Qt.Key_Left, "ArrowRight": Qt.Key_Right, "ArrowUp": Qt.Key_Up,
               "ArrowDown": Qt.Key_Down, "Escape": Qt.Key_Escape, "Enter": Qt.Key_Return, "Home": Qt.Key_Home,
               "End": Qt.Key_End, "PageUp": Qt.Key_PageUp, "PageDown": Qt.Key_PageDown, "Tab": Qt.Key_Tab,
               "F11": Qt.Key_F11, "Backspace": Qt.Key_Backspace, "Delete": Qt.Key_Delete}

    def _raton_teclado(self, m):
        """Lo que se hace sobre el vídeo de Edge, como si se hiciera sobre la zona de Cat-ode (ZonaVideo)."""
        from PySide6.QtCore import QPoint, QPointF
        from PySide6.QtGui import QCursor, QKeyEvent, QMouseEvent, QWheelEvent
        from PySide6.QtWidgets import QApplication
        z, ven = self.zona, getattr(self.zona, "ventana", None)
        t = m.get("tipo")
        local = QPointF(z.mapFromGlobal(QCursor.pos())); glob = QPointF(QCursor.pos())
        if t == "clic":
            QApplication.sendEvent(z, QMouseEvent(QEvent.MouseButtonPress, local, glob, Qt.LeftButton, Qt.LeftButton, Qt.NoModifier))
        elif t == "menu":
            QApplication.sendEvent(z, QMouseEvent(QEvent.MouseButtonPress, local, glob, Qt.RightButton, Qt.RightButton, Qt.NoModifier))
        elif t == "doble" and ven is not None:
            f = getattr(ven, "flotante", None)
            if f is not None and f.zona is z:
                ven.volver_de_flotante()
            else:
                ven.pantalla_completa()
        elif t == "rueda":
            d = -int(m.get("dy") or 0)
            QApplication.sendEvent(z, QWheelEvent(local, glob, QPoint(), QPoint(0, 120 if d > 0 else -120), Qt.NoButton,
                                                  Qt.NoModifier, Qt.NoScrollPhase, False))
        elif t == "tecla":
            k = m.get("key") or ""
            tecla = MpvWeb._TECLAS.get(k) or (ord(k.upper()) if len(k) == 1 else None)
            if tecla is None:
                return
            mods = Qt.NoModifier
            if m.get("ctrl"):
                mods |= Qt.ControlModifier
            if m.get("shift"):
                mods |= Qt.ShiftModifier
            if m.get("alt"):
                mods |= Qt.AltModifier
            destino = (ven.focusWidget() if ven is not None else None) or z
            QApplication.sendEvent(destino, QKeyEvent(QEvent.KeyPress, tecla, mods, k if len(k) == 1 else ""))
        if ven is not None and t in ("clic", "doble", "menu"):   # el teclado vuelve a Cat-ode (sus atajos)
            ven.activateWindow(); z.setFocus()

    # ---- lo que usa Reproductor, como python-mpv ----
    def observe_property(self, nombre, cb):
        self._obs.setdefault(nombre, []).append(cb)
        # 06/10/2026: como mpv, el valor actual se avisa en cuanto se observa. Sin esto, Reproductor nacía con pausa=True y
        # «pause» de aquí era False: si la página no mandaba nunca un estado en pausa antes de sonar, no había «cambio» y
        # Reproductor se quedaba en pausa con el vídeo sonando (fallo «pos 18.1 pausa True» de la prueba Qt en Windows)
        def avisar():
            try:
                cb(nombre, self.s.get(nombre))
            except Exception:   # noqa: BLE001
                pass
        QTimer.singleShot(0, avisar)

    def event_callback(self, nombre):
        def poner(cb):
            self._ev.setdefault(nombre, []).append(cb)
            return cb
        return poner

    def register_message_handler(self, *_a):
        pass

    def loadfile(self, ruta, modo="replace", **op):
        inicio = float(str(op.get("start", 0)).lstrip("+") or 0)
        fuente = self.fuente_web
        if ruta and os.path.exists(str(ruta)):   # descargado (o un archivo local): se sirve desde el servidor interno
            # 05/10/2026: el host virtual «archivos.catode» no servía: la página va sin origen propio (NavigateToString, para que
            # YouTube no la rechace) y desde ahí Edge no deja leer un host virtual («Failed to fetch»). Un servidor HTTP en
            # 127.0.0.1 con saltos (Range) sí vale desde cualquier origen. Antes, las descargas no se reproducían en Windows.
            fuente, tipo = _ServidorLocal.instancia().url(os.path.abspath(ruta)), "archivo"
        elif fuente:
            tipo = "hls"
        else:
            fuente, tipo = (ruta if str(ruta).startswith("http") else None), "archivo"
        self._cargado = False
        self.s["idle-active"] = not fuente
        if not fuente:
            self._registro(f"Edge: sin dirección que reproducir ({str(ruta)[:80]})")
            import mpv
            return self._evento("end-file", SimpleNamespace(reason=mpv.MpvEventEndFile.ERROR, error="sin dirección"))
        self.s["pistas"] = []
        self._registro(f"Edge: cargar {tipo} {str(fuente)[:60]} desde {inicio:.0f} s")
        self._js(f"cat.cargar({json.dumps(fuente)}, {json.dumps(tipo)}, {inicio})")

    def command(self, nombre, *args):
        a = [str(x) for x in args]
        if nombre == "stop":
            self.s["idle-active"] = True
            self._js("cat.parar()")
        elif nombre == "seek":
            self._js(f"cat.saltar({float(a[0])}, {json.dumps(a[1] if len(a) > 1 else 'relative')})")
        elif nombre == "cycle" and a and a[0] == "pause":
            self._js("cat.alternar()")
        elif nombre == "cycle" and a and a[0] == "fullscreen":   # el botón de pantalla completa: lo hace la ventana
            ven = getattr(self.zona, "ventana", None)
            if ven is not None:
                self._ui(ven.pantalla_completa)
        elif nombre == "set" and len(a) >= 2:
            setattr(self, a[0].replace("-", "_"), a[1])
        elif nombre == "sub-add" and a:
            self.s["pistas"].append({"id": len(self.s["pistas"]) + 1, "type": "sub", "title": a[2] if len(a) > 2 else "",
                                     "lang": a[3] if len(a) > 3 else ""})
            self._js(f"cat.subtitulo({json.dumps(a[0])}, {json.dumps(a[2] if len(a) > 2 else '')}, {json.dumps(a[3] if len(a) > 3 else '')})")
        elif nombre == "loadfile" and a:
            self.loadfile(a[0], a[1] if len(a) > 1 else "replace")
        # keybind, frame-step, screenshot…: no hacen falta con Edge

    def command_async(self, nombre, *args, **_k):
        self.command(nombre, *args)

    def terminate(self):
        def cerrar():
            self._reloj.stop()
            try:
                if self._ctl is not None:
                    self._ctl.Close()
            except Exception:   # noqa: BLE001
                pass
            self._ctl = self._wv = None
        self.s["idle-active"] = True
        self._ui(cerrar)

    def _poner(self, k, v):
        """Como en mpv: lo que se cambia se avisa a quien lo observa (si no, Reproductor se quedaba con la pausa vieja)."""
        if self.s.get(k) == v:
            return
        self.s[k] = v
        for cb in self._obs.get(k, []):
            try:
                cb(k, v)
            except Exception:   # noqa: BLE001
                pass

    # ---- propiedades (las que se leen y escriben como en python-mpv) ----
    _LEER = {"time_pos": "time-pos", "duration": "duration", "pause": "pause", "volume": "volume", "mute": "mute",
             "speed": "speed", "idle_active": "idle-active", "sid": "sid", "fullscreen": "fullscreen", "width": "width",
             "height": "height", "frame_drop_count": "dropped", "vid": "vid"}

    def __getattr__(self, nombre):
        if nombre.startswith("_") or nombre in ("s", "zona"):
            raise AttributeError(nombre)
        s = self.__dict__.get("s", {})
        if nombre in MpvWeb._LEER:
            return s.get(MpvWeb._LEER[nombre])
        if nombre == "track_list":
            return list(s.get("pistas", []))
        if nombre in ("decoder_frame_drop_count", "vo_delayed_frame_count"):
            return 0
        if nombre == "avsync":
            return 0.0
        if nombre == "hwdec_current":
            return "edge"
        if nombre in ("container_fps", "estimated_vf_fps", "display_fps", "demuxer_cache_duration"):
            return 0.0
        return None

    def __setattr__(self, nombre, valor):
        if nombre in ("pause", "volume", "mute", "speed", "sid", "loop_file", "vid", "force_media_title", "ytdl_format",
                      "fullscreen") and "s" in self.__dict__:
            v = str(valor).lower()
            if nombre == "pause":
                p = v in ("true", "yes", "1")
                self._poner("pause", p)
                self._t_pausa = time.time()   # el estado que llegue de la página en 0,6 s aún es el de antes
                self._js(f"cat.pausa({str(p).lower()})")
            elif nombre == "volume":
                self._poner("volume", float(valor))
                self._js(f"cat.volumen({float(valor)})")
            elif nombre == "mute":
                m = v in ("true", "yes", "1")
                self._poner("mute", m)
                self._js(f"cat.silencio({str(m).lower()})")
            elif nombre == "speed":
                self._poner("speed", float(valor))
                self._js(f"cat.velocidad({float(valor)})")
            elif nombre == "sid":
                self._poner("sid", valor)
                self._js(f"cat.verSubtitulo({json.dumps(str(valor))})")
            elif nombre == "loop_file":
                self._js(f"cat.bucle({str(v == 'inf').lower()})")
            elif nombre == "vid":
                self._poner("vid", False if v in ("no", "false") else "auto")
                self._js(f"cat.soloSonido({str(v == 'no').lower()})")
            return
        object.__setattr__(self, nombre, valor)
