"""Cat-ode · anfitrión de la extensión «Cat-ode enlaces» (19/10/2026; ~/Cat-ode/navegador). Dos maneras de hablar con ella:
  · nativa (Chrome): Chrome lo arranca, le pasa un mensaje y lo cierra: {ping} → {ok, version}; {url} → abre el enlace en
    Cat-ode (enlace.a_catode).
  · «servir» (31/10/2026, el autor: «desde whatsapp me lo ha abierto en chromium … quiero todos los enlaces de youtube
    abriéndose en cat-ode»): WhatsApp Web vive en el Chromium del snap, y la caja del snap no deja arrancar anfitriones
    nativos de fuera (no ve ~/.local ni el Python de Cat-ode). Así que este mismo archivo sirve en http://127.0.0.1:8829
    (catode-enlaces-navegador.service) GET /ping y GET /abrir?url=…, como «Códigos» en el 8823: solo con el Host exacto (contra
    el «DNS rebinding»), la cabecera X-Catode con el id de la extensión (una web no puede ponerla sin un permiso CORS que aquí
    nunca se da) y ningún Origin de web. Cat-ode se arranca en su propio scope (app-gnome-es.catode.app-…, en app.slice, como
    lo que el autor abre desde el escritorio): dentro del servicio heredaría sus hilos 2,3,6,7.
  · «comprobar» (para el vigía, ~/.config/vigia/comprobaciones): un problema por línea («clave<TAB>texto»), nada si va bien.
Solo acepta enlaces de YouTube (lo demás se rechaza: nada de abrir lo que mande una página). Va con el Python de Cat-ode
(el que tiene PySide6), que es también el que arranca la app si estaba cerrada."""
import json
import os
import shutil
import struct
import subprocess
import sys
import threading
import time
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from catode import VERSION, enlace  # noqa: E402

PUERTO = 8829
ID_TXT = os.path.expanduser("~/Cat-ode/navegador/id.txt")
POLITICAS = {"Chrome": "/etc/opt/chrome/policies/managed/llamar_a36.json",
             "Chromium": "/etc/chromium-browser/policies/managed/sin_anuncios.json"}
PERFILES = {"Chrome": "~/.config/google-chrome/Default", "Chromium": "~/snap/chromium/common/chromium/Default"}


def leer():
    n = sys.stdin.buffer.read(4)
    if len(n) < 4:
        return None
    return json.loads(sys.stdin.buffer.read(struct.unpack("<I", n)[0]).decode("utf-8"))


def escribir(o):
    b = json.dumps(o).encode("utf-8")
    sys.stdout.buffer.write(struct.pack("<I", len(b)) + b)
    sys.stdout.buffer.flush()


def main():
    m = leer() or {}
    if m.get("ping"):
        return escribir({"ok": True, "version": VERSION})
    url = str(m.get("url", ""))
    if not enlace.YT.match(url) or "catode=navegador" in url:
        return escribir({"ok": False, "error": "no es un enlace de YouTube para Cat-ode"})
    escribir({"ok": enlace.a_catode(url) is not None})


# ---- «servir»: el servicio local para el Chromium del snap

def ids():
    try:
        with open(ID_TXT) as f:
            return set(f.read().split())
    except OSError:
        return set()


def abrir_desde_servicio(url):
    """Cat-ode en su propio scope de app del autor; si systemd-run falla, como siempre (dentro del servicio)."""
    scope = ("systemd-run", "--user", "--scope", "--quiet", "--collect", "--slice=app.slice",
             f"--unit=app-gnome-es.catode.app-enlace{time.time_ns()}.scope", "--") if shutil.which("systemd-run") else ()
    p = enlace.a_catode(url, scope)
    if p is True or p is None or not scope:   # True: CATODE_ENLACE_PRUEBA (solo lo apunta)
        return p is not None
    try:
        rc = p.wait(timeout=1.5)
    except subprocess.TimeoutExpired:
        threading.Thread(target=p.wait, daemon=True).start()   # se recoge al cerrarse (si no, queda zombi en su scope)
        return True    # sigue vivo: Cat-ode arrancando o pasando el enlace a la ventana que ya está abierta
    if rc == 0:
        return True    # Cat-ode ya estaba abierto: le pasó el enlace y salió
    print(f"systemd-run salió con {rc}: Cat-ode se abre sin scope propio", flush=True)
    return enlace.a_catode(url) is not None


class Atiende(BaseHTTPRequestHandler):
    ultimo_ping = 0.0

    def log_message(self, *a):
        pass

    def responder(self, codigo, datos):
        cuerpo = json.dumps(datos).encode("utf-8")
        self.send_response(codigo)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(cuerpo)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(cuerpo)

    def do_GET(self):
        puerto = self.server.server_port
        origen, ide = self.headers.get("Origin", ""), self.headers.get("X-Catode", "")
        if self.headers.get("Host") not in (f"127.0.0.1:{puerto}", f"localhost:{puerto}") or ide not in ids() or \
                (origen and origen != f"chrome-extension://{ide}"):
            print(f"rechazada: Host={self.headers.get('Host')} Origin={origen or '-'} X-Catode={ide or '-'}"[:200], flush=True)
            return self.responder(403, {"ok": False, "error": "solo la extensión Cat-ode enlaces"})
        u = urllib.parse.urlsplit(self.path)
        if u.path == "/ping":
            if time.time() - Atiende.ultimo_ping > 3600:   # la extensión llama cada 10 min: al diario, uno por hora
                print("ping de la extensión", flush=True)
                Atiende.ultimo_ping = time.time()
            return self.responder(200, {"ok": True, "version": VERSION})
        if u.path != "/abrir":
            return self.responder(404, {"ok": False, "error": "no existe"})
        url = urllib.parse.parse_qs(u.query).get("url", [""])[0]
        if not enlace.YT.match(url) or "catode=navegador" in url:
            print(f"rechazado (no es de YouTube para Cat-ode): {url[:120]}", flush=True)
            return self.responder(400, {"ok": False, "error": "no es un enlace de YouTube para Cat-ode"})
        ok = abrir_desde_servicio(url)
        print(f"{'abierto en Cat-ode' if ok else 'NO se pudo abrir en Cat-ode'}: {url[:160]}", flush=True)
        self.responder(200, {"ok": ok})


def servir(puerto=PUERTO):
    print(f"escucha en 127.0.0.1:{puerto} (extensión {', '.join(sorted(ids())) or 'SIN id.txt'})", flush=True)
    ThreadingHTTPServer(("127.0.0.1", puerto), Atiende).serve_forever()


# ---- «comprobar»: para el vigía

def comprobar():
    problemas = []
    ide = min(ids(), default="")
    try:
        with urllib.request.urlopen(urllib.request.Request(f"http://127.0.0.1:{PUERTO}/ping", headers={"X-Catode": ide}),
                                    timeout=5) as r:
            if not json.loads(r.read()).get("ok"):
                raise ValueError("contesta sin ok")
    except Exception as e:   # noqa: BLE001
        problemas.append(("catode-enlaces-servicio", f"el servicio de los enlaces de Chromium (127.0.0.1:{PUERTO}, "
                                                     f"catode-enlaces-navegador) no contesta: {e}"))
    for nav, f in POLITICAS.items():
        try:
            with open(f) as h:
                lista = json.load(h).get("ExtensionInstallForcelist", [])
        except (OSError, ValueError):
            lista = []
        if not any(e.split(";")[0] == ide for e in lista):
            problemas.append((f"catode-enlaces-politica-{nav.lower()}", f"la política de {nav} ({f}) ya no fuerza la "
                                                                        "extensión «Cat-ode enlaces»"))
        perfil = os.path.expanduser(PERFILES[nav])
        if os.path.isdir(perfil) and not os.path.isdir(os.path.join(perfil, "Extensions", ide)):
            problemas.append((f"catode-enlaces-instalada-{nav.lower()}", f"la extensión «Cat-ode enlaces» no está "
                                                                         f"instalada en {nav}"))
    try:
        https = subprocess.run(["xdg-mime", "query", "default", "x-scheme-handler/https"], capture_output=True, text=True,
                               timeout=10).stdout.strip()
    except (OSError, subprocess.SubprocessError):
        https = "?"
    if https != "catode-enlaces.desktop":
        problemas.append(("catode-enlaces-sistema", f"los enlaces de fuera del navegador van a «{https}», no a Cat-ode "
                                                    "(catode-enlaces.desktop)"))
    for clave, texto in problemas:
        print(f"{clave}\t{texto[:300]}")


if __name__ == "__main__":
    orden = sys.argv[1] if len(sys.argv) > 1 else ""   # Chrome pasa el origen de la extensión como primer argumento
    if orden == "servir":
        servir(int(sys.argv[2]) if len(sys.argv) > 2 else PUERTO)
    elif orden == "comprobar":
        comprobar()
    else:
        main()
