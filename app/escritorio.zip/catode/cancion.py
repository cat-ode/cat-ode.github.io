"""Cat-ode escritorio · ¿es la misma canción? (22/10/2026, encargo 3.8).

Orden del autor (20/10/2026): «en reproducción continua salta relacionados del video, sale igual la misma canción del video y
pocas veces sale otra canción relacionada, pero la primera que sugiere es la misma que has buscado». Los relacionados de
YouTube de una canción empiezan casi siempre por la misma canción en otras subidas (otro canal, «lyrics», «official audio»,
«live», remaster, cover…). Antes solo se quitaba el mismo vídeo (mismo id). Aquí se reconoce la misma canción por el título
y el artista normalizados, y ordenar() deja esas subidas al final: lo siguiente es OTRA canción.
Lo usan la reproducción automática y «A continuación» de las dos interfaces (interfaz.py y servicio.py para la web); Android
lleva lo mismo en Cancion.kt (mismas reglas, mismas pruebas: pruebas/cancion_misma.py)."""
import re
import unicodedata

# palabras que dicen QUÉ subida es, no qué canción (se quitan del nombre de la canción)
_RUIDO = re.compile(r"\b(official|oficial|music|musical|video|videoclip|clip|audio|lyrics?|letra|con letra|visuali[sz]er|live|"
                    r"en vivo|en directo|directo|unplugged|acoustic|acustic[oa]|remaster(ed)?|remasterizad[oa]|hd|hq|4k|8k|mv|"
                    r"full|version|cover|karaoke|instrumental|sub|subtitulad[oa]|subtitulos|subtitles|traducid[oa]|traduccion|"
                    r"espanol|english|sped up|slowed|reverb|nightcore|extended|radio edit|edit|mix|remix|1080p|720p|topic)\b")
_PARENTESIS = re.compile(r"[\(\[\{【「].*?[\)\]\}】」]")
_INVITADOS = re.compile(r"\s(ft|feat|featuring)\.?\s.*$")
_SEPARADOR = re.compile(r"\s+[-–—|:~]\s+|\s+//\s+")


def _plano(t):
    t = unicodedata.normalize("NFKD", (t or "").lower())
    return "".join(c for c in t if not unicodedata.combining(c)).replace("’", "'")


def _limpio(t):
    return " ".join(re.sub(r"[^\w\s]", " ", t).split())


def clave(titulo, autor=""):
    """(artista, canción) normalizados; el artista sale del título («Artista - Canción») o, si no, del canal."""
    t = _PARENTESIS.sub(" ", _plano(titulo))
    partes = _SEPARADOR.split(t, maxsplit=1)
    if len(partes) == 2 and partes[0].strip() and partes[1].strip():
        artista, cancion = partes
    else:
        artista, cancion = _plano(autor), t
    artista = re.sub(r"\s*-\s*topic$|vevo$|\b(official|oficial|music|tv)\b", " ", artista)
    cancion = _INVITADOS.sub(" ", cancion)
    cancion = _RUIDO.sub(" ", cancion)
    return _limpio(artista), _limpio(cancion)


def _compatibles(a, b):
    return not a or not b or a == b or a in b or b in a


def misma(e1, e2):
    """¿Son la misma canción (o el mismo vídeo)? e1, e2: objetos o dicts con url, titulo y autor."""
    g = (lambda e, k: e.get(k, "") if isinstance(e, dict) else getattr(e, k, "") or "")
    from .motor import id_video
    i1, i2 = id_video(g(e1, "url")), id_video(g(e2, "url"))
    if i1 and i1 == i2:
        return True
    a1, c1 = clave(g(e1, "titulo"), g(e1, "autor"))
    a2, c2 = clave(g(e2, "titulo"), g(e2, "autor"))
    # también al revés: los canales de letras ponen «Canción - Artista»
    return _iguales(a1, c1, a2, c2) or _iguales(a1, c1, c2, a2) or _iguales(c1, a1, a2, c2)


def _iguales(a1, c1, a2, c2):
    if not c1 or not c2 or not _compatibles(a1, a2):
        return False
    if c1 == c2:
        return True
    p1, p2 = set(c1.split()), set(c2.split())
    if min(len(p1), len(p2)) < 2:   # una palabra sola («Hello», «Intro»): solo si es igual (ya mirado)
        return False
    return len(p1 & p2) / len(p1 | p2) >= 0.75


def ordenar(rel, actual, sonados=()):
    """Los relacionados con lo de la misma canción (del que suena o de lo ya sonado en la sesión) al final, en su orden."""
    otros, mismas = [], []
    for e in rel or []:
        (mismas if misma(e, actual) or any(misma(e, s) for s in sonados) else otros).append(e)
    return otros + mismas


# recopilatorios: «Mix», «playlist», «best of», «1 hour»… (medido el 22/10/2026 con «James Blunt - Circles»: los 18
# relacionados de YouTube eran recopilatorios de una hora; la reproducción continua saltaba a uno de ellos)
_RECOPILATORIO = re.compile(r"\b(mix|mixes|playlist|best of|grandes exitos|recopilatorio|compilation|full album|album completo|"
                            r"non ?stop|sin parar|hits|top \d+|\d+ (songs|canciones|temas)|\d+ ?(h|hr|hrs|hour|hours|horas?)\b|"
                            r"live stream|24/7)\b")


def _g(e, k):
    return (e.get(k) if isinstance(e, dict) else getattr(e, k, None)) or ""


def _duracion(e):
    try:
        return int(_g(e, "duracion") or -1)
    except (TypeError, ValueError):
        return -1


def suelta(e):
    """¿Es una canción suelta (no un recopilatorio de una hora)?"""
    d = _duracion(e)
    # sin lo de entre paréntesis: «(Extended Mix)», «(Radio Edit)» son canciones sueltas
    return not _RECOPILATORIO.search(_PARENTESIS.sub(" ", _plano(_g(e, "titulo")))) and (d <= 0 or d <= 900)


def es_cancion(e):
    """¿Lo que suena es una canción? (suelta y con pinta de canción: «Artista - Canción», audio, letra, vídeo oficial…)"""
    t = _plano(_g(e, "titulo"))
    musical = bool(_SEPARADOR.search(t)) or bool(re.search(r"\b(official|oficial|audio|lyrics?|letra|video musical|music video|feat|ft)\b", t))
    return suelta(e) and musical and 0 < _duracion(e) <= 600 if _duracion(e) > 0 else suelta(e) and musical


def siguiente(rel, actual, sonados=(), vistos=frozenset(), ocultos=frozenset()):
    """Lo que toca en la reproducción automática: otra canción, no vista antes si se puede; nunca la misma canción mientras
    haya otra cosa; y si lo que suena es una canción, otra canción SUELTA (no un recopilatorio). None si no hay (el que
    llama busca relleno: mezcla())."""
    from .motor import id_video
    candidatos = [e for e in ordenar(rel, actual, sonados) if not (misma(e, actual) or any(misma(e, s) for s in sonados))]
    if es_cancion(actual):
        candidatos = [e for e in candidatos if suelta(e)]
    url = (lambda e: e.get("url", "") if isinstance(e, dict) else getattr(e, "url", ""))
    return (next((e for e in candidatos if id_video(url(e)) not in vistos and url(e) not in ocultos), None)
            or next(iter(candidatos), None))


_mezcla = {"semilla": "", "lista": []}


def mezcla(actual, sonados, vistos, ocultos, pedir):
    """Relleno de la reproducción automática cuando lo que suena es una canción y entre los relacionados no hay otra
    canción suelta: el «Mix» de YouTube de esa canción (list=RD<id>, unas 25 canciones relacionadas; es lo que hace YouTube).
    Se sigue tirando de la misma mezcla mientras le queden canciones: UNA petición para muchas canciones (regla 24).
    pedir(url) → lista de elementos (motor.lista)."""
    from .motor import id_video
    sig = siguiente(_mezcla["lista"], actual, sonados, vistos, ocultos)
    if sig is not None:
        return sig
    i = id_video(_g(actual, "url"))
    if not i or i == _mezcla["semilla"]:
        return None
    try:
        lista = pedir(f"https://www.youtube.com/watch?v={i}&list=RD{i}") or []
    except Exception:   # noqa: BLE001
        lista = []
    _mezcla.update(semilla=i, lista=list(lista))
    return siguiente(_mezcla["lista"], actual, sonados, vistos, ocultos)
