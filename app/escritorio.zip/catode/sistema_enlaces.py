"""Cat-ode · Cat-ode como «navegador» de los enlaces en Windows (19/10/2026). El autor: «catode tiene que abrir los enlaces
a youtube en los que haces clic en todos los sistemas en los que se instala y en los míos».
Windows no deja que un programa se ponga solo de predeterminado para http/https (lo protege con un hash y, en Windows 11,
con el controlador UCPD): se registra todo (como pruebas/enlaces_windows.ps1 en el mini PC el 03/10) y se abre la página
de Cat-ode en Ajustes → Aplicaciones predeterminadas (ms-settings:defaultapps?registeredAppUser=Cat-ode), donde basta con
«Establecer valor predeterminado». enlace.py reparte después: YouTube a Cat-ode, lo demás al navegador de antes
(navegador.json). Todo en HKCU (sin administrador). Lo usan el instalador y el botón de Ajustes de la app.
    python sistema_enlaces.py registrar | pedir | estado | quitar [carpeta]"""
import json
import os
import sys

NOMBRE = "Cat-ode"
PROGID = "CatodeEnlaces"
AQUI = os.path.dirname(os.path.abspath(__file__))   # .../app/catode


def _pythonw():
    d = os.path.dirname(sys.executable)
    w = os.path.join(d, "pythonw.exe")
    return w if os.path.exists(w) else sys.executable


def _orden_de(progid):
    """La orden de un ProgId («"C:\\…\\msedge.exe" --single-argument %1») → [exe, «{url}»]."""
    import winreg
    try:
        with winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, progid + r"\shell\open\command") as k:
            cmd = winreg.QueryValueEx(k, "")[0]
    except OSError:
        return None
    exe = cmd.split('"')[1] if cmd.startswith('"') else cmd.split(" ")[0]
    return [exe, "{url}"] if os.path.exists(exe) else None


def actual():
    """El ProgId que abre hoy los enlaces https, o "". Windows 11 (medido en el mini PC, 26H2) guarda la elección de Ajustes
    en UserChoiceLatest/ProgId y deja UserChoice con la de antes: manda la nueva."""
    import winreg
    base = r"Software\Microsoft\Windows\Shell\Associations\UrlAssociations\https"
    for ruta in (base + r"\UserChoiceLatest\ProgId", base + r"\UserChoice"):
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, ruta) as k:
                v = winreg.QueryValueEx(k, "ProgId")[0]
                if v:
                    return v
        except OSError:
            continue
    return ""


def estado():
    return actual() == PROGID


def registrar():
    import winreg
    from . import enlace as _e   # noqa: F401  (comprueba que enlace.py está al lado)
    previo = actual()
    carpeta = _e.carpeta()
    os.makedirs(carpeta, exist_ok=True)
    nav = os.path.join(carpeta, "navegador.json")
    if previo and previo != PROGID:
        orden = _orden_de(previo)
        if orden:
            with open(nav, "w", encoding="utf-8") as f:
                json.dump({"progid": previo, "orden": orden}, f, ensure_ascii=False, indent=1)
    cmd = f'"{_pythonw()}" "{os.path.join(AQUI, "enlace.py")}" "%1"'
    icono = os.path.join(os.path.dirname(AQUI), "catode.ico")
    def poner(ruta, valores):
        with winreg.CreateKeyEx(winreg.HKEY_CURRENT_USER, ruta, 0, winreg.KEY_WRITE) as k:
            for nombre, valor in valores.items():
                winreg.SetValueEx(k, nombre, 0, winreg.REG_SZ, valor)
    poner(rf"Software\Classes\{PROGID}", {"": "Enlace (Cat-ode)"})
    poner(rf"Software\Classes\{PROGID}\DefaultIcon", {"": icono})
    poner(rf"Software\Classes\{PROGID}\shell\open\command", {"": cmd})
    poner(r"Software\Classes\catode", {"": "URL:Cat-ode", "URL Protocol": ""})
    poner(r"Software\Classes\catode\shell\open\command", {"": cmd})
    base = rf"Software\Clients\StartMenuInternet\{NOMBRE}"
    poner(base, {"": NOMBRE})
    poner(base + r"\DefaultIcon", {"": icono})
    poner(base + r"\shell\open\command", {"": f'"{_pythonw()}" "{os.path.join(AQUI, "enlace.py")}"'})
    poner(base + r"\Capabilities", {"ApplicationName": NOMBRE, "ApplicationIcon": icono,
                                    "ApplicationDescription": "Los enlaces de YouTube se abren en Cat-ode; los demás, en tu navegador de siempre"})
    poner(base + r"\Capabilities\URLAssociations", {"http": PROGID, "https": PROGID})
    # .htm/.html también: así Ajustes ofrece el botón «Establecer valor predeterminado» de los navegadores
    poner(base + r"\Capabilities\FileAssociations", {".htm": PROGID, ".html": PROGID})
    poner(r"Software\RegisteredApplications", {NOMBRE: base + r"\Capabilities"})
    try:
        import ctypes
        ctypes.windll.shell32.SHChangeNotify(0x08000000, 0, None, None)   # SHCNE_ASSOCCHANGED
    except Exception:   # noqa: BLE001
        pass
    return True


def pedir():
    """La página de Cat-ode en Aplicaciones predeterminadas (Windows 11; en Windows 10 abre la lista general)."""
    os.startfile("ms-settings:defaultapps?registeredAppUser=" + NOMBRE)   # noqa: S606


def quitar(carpeta=""):
    """Para el desinstalador: solo si lo registrado apunta a ESTA instalación (una copia de prueba no quita la buena)."""
    import winreg
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, rf"Software\Classes\{PROGID}\shell\open\command") as k:
            cmd = winreg.QueryValueEx(k, "")[0]
    except OSError:
        return False
    if carpeta and os.path.normcase(os.path.abspath(carpeta)) not in os.path.normcase(cmd):
        return False
    def borrar(ruta):
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, ruta, 0, winreg.KEY_ALL_ACCESS) as k:
                while True:
                    try:
                        borrar(ruta + "\\" + winreg.EnumKey(k, 0))
                    except OSError:
                        break
            winreg.DeleteKey(winreg.HKEY_CURRENT_USER, ruta)
        except OSError:
            pass
    for r in (rf"Software\Classes\{PROGID}", r"Software\Classes\catode", rf"Software\Clients\StartMenuInternet\{NOMBRE}"):
        borrar(r)
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\RegisteredApplications", 0, winreg.KEY_SET_VALUE) as k:
            winreg.DeleteValue(k, NOMBRE)
    except OSError:
        pass
    return True


if __name__ == "__main__":
    sys.path.insert(0, os.path.dirname(AQUI))
    __package__ = "catode"   # para «from . import enlace» al ejecutarlo como archivo (lo hace el instalador)
    import catode  # noqa: F401,E402
    que = sys.argv[1] if len(sys.argv) > 1 else "estado"
    if os.name != "nt":
        print("solo Windows (en Linux: navegador/instalar_linux.sh)")
        sys.exit(2)
    if que == "registrar":
        registrar()
        print("registrado; predeterminado:", estado())
    elif que == "pedir":
        pedir()
    elif que == "quitar":
        print("quitado" if quitar(sys.argv[2] if len(sys.argv) > 2 else "") else "no era de esta carpeta")
    else:
        print("predeterminado" if estado() else "no predeterminado:", actual())
        sys.exit(0 if estado() else 1)
