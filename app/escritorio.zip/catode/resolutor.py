"""Cat-ode escritorio · el resolutor, sin Qt (06/10/2026, interfaz web): del enlace de YouTube a lo que se reproduce.
Movido tal cual de reproductor.py (que lo importa con los mismos nombres: Linux y la Qt no cambian) para que el servicio
web lo use sin cargar Qt ni mpv."""
import os
import sys
import threading
import time

from . import motor, roto

def registro(texto):
    """Lo que pasa con cada vídeo (tiempos, errores, reintentos), en catode.log de la carpeta de datos (máx. 1 MB)."""
    linea = time.strftime("%d/%m %H:%M:%S ") + texto
    print("Cat-ode:", texto, file=sys.stderr, flush=True)
    try:
        from .datos import carpeta_datos
        ruta = os.path.join(carpeta_datos(), "catode.log")
        if os.path.exists(ruta) and os.path.getsize(ruta) > 1_000_000:
            os.replace(ruta, ruta + ".1")
        with open(ruta, "a", encoding="utf-8") as f:
            f.write(linea + "\n")
    except Exception:
        pass


ESCALONES_P = (144, 240, 360, 480, 720, 1080, 1440, 2160, 4320)


def escalon(lado):
    """El escalón de YouTube de un lado corto: un 1280×702 es 720p (medido en el M13 el 22/10/2026)."""
    return next((e for e in ESCALONES_P if lado <= e * 1.02), lado) if lado and lado > 0 else 0


def _p(f):
    """22/10/2026 (3.6): la calidad de un formato como la dice YouTube: el lado corto (1080×1920 es 1080p), en su escalón."""
    w, h = f.get("width") or 0, f.get("height") or 0
    return escalon(min(w, h) if w and h else h)


def formato(alto):
    """Primero HLS (trozos pequeños): las direcciones directas de YouTube se atascan o se cortan si se piden enteras (el
    1080p de 452 MB se quedaba en el segundo 0 en el mini PC, 02/10/2026). H.264 para que lo descodifique la gráfica.
    22/10/2026 (encargo 3.6, «debe coincidir la calidad elegida con la que se muestra»): la calidad es el lado CORTO, como en
    YouTube. Un vídeo vertical de 1080×1920 es 1080p; con «height<=1080» se cogía el de 608×1080 (y con 360, ninguno)."""
    # en Windows (el N100 del mini PC), la versión de 25-30 fps si la hay: misma resolución y la mitad de trabajo
    fps = "[fps<=30]" if os.name == "nt" else ""
    alternativas = []
    for lado in (f"[aspect_ratio>=?1][height<={alto}]", f"[aspect_ratio<1][width<={alto}]"):   # apaisado (o sin dato) y vertical
        alternativas += [f"bv*[protocol^=m3u8]{lado}[vcodec^=avc1]{fps}+ba[protocol^=m3u8]",
                         f"bv*[protocol^=m3u8]{lado}[vcodec^=avc1]+ba[protocol^=m3u8]", f"b[protocol^=m3u8]{lado}",
                         f"bv*{lado}[vcodec^=avc1]+ba[ext=m4a]", f"bv*{lado}+ba", f"b{lado}"]
    return "/".join(alternativas + ["b"])


# errores de YouTube que no se arreglan reintentando: se dice qué pasa y no se insiste
DEFINITIVOS = (("recording is not available", "Este directo ya terminó y YouTube no guarda su grabación"),
               ("live event will begin", "Este directo aún no ha empezado"), ("Premieres in", "Este estreno aún no ha empezado"),
               ("Private video", "Este vídeo es privado"), ("members", "Este vídeo es solo para miembros del canal"),
               ("removed", "Este vídeo ya no está en YouTube"), ("confirm your age", "Este vídeo tiene restricción de edad"), ("Video unavailable", "Este vídeo ya no está disponible en YouTube"),
               ("This video is unavailable", "Este vídeo ya no está disponible en YouTube"),
               ("not available in your country", "Este vídeo no está disponible en España"))


def definitivo(error):
    """El aviso en español si el error de YouTube es de los que no se arreglan reintentando; si no, None."""
    t = str(error)
    return next((aviso for clave, aviso in DEFINITIVOS if clave.lower() in t.lower()), None)


# lo resuelto por adelantado vale 20 minutos (03/10/2026: con 4 horas, al saltar a otro punto YouTube rechazaba los
# trozos con las direcciones viejas y el vídeo se quedaba parado)
FRESCO = 20 * 60


def _edl(url):
    return f"%{len(url.encode())}%{url}"


def _storyboard(i):
    """Las miniaturas de la barra (03/10/2026): el mosaico de YouTube de ~160 px de ancho (una imagen cada ~10 s).
    {ancho, alto, filas, columnas, paso (s por miniatura), mosaicos [urls]} o None."""
    sbs = [f for f in (i.get("formats") or []) if (f.get("format_id") or "").startswith("sb") and f.get("fragments")
           and f.get("rows") and f.get("columns") and f.get("fps")]
    if not sbs:
        return None
    f = min(sbs, key=lambda f: abs((f.get("width") or 0) - 160))
    return {"ancho": f["width"], "alto": f["height"], "filas": f["rows"], "columnas": f["columns"], "paso": 1 / f["fps"],
            "mosaicos": [t["url"] for t in f["fragments"] if t.get("url")]}


def _storyboard_spec(spec):
    """El storyboard tal como lo da la API interna («spec» de playerStoryboardSpecRenderer), en el mismo formato que
    _storyboard: niveles «ancho#alto#total#columnas#filas#ms#nombre#firma» separados por «|»; se elige el de ~160 px."""
    if not spec or "|" not in spec:
        return None
    try:
        base, *niveles = spec.split("|")
        mejor = None
        for n, nivel in enumerate(niveles):
            p = nivel.split("#")
            if len(p) < 8:
                continue
            ancho, alto, total, cols, filas, ms, nombre, firma = int(p[0]), int(p[1]), int(p[2]), int(p[3]), int(p[4]), int(p[5]), p[6], p[7]
            if not ms:
                continue   # el nivel 0 es una sola imagen del vídeo entero
            if mejor is None or abs(ancho - 160) < abs(mejor[0] - 160):
                mejor = (ancho, alto, total, cols, filas, ms, nombre, firma, n)
        if mejor is None:
            return None
        ancho, alto, total, cols, filas, ms, nombre, firma, n = mejor
        import math
        mosaicos = [base.replace("$L", str(n)).replace("$N", nombre.replace("$M", str(i))) + "&sigh=" + firma
                    for i in range(max(1, math.ceil(total / (cols * filas))))]
        return {"ancho": ancho, "alto": alto, "filas": filas, "columnas": cols, "paso": ms / 1000, "mosaicos": mosaicos}
    except Exception:   # noqa: BLE001
        return None


def _pista(f, duracion=0):
    """Una pista para el EDL de mpv: la dirección directa o, si YouTube solo da DASH por trozos (03/10/2026: «WWII Restored»,
    la grabación de un directo en 836 trozos de ~5 s SIN duración declarada: mpv decía -16 «nada que reproducir» y el vídeo
    no cargaba nunca), los trozos como los monta el ytdl_hook de mpv. Si los trozos no traen duración, se reparte la del
    vídeo entre todos (los directos de YouTube van en trozos iguales); mpv ajusta con las marcas de tiempo de cada uno."""
    if f.get("protocol") != "http_dash_segments":
        return _edl(f["url"])
    trozos = f.get("fragments") or []
    base = f.get("fragment_base_url") or ""

    def direccion(t):
        return t.get("url") or (base + t.get("path", "") if t.get("path") else "")
    con_duracion = [t for t in trozos if t.get("duration") is not None]
    partes, desde, cabecera = [], 0, "!mp4_dash"
    if trozos and trozos[0].get("duration") is None and len(trozos) > 1 and con_duracion:   # el primero sin duración: el de inicio
        cabecera += ",init=" + _edl(direccion(trozos[0]))
        desde = 1
    partes.append(cabecera)
    uniforme = (duracion / len(trozos)) if (not con_duracion and duracion and trozos) else None
    for t in trozos[desde:]:
        if not direccion(t):
            return None
        largo = t.get("duration") if t.get("duration") is not None else uniforme
        if largo is None:
            return None
        partes.append(_edl(direccion(t)) + f",length={largo:.3f}")
    return ";".join(partes) if len(partes) > 1 else None


class Resolutor:
    """Del enlace de YouTube a lo que mpv reproduce directamente: imagen + sonido (EDL, como hace el propio mpv),
    título, duración y subtítulos en español e inglés. Guarda lo resuelto 4 horas (YouTube da los enlaces para 6)."""
    def __init__(self, ajustes=None):
        self.ajustes = ajustes or {}   # por la cuenta para vídeos de miembros
        self.cache, self.cerrojo = {}, threading.Lock()
        self._ydl = {}
        self.uso = threading.Lock()
        self.uso_fondo = threading.Lock()
        self.uso_hls = threading.Lock()
        self._sin_hls = set()      # vídeos a los que la vía rápida dijo OK sin HLS (18/10/2026, roto.py)
        # 18/10/2026 (hallazgo 11): la excepción del manifiesto HLS, POR HILO (antes era compartida y el adelanto de
        # fondo podía pisar la del vídeo pedido); y lo que la vía rápida vio raro, que solo se apunta en roto.py si
        # yt-dlp TAMPOCO saca el vídeo (si yt-dlp lo reproduce, YouTube no está roto)
        self._local = threading.local()
        self._rapido_raro = {}     # id del vídeo → (texto, clase)

    def _cliente(self, alto, fondo=False):
        import yt_dlp
        clave = (alto, fondo)
        if clave not in self._ydl:
            # el de fondo, sin caché en disco: en Windows, dos clientes escribiendo a la vez la caché de yt-dlp se
            # bloquean el archivo y el vídeo pedido fallaba con «Permission denied» (02/10/2026)
            extra = {"cachedir": False} if fondo else {}
            self._ydl[clave] = yt_dlp.YoutubeDL(motor._opciones(format=formato(alto), **extra))
        return self._ydl[clave]

    def resolver(self, url, alto, fondo=False):
        """fondo=True: lo que se adelanta (otro cliente y otro cerrojo: nunca hace esperar al vídeo que se ha pedido)."""
        clave = (motor.id_video(url), alto)
        with self.cerrojo:
            x = self.cache.get(clave)
            if x and time.time() - x["t"] < FRESCO:
                return x
        # 06/10/2026 · en Windows (motor de Edge) primero la vía rápida: UNA petición a la API interna de YouTube con el
        # cliente de visionOS, como la app de Android (medido en el mini PC: yt-dlp tardaba 2,9 s de media y hasta 12,6 s
        # por vídeo; esta petición, décimas). Si falla (p. ej. «no eres un bot»), yt-dlp como siempre.
        if os.name == "nt":
            x = self._rapido(url)
            if x is not None:
                with self.cerrojo:
                    self.cache[clave] = x
                return x
            if getattr(self, "_sin_red", False):   # 06/10/2026: sin conexión no se insiste con yt-dlp (se atascaba minutos)
                raise RuntimeError("sin conexión")
        with (self.uso_fondo if fondo else self.uso):   # yt-dlp no se fía de dos hilos a la vez con el mismo cliente
            with self.cerrojo:
                x = self.cache.get(clave)
            if x and time.time() - x["t"] < FRESCO:
                with self.cerrojo:
                    self._rapido_raro.pop(motor.id_video(url), None)
                return x
            try:
                try:
                    for intento in range(3):
                        try:
                            i = self._cliente(alto, fondo).extract_info(url, download=False)
                            break
                        except PermissionError:   # un archivo bloqueado un instante (antivirus, otro proceso): otra vez
                            if intento == 2:
                                raise
                            time.sleep(0.4)
                except Exception as error:   # noqa: BLE001
                    # 03/10/2026: solo para miembros → otra vez con la cuenta elegida en Ajustes (y solo entonces)
                    from . import miembros
                    if fondo or not (miembros.es_de_miembros(error) and miembros.configurada(self.ajustes)):
                        raise
                    registro(f"vídeo de miembros: se pide con la cuenta ({str(error)[:120]})")
                    i = miembros.resolver(url, alto, self.ajustes)
            except Exception:
                with self.cerrojo:
                    raro = self._rapido_raro.pop(motor.id_video(url), None)
                if raro:   # ni la vía rápida ni yt-dlp: ahora sí cuenta para «YouTube roto»
                    roto.apuntar_video(url, raro[0], raro[1])
                raise
            with self.cerrojo:
                self._rapido_raro.pop(motor.id_video(url), None)   # yt-dlp lo ha sacado: no estaba roto
        partes = i.get("requested_formats") or [i]
        if not partes or not partes[0].get("url"):
            raise RuntimeError("sin formatos")
        pistas = [_pista(f, i.get("duration") or 0) for f in partes]
        if any(p is None for p in pistas):
            registro(f"formato por trozos sin montar ({partes[0].get('protocol')}): se lo dejo a mpv")
            ruta = url
        elif len(partes) > 1:
            ruta = "edl://!no_clip;!no_chapters;" + pistas[0] + ";!new_stream;!no_clip;!no_chapters;" + pistas[1]
        elif partes[0].get("protocol") == "http_dash_segments":
            ruta = "edl://!no_clip;!no_chapters;" + pistas[0]
        else:
            ruta = partes[0]["url"]
        subs = []
        for fuente, auto in ((i.get("subtitles") or {}, False), (i.get("automatic_captions") or {}, True)):
            for lengua, pistas in fuente.items():
                base = lengua.split("-")[0]
                # 15/10/2026: también «es-419-orig», «es-ES-orig»… (el original con otra variante), y el original gana a la
                # traducción automática (tlang=, la que YouTube corta antes con 429)
                if base not in ("es", "en") or (auto and lengua not in ("es", "en") and not lengua.endswith("-orig")):
                    continue
                vtt = next((p["url"] for p in pistas if p.get("ext") == "vtt"), None)
                if vtt:
                    nombre = {"es": "Español", "en": "Inglés"}[base] + (" (automáticos)" if auto else "")
                    ya = next((k for k, (_, n, _) in enumerate(subs) if n == nombre), None)
                    if ya is None:
                        subs.append((vtt, nombre, base))
                    elif "tlang=" in subs[ya][0] and "tlang=" not in vtt:
                        subs[ya] = (vtt, nombre, base)
        hls = self._hls(url, i) if os.name == "nt" else None   # para el motor de Edge en Windows (motor_web)
        with self.cerrojo:
            sin_hls_rapido = motor.id_video(url) in self._sin_hls
            self._sin_hls.discard(motor.id_video(url))
        if sin_hls_rapido and not hls and getattr(self._local, "hls_fallo", None) is None:   # 18/10/2026: ni la vía rápida ni yt-dlp traen HLS
            roto.todos_sin_hls(url)
        x = {"t": time.time(), "ruta": ruta, "hls": hls, "titulo": i.get("title") or "", "duracion": i.get("duration") or 0,
             "directo": bool(i.get("is_live")), "storyboard": _storyboard(i),
             "subs": subs, "alto": max(_p(p) for p in partes),
             # 22/10/2026 (3.6): las calidades que tiene este vídeo (para el selector: solo esas)
             "niveles": sorted({_p(f) for f in i.get("formats") or [] if f.get("vcodec") not in (None, "none") and _p(f)})}
        with self.cerrojo:
            if len(self.cache) > 200:
                self.cache.clear()
            self.cache[clave] = x
        return x

    _visitante = (0.0, "")

    def _rapido(self, url):
        """Lista HLS, título, duración, subtítulos y storyboard con una petición «player» (cliente visionOS). None si no."""
        from . import metadatos, motor_web
        if not motor_web.disponible():
            return None
        t0 = time.time()
        self._sin_red = False
        try:
            vid = motor.id_video(url)
            t, visitante = Resolutor._visitante
            if time.time() - t > 6 * 3600 or not visitante:   # el identificador de visitante de la página (sin él, «inicia sesión»)
                import re, urllib.request
                req = urllib.request.Request(f"https://www.youtube.com/watch?v={vid}", headers={"User-Agent": metadatos.AGENTE, "Accept-Language": "es-ES"})
                with urllib.request.urlopen(req, timeout=10) as r:
                    m = re.search(r'"VISITOR_DATA":"([^"]+)"', r.read().decode("utf-8", "ignore"))
                visitante = m.group(1) if m else ""
                Resolutor._visitante = (time.time(), visitante)
            j = metadatos.innertube("player", {"videoId": vid, "contentCheckOk": True, "racyCheckOk": True}, "VISIONOS", visitante or None)
            estado = (j.get("playabilityStatus") or {}).get("status")
            hls = (j.get("streamingData") or {}).get("hlsManifestUrl")
            cliente = "visionOS"
            if estado != "OK" or not hls:
                # 19/10/2026: el identificador de visitante rechazado no se guarda 6 h más: el vídeo siguiente pide uno nuevo
                # (el 19/10 a las 05:53 se usaba uno de las 03:10 y visionOS decía «no eres un bot»; con uno nuevo, a las 09:41, iba)
                Resolutor._visitante = (0.0, "")
                # 19/10/2026: probado UNA vez desde casa el cliente de iOS como respaldo: «OK» pero SIN lista HLS (sin visitante).
                # No sirve: no se le pide nada (cada petición de más cuenta para el «no eres un bot»).
            if cliente == "visionOS" and (estado != "OK" or not hls):
                motivo = (j.get('playabilityStatus') or {}).get('reason') or ''
                registro(f"vía rápida: {estado} {motivo[:60]} → yt-dlp")
                # 18/10/2026: OK sin HLS o UNPLAYABLE sin motivo = YouTube ha cambiado algo (roto.py lo cuenta)
                clase = roto.jugabilidad(estado, motivo, bool(hls))
                if clase:   # 18/10/2026 (hallazgo 11): se apunta solo si yt-dlp también falla (resolver)
                    with self.cerrojo:
                        if len(self._rapido_raro) > 200:
                            self._rapido_raro.clear()
                        self._rapido_raro[vid] = (f"vía rápida: {estado} {motivo}"[:200], clase)
                if estado == "OK":
                    with self.cerrojo:
                        self._sin_hls.add(vid)   # si yt-dlp tampoco trae HLS: todos los clientes OK sin HLS
                return None
            d = j.get("videoDetails") or {}
            subs = []
            for t_ in (((j.get("captions") or {}).get("playerCaptionsTracklistRenderer") or {}).get("captionTracks") or []):
                lengua = (t_.get("languageCode") or "").split("-")[0]
                if lengua not in ("es", "en") or not t_.get("baseUrl"):
                    continue
                auto = t_.get("kind") == "asr"
                nombre = {"es": "Español", "en": "Inglés"}[lengua] + (" (automáticos)" if auto else "")
                if all(n != nombre for _, n, _ in subs):
                    subs.append((t_["baseUrl"] + "&fmt=vtt", nombre, lengua))
            x = {"t": time.time(), "ruta": hls, "hls": hls, "titulo": d.get("title") or "", "duracion": int(d.get("lengthSeconds") or 0),
                 "directo": bool(d.get("isLive")), "storyboard": _storyboard_spec(((j.get("storyboards") or {}).get("playerStoryboardSpecRenderer") or {}).get("spec")),
                 "subs": subs, "alto": 1080}
            registro(f"vía rápida ({cliente}): «{x['titulo'][:40]}» en {time.time() - t0:.1f} s")
            return x
        except Exception as error:   # noqa: BLE001
            import urllib.error
            self._sin_red = isinstance(error, urllib.error.URLError) and isinstance(getattr(error, "reason", None), (ConnectionRefusedError, OSError)) \
                and not isinstance(getattr(error, "reason", None), TimeoutError)
            registro(f"vía rápida falla ({error!r}"[:160] + (") → sin conexión, no se insiste" if self._sin_red else ") → yt-dlp"))
            return None

    def _hls(self, url, i):
        """El manifiesto HLS para el motor de Edge. El de los clientes «web» (los que salen con node) no se deja bajar fuera
        de youtube.com (manifestLoadError); el de los clientes sin JavaScript sí (el prototipo que fue perfecto, 04/10/2026)."""
        from . import motor_web
        if not motor_web.disponible():
            return None
        self._local.hls_fallo = None
        try:
            import yt_dlp
            if getattr(self, "_ydl_hls", None) is None:
                self._ydl_hls = yt_dlp.YoutubeDL({"quiet": True, "no_warnings": True, "skip_download": True, "logger": motor._Callado()})
            with self.uso_hls:
                j = self._ydl_hls.extract_info(url, download=False)
            return next((f.get("manifest_url") for f in (j.get("formats") or []) if str(f.get("protocol", "")).startswith("m3u8")
                         and f.get("manifest_url")), None)
        except Exception as error:   # noqa: BLE001
            self._local.hls_fallo = error
            registro(f"manifiesto HLS para Edge: {error!r}"[:200])
            return None

    def guardado(self, url, alto):
        """Lo ya resuelto (sin esperar a nada), o None."""
        with self.cerrojo:
            x = self.cache.get((motor.id_video(url), alto))
        return x if x and time.time() - x["t"] < FRESCO else None

    def olvidar(self, url):
        with self.cerrojo:
            for k in [k for k in self.cache if k[0] == motor.id_video(url)]:
                del self.cache[k]
