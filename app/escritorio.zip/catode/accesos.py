"""Cat-ode escritorio · los accesos directos de Windows (y los lanzadores de Linux) con el icono de ahora (22/10/2026, el
autor: «el icono de linux, windows y android de catode no ha cambiado por el nuevo»).

Dos causas medidas en el mini PC: (1) sus accesos (escritorio, Inicio y el anclado de la barra de tareas) eran de la
instalación a mano del 01/10 y apuntaban a %LOCALAPPDATA%\\Cat-ode\\catode.ico, que ninguna actualización toca; (2) aunque el
.ico cambie, el Explorador sigue enseñando el que guarda en su caché. Por eso, cuando app\\catode.ico cambia (y la primera
vez): los accesos que abren ESTE catode.pyw pasan a apuntar a una copia del icono con nombre propio de esa versión
(iconos\\catode-<huella>.ico en la carpeta de datos: un archivo nuevo el Explorador lo lee sí o sí; el mismo archivo
cambiado puede seguir saliendo viejo de su caché) y además se refresca la caché (SHChangeNotify e ie4uinit -show).
En otro hilo, una vez por icono (icono-<equipo>.json en la carpeta de datos); nunca frena ni falla.
En Linux pasa lo mismo con el dock de GNOME (medido el 22/10/2026 en el Dell y el ProBook: catode.svg cambiado y el dock
con el de antes): los lanzadores de Cat-ode (~/.local/share/applications, «Icon=» con catode) pasan a una copia con nombre
propio en ~/.local/share/icons/catode; GNOME relee el lanzador al cambiar y, con un nombre nuevo, también el icono.
Suelto para probarlo: python accesos.py <carpeta app> (pone los accesos; no toca icono-<equipo>.json)."""
import base64
import hashlib
import json
import os
import socket
import subprocess
import sys
import threading
import time

SIN_VENTANA = 0x08000000
# escritorio y menú Inicio (del usuario y de todos; los de todos solo si hay permiso) y los anclados de la barra de tareas
PS = r"""
$ico = $env:CATODE_ICONO; $pyw = $env:CATODE_PYW
$sh = New-Object -ComObject WScript.Shell
$dirs = @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('CommonDesktopDirectory'),
          [Environment]::GetFolderPath('Programs'), [Environment]::GetFolderPath('CommonPrograms'),
          (Join-Path $env:APPDATA 'Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar'))
foreach ($d in $dirs) {
  if (-not $d -or -not (Test-Path -LiteralPath $d)) { continue }
  foreach ($f in Get-ChildItem -LiteralPath $d -Filter *.lnk -File -ErrorAction SilentlyContinue) {
    try {
      $l = $sh.CreateShortcut($f.FullName)
      if (([string]$l.TargetPath + ' ' + [string]$l.Arguments).IndexOf($pyw, [StringComparison]::OrdinalIgnoreCase) -lt 0) { continue }
      if ($l.IconLocation -ieq "$ico,0") { "igual`t" + $f.FullName; continue }
      $l.IconLocation = "$ico,0"; $l.Save(); "cambiado`t" + $f.FullName
    } catch { "fallo`t" + $f.FullName + "`t" + $_.Exception.Message }
  }
}
"""


def _apunta(t):
    try:
        from .resolutor import registro
        registro("accesos: " + t)
    except Exception:   # noqa: BLE001 (suelto, sin la app: a la consola)
        print("accesos:", t, flush=True)


def _carpeta_datos():
    d = os.environ.get("CATODE_CARPETA", "").strip()   # como enlace.carpeta(): la instalación aislada manda
    if d:
        return os.path.abspath(os.path.expanduser(d))
    return os.path.join(os.environ.get("LOCALAPPDATA", ""), "Cat-ode") if os.name == "nt" else os.path.expanduser("~/.config/catode")


def poner(app):
    """Los accesos de este Cat-ode, con la copia de app\\catode.ico de esta versión; después, la caché de iconos al día.
    Lista de (estado, ruta)."""
    with open(os.path.join(app, "catode.ico"), "rb") as f:
        datos = f.read()
    carpeta = os.path.join(_carpeta_datos(), "iconos")
    os.makedirs(carpeta, exist_ok=True)
    nombre = f"catode-{hashlib.sha256(datos).hexdigest()[:10]}.ico"
    ico, pyw = os.path.join(carpeta, nombre), os.path.join(app, "catode.pyw")
    if not os.path.exists(ico):
        with open(ico + ".tmp", "wb") as f:
            f.write(datos)
        os.replace(ico + ".tmp", ico)
    # en base64 (-EncodedCommand): por la entrada estándar PowerShell no se traga bien los bloques de varias líneas
    orden = base64.b64encode(("[Console]::OutputEncoding = [Text.Encoding]::UTF8\n" + PS).encode("utf-16-le")).decode()
    r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-EncodedCommand", orden],
                       capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=60,
                       creationflags=SIN_VENTANA, env={**os.environ, "CATODE_ICONO": ico, "CATODE_PYW": pyw})
    hechos = [tuple(x.split("\t", 1)) for x in r.stdout.splitlines() if "\t" in x]
    if r.returncode == 0 and not any(e == "fallo" for e, _ in hechos):   # las copias de iconos anteriores ya no las usa nadie
        for viejo in os.listdir(carpeta):
            if viejo.startswith("catode-") and viejo.endswith(".ico") and viejo != nombre:
                try:
                    os.remove(os.path.join(carpeta, viejo))
                except OSError:
                    pass
    try:
        import ctypes
        s = ctypes.windll.shell32
        s.SHChangeNotify.argtypes = [ctypes.c_long, ctypes.c_uint, ctypes.c_void_p, ctypes.c_void_p]
        for estado, ruta in hechos:
            if estado == "cambiado":
                s.SHChangeNotify(0x00002000, 0x0005, ctypes.c_wchar_p(ruta), None)   # SHCNE_UPDATEITEM, SHCNF_PATHW
        s.SHChangeNotify(0x08000000, 0, None, None)   # SHCNE_ASSOCCHANGED: el Explorador vuelve a leer los iconos
    except Exception as e:   # noqa: BLE001
        _apunta(f"SHChangeNotify: {e!r}"[:200])
    ie4 = os.path.join(os.environ.get("SystemRoot", r"C:\Windows"), "System32", "ie4uinit.exe")
    if os.path.exists(ie4):   # Windows 10 y 11: refresca la caché de iconos sin reiniciar el Explorador
        subprocess.run([ie4, "-show"], timeout=60, creationflags=SIN_VENTANA, capture_output=True)
    return hechos


def poner_linux(app):
    """Linux: los lanzadores de Cat-ode con la copia de catode.svg de esta versión. Lista de (estado, ruta)."""
    with open(os.path.join(app, "catode.svg"), "rb") as f:
        datos = f.read()
    carpeta = os.path.expanduser("~/.local/share/icons/catode")
    os.makedirs(carpeta, exist_ok=True)
    nombre = f"catode-{hashlib.sha256(datos).hexdigest()[:10]}.svg"
    ico = os.path.join(carpeta, nombre)
    if not os.path.exists(ico):
        with open(ico + ".tmp", "wb") as f:
            f.write(datos)
        os.replace(ico + ".tmp", ico)
    hechos = []
    lanzadores = os.path.expanduser("~/.local/share/applications")
    for n in sorted(os.listdir(lanzadores)) if os.path.isdir(lanzadores) else []:
        ruta = os.path.join(lanzadores, n)
        if not n.endswith(".desktop"):
            continue
        try:
            with open(ruta, encoding="utf-8") as f:
                lineas = f.read().split("\n")
            i = next((k for k, x in enumerate(lineas) if x.startswith("Icon=/") and "catode" in x.lower()), None)
            if i is None:
                continue
            if lineas[i] == "Icon=" + ico:
                hechos.append(("igual", ruta))
                continue
            lineas[i] = "Icon=" + ico
            with open(ruta + ".tmp", "w", encoding="utf-8") as f:
                f.write("\n".join(lineas))
            os.replace(ruta + ".tmp", ruta)
            hechos.append(("cambiado", ruta))
        except OSError as e:
            hechos.append(("fallo", f"{ruta}\t{e!r}"))
    if not any(e == "fallo" for e, _ in hechos):   # las copias anteriores ya no las usa nadie
        for viejo in os.listdir(carpeta):
            if viejo.startswith("catode-") and viejo.endswith(".svg") and viejo != nombre:
                try:
                    os.remove(os.path.join(carpeta, viejo))
                except OSError:
                    pass
    return hechos


def al_dia(app=None, forzar=False):
    app = app or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    with open(os.path.join(app, "catode.ico" if os.name == "nt" else "catode.svg"), "rb") as f:
        sha = hashlib.sha256(f.read()).hexdigest()
    # con el nombre del equipo: en Linux la carpeta de datos puede ir sincronizada entre el Dell y el ProBook
    ruta = os.path.join(_carpeta_datos(), f"icono-{socket.gethostname()}.json")
    try:
        with open(ruta, encoding="utf-8") as f:
            visto = json.load(f).get("sha256")
    except Exception:   # noqa: BLE001
        visto = None
    if visto == sha and not forzar:
        return None
    hechos = poner(app) if os.name == "nt" else poner_linux(app)
    _apunta(", ".join(f"{e} {os.path.basename(os.path.dirname(r))}\\{os.path.basename(r)}" for e, r in hechos)
            or "ningún acceso de Cat-ode")
    try:
        with open(ruta, "w", encoding="utf-8") as f:
            json.dump({"sha256": sha, "fecha": time.strftime("%d/%m/%Y %H:%M")}, f)
    except OSError as e:
        _apunta(f"no se pudo guardar {os.path.basename(ruta)}: {e!r}"[:200])
    return hechos


def al_arrancar():
    """Al abrir la app (catode.pyw): en otro hilo y al minuto, para no quitarle tiempo al arranque."""
    if "--prueba" in sys.argv or os.environ.get("CATODE_CARPETA", "").strip():
        return

    def trabajo():
        time.sleep(60)
        try:
            al_dia()
        except Exception as e:   # noqa: BLE001
            _apunta(f"fallo: {e!r}"[:200])
    threading.Thread(target=trabajo, daemon=True, name="accesos").start()


if __name__ == "__main__":
    _app = sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    for e, r in poner(_app) if os.name == "nt" else poner_linux(_app):
        print(e, r)
