"""Cat-ode escritorio · cerrada a usuarios nuevos (30/10/2026).

Orden del autor: «quiero que impidas el acceso a nuevos usuarios de cat-ode, pero que los actuales puedan seguir usándolo y
recibiendo updates». Los enlaces de Drive que se repartieron son los MISMOS archivos de los que se actualizan los actuales:
cerrarlos los dejaría sin versiones nuevas, así que el cierre va dentro de la app (como en el móvil, Acceso.kt). Pasa quien
ya la tenía antes del corte y cualquier equipo del autor (sincro.json). «Ya la tenía» = la carpeta de la app o la de los
datos se creó antes del corte: Windows conserva la fecha de creación de la carpeta aunque los archivos de dentro se
reescriban (medido en el mini PC: carpeta del 01/10, datos-*.json «creado» hoy). Linux no da esa fecha (Python 3.12): allí
solo pasan los equipos del autor (Linux no se reparte). Ante cualquier error, pasa: antes dejar entrar a uno nuevo que
cerrarle la app a uno de los de siempre. En el camino cerrado se sigue buscando versión nueva (si un día se abre, le llega
sola). Las pruebas (--prueba, CATODE_PRUEBA_INTERFAZ) pasan: corren con los datos copiados y SIN sincro.json a propósito
(interfaz_linux.sh, escritorio_xephyr.sh). CATODE_PRUEBA_ACCESO=nuevo cierra a la fuerza (solo para probar el aviso; nunca
abre)."""
import json
import os
import sys
import threading
import time

CORTE = 1793332800   # 30/10/2026 05:00 (hora de Madrid): lo instalado después ya es de un usuario nuevo
TITULO = "Cat-ode ya no admite usuarios nuevos"
TEXTO = "Solo puede usarla quien ya la tenía instalada."


def decidir(sincro, creadas):
    """La regla, sin tocar el disco (para las pruebas). 02/11/2026 · ABIERTA OTRA VEZ A TODOS (orden del autor: «quiero hacerla
    disponible en mi web, en todas sus versiones con web propia separada de mi alojamiento»): ya no se reparte desde su Drive
    sino desde su web propia (cat-ode.github.io), así que pasa cualquiera. El corte se guarda por si se vuelve a cerrar."""
    return True


def creada(ruta):
    """Fecha de creación de una carpeta (segundos), o None si no existe o el sistema no la da (Linux)."""
    try:
        st = os.stat(ruta)
    except OSError:
        return None
    t = getattr(st, "st_birthtime", None)   # Windows, desde Python 3.12
    if t is None and os.name == "nt":
        t = st.st_ctime   # en Windows, antes de la 3.12, st_ctime era la creación
    return t


def _sincro():
    from .datos import carpeta_config
    try:
        with open(os.path.join(carpeta_config(), "sincro.json"), encoding="utf-8") as f:
            return bool(json.load(f).get("clave"))
    except Exception:   # noqa: BLE001
        return False


def carpetas():
    """Las carpetas que solo crea Cat-ode: la de la app (catode.pyw; la crea el instalador y las actualizaciones escriben
    dentro sin rehacerla) y la de los datos (%LOCALAPPDATA%\\Cat-ode; ~/.local/share/catode)."""
    from .datos import carpeta_datos
    return [os.path.dirname(os.path.dirname(os.path.abspath(__file__))), carpeta_datos()]


def informe():
    """(¿pasa?, explicación para el registro)."""
    if os.environ.get("CATODE_PRUEBA_ACCESO", "").strip().lower() == "nuevo":
        return False, "CATODE_PRUEBA_ACCESO=nuevo"
    if "--prueba" in sys.argv or os.environ.get("CATODE_PRUEBA_INTERFAZ"):
        return True, "prueba"
    sincro = _sincro()
    fechas = {c: creada(c) for c in carpetas()}
    texto = ", ".join(f"{c} creada {time.strftime('%d/%m/%Y %H:%M', time.localtime(t)) if t else '¿?'}" for c, t in fechas.items())
    return decidir(sincro, fechas.values()), f"sincronización {'sí' if sincro else 'no'}; {texto}"


def permitido():
    """¿Se puede usar Cat-ode en este equipo? Lo apunta en catode.log; ante cualquier error, sí."""
    try:
        bien, por_que = informe()
    except Exception as e:   # noqa: BLE001
        bien, por_que = True, f"no he podido comprobarlo ({e!r})"[:200]
    try:
        from .resolutor import registro
        registro(f"acceso: {'pasa' if bien else 'CERRADA a usuarios nuevos'} ({por_que})")
    except Exception:   # noqa: BLE001
        pass
    return bien


def _buscar_version():
    """Windows: la versión nueva de Drive, como siempre (Linux va desde ~/Cat-ode y no se descarga)."""
    if os.name != "nt":
        return
    try:
        from .actualizar import buscar_version
        _info, nueva = buscar_version()
        if nueva:
            from .resolutor import registro
            registro(f"acceso: versión {nueva} instalada; se usa al volver a abrir")
    except Exception:   # noqa: BLE001
        pass


def cerrada(app):
    """El aviso al usuario nuevo; mientras se ve, se busca versión nueva. Vuelve al cerrarlo (y la app sale)."""
    from PySide6.QtWidgets import QMessageBox
    hilo = threading.Thread(target=_buscar_version, daemon=True, name="acceso-version")
    hilo.start()
    caja = QMessageBox(QMessageBox.Icon.Information, "Cat-ode", TITULO)
    caja.setInformativeText(TEXTO)
    caja.addButton("Cerrar", QMessageBox.ButtonRole.AcceptRole)
    caja.exec()
    hilo.join(120)   # si estaba bajando una versión, que acabe (ya sin ventana)


if __name__ == "__main__":   # comprobar un equipo sin abrir nada: python -m catode.acceso
    print(informe())
    sys.exit(0)
