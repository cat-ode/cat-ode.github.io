// Cat-ode escritorio · interfaz web, módulo M7 (06/10/2026): la página Shorts (PaginaShorts, interfaz.py 1659-1783 y
// 3295-3317). Un short a la vez en un marco 9:16 centrado (la capa del reproductor se coloca encima), a la derecha
// título, canal (clic = canal), 👍 👎 (excluyentes), ↗ Compartir, ▶ Ver como vídeo, ↑ Anterior / ↓ Siguiente y el aviso
// «n Shorts de tus canales · rueda o ↑ ↓ para pasar». Rueda, ↑/↓ y RePág/AvPág pasan de short con antirrebote de 0,4 s;
// espacio o K, pausa; M, sonido. Sin pantalla completa. Al salir se para el vídeo y se quita el bucle.
//   CatodeM7.paginas.shorts(contenedor, a) → {salir(), titulo, pasar(dir), actual()}
"use strict";
(function () {
  const M7 = window.CatodeM7 = window.CatodeM7 || {};
  M7.paginas = M7.paginas || {};

  function PaginaShorts(cont, a, ctx) {
    ctx = ctx || {};
    const U = M7.util, el = U.el;
    const ctl = new AbortController();
    const limpiar = [];
    let lista = [], i = 0, ultimoPaso = 0, votos = {};
    const marco = el("div", {class: "sh-marco"}, el("div", {class: "sh-espera m7-gris", text: "Cargando los Shorts…"}));
    const titulo = el("h2", {class: "sh-titulo"});
    const canal = el("a", {class: "sh-canal", href: "#"});
    const bMeGusta = el("button", {class: "m7-boton sh-megusta", text: "👍", title: "Me gusta"});
    const bNoMeGusta = el("button", {class: "m7-boton sh-nomegusta", text: "👎", title: "No me gusta"});
    const bCompartir = el("button", {class: "m7-boton sh-compartir", text: "↗ Compartir"});
    const bSonido = el("button", {class: "m7-boton sh-sonido", text: "🔊 Sonido", title: "Silenciar (M)"});
    const bVideo = el("button", {class: "m7-boton sh-video", text: "▶ Ver como vídeo"});
    const bAnt = el("button", {class: "m7-boton sh-anterior", text: "↑ Anterior"});
    const bSig = el("button", {class: "m7-boton sh-siguiente", text: "↓ Siguiente"});
    const contador = el("div", {class: "sh-contador m7-gris"});
    const aviso = el("div", {class: "sh-aviso m7-gris"});
    const lado = el("div", {class: "sh-lado"}, titulo, canal,
      el("div", {class: "sh-fila"}, bMeGusta, bNoMeGusta, bCompartir),
      el("div", {class: "sh-fila"}, bSonido, bVideo),
      el("div", {class: "sh-fila"}, bAnt, bSig), contador, aviso);
    const raiz = el("div", {class: "m7 sh", tabindex: "-1"}, el("div", {class: "sh-centro"}, marco, lado));
    cont.append(raiz);
    const rep = M7.rep();
    let silencio = false;

    function poner(e) {
      const k = lista.findIndex((x) => x.url === e.url);
      if (k >= 0) i = k;
      titulo.textContent = e.titulo || "";
      canal.textContent = e.autor || "";
      const v = votos[e.url] || {};
      bMeGusta.classList.toggle("activo", !!v.megusta);
      bNoMeGusta.classList.toggle("activo", !!v.nomegusta);
      contador.textContent = lista.length ? `${i + 1} de ${lista.length}` : "";
      bAnt.disabled = i <= 0;
      bSig.disabled = i >= lista.length - 1;
      pagina.titulo = e.titulo || "Shorts";
    }
    function pasar(dir) {   // antirrebote de 0,4 s (la rueda de Edge parte una muesca en varios trozos)
      const ahora = performance.now();
      if (ahora - ultimoPaso < 400 || !lista.length) return false;
      const k = i + (dir > 0 ? 1 : -1);
      if (k < 0 || k >= lista.length) return false;
      ultimoPaso = ahora;
      i = k;
      poner(lista[k]);
      if (rep) rep.saltar_a(k);
      return true;
    }
    async function votar(col) {   // _voto: 👍 y 👎 se excluyen
      const e = lista[i];
      if (!e) return;
      const p = await M7.alternar(col, e);
      if (p === null) return;
      const v = votos[e.url] = votos[e.url] || {};
      v[col] = p;
      if (p) v[col === "megusta" ? "nomegusta" : "megusta"] = false;
      poner(e);
    }
    bMeGusta.addEventListener("click", () => votar("megusta"));
    bNoMeGusta.addEventListener("click", () => votar("nomegusta"));
    bCompartir.addEventListener("click", () => { const r = bCompartir.getBoundingClientRect(); if (lista[i]) M7.menuCompartir(lista[i], r.left, r.bottom + 4, 0); });
    bVideo.addEventListener("click", () => { if (lista[i]) M7.abrirVideo(lista[i], {sonar: false}); });
    bAnt.addEventListener("click", () => { ultimoPaso = 0; pasar(-1); });
    bSig.addEventListener("click", () => { ultimoPaso = 0; pasar(1); });
    bSonido.addEventListener("click", () => alternarSonido());
    canal.addEventListener("click", (ev) => { ev.preventDefault(); const e = lista[i]; if (e) M7.irCanal(e.autorUrl, ev.ctrlKey); });
    canal.addEventListener("auxclick", (ev) => { if (ev.button === 1) { ev.preventDefault(); const e = lista[i]; if (e) M7.irCanal(e.autorUrl, true); } });
    function alternarSonido() {
      silencio = !silencio;
      if (rep) M7.silenciar(rep, silencio);
      bSonido.textContent = silencio ? "🔇 Sin sonido" : "🔊 Sonido";
      bSonido.classList.toggle("activo", silencio);
    }
    function tecla(k) {
      if (k === "ArrowDown" || k === "PageDown") { pasar(1); return true; }
      if (k === "ArrowUp" || k === "PageUp") { pasar(-1); return true; }
      if (k === " " || k === "k" || k === "K") { if (rep) rep.alternar(); return true; }
      if (k === "m" || k === "M") { alternarSonido(); return true; }
      if (k === "f" || k === "F" || k === "F11") return true;   // sin pantalla completa en Shorts
      return false;
    }
    const alTeclado = (ev) => {
      if (ev.defaultPrevented || !pagina.visible || ev.ctrlKey || ev.altKey || /^(INPUT|TEXTAREA|SELECT)$/.test((ev.target && ev.target.tagName) || "")) return;
      if (document.querySelector(".m7-dialogo-fondo, .m7-menu")) return;
      if (tecla(ev.key)) { ev.preventDefault(); ev.stopImmediatePropagation(); }
    };
    document.addEventListener("keydown", alTeclado, true);
    limpiar.push(() => document.removeEventListener("keydown", alTeclado, true));
    raiz.addEventListener("wheel", (ev) => { ev.preventDefault(); if (Math.abs(ev.deltaY) > 2) pasar(ev.deltaY); }, {passive: false});

    async function cargar() {
      let r;
      try { r = await M7.api("/api/pagina/shorts", undefined, "GET", ctl.signal); } catch (err) { return; }
      if (!pagina.visible) return;
      marco.textContent = "";
      if (!r.ok) {
        aviso.textContent = r.error || "No he podido cargar los Shorts";
        marco.append(el("div", {class: "sh-espera"}, el("div", {class: "m7-gris", text: aviso.textContent}),
          el("button", {class: "m7-boton", text: "Reintentar", onclick: () => cargar()})));
        return;
      }
      lista = (r.elementos || []).filter((x) => x.tipo === "VIDEO");
      aviso.textContent = r.aviso || "";
      if (!lista.length) { marco.append(el("div", {class: "sh-espera m7-gris", text: r.aviso || "No hay Shorts"})); return; }
      poner(lista[0]);
      if (M7.capa) M7.capa.ponerEn(marco, "shorts");
      if (rep) { rep.bucle(true); rep.todo(lista, 0); }
    }
    limpiar.push(M7.on("pestana:cambia", () => setTimeout(() => {
      const v = raiz.isConnected && raiz.getClientRects().length > 0;
      if (v === pagina.visible) return;
      pagina.visible = v;
      document.body.classList.toggle("en-video", v);
      if (v && lista.length && M7.capa) M7.capa.ponerEn(marco, "shorts");
      if (!v && rep) M7.pausar(rep, true);
    }, 0)));
    if (rep && rep.on) {
      limpiar.push(M7.oir(rep, "empieza", (e) => { if (pagina.visible && e) poner(e); }));
    }
    const pagina = {
      titulo: "Shorts", visible: true, raiz, pasar, actual: () => lista[i], lista: () => lista, tecla,
      rueda(dy) { pasar(dy); },
      salir() {   // _pagina_cambiada 4098: para el vídeo, quita el bucle y devuelve la zona
        pagina.visible = false;
        ctl.abort();
        for (const f of limpiar) try { f && f(); } catch (e) { /* nada */ }
        document.body.classList.remove("en-video");
        if (rep) { rep.bucle(false); if (silencio) M7.silenciar(rep, false); if (lista.length && rep.actual && lista.some((x) => x.url === rep.actual.url)) rep.parar(); }
        if (M7.capa && M7.capa.sitio === marco) M7.capa.ocultar();
        if (M7._shorts === pagina) M7._shorts = null;
        raiz.remove();
      },
    };
    pagina.destruir = pagina.salir;   // contrato de app.js (M4)
    M7._shorts = pagina;
    document.body.classList.add("en-video");
    if (typeof ctx.titulo === "function") ctx.titulo("Shorts");
    cargar();
    return pagina;
  }
  M7.paginas.shorts = PaginaShorts;
  if (typeof M7.registrar === "function") M7.registrar();
})();
