// Cat-ode escritorio · interfaz web: el botón central y el clic derecho como en el navegador (12/10/2026).
// Orden del autor: «quiero poder hacer scroll con el botón central del ratón y que se pueda hacer clic derecho en todos los
// elementos para abrir nuevas pestañas».
//   - Botón central sobre algo que NO abre pestaña (hueco, texto, fondo): desplazamiento automático. Se mueve el ratón
//     lejos del punto y la página corre hacia allí, más deprisa cuanto más lejos. Si se arrastra con el botón pulsado, se
//     para al soltarlo; si fue un clic, sigue hasta el siguiente clic, tecla o rueda.
//   - Botón central sobre algo que SÍ abre pestaña: como siempre (pestaña nueva), sin desplazamiento.
//   - Clic derecho sobre cualquier cosa que se abre con el central y no tiene menú propio: «Abrir» y «Abrir en pestaña
//     nueva» (app.js). Se sabe qué elementos abren pestaña porque escuchan «auxclick»: se marcan al registrarse.
// Va el PRIMERO de index.html: tiene que ver todos los addEventListener de los demás módulos.
"use strict";
(function () {
  const C = window.catode = window.catode || {};
  const MARCA = "__catodeCentral";
  const original = EventTarget.prototype.addEventListener;
  EventTarget.prototype.addEventListener = function (tipo, fn, op) {
    if (tipo === "auxclick" && this instanceof Element) this[MARCA] = true;
    return original.call(this, tipo, fn, op);
  };
  const editable = (el) => !!el && (el.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(el.tagName));
  const mano = (el) => { try { return getComputedStyle(el).cursor === "pointer"; } catch (e) { return false; } };

  // el elemento que abre en pestaña nueva con el central (un nodo con la mano entre el objetivo y quien escucha auxclick)
  function abreConCentral(el) {
    let conMano = false;
    for (let n = el; n && n.nodeType === 1; n = n.parentElement) {
      if (n.classList.contains("menu-ctx") || n.classList.contains("m5-menu")) return false;   // dentro de un menú, nada
      if (!conMano && mano(n)) conMano = true;
      if (n[MARCA]) return conMano;
    }
    return false;
  }
  const evento = (tipo, boton, ev) => new MouseEvent(tipo, {bubbles: true, cancelable: true, view: window, button: boton,
    clientX: ev ? ev.clientX : 0, clientY: ev ? ev.clientY : 0});

  C.raton = {
    abreConCentral,
    clic(el, ev) { el.dispatchEvent(evento("click", 0, ev)); },
    central(el, ev) { el.dispatchEvent(evento("auxclick", 1, ev)); },
  };

  // ---------------------------------------------------------------------------------------- desplazamiento automático
  const ZONA_MUERTA = 10;
  let auto = null;   // {cont, x0, y0, x, y, capa, arrastre, raf}

  function desplazable(n) {
    const s = getComputedStyle(n);
    const y = /(auto|scroll|overlay)/.test(s.overflowY) && n.scrollHeight > n.clientHeight + 1;
    const x = /(auto|scroll|overlay)/.test(s.overflowX) && n.scrollWidth > n.clientWidth + 1;
    return y || x;
  }
  function contenedor(el) {
    for (let n = el; n && n.nodeType === 1 && n !== document.body && n !== document.documentElement; n = n.parentElement)
      if (desplazable(n)) return n;
    const d = document.scrollingElement;
    return d && (d.scrollHeight > d.clientHeight + 1 || d.scrollWidth > d.clientWidth + 1) ? d : null;
  }
  const velocidad = (d) => { const a = Math.abs(d) - ZONA_MUERTA; return a <= 0 ? 0 : Math.sign(d) * Math.min(60, a * a / 4000 + a / 12); };

  function paso() {
    if (!auto) return;
    const vx = velocidad(auto.x - auto.x0), vy = velocidad(auto.y - auto.y0);
    if (vx || vy) auto.cont.scrollBy(vx, vy);
    const dx = auto.x - auto.x0, dy = auto.y - auto.y0;
    const cursor = Math.max(Math.abs(dx), Math.abs(dy)) <= ZONA_MUERTA ? "all-scroll"
      : Math.abs(dy) >= Math.abs(dx) ? (dy < 0 ? "n-resize" : "s-resize") : (dx < 0 ? "w-resize" : "e-resize");
    if (auto.capa.style.cursor !== cursor) auto.capa.style.cursor = cursor;
    auto.raf = requestAnimationFrame(paso);
  }
  function empezar(cont, x, y) {
    const capa = document.createElement("div");
    capa.className = "raton-auto";
    capa.style.cssText = "position:fixed;inset:0;z-index:2147483647;cursor:all-scroll;background:transparent";
    const punto = document.createElement("div");
    punto.style.cssText = `position:fixed;left:${x - 14}px;top:${y - 14}px;width:28px;height:28px;border-radius:50%;` +
      "background:rgba(255,255,255,.85);box-shadow:0 0 0 1px rgba(0,0,0,.5);color:#111;font:bold 13px/28px sans-serif;" +
      "text-align:center;pointer-events:none";
    punto.textContent = "↕";
    capa.appendChild(punto);
    document.body.appendChild(capa);
    auto = {cont, x0: x, y0: y, x, y, capa, arrastre: false};
    auto.raf = requestAnimationFrame(paso);
  }
  function parar() {
    if (!auto) return;
    cancelAnimationFrame(auto.raf);
    auto.capa.remove();
    auto = null;
  }

  original.call(window, "mousedown", (ev) => {
    if (auto) { ev.preventDefault(); ev.stopPropagation(); parar(); return; }   // cualquier clic lo para y no hace nada más
    if (ev.button !== 1 || editable(ev.target)) return;
    ev.preventDefault();   // ni el desplazamiento propio del motor ni pegar
    if (abreConCentral(ev.target)) return;   // el central abre en pestaña nueva
    const cont = contenedor(ev.target);
    if (cont) empezar(cont, ev.clientX, ev.clientY);
  }, true);
  original.call(window, "mousemove", (ev) => {
    if (!auto) return;
    auto.x = ev.clientX; auto.y = ev.clientY;
    if (ev.buttons & 4 && Math.hypot(auto.x - auto.x0, auto.y - auto.y0) > ZONA_MUERTA) auto.arrastre = true;
  }, true);
  original.call(window, "mouseup", (ev) => { if (auto && ev.button === 1 && auto.arrastre) parar(); }, true);
  original.call(window, "auxclick", (ev) => { if (ev.target && ev.target.classList && ev.target.classList.contains("raton-auto")) ev.stopPropagation(); }, true);
  original.call(window, "keydown", (ev) => { if (auto) { ev.preventDefault(); ev.stopPropagation(); parar(); } }, true);
  original.call(window, "wheel", () => parar(), {capture: true, passive: true});
  original.call(window, "blur", () => parar());
  original.call(window, "contextmenu", (ev) => { if (auto) { ev.preventDefault(); ev.stopPropagation(); parar(); } }, true);
})();
