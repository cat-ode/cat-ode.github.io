// Cat-ode escritorio · interfaz web · módulo M5 (DISENO_WEB.md §3), 06/10/2026.
// tarjeta.js: la tarjeta de vídeo, canal o lista (tarjetas.py Tarjeta 112-415, FilaCompacta 417, pie 18, nitida 34) y la
// base común del módulo (window.M5): peticiones a /api con el token, avisos, navegación y acciones sobre un elemento.
// Orden de carga: tarjeta.js → menus.js → previa.js → rejilla.js → paginas_listas.js (todos con defer o al final).
//
// Formas: «rejilla» (miniatura arriba, como el Inicio de YouTube), «vertical» (Shorts 9:16) y «fila» (miniatura a la
// izquierda: historial, búsquedas, colecciones). Un nodo se crea una vez y se rellena con poner() cada vez que la rejilla
// lo reutiliza para otro elemento (pool de ≤150 nodos): nada de crear y tirar DOM al hacer scroll.
"use strict";
(function () {
  // ------------------------------------------------------------------------------------------------ registro de páginas
  // Si app.js (M4) aún no existe, el registro mínimo. Las páginas quedan además en window.catodePaginas por si app.js
  // se carga después y crea su propio objeto: al cargar el documento se vuelven a registrar en el app que haya.
  const app = window.app = window.app || {};
  app.paginas = app.paginas || {};
  if (typeof app.registrar !== "function") app.registrar = function (n, f) { this.paginas[n] = f; };
  window.catodePaginas = window.catodePaginas || {};
  document.addEventListener("DOMContentLoaded", () => {
    const a = window.app;
    if (!a) return;
    for (const [n, f] of Object.entries(window.catodePaginas)) {
      if (!a.paginas || a.paginas[n] !== f) { try { a.registrar(n, f); } catch (e) { (a.paginas = a.paginas || {})[n] = f; } }
    }
  });

  // ------------------------------------------------------------------------------------------------ base común (M5)
  const M5 = window.M5 = window.M5 || {};
  const qs = new URLSearchParams(location.search);
  M5.token = () => (window.app && window.app.token) || (window.catode && window.catode.token) || qs.get("t") || "";
  M5.base = () => (window.app && window.app.base) || location.origin;   // plan B (NavigateToString): base absoluta

  /** Petición JSON al servidor local: {ok:true,…} o {ok:false, error, clase, reintentar} (§2.2). Nunca lanza. */
  M5.api = async function (ruta, cuerpo, opciones) {
    const o = opciones || {};
    // la del Inicio pedida por app.js durante el arranque (precargarInicio): se usa una vez y solo si es reciente
    const pre = window.catode && window.catode.precarga;
    if (pre && cuerpo === undefined && !o.metodo && pre.ruta === ruta) {
      window.catode.precarga = null;
      if (performance.now() - pre.t < 15000) return pre.p;
    }
    try {
      const r = await fetch(M5.base() + ruta, {
        method: o.metodo || (cuerpo === undefined ? "GET" : "POST"),
        headers: Object.assign({"X-Catode": M5.token()}, cuerpo === undefined ? {} : {"Content-Type": "application/json"}),
        body: cuerpo === undefined ? undefined : JSON.stringify(cuerpo),
        signal: o.signal,
      });
      if (r.status === 204) return {ok: true};
      let d;
      try { d = await r.json(); } catch (e) { d = {ok: false, error: "Respuesta no válida (" + r.status + ")", clase: "servidor_autor"}; }
      if (d && d.ok === undefined) d.ok = r.ok;
      return d;
    } catch (err) {
      if (err && err.name === "AbortError") return {ok: false, abortada: true, error: "cancelada", clase: "cancelada"};
      return {ok: false, error: String(err && err.message || err), clase: "sin_red", reintentar: 15};
    }
  };
  // M5.soloLocal = true (pruebas del módulo): no se delega en app.js aunque exista; todo queda en el enrutador mínimo.
  const appDe = () => (M5.soloLocal ? null : window.app);
  M5.datos = (accion, extra) => M5.api("/api/datos", Object.assign({accion}, extra || {}));
  M5.ventana = (accion, valor) => M5.api("/api/ventana", {accion, valor});

  let cajaAviso = null, relojAviso = 0;
  /** Aviso de 3,5 s (statusBar de la Qt). El de app.js (M4) si existe. */
  M5.avisar = function (texto) {
    M5.ultimoAviso = texto;
    const a = appDe();
    if (a && typeof a.avisar === "function" && a.avisar !== M5.avisar) return a.avisar(texto);
    if (!cajaAviso) { cajaAviso = document.createElement("div"); cajaAviso.className = "m5-aviso"; }
    cajaAviso.textContent = texto;
    if (!cajaAviso.isConnected) document.body.appendChild(cajaAviso);
    clearTimeout(relojAviso);
    relojAviso = setTimeout(() => cajaAviso.remove(), 3500);
  };

  // ---- navegación: lo de app.js (M4) si existe; si no, un enrutador mínimo que pinta en M5.raiz (pruebas del módulo)
  M5.pila = [];
  function pintarLocal(f, a) {
    const fn = (window.app && window.app.paginas && window.app.paginas[f]) || window.catodePaginas[f];
    if (!fn || !M5.raiz) { M5.avisar("Esa página aún no existe aquí (" + f + ")"); return null; }
    if (M5.actual && M5.actual.destruir) M5.actual.destruir();
    M5.raiz.textContent = "";
    M5.actual = fn(M5.raiz, a || [], {});
    return M5.actual;
  }
  const delApp = (n) => { const a = appDe(); return a && typeof a[n] === "function" ? a[n].bind(a) : null; };
  M5.ir = function (f, a) {
    const ir = delApp("ir");
    if (ir) return ir(f, a || []);
    M5.pila.push({f, a: a || []});
    if (M5.pila.length > 60) M5.pila.shift();
    return pintarLocal(f, a);
  };
  /** Cambia los argumentos de la página actual sin apilar (chips, filtros: _refiltrar 3713). */
  M5.reemplazar = function (f, a) {
    const r = delApp("reemplazar");
    if (r) return r(f, a || []);
    if (delApp("ir")) return delApp("ir")(f, a || []);
    if (M5.pila.length) M5.pila.pop();
    return M5.ir(f, a);
  };
  M5.volver = function () {
    const v = delApp("volver");
    if (v) return v();
    if (M5.pila.length > 1) { M5.pila.pop(); const t = M5.pila[M5.pila.length - 1]; return pintarLocal(t.f, t.a); }
    return null;
  };
  /** A qué página lleva un elemento: {f, a} en el mismo formato que las pestañas guardadas de la Qt (2636). */
  M5.destino = function (e) {
    if (e.tipo === "CANAL") return {f: "_canal", a: [e.url, "videos"]};
    if ((e.url || "").startsWith("propia:")) return {f: "_lista_propia", a: [e.url]};
    if ((e.url || "").startsWith("biblioteca:")) return {f: "_lista_musica", a: [e.url.slice(11), e.titulo || "Lista"]};   // 22/10/2026
    if (e.tipo === "LISTA") return {f: "_lista_yt", a: [e.url, e.titulo || "Lista"]};
    return {f: "abrir_video", a: [{_e: M5.limpio(e)}]};
  };
  /** ventana.abrir(e) 3003: vídeo (también descargado: file:) → abrir_video; canal; lista propia; lista de YouTube. */
  M5.abrir = function (e, opciones) {
    const a = appDe();
    if (a && typeof a.abrir === "function" && a.abrir !== M5.abrir) return a.abrir(e, opciones);
    if (e.tipo === "VIDEO") {
      if (a && typeof a.abrirVideo === "function") return a.abrirVideo(e, opciones || {});
      M5.ultimaApertura = e;
      return M5.ir("abrir_video", [{_e: M5.limpio(e)}]);
    }
    const d = M5.destino(e);
    return M5.ir(d.f, d.a);
  };
  M5.abrirCanal = (url, nueva) => nueva ? M5.nuevaPestanaEn("_canal", [url, "videos"]) : M5.ir("_canal", [url, "videos"]);
  /** nueva_pestana(e) 2465 (botón central, Ctrl+clic, Ctrl+Enter, «⧉ Abrir en pestaña nueva»). */
  M5.nuevaPestana = function (e) {
    const a = appDe();
    if (a && typeof a.nuevaPestanaElemento === "function") return a.nuevaPestanaElemento(e);
    const d = M5.destino(e);
    return M5.nuevaPestanaEn(d.f, d.a, e.titulo);
  };
  M5.nuevaPestanaEn = function (f, args, titulo) {
    const n = delApp("nuevaPestana");
    M5.ultimaPestana = {f, a: args};
    if (n) return n(f, args, titulo);
    M5.avisar("Abierto en una pestaña nueva");
    return null;
  };
  /** El reproductor (M6, app.rep): todo, verALaVez, aContinuacion, encolar. Talón: avisa si aún no está. */
  // Nombres de M6 (reproductor.js, Reproductor.gestor.activo): todo(lista, aleatorio), encolar(e), insertar_siguiente(e);
  // «ver a la vez» (segundo vídeo flotante) es un gancho del marco: app.ganchos.verALaVez(e).
  const NOMBRES_M6 = {todo: "todo", encolar: "encolar", aContinuacion: "insertar_siguiente"};
  M5.rep = function (nombre, ...args) {
    M5.ultimaOrdenRep = {nombre, n: args[0] && args[0].length !== undefined ? args[0].length : 1};
    const a = appDe();
    if (a && a.ganchos && typeof a.ganchos[nombre] === "function") return a.ganchos[nombre](...args);
    // M8: sin ninguno sonando, el de la pestaña activa (catode.reproductor lo crea al pedirlo)
    // el de la pestaña activa (nunca la cola de otra pestaña); catode.reproductor lo crea al pedirlo
    const r = a ? (a.rep || (window.catode && window.Reproductor && window.catode.reproductor) ||
      (window.Reproductor && window.Reproductor.gestor && window.Reproductor.gestor.activo)) : null;
    if (r && typeof r[nombre] === "function") return r[nombre](...args);
    if (r && NOMBRES_M6[nombre] && typeof r[NOMBRES_M6[nombre]] === "function") return r[NOMBRES_M6[nombre]](...args);
    M5.avisar("El reproductor aún no está listo (" + nombre + ")");
    return null;
  };
  /** El Elemento tal cual lo espera Python (motor.elemento_de_dict). */
  M5.limpio = (e) => ({tipo: e.tipo, url: e.url, titulo: e.titulo || "", autor: e.autor || "", autorUrl: e.autorUrl || "",
    miniatura: e.miniatura || "", duracion: e.duracion == null ? -1 : e.duracion, detalle: e.detalle || "", fecha: e.fecha || 0});

  // ---- formato (motor.tiempo 63, metadatos.hace 188, tarjetas.pie 18 y nitida 34)
  M5.tiempo = function (s) {
    if (s == null || s < 0) return "";
    s = Math.floor(s);
    const dd = (n) => String(n).padStart(2, "0");
    return s >= 3600 ? `${Math.floor(s / 3600)}:${dd(Math.floor(s % 3600 / 60))}:${dd(s % 60)}` : `${Math.floor(s / 60)}:${dd(s % 60)}`;
  };
  M5.hace = function (ms) {
    if (!ms || ms <= 0) return "";
    let s = Math.floor((Date.now() - ms) / 1000);
    if (s < 0) return "";
    if (s < 60) return "hace un momento";
    for (const [lim, div, uno, varios] of [[3600, 60, "minuto", "minutos"], [86400, 3600, "hora", "horas"], [86400 * 30, 86400, "día", "días"],
      [86400 * 365, 86400 * 30, "mes", "meses"], [1e12, 86400 * 365, "año", "años"]]) {
      if (s < lim) { const x = Math.floor(s / div); return `hace ${x} ${x === 1 ? uno : varios}`; }
    }
    return "";
  };
  M5.pie = function (e) {
    const det = e.detalle || "";
    const partes = [];
    if (e.tipo === "LISTA") partes.push("Lista" + (det ? " · " + det : ""));
    else if (e.tipo === "CANAL") partes.push(det);
    else { if (det) partes.push(det); if (e.fecha) partes.push(M5.hace(e.fecha)); }
    return partes.filter(Boolean).join(" · ");
  };
  M5.nitida = function (url, vertical, ancho) {
    if (!url || (url.indexOf("/mqdefault.") < 0 && url.indexOf("/hqdefault.") < 0)) return url || "";
    const base = url.slice(0, url.lastIndexOf("/"));
    if (vertical) return base + "/oardefault.jpg";
    return ancho >= 200 ? base + "/hq720.jpg" : url;
  };
  M5.idVideo = function (url) {
    const m = /(?:v=|youtu\.be\/|shorts\/)([A-Za-z0-9_-]{11})/.exec(url || "");
    return m ? m[1] : url;
  };

  // ------------------------------------------------------------------------------------------------ la tarjeta
  const Tarjeta = window.Tarjeta = {};
  const PLANTILLA = document.createElement("template");
  PLANTILLA.innerHTML = '<div class="tj" tabindex="-1" role="button"><div class="tj-img"><img alt="" decoding="async" draggable="false">' +
    '<span class="tj-dur"></span><div class="tj-visto"><i></i></div></div><div class="tj-txt"><div class="tj-tit"></div>' +
    '<div class="tj-aut"></div><div class="tj-meta"></div><div class="tj-mot"></div></div>' +
    '<button class="tj-mas" tabindex="-1" title="Más opciones" aria-label="Más opciones">⋮</button>' +
    '<button class="tj-quitar" tabindex="-1" title="Quitar" aria-label="Quitar">✕</button></div>';

  /** Un nodo vacío para el pool de la rejilla. */
  Tarjeta.crear = function () {
    const n = PLANTILLA.content.firstChild.cloneNode(true);
    n._p = {img: n.querySelector("img"), caja: n.querySelector(".tj-img"), dur: n.querySelector(".tj-dur"), visto: n.querySelector(".tj-visto i"),
      txt: n.querySelector(".tj-txt"), tit: n.querySelector(".tj-tit"), aut: n.querySelector(".tj-aut"), meta: n.querySelector(".tj-meta"),
      mot: n.querySelector(".tj-mot"), mas: n.querySelector(".tj-mas"), quitar: n.querySelector(".tj-quitar")};
    n._p.img.addEventListener("error", () => {   // sin hq720/oardefault: la miniatura pequeña (Imagenes de la Qt)
      const i = n._p.img, o = i._orig;
      if (o && i._src !== o) { if (i._src) sinNitida.add(i._src); i._src = o; i.src = o; }
    });
    // 22/10/2026 (visto en la tele, Música): sin hq720, YouTube contesta 404 CON una imagen gris de 120×90 («…») y el
    // navegador no da «error»: la tarjeta se quedaba gris. Una «nítida» de ese tamaño es que no existe → la pequeña
    n._p.img.addEventListener("load", () => {
      const i = n._p.img, o = i._orig;
      if (o && i._src && i._src !== o && i.naturalWidth <= 120 && i.naturalHeight <= 90) { sinNitida.add(i._src); i._src = o; i.src = o; }
    });
    return n;
  };

  /** Medidas de una forma: {ancho, alto, iw, ih} (Tarjeta._maquetar). forma: {fila, vertical, anchoImg, conMotivo}. */
  Tarjeta.medidas = function (forma, ancho, canal) {
    if (forma.fila) {
      const iw = forma.anchoImg || 246;
      const ih = Math.round(iw * 9 / 16);
      return {ancho, iw, ih, alto: Math.max(ih, forma.conMotivo ? 100 : 84) + 8};
    }
    const ih = forma.vertical ? Math.round(ancho * 16 / 9) : Math.round(ancho * 9 / 16);
    return {ancho, iw: ancho, ih, alto: ih + 10 + 42 + 19 + 19 + (forma.conMotivo ? 17 : 0) + 10};
  };

  // 06/10/2026 (rendimiento en el N100): cada escritura solo si cambia. Un nodo del pool que se reutiliza para otro
  // elemento de la MISMA forma solo cambia sus textos y la imagen; la geometría (clases, tamaños, posiciones) se escribe
  // una vez por forma. Así el cuadro del scroll no invalida estilos ni maquetado de lo que ya estaba bien.
  const sinNitida = new Set();   // las hq720/oardefault que no existen: a la pequeña directamente, sin volver a pedirlas
  const txt = (el, v) => { if (el._t !== v) { el._t = v; el.textContent = v; } };
  const est = (el, k, v) => { const c = el._c || (el._c = {}); if (c[k] !== v) { c[k] = v; el.style[k] = v; } };

  /** Rellena el nodo con el elemento e. m = medidas de la forma; o = {fila, vertical, quitar, motivo}. */
  Tarjeta.poner = function (n, e, m, o) {
    const p = n._p;
    const canal = e.tipo === "CANAL";
    const fila = !!o.fila;
    if (n._e === e && n._forma === m) return;
    n._e = e; n._forma = m;
    const clave = (fila ? "f" : "r") + (o.vertical ? "v" : "") + (canal ? "c" : "") + (o.quitar ? "q" : "") + e.tipo;
    if (n._formaM !== m || n._clave !== clave) {   // la geometría: solo al cambiar de forma (ancho, fila, canal…)
      n._formaM = m; n._clave = clave;
      n.className = "tj " + (fila ? "tj-fila" : "tj-rejilla") + (o.vertical ? " tj-vertical" : "") + (canal ? " tj-canal" : "") +
        (e.tipo === "VIDEO" ? " es-video" : "") + (o.quitar ? " con-quitar" : "") + (e.tipo === "LISTA" ? " tj-lista" : "") +
        (n._visto ? " con-visto" : "");
      est(n, "width", m.ancho + "px");
      est(n, "height", m.alto + "px");
      let iw = m.iw, ih = m.ih, ix = 0, iy = 0;
      if (fila) {
        ix = 4; iy = 4;
        if (canal) { ih = Math.min(136, Math.round(m.iw * 0.55)); iw = ih; ix = 4 + Math.round((m.iw - iw) / 2); }
      } else if (canal) {
        iw = ih = Math.min(m.ancho, 160);
        ix = Math.round((m.ancho - iw) / 2);
      }
      n._iw = iw;
      est(p.caja, "width", iw + "px"); est(p.caja, "height", ih + "px"); est(p.caja, "transform", `translate(${ix}px, ${iy}px)`);
      if (fila) {
        est(p.txt, "left", (m.iw + 16) + "px"); est(p.txt, "top", "4px"); est(p.txt, "bottom", "4px");
        est(p.txt, "right", ((e.tipo === "VIDEO" ? 34 : 4) + (o.quitar ? 30 : 0)) + "px");
        est(p.mas, "right", (o.quitar ? 30 : 0) + "px");
      } else {
        est(p.txt, "top", (canal ? Math.min(m.ancho, 160) : m.ih) + 10 + "px"); est(p.txt, "left", "0px"); est(p.txt, "bottom", "0px");
        est(p.txt, "right", canal ? "0px" : "34px");
        est(p.mas, "top", (m.ih + 8) + "px");
        if (o.quitar) { est(p.quitar, "top", "4px"); est(p.quitar, "right", "4px"); }
      }
    }
    // el contenido
    const orig = e.miniatura || "";
    let url = canal ? orig : M5.nitida(orig, !!o.vertical, n._iw);
    if (url !== orig && sinNitida.has(url)) url = orig;
    p.img._orig = orig;
    if (url) { if (p.img._src !== url) { p.img._src = url; p.img.src = url; } }
    else if (p.img._src) { p.img._src = ""; p.img.removeAttribute("src"); }
    txt(p.dur, e.duracion > 0 ? M5.tiempo(e.duracion) : (e.tipo === "LISTA" ? "LISTA" : ""));
    const visto = e.tipo === "VIDEO" ? Math.max(0, Math.min(100, +e.visto || 0)) : 0;
    if ((visto > 0) !== !!n._visto) { n._visto = visto > 0; n.classList.toggle("con-visto", n._visto); }
    if (visto > 0) est(p.visto, "width", visto + "%");
    const titulo = e.titulo || "";
    txt(p.tit, titulo);
    if (n._tit !== titulo) { n._tit = titulo; p.tit.title = titulo; n.setAttribute("aria-label", titulo); }
    txt(p.aut, canal ? "" : (e.autor || ""));
    txt(p.meta, M5.pie(e));
    txt(p.mot, o.motivo || "");
  };

  /** Qué parte de la tarjeta está bajo el ratón (Tarjeta._zonas 192): «mas», «quitar», «autor» o «tarjeta». */
  Tarjeta.zona = function (objetivo) {
    if (!objetivo || !objetivo.closest) return "tarjeta";
    if (objetivo.closest(".tj-mas")) return "mas";
    if (objetivo.closest(".tj-quitar")) return "quitar";
    if (objetivo.closest(".tj-aut")) return "autor";
    return "tarjeta";
  };

  /**
   * Un clic (mousePressEvent 375). boton: 0 izq, 1 central. ctx = {quitar(e), menu(e, x, y), rejilla}.
   * Izq → abrir · autor → canal · ⋮ → menú · ✕ → quitar · central o Ctrl+clic → pestaña nueva (sobre el autor, el
   * canal) · Mayús+clic en un vídeo → ver a la vez.
   */
  Tarjeta.pulsar = function (ev, e, zona, ctx) {
    const boton = ev.button;
    if (boton === 1 || (boton === 0 && (ev.ctrlKey || ev.metaKey))) {
      if (zona === "autor" && e.autorUrl) return M5.abrirCanal(e.autorUrl, true);
      return M5.nuevaPestana(e);
    }
    if (boton !== 0) return;
    if (zona === "mas" && e.tipo === "VIDEO") return ctx.menu(e, ev.clientX, ev.clientY);
    if (zona === "quitar" && ctx.quitar) return ctx.quitar(e);
    if (ev.shiftKey && e.tipo === "VIDEO") return M5.rep("verALaVez", e);
    if (zona === "autor" && e.autorUrl) return M5.abrirCanal(e.autorUrl, false);
    return M5.abrir(e);
  };
})();
