// Cat-ode escritorio · interfaz web, módulo M7 (06/10/2026): la página Ajustes (interfaz.py 3770-3926, con
// _pintar_vetos_ajustes 3132, _nuevo_tema 3156 e _importar 3919). Cada casilla escribe su clave real de
// escritorio-ajustes.json con PUT /api/ajustes (calidad, automatica, reanudar, vista_previa, avisos, patrocinios,
// cuenta_miembros, interfaz); el remoto va por POST /api/remoto (apagar_remoto lo guarda el servidor), los temas y los
// fulminados por POST /api/datos, la importación por POST /api/importar. 18/10/2026: arriba, «Traer mi YouTube» (cuenta.js,
// /api/cuenta): «Actualizar cuenta desde YouTube» y «Actualizar YouTube desde Cat-ode».
//   CatodeM7.paginas.ajustes(contenedor) → {salir(), titulo, refrescar()}
"use strict";
(function () {
  const M7 = window.CatodeM7 = window.CatodeM7 || {};
  M7.paginas = M7.paginas || {};

  function PaginaAjustes(cont, a, ctx) {
    ctx = ctx || {};
    const U = M7.util, el = U.el;
    const limpiar = [];
    let estado = {}, vivo = true;
    const raiz = el("div", {class: "m7 aj"});
    const caja = el("div", {class: "aj-caja"});
    raiz.append(caja);
    cont.append(raiz);
    const seccion = (texto) => caja.append(el("h2", {class: "aj-seccion", text: texto}));
    const parrafo = (texto) => { const p = el("p", {class: "aj-texto", text: texto}); caja.append(p); return p; };
    const gris = (texto) => { const p = el("p", {class: "aj-texto m7-gris", text: texto || ""}); caja.append(p); return p; };
    const casillas = {};
    function casilla(texto, clave, defecto, alCambiar) {
      const i = el("input", {type: "checkbox", class: "aj-interruptor", "data-clave": clave});
      i.checked = !!M7.ajuste(clave, defecto);
      i.addEventListener("change", async () => { await M7.ponerAjuste(clave, i.checked); alCambiar && alCambiar(i.checked); });
      caja.append(el("label", {class: "m7-casilla aj-casilla"}, i, el("span", {text: texto})));
      casillas[clave] = {i, defecto};
      return i;
    }

    caja.append(el("h1", {class: "aj-titulo", text: "Ajustes"}));

    // ---- Traer mi YouTube (18/10/2026, cuenta.js): lo primero, para un equipo nuevo
    const cuentaYT = window.catode && window.catode.cuenta && window.catode.cuenta.seccion(caja);
    if (cuentaYT) limpiar.push(() => cuentaYT.destruir());

    // ---- Reproducción
    seccion("Reproducción");
    const calidad = el("select", {class: "aj-calidad", "aria-label": "Calidad por defecto", "data-clave": "calidad"},
      el("option", {value: "auto", text: "Automática (según el tamaño del vídeo)"}),
      [360, 480, 720, 1080, 1440, 2160].map((a) => el("option", {value: String(a), text: `${a}p`})));
    caja.append(el("label", {class: "aj-fila"}, el("span", {text: "Calidad por defecto"}), calidad));
    calidad.addEventListener("change", () => {
      const v = calidad.value === "auto" ? "auto" : Number(calidad.value);
      M7.ponerAjuste("calidad", v);
      // «auto» tal cual (0 lo leía la Qt como altura ≤ 0); sin crear reproductores: el que se ve, si lo hay
      const g = window.Reproductor && window.Reproductor.gestor;
      if (g && g.ajustes) g.ajustes.calidad = v;
      const r = g && typeof g.vista === "function" ? g.vista() : M7.rep();
      if (r && r.calidad) r.calidad(v);
    });
    casilla("Reproducción automática: al acabar, sigue con un vídeo relacionado", "automatica", true);
    casilla("Seguir donde lo dejé al volver a abrir un vídeo", "reanudar", true);
    casilla("Vista previa sin sonido al posar el ratón sobre un vídeo", "vista_previa", true);
    casilla("Avisarme (aviso del sistema) cuando mis canales suban vídeos nuevos", "avisos", false);
    casilla("Saltar patrocinios, autopromociones y «suscríbete» (SponsorBlock)", "patrocinios", true,
      (s) => { const r = M7.rep(); if (r) r.saltar_patrocinios = s; });

    // ---- Enlaces de YouTube (solo Windows; 19/10/2026 «catode tiene que abrir los enlaces a youtube en los que haces clic
    // en todos los sistemas en los que se instala»): Windows solo deja que lo elija la persona, en Ajustes del sistema
    const bloqueEnlaces = el("div", {class: "aj-bloque", hidden: true});
    caja.append(bloqueEnlaces);
    const estadoEnlaces = el("p", {class: "aj-texto aj-enlaces-estado"});
    const bEnlaces = el("button", {class: "m7-boton aj-enlaces", text: "Abrir los enlaces de YouTube con Cat-ode"});
    bloqueEnlaces.append(el("h2", {class: "aj-seccion", text: "Enlaces de YouTube"}),
      el("p", {class: "aj-texto", text: "Los enlaces de YouTube en los que haces clic (WhatsApp, correo, otras apps) se abren en Cat-ode y los demás en tu navegador de siempre. Al pulsar, Windows abre su página de aplicaciones predeterminadas: pulsa «Establecer valor predeterminado»."}),
      estadoEnlaces, bEnlaces);
    async function pintarEnlaces() {
      const r = await M7.api("/api/ventana", {accion: "enlaces", valor: "estado"}).catch(() => null);
      if (!vivo || !r) return;
      estadoEnlaces.textContent = r.predeterminado ? "✓ Ya se abren en Cat-ode." : "Ahora se abren en el navegador.";
      bEnlaces.hidden = !!r.predeterminado;
    }
    bEnlaces.addEventListener("click", async () => {
      await M7.api("/api/ventana", {accion: "enlaces", valor: "pedir"}).catch(() => null);
      setTimeout(pintarEnlaces, 15000);
    });
    const alVolver = () => { if (!bloqueEnlaces.hidden) pintarEnlaces(); };   // de vuelta de los Ajustes de Windows
    window.addEventListener("focus", alVolver);
    limpiar.push(() => window.removeEventListener("focus", alVolver));

    // ---- Escritorio remoto (solo Windows; con los datos de prueba también, para probarlo: remoto.py no toca Sunshine)
    const bloqueRemoto = el("div", {class: "aj-bloque", hidden: true});
    caja.append(bloqueRemoto);
    const remoto = el("input", {type: "checkbox", class: "aj-interruptor aj-remoto", "data-clave": "apagar_remoto"});
    bloqueRemoto.append(el("h2", {class: "aj-seccion", text: "Escritorio remoto"}),
      el("p", {class: "aj-texto", text: "Si manejas este equipo por Moonlight y a la vez ves Cat-ode en su pantalla, el remoto le quita fluidez al vídeo. «Apagar» cierra la sesión del remoto; el portátil se queda esperando y vuelve a conectar solo al «encender». También con F9."}),
      el("label", {class: "m7-casilla aj-casilla"}, remoto, el("span", {text: "Apagar el remoto (el portátil reconecta solo al encenderlo)"})));
    remoto.addEventListener("change", async () => {
      const r = await M7.api("/api/remoto", {apagar: remoto.checked});
      if (!r.ok) { remoto.checked = !remoto.checked; return M7.fallo(r, "No he podido con el remoto"); }
      if (M7._ajustes) M7._ajustes.apagar_remoto = remoto.checked;
      if (window.app && typeof window.app.ponerRemoto === "function") window.app.ponerRemoto(remoto.checked);   // F9 y menú ⚙
      M7.avisar(r.texto || (remoto.checked ? "Remoto apagado" : "Remoto encendido"));
    });
    limpiar.push(M7.on("remoto", (d) => { if (d && "apagado" in d) remoto.checked = !!d.apagado; }));

    // ---- Sincronización
    seccion("Sincronización con tus dispositivos");
    parrafo("Suscripciones, historial, ver más tarde, me gusta, listas y por dónde vas en cada vídeo, a través de tu servidor.");
    const sincro = gris("");
    sincro.classList.add("aj-sincro");
    const bSincro = el("button", {class: "m7-boton aj-sincronizar", text: "Sincronizar ahora"});
    caja.append(bSincro);
    bSincro.addEventListener("click", async () => {
      bSincro.disabled = true; sincro.textContent = "Sincronizando…";
      const r = await M7.api("/api/datos", {accion: "sincronizar"});
      bSincro.disabled = false;
      sincro.textContent = r.ok ? (r.sincro || "Sincronizado") : (r.error || "No he podido sincronizar");
    });
    limpiar.push(M7.on("sincro", (d) => { if (d && d.estado) sincro.textContent = d.estado; }));

    // ---- Temas filtrados y canales fulminados
    seccion("Temas filtrados");
    parrafo("Nada cuyo título, canal o descripción tenga estas palabras («ultra*» vale para lo que empieza así).");
    const cajaTemas = el("div", {class: "aj-lista aj-temas"});
    caja.append(cajaTemas);
    const bTema = el("button", {class: "m7-boton aj-nuevo-tema", text: "＋  Añadir un tema…"});
    caja.append(bTema);
    bTema.addEventListener("click", () => nuevoTema());
    seccion("Canales fulminados");
    const cajaFulminados = el("div", {class: "aj-lista aj-fulminados"});
    caja.append(cajaFulminados);
    const fila = (texto, negrita, boton, accion) => el("div", {class: "aj-vetado"},
      el("span", {class: "aj-vetado-texto"}, negrita ? el("b", {text: negrita}) : null, texto),
      el("button", {class: "m7-boton", text: boton, onclick: accion}));
    async function pintarVetos() {
      const r = await M7.api("/api/vetos");
      if (!vivo || !r.ok) return;
      cajaTemas.textContent = "";
      for (const [nombre, pal] of r.temas || []) {
        cajaTemas.append(fila(` · ${(pal || []).join(", ")}`, nombre, "Quitar", async () => {
          const x = await M7.api("/api/datos", {accion: "quitar_tema", nombre});
          if (!x.ok) return M7.fallo(x);
          M7.avisar(`Tema «${nombre}» quitado`); vetosCambiados(); pintarVetos();
        }));
      }
      cajaFulminados.textContent = "";
      const fs = r.fulminados || [];
      if (!fs.length) cajaFulminados.append(el("p", {class: "aj-texto m7-gris", text: "Ninguno. Se fulmina desde el menú de cada vídeo, la página del vídeo o la del canal."}));
      for (const [url, nombre] of fs) {
        cajaFulminados.append(fila(nombre, "", "Indultar", async () => {
          const x = await M7.api("/api/datos", {accion: "indultar", url});
          if (!x.ok) return M7.fallo(x);
          M7.avisar(`«${nombre}» indultado`); vetosCambiados(); pintarVetos();
        }));
      }
    }
    async function nuevoTema() {   // _nuevo_tema: nombre y palabras separadas por comas
      const d = await M7.dialogo({titulo: "Tema filtrado", campos: [{etiqueta: "Nombre del tema (p. ej. «fachas»):"}, {etiqueta: "Palabras, separadas por comas:"}],
        botones: [{texto: "Cancelar", valor: null}, {texto: "Filtrar", valor: "si", principal: true}]});
      if (!d || d.boton !== "si" || !d.campos[0].trim()) return;
      const palabras = d.campos[1].split(",").map((x) => x.trim()).filter(Boolean);
      const r = await M7.api("/api/datos", {accion: "tema", nombre: d.campos[0].trim(), palabras});
      if (!r.ok) return M7.fallo(r);
      M7.avisar(`Tema «${d.campos[0].trim()}» filtrado en todos tus Cat-ode`);
      vetosCambiados(); pintarVetos();
    }
    function vetosCambiados() { for (const f of M7._alVetar || []) try { f(); } catch (e) { /* nada */ } }
    limpiar.push(M7.alVetar(() => pintarVetos()));
    limpiar.push(M7.on("datos", (d) => { if (!d || !d.col || /tema|fulmin|veto/.test(d.col)) pintarVetos(); }));

    // ---- Vídeos solo para miembros
    seccion("Vídeos solo para miembros");
    parrafo("Los vídeos de miembros se piden con la sesión de YouTube de tu navegador y esta cuenta (solo esos: nunca para buscar, para el Inicio ni para descargar).");
    const cuenta = el("select", {class: "aj-cuenta", "aria-label": "Cuenta para los vídeos de miembros", "data-clave": "cuenta_miembros"});
    caja.append(el("label", {class: "aj-fila"}, el("span", {text: "Cuenta"}), cuenta));
    const avisoMiembros = gris("Buscando las cuentas abiertas en tus navegadores…");
    let cuentas = [];
    function pintarCuentas() {
      const actual = M7.ajuste("cuenta_miembros", null) || {};
      cuenta.textContent = "";
      cuenta.append(el("option", {value: "", text: "Ninguna"}));
      const todas = cuentas.slice();
      if (actual.nombre && !todas.some((c) => (c.nombre || "").toLowerCase() === actual.nombre.toLowerCase())) todas.unshift({navegador: actual.navegador, nombre: actual.nombre, nav: actual.navegador});
      todas.forEach((c, k) => cuenta.append(el("option", {value: String(k), text: `${c.cuenta || c.nombre} (${c.nav || c.navegador})`})));
      cuenta._todas = todas;
      const k = todas.findIndex((c) => actual.nombre && ((c.cuenta || c.nombre) || "").toLowerCase() === actual.nombre.toLowerCase());
      cuenta.value = k >= 0 ? String(k) : "";
    }
    cuenta.addEventListener("change", () => {
      const c = cuenta.value === "" ? null : cuenta._todas[Number(cuenta.value)];
      M7.ponerAjuste("cuenta_miembros", c ? {navegador: c.navegador, nombre: c.cuenta || c.nombre} : null);
    });
    async function buscarCuentas() {
      const r = await M7.api("/api/miembros/cuentas");
      if (!vivo) return;
      // del servidor: {navegador, nombre (el del navegador), cuenta (el de la cuenta)}
      cuentas = r.ok ? (r.cuentas || []).map((c) => ({navegador: c.navegador, nav: c.nombre, cuenta: c.cuenta, nombre: c.cuenta})) : [];
      pintarCuentas();
      avisoMiembros.textContent = cuentas.length ? `${cuentas.length} cuentas y canales abiertos en tus navegadores`
        : "No hay ninguna sesión de YouTube abierta en Firefox, Chrome, Edge o Brave";
    }

    // ---- Importar y exportar
    seccion("Importar de YouTube");
    parrafo("El archivo «suscripciones.csv» de Google Takeout");
    const archivo = el("input", {type: "file", accept: ".csv,text/csv,.json,application/json", class: "aj-archivo", hidden: true});
    const bImportar = el("button", {class: "m7-boton aj-importar", text: "Importar suscripciones…"});
    caja.append(archivo, bImportar);
    bImportar.addEventListener("click", () => archivo.click());
    archivo.addEventListener("change", async () => {
      const f = archivo.files && archivo.files[0];
      if (!f) return;
      const texto = await f.text();
      archivo.value = "";
      await importar(texto, f.name);
    });
    async function importar(texto, nombre) {
      if (/\.json$/i.test(nombre || "")) return importarCopia(texto);
      const r = await M7.api("/api/importar", {texto});
      if (!r.ok) return M7.fallo(r, "No he podido importarlo");
      M7.avisar(`Importados ${r.n} canales`);
      const c = M7.cat(); if (typeof c.pintarCanales === "function") c.pintarCanales();
      return r;
    }
    seccion("Copia de tus ajustes");
    parrafo("Tus ajustes, temas filtrados y canales fulminados en un archivo, para llevarlos a otro equipo (se vuelven a cargar con «Importar…»).");
    const bExportar = el("button", {class: "m7-boton aj-exportar", text: "Exportar ajustes…"});
    caja.append(bExportar);
    async function copia() {
      const v = await M7.api("/api/vetos");
      const aj = Object.assign({}, await M7.ajustes(true));
      for (const k of ["geometria", "pestanas", "pestana_activa", "pip_geometria", "avisados"]) delete aj[k];
      return {catode: "ajustes", version: estado.version || "", ajustes: aj, temas: (v.ok && v.temas) || [], fulminados: (v.ok && v.fulminados) || []};
    }
    bExportar.addEventListener("click", async () => {
      const datos = await copia();
      const url = URL.createObjectURL(new Blob([JSON.stringify(datos, null, 1)], {type: "application/json"}));
      const a = el("a", {href: url, download: "catode-ajustes.json", hidden: true});
      document.body.append(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 5000);
      M7.avisar("Ajustes exportados: catode-ajustes.json");
    });
    async function importarCopia(texto) {
      let d;
      try { d = JSON.parse(texto); } catch (e) { return M7.avisar("Ese archivo no es una copia de los ajustes de Cat-ode"); }
      if (!d || d.catode !== "ajustes") return M7.avisar("Ese archivo no es una copia de los ajustes de Cat-ode");
      if (d.ajustes) await M7.api("/api/ajustes", d.ajustes, "PUT");
      for (const [nombre, palabras] of d.temas || []) await M7.api("/api/datos", {accion: "tema", nombre, palabras});
      if ((d.fulminados || []).length) await M7.api("/api/datos", {accion: "fulminar_lote", urls: d.fulminados.map(([url, nombre]) => ({url, nombre}))});
      await M7.ajustes(true);
      vetosCambiados();
      M7.avisar("Ajustes importados");
      pagina.refrescar();
    }
    M7._ajustesCopia = {copia, importar};   // para las pruebas

    // ---- Descargas, actualizaciones, interfaz y atajos
    seccion("Descargas");
    const carpeta = gris("");
    carpeta.classList.add("aj-carpeta");
    const bCarpeta = el("button", {class: "m7-boton aj-abrir-carpeta", text: "Abrir la carpeta"});
    caja.append(bCarpeta);
    bCarpeta.addEventListener("click", () => M7.ventana("carpeta_descargas"));
    seccion("Actualizaciones");
    const actualizacion = gris("Al día");
    actualizacion.classList.add("aj-actualizacion");
    limpiar.push(M7.on("actualizacion", (d) => { if (d && d.estado) actualizacion.textContent = d.estado; }));
    const bloqueInterfaz = el("div", {class: "aj-bloque", hidden: true});
    caja.append(bloqueInterfaz);
    const clasica = el("input", {type: "checkbox", class: "aj-interruptor aj-clasica", "data-clave": "interfaz"});
    bloqueInterfaz.append(el("h2", {class: "aj-seccion", text: "Interfaz"}),
      el("label", {class: "m7-casilla aj-casilla"}, clasica, el("span", {text: "Usar la interfaz clásica la próxima vez que abra Cat-ode"})),
      el("p", {class: "aj-texto m7-gris", text: "También se abre una vez con «catode.pyw --clasica». Si esta interfaz no arranca, Cat-ode vuelve sola a la clásica."}));
    clasica.addEventListener("change", () => M7.ponerAjuste("interfaz", clasica.checked ? "qt" : "web"));
    seccion("Atajos de teclado");
    gris("Espacio o K: pausa · J / L: 10 s atrás / adelante · ← / →: 5 s · ↑ / ↓: volumen · 0-9: ir al 0-90 % · F: pantalla completa · " +
      "T: modo cine · I: imagen en imagen · M: silenciar · Mayús+N / Mayús+P: siguiente / anterior · /: buscar · Alt+←: atrás · F9: apagar el remoto");
    const bAtajos = el("button", {class: "m7-boton aj-atajos", text: "Ver todos los atajos", hidden: true});
    caja.append(bAtajos);
    // ver_atajos de M4: window.catode.atajos.verAtajos o app.verAtajos (antes se buscaba en window.catode y el botón no salía nunca)
    const verAtajos = () => { const c = M7.cat(), f = (c.atajos && c.atajos.verAtajos) || c.verAtajos || (window.app && window.app.verAtajos); return typeof f === "function" ? f : null; };
    bAtajos.addEventListener("click", () => { const f = verAtajos(); if (f) f(); });
    const pie = el("p", {class: "aj-pie"});
    caja.append(pie);

    const pagina = {
      titulo: "Ajustes", visible: true, raiz, casillas,
      async refrescar() {   // ajustes_pagina: sincro, actualización y vetos al día antes de mostrar
        const [aj, e] = await Promise.all([M7.ajustes(true), M7.api("/api/estado")]);
        if (!vivo) return;
        estado = e.ok ? e : {};
        for (const {i, defecto} of Object.values(casillas)) { const v = aj[i.dataset.clave]; i.checked = v === undefined ? !!defecto : !!v; }
        const c = aj.calidad === undefined ? "auto" : String(aj.calidad);
        calidad.value = [...calidad.options].some((o) => o.value === c) ? c : "auto";
        const ventanas = estado.so === "nt" || !!estado.fixtures;
        bloqueRemoto.hidden = !ventanas;
        bloqueEnlaces.hidden = !ventanas;
        if (ventanas) pintarEnlaces();
        bloqueInterfaz.hidden = !ventanas;
        remoto.checked = !!aj.apagar_remoto;
        clasica.checked = aj.interfaz === "qt";
        sincro.textContent = estado.sincro || "";
        actualizacion.textContent = estado.actualizacion || "Al día";
        pie.textContent = `Cat-ode ${estado.version || ""} · sin anuncios ni pausas`;
        bAtajos.hidden = !verAtajos();
        pintarCuentas();
        pintarVetos();
        M7.api("/api/pagina/descargas").then((d) => { if (vivo) carpeta.textContent = (d.ok && d.carpeta) || ""; });
      },
      salir() { vivo = false; for (const f of limpiar) try { f && f(); } catch (e) { /* nada */ } raiz.remove(); },
    };
    pagina.destruir = pagina.salir;   // contrato de app.js (M4)
    if (typeof ctx.titulo === "function") ctx.titulo("Ajustes");
    pagina.refrescar().then(() => buscarCuentas());
    return pagina;
  }
  M7.paginas.ajustes = PaginaAjustes;
  if (typeof M7.registrar === "function") M7.registrar();
})();
