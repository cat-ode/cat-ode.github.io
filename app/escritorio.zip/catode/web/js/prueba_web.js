// Cat-ode escritorio · interfaz web: la batería de la interfaz DENTRO de la página (módulo M8, DISENO_WEB.md §4), 06/10/2026.
// Equivale a catode/prueba.py para la Qt: los mismos pasos (secciones, chips, buscar, abrir un vídeo, mandos, mini, cola,
// pestañas, atajos, Ajustes, zoom, atrás/adelante…), pero con eventos del DOM (sin entrada simulada del sistema).
// La inyectan prueba_web.py (Linux: Playwright Chromium headless) o VentanaWeb --prueba (Windows: ExecuteScriptAsync).
// Cada paso escribe «OK  nombre» o «FALLA nombre  motivo» por POST /api/prueba (el servidor lo imprime como prueba.py) y
// al final {fin, bien, total}. Uso: catode.prueba.correr({pestanas: N}) → promesa con {bien, total, resultados}.
// Sin red: el servidor debe ir con fixtures (CATODE_PRUEBA_INTERFAZ=1); el vídeo es el archivo local por /<id>.
(function () {
  "use strict";
  const C = window.catode = window.catode || {};
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => [...(r || document).querySelectorAll(s)];
  const dormir = (ms) => new Promise((ok) => setTimeout(ok, ms));
  const resultados = [];
  let enviar = true;

  async function esperar(fn, ms) {
    const fin = performance.now() + (ms || 5000);
    while (performance.now() < fin) {
      try { const v = fn(); if (v) return v; } catch (e) { /* aún no */ }
      await dormir(50);
    }
    try { return fn(); } catch (e) { return null; }
  }
  async function anotar(nombre, bien, detalle) {
    bien = !!bien;
    detalle = detalle === undefined ? "" : (typeof detalle === "string" ? detalle : JSON.stringify(detalle));
    resultados.push({nombre, bien, detalle});
    (bien ? console.log : console.warn)(`${bien ? "OK    " : "FALLA "} ${nombre}  ${detalle}`);
    if (enviar) try { await C.api.post("/api/prueba", {nombre, bien, detalle: detalle.slice(0, 300)}); } catch (e) { /* sin servidor de prueba */ }
    if (!bien && enviar) try { await C.api.post("/api/prueba", {registro: "diag " + nombre.slice(0, 30) + ": " + diag()}); } catch (e) { /* nada */ }
  }
  function diag() {   // el estado en cada FALLA: foco, iframes, reproductor que suena (06/10/2026, Windows)
    try {
      const a = document.activeElement;
      const ae = a ? a.tagName + (a.id ? "#" + a.id : "") + (typeof a.className === "string" && a.className ? "." + a.className.split(" ")[0] : "") : "-";
      const ifs = [...document.querySelectorAll("iframe")].map((f) => { const r = f.getBoundingClientRect(); return `${Math.round(r.width)}x${Math.round(r.height)}${f.offsetParent ? "" : "(oculto)"}`; }).join(",");
      const r = repSuena(), e = r && r.estado;
      const est = e ? JSON.stringify({t: e.t, d: e.d, p: e.p, rs: e.rs, ns: e.ns, error: e.error, listo: e.listo, fin: e.fin, notas: e.notas}) : "-";
      const g = G();
      return `foco=${ae} hasFocus=${document.hasFocus()} vis=${document.visibilityState} cambiosVis=[${cambiosVis}] f=${fActual()} iframes=[${ifs}] rep=${est}` +
        (g ? ` manda=${g.porque} [${g.cambios.join(" | ")}]` : "");
    } catch (x) { return "diag: " + x; }
  }
  // la visibilidad de la página (06/10/2026): Edge marca oculta la ventana tapada o minimizada, y entonces no deja empezar
  // el vídeo de un marco nuevo hasta que se vea
  const cambiosVis = [];
  document.addEventListener("visibilitychange", () => { if (cambiosVis.length < 10) cambiosVis.push(document.visibilityState[0] + "@" + Math.round(performance.now() / 1000)); });
  // el estado de un reproductor pedido AHORA a su iframe (readyState, networkState, paused, play(), visibilidad, fuente…)
  async function diagRep(r) {
    if (!r) return "sin reproductor";
    try {
      const antes = r.ultimo;
      r._orden("estado");
      await esperar(() => r.ultimo && r.ultimo !== antes, 800);
      const e = r.ultimo || {};
      const c = r._cargado;
      return `iframe{t=${e.t} rs=${e.rs} ns=${e.ns} paused=${e.paused} ended=${e.ended} play=${e.play} vis=${e.vis} err=${e.err} src=…${e.src} orden=${e.cn}/${e.ct}}` +
        ` prematuros=${r._prematuros || 0} cargado=${c ? `${c.n}/${c.como} vis=${c.vis} rs=${c.rs} ns=${c.ns} …${c.fuente}` : "nunca"} n=${r._n_cargar} listo=${r.listo} pend=${r._pendientes.length} cargas=${r._cargas} congelado=${!!r.congelado} fondo=${r.fondo}`;
    } catch (x) { return "diagRep: " + x; }
  }
  async function paso(nombre, fn) {
    try {
      const r = await fn();
      if (r && typeof r === "object" && "bien" in r) await anotar(nombre, r.bien, r.detalle);
      else await anotar(nombre, !!r, "");
    } catch (e) {
      await anotar(nombre, false, "excepción: " + (e && e.stack ? String(e.stack).split("\n").slice(0, 2).join(" | ") : e));
    }
  }
  // teclas como las daría el teclado (los oyentes de atajos.js y mandos.js no miran isTrusted)
  function tecla(key, mods, destino) {
    mods = mods || {};
    const code = key.length === 1 ? (/[a-z]/i.test(key) ? "Key" + key.toUpperCase() : /[0-9]/.test(key) ? "Digit" + key : "") :
      key === " " ? "Space" : key;
    const ev = new KeyboardEvent("keydown", {key, code, ctrlKey: !!mods.ctrl, shiftKey: !!mods.mayus, altKey: !!mods.alt,
      bubbles: true, cancelable: true, composed: true});
    (destino || document.activeElement || document.body).dispatchEvent(ev);
    (destino || document.activeElement || document.body).dispatchEvent(new KeyboardEvent("keyup", {key, code, bubbles: true}));
    return ev.defaultPrevented;
  }
  function raton(el, tipo, op) {
    op = op || {};
    const r = el.getBoundingClientRect();
    const x = op.x !== undefined ? op.x : r.left + Math.min(r.width / 2, 40), y = op.y !== undefined ? op.y : r.top + Math.min(r.height / 2, 40);
    el.dispatchEvent(new MouseEvent(tipo, {bubbles: true, cancelable: true, composed: true, clientX: x, clientY: y,
      button: op.boton || 0, buttons: op.boton === 2 ? 2 : 1, ctrlKey: !!op.ctrl, shiftKey: !!op.mayus, view: window}));
  }
  const P = () => C.pestanas;
  const activa = () => P().activa();
  const fActual = () => { const p = activa(); return p && p.pila.length ? p.pila[p.pila.length - 1].f : ""; };
  const cuerpo = () => { const p = activa(); return p && p.cuerpo; };
  const tarjetas = () => { const c = cuerpo(); return c ? $$(".tj", c).filter((n) => n._e && n.offsetParent !== null) : []; };
  const rep = () => C.reproductor;
  const repSuena = () => { const p = P().lista.find((x) => x.rep && x.rep.actual); return p ? p.rep : null; };
  // 07/10/2026 · RATÓN REAL dentro del motor (Windows: /api/ventana «raton», por DevTools de WebView2; sin tocar el ratón del
  // sistema). El gesto hace el camino del autor: quién está bajo el cursor, el <video> del iframe, su postMessage. Hasta hoy el
  // «doble clic DENTRO del vídeo» era rep()._mensaje({tipo:"doble"}): se saltaba todo eso y daba por bueno lo que al autor no
  // le funcionaba. Devuelve false donde no hay ratón real (Linux headless: ahí lo cubre pruebas/web/completa_mandos.py).
  const centroVideo = (fx, fy) => {
    const f = rep() && rep().iframe, r = f && f.getBoundingClientRect();
    return r && r.width > 0 && r.height > 0 ? {x: r.left + r.width * (fx === undefined ? 0.5 : fx), y: r.top + r.height * (fy === undefined ? 0.5 : fy)} : null;
  };
  let ratonRealHay = null;   // null: sin saber; false: la ventana no lo admite
  const ratonReal = async (tipo, fx, fy) => {
    if (ratonRealHay === false) return false;
    const c = centroVideo(fx, fy);
    if (!c) { ratonRealHay = ratonRealHay || null; return false; }
    try {
      const r = await C.api.ventana("raton", {x: Math.round(c.x), y: Math.round(c.y), tipo});
      ratonRealHay = !!(r && r.hecho);
    } catch (e) { ratonRealHay = false; }
    return ratonRealHay;
  };
  // doble clic sobre el vídeo: real si se puede; si no, como llegan los avisos del iframe (clic y luego doble). Dice cuál fue
  const dobleEnVideo = async () => (await ratonReal("doble")) ? "ratón real" : (rep()._mensaje({tipo: "clic"}), rep()._mensaje({tipo: "doble"}), "simulado");
  const moverEnVideo = async () => (await ratonReal("mover", 0.4, 0.45)) ? "ratón real" : (rep()._mensaje({tipo: "raton"}), "simulado");
  const idDe = (u) => { const m = /(?:v=|youtu\.be\/|shorts\/)([\w-]{11})/.exec(u || ""); return m ? m[1] : ""; };
  const G = () => window.Reproductor && window.Reproductor.gestor;
  const ajustes = async () => (await C.api.get("/api/ajustes")).ajustes || {};
  const json = (o) => JSON.stringify(o);
  // la CPU del equipo en 1 s (todo, lo de esta prueba y lo ajeno), medida por el servidor (catode/carga.py)
  async function cargaEquipo() { try { return await C.api.post("/api/prueba", {carga: 1}); } catch (e) { return null; } }

  async function seccion(clave, f, minimo) {
    const t0 = performance.now();
    app.irSeccion(clave);
    const ok = await esperar(() => fActual() === f && tarjetas().length >= (minimo || 1), 8000);
    const ms = Math.round(performance.now() - t0);
    const c = cuerpo();
    const cartel = c && $(".cartel", c);
    return {bien: !!ok && ms < 4000, detalle: `${tarjetas().length} tarjetas en ${ms} ms` + (cartel ? ` · cartel: ${cartel.textContent.slice(0, 80)}` : "")};
  }

  // peticiones en vuelo de la página (para medir la rejilla con la página quieta y saber qué se cuela), 06/10/2026
  const red = {vuelo: 0, urls: [], oir: false, llegadas: [], t0: 0, perfil: null};
  if (!window.__catodeFetchContado) {
    window.__catodeFetchContado = true;
    const f0 = window.fetch.bind(window);
    window.fetch = function (u, o) {
      const url = String(u && u.url || u);
      if (/\/api\/prueba/.test(url)) return f0(u, o);
      red.vuelo++;
      const tIda = performance.now();
      const corta = url.replace(/^https?:\/\/[^/]+/, "").split("?")[0].replace(/^\/api\//, "");
      if (red.oir && red.urls.length < 8) red.urls.push(corta);
      // la hora de cada respuesta (para saber qué respuesta cae dentro de un cuadro largo de la rejilla)
      return f0(u, o).finally(() => { red.vuelo--; if (red.perfil && red.perfil.length < 3000) red.perfil.push([tIda, performance.now(), corta]); if (red.oir && red.llegadas.length < 24) red.llegadas.push(corta + "@" + Math.round(performance.now() - red.t0)); });
    };
  }

  // el primer vídeo del Inicio (con red de verdad) → página del vídeo → /api/resolver (vía rápida visionOS) → HLS en el
  // iframe opaco. Bien si en 25 s el reproductor del iframe manda un estado con t > 3 s y resolución.
  async function videoReal() {
    const deSeccion = async (clave, ms) => {
      app.irSeccion(clave);
      return await esperar(() => fActual() === clave && tarjetas().find((x) => x._e.tipo === "VIDEO" && /^https?:/.test(String(x._e.url))), ms);
    };
    let n = await deSeccion("inicio", 20000), de = "Inicio";
    if (!n) { n = await deSeccion("historial", 8000); de = "Historial"; }   // perfil de prueba sin Inicio: el historial
    if (!n) {
      const c = cuerpo(), cartel = c && $(".cartel", c);
      return {bien: false, detalle: "motivo: ni el Inicio ni el Historial traen vídeos" + (cartel ? " · " + cartel.textContent.slice(0, 120) : "")};
    }
    const e = n._e, t0 = performance.now();
    raton(n, "click");
    // 07/10/2026: mudo desde el primer momento (datos aparte: no toca el volumen del autor); el mini PC es su tele
    esperar(() => rep() && rep().actual, 5000).then(() => { try { rep().volumen(0); if (!rep().mute) rep().silencio(); } catch (err) { /* nada */ } });
    const u = await esperar(() => { const r = rep(), m = r && r.actual && r.ultimo;
      return m && m.t > 3 && m.w > 0 && m.h > 0 && !m.error ? m : null; }, 25000);
    const seg = ((performance.now() - t0) / 1000).toFixed(1), r = rep(), m = r && r.ultimo;
    if (u) return {bien: true, detalle: `t=${(+u.t).toFixed(1)} · ${u.w}x${u.h} · drop=${u.drop || 0} de ${u.tot || 0} · ${seg} s · ${de}: «${String(e.titulo || "").slice(0, 50)}»`};
    const est = m ? `t=${m.t} ${m.w}x${m.h} rs=${m.rs} ns=${m.ns} error=${m.error} notas=${JSON.stringify(m.notas || []).slice(0, 160)}` : "sin estado del iframe";
    return {bien: false, detalle: `motivo: en 25 s no llega t>3 s con imagen · página ${fActual()} · tipo ${r && r.tipo} · ${est} · «${String(e.titulo || "").slice(0, 40)}»`};
  }

  // 07/10/2026 · el vídeo RECORDADO al arrancar (como la app del autor): pulsar ▶ del cartel, doble clic (real si se puede)
  // → pantalla completa, y doble clic → vuelta. Con traza=true, la cronología de todo lo que toca la pantalla completa
  async function videoRecordado(traza) {
    const pv = P().lista.find((p) => p.pila.length && p.pila[p.pila.length - 1].f === "_mostrar_video");
    if (!pv) return {bien: false, detalle: "no hay pestaña de vídeo recordada"};
    if (activa() !== pv) P().activar(P().lista.indexOf(pv));
    const boton = await esperar(() => { const c = cuerpo() && $(".pv-cartel:not([hidden]) .pv-cartel-play", cuerpo()); return c && c.offsetParent !== null ? c : null; }, 8000);
    if (!boton) return {bien: false, detalle: `sin cartel ▶ en 8 s (página ${fActual()}, actual=${!!(rep() && rep().actual)})`};
    raton(boton, "click");
    const suena = await esperar(() => rep() && rep().actual && rep().ultimo && !rep().ultimo.idle && rep().pos > 0.5, 15000);
    if (!suena) return {bien: false, detalle: `tras pulsar ▶ el vídeo recordado no suena en 15 s (actual=${!!(rep() && rep().actual)} pos=${rep() && rep().pos})`};
    if (rep().pausa) rep().alternar();
    const cron = [], t00 = performance.now(), quitar = [];
    const est = () => `${app.enCompleta() ? "C" : "c"}${CatodeM7.capa.modo[0]}${app._ventanaReal ? "R" : "r"}n${app._ventanaN}`;
    const apunta = (t) => { cron.push(`${Math.round(performance.now() - t00)}:${t}[${est()}]`); if (cron.length > 80) cron.shift(); };
    if (traza) {
      const pila = () => (new Error().stack || "").split("\n").slice(3, 7).map((x) => x.trim().replace(/https?:\/\/[^/]+\//, "").replace(/\?v=[^:]+/, "").replace(/^at /, "")).join("<");
      const pc0 = CatodeM7.pantallaCompleta, po0 = app.ponerCompleta, re0 = CatodeM7.capa.ponerEn, mi0 = CatodeM7.capa.mini;
      CatodeM7.pantallaCompleta = function (q) { apunta(`pC(${q === undefined ? "" : q})<${pila()}`); const r = pc0.apply(this, arguments); apunta("·"); return r; };
      app.ponerCompleta = function (si) { apunta(`poner(${si})`); return po0.apply(this, arguments); };
      CatodeM7.capa.ponerEn = function (z, m) { apunta(`ponerEn(${m})<${pila()}`); return re0.apply(this, arguments); };
      CatodeM7.capa.mini = function () { apunta(`mini()<${pila()}`); return mi0.apply(this, arguments); };
      const f1 = (si) => apunta(`ev completa ${si}`), f2 = (d) => apunta(`sse ${d && d.completa} n${d && d.n}`);
      app.on("completa", f1); app.on("ventana", f2);
      quitar.push(() => { CatodeM7.pantallaCompleta = pc0; app.ponerCompleta = po0; CatodeM7.capa.ponerEn = re0; CatodeM7.capa.mini = mi0; });
    }
    if (traza) {   // qué hay bajo el cursor en el punto del doble clic, y dónde están las capas y los iframes
      const c = centroVideo() || {x: 0, y: 0};
      const desc = (n) => n ? `${n.tagName.toLowerCase()}${n.id ? "#" + n.id : ""}.${String(n.className || "").trim().split(/\s+/).slice(0, 3).join(".")}` : "nada";
      const rect = (n) => { if (!n) return "-"; const r = n.getBoundingClientRect(); return `${Math.round(r.left)},${Math.round(r.top)} ${Math.round(r.width)}x${Math.round(r.height)}`; };
      const pila = document.elementsFromPoint(c.x, c.y).slice(0, 5).map(desc).join(" > ");
      const ifr = [...document.querySelectorAll("iframe")].map((f) => `${desc(f)}@${rect(f)}${f === (rep() && rep().iframe) ? "*" : ""}`).join(" ; ");
      apunta(`punto ${Math.round(c.x)},${Math.round(c.y)} bajo: ${pila} | m7-capa@${rect(document.querySelector("#m7-capa"))} cm-capa@${rect(document.querySelector(".cm-capa"))} cm-fondo@${rect(document.querySelector(".cm-capa-fondo"))} | iframes ${ifr} | pestañas ${P().lista.length} activa ${P().indice ? P().indice() : "?"} reps ${P().lista.map((q) => q.rep ? (q.rep.actual ? "V" : "v") : "-").join("")}`);
    }
    // la BARRA de progreso y los mandos tienen que existir sobre el vídeo (el autor: «la barra de progreso del vídeo»)
    const mandos = await esperar(() => { const c = document.querySelector("#m7-capa .cm-capa .cm-abajo"); return c && c.getBoundingClientRect().width > 100 ? c : null; }, 3000);
    apunta(`mandos ${mandos ? "sí" : "NO"}`);
    apunta("doble 1");
    const como = await dobleEnVideo();
    const a = await esperar(() => app.enCompleta() && CatodeM7.capa.modo === "completa", 4000);
    apunta(`tras doble 1: ${a}`);
    await dormir(600);
    const v1 = await C.api.ventana("estado").catch(() => null);
    apunta(`ventana real ${v1 && v1.completa} n${v1 && v1.n}`);
    apunta("doble 2");
    await dobleEnVideo();
    const b = await esperar(() => !app.enCompleta() && CatodeM7.capa.modo === "video", 4000);
    apunta(`tras doble 2: ${b}`);
    for (const q of quitar) q();
    const det = `(${como}) mandos y barra=${!!mandos} completa=${a} vuelta=${b} capa ${CatodeM7.capa.modo} pos ${rep().pos.toFixed(1)}` + (traza ? " ## CRON " + cron.join(" | ") : "");
    if (traza && enviar) try { await C.api.post("/api/prueba", {registro: "recordado: " + cron.join(" | ").slice(0, 3000)}); } catch (err) { /* nada */ }
    try { rep().parar(); } catch (err) { /* nada */ }   // como estaba: los pasos siguientes cuentan con que no suene nada
    await dormir(300);
    return {bien: a && b && !!mandos, detalle: det};
  }

  // ================================================================================================ modo PERFIL
  // 06/10/2026 · CATODE_PRUEBA_SOLO=perfil: los recorridos del autor, 3 veces cada uno, medidos en la propia página (en
  // Windows, con el Edge real del mini PC): performance.now(), PerformanceObserver (longtask y long-animation-frame) y
  // cuadros por requestAnimationFrame. (a) arranque (la ronda 0 es el arranque en frío de verdad; la 1 y la 2, recargas que
  // pide la página y reinyecta prueba_web.py); (b) secciones; (c) desplazar la rejilla 2 s; (d) clic en tarjeta → vídeo
  // local con t>0, por tramos; (e) pestaña nueva con vídeo y cambio de pestaña; (f) pantalla completa y vuelta hasta que la
  // ventana responde; (g) 4 letras en el buscador hasta las sugerencias; (h) /api/estado y /api/ventana vistos por la página.
  // Manda {perfil: …} por POST /api/prueba; prueba_web.py junta las rondas del arranque, imprime la TABLA y cierra.
  const mediana = (xs) => { const s = xs.slice().sort((a, b) => a - b); const n = s.length; return n ? (n % 2 ? s[(n - 1) / 2] : (s[n / 2 - 1] + s[n / 2]) / 2) : -1; };
  async function perfil(op) {
    const ronda = +op.ronda || 0;
    const post = (o) => C.api.post("/api/prueba", Object.assign({perfil: 1}, o)).catch(() => null);
    const marcaDe = (n) => { const x = (C.medir && C.medir.ultimas || []).find((y) => y.n === n); return x ? x.ms : -1; };
    const recurso = (re) => (performance.getEntriesByType("resource").find((x) => re.test(x.name)) || {}).responseEnd || -1;

    // ---- (a) arranque: hasta tarjetas pintadas, desde el inicio de la página (marcas de medir.js)
    await esperar(() => marcaDe("arranque:tarjetas") >= 0, 20000);
    const tj = marcaDe("arranque:tarjetas");
    const largasA = (C.medir.ultimas || []).filter((m) => m.n === "tarea_larga" && (m.inicio || 0) <= tj);
    const nav = performance.getEntriesByType("navigation")[0] || {};
    await post({rec: "a", ronda, epoch: performance.timeOrigin, tarjetas: tj, pintada: marcaDe("arranque:pintada"),
      lista: marcaDe("arranque:lista"), dom: Math.round(nav.domContentLoadedEventEnd || -1), load: Math.round(nav.loadEventEnd || -1),
      js: Math.round(performance.getEntriesByType("resource").filter((x) => /\/js\//.test(x.name) && !/prueba_web/.test(x.name)).reduce((a, x) => Math.max(a, x.responseEnd), 0)),
      estado: Math.round(recurso(/\/api\/estado/)), inicio: Math.round(recurso(/\/api\/pagina\//)),
      largas: largasA.length, largas_max: Math.round(Math.max(0, ...largasA.map((m) => m.ms)))});
    if (ronda < 2) { await post({recargar: ronda + 1}); await dormir(200); location.reload(); return new Promise(() => {}); }

    // ---- lo que se observa durante el resto
    const T = {};
    const ap = (rec, met, v) => { const k = rec + " · " + met; (T[k] = T[k] || []).push(Math.round(v * 10) / 10); };
    const lt = [], loaf = [], msgs = [];
    try { new PerformanceObserver((l) => { for (const e of l.getEntries()) lt.push([e.startTime, e.duration]); }).observe({type: "longtask"}); } catch (e) { /* nada */ }
    try {
      new PerformanceObserver((l) => { for (const e of l.getEntries()) if (loaf.length < 2000) {
        const s = (e.scripts || []).slice().sort((a, b) => b.duration - a.duration)[0];
        loaf.push({t: e.startTime, d: e.duration, js: (e.scripts || []).reduce((a, x) => a + x.duration, 0),
          lay: e.styleAndLayoutStart ? e.startTime + e.duration - e.styleAndLayoutStart : 0,
          s: s ? `${Math.round(s.duration)}:${String(s.sourceURL || "").split("/").pop().split("?")[0]}:${(s.sourceFunctionName || s.invoker || "?").slice(0, 30)}` : ""});
      } }).observe({type: "long-animation-frame"});
    } catch (e) { /* nada */ }
    addEventListener("message", (ev) => { const d = ev.data; if (d && typeof d.tipo === "string" && msgs.length < 5000) msgs.push([performance.now(), d.tipo, d.t, ev.source]); }, true);
    red.perfil = [];
    const entre = (t0, t1) => {   // tareas largas y el cuadro más largo con su culpable, entre t0 y t1
      const l = lt.filter((x) => x[0] >= t0 - 5 && x[0] <= t1);
      const f = loaf.filter((x) => x.t >= t0 - 5 && x.t <= t1).sort((a, b) => b.d - a.d)[0];
      return {n: l.length, max: Math.round(Math.max(0, ...l.map((x) => x[1]))), culpa: f && f.d > 50 ? `${Math.round(f.d)}ms js${Math.round(f.js)} lay${Math.round(f.lay)} ${f.s}` : ""};
    };
    const culpas = {};
    const culpa = (rec, c) => { if (c && (culpas[rec] = culpas[rec] || []).length < 4) culpas[rec].push(c); };
    // la condición, y un cuadro pintado después (rAF + tarea): el instante en que el usuario lo ve
    const hasta = (cond, tope) => new Promise((ok) => { const t0 = performance.now();
      const f = () => { let c = false; try { c = cond(); } catch (e) { c = false; }
        if (c) return requestAnimationFrame(() => setTimeout(() => ok(performance.now()), 0));
        if (performance.now() - t0 > tope) return ok(-1);
        requestAnimationFrame(f); }; f(); });
    const cuadros = (ms) => new Promise((ok) => { const d = []; let u = performance.now(); const t0 = u;
      const f = (t) => { d.push(t - u); u = t; if (t - t0 < ms) requestAnimationFrame(f); else ok(d); }; requestAnimationFrame(f); });
    const marcarViejas = () => { for (const n of document.querySelectorAll(".tj")) n.__vieja = true; };
    const nuevas = () => tarjetas().filter((n) => !n.__vieja);
    const repA = () => { const p = activa(); return p && p.rep; };
    const pararTodo = () => { for (const p of P().lista) if (p.rep && p.rep.actual) try { p.rep.parar(); } catch (e) { /* nada */ } };
    const scroller = () => { const c = cuerpo(); const r = [...(window.Rejilla && Rejilla.vivas || [])].find((x) => x.nodo.isConnected && c.contains(x.nodo));
      return r ? r.scroller : ($(".pr-raiz", c) || c); };
    const videos = () => tarjetas().filter((x) => x._e.tipo === "VIDEO");
    const pestanaLimpia = async () => { P().crear(); await esperar(() => fActual() === "inicio" && videos().length > 1, 10000); await dormir(400); };
    const apiVistas = {}, ventanasF = [], apiTodas = [];
    let pasoPerfil = "b";
    const apiOrig = C.medir.api;   // todas las peticiones del perfil (catode.medir.ultimas solo guarda las 200 últimas marcas)
    C.medir.api = function (ruta, ms, st) {
      const r = String(ruta).split("?")[0], m = /dur=([\d.]+)/.exec(st || "");
      if (/^\/api\/(estado|ventana)$/.test(r) && apiTodas.length < 5000) apiTodas.push({t: Date.now(), n: "api:" + r, ms, s: m ? +m[1] : -1, p: pasoPerfil, v: red.vuelo});
      return apiOrig.apply(this, arguments);
    };
    const fallo = (rec, x) => { ap(rec, "fallos", 1); post({registro: `perfil ${rec}: ${x}`}); };

    // ---- (b) Inicio → Suscripciones → Historial → Inicio
    await pestanaLimpia();
    for (let i = 0; i < 3; i++) {
      for (const clave of ["suscripciones", "historial", "inicio"]) {
        marcarViejas();
        const t0 = performance.now();
        app.irSeccion(clave);
        const t = await hasta(() => fActual() === clave && nuevas().length > 0, 8000);
        const e = entre(t0, t < 0 ? t0 + 8000 : t);
        ap("b sección", `→ ${clave} (ms)`, t < 0 ? 99999 : t - t0);
        ap("b sección", "tareas largas (n)", e.n); ap("b sección", "peor tarea larga (ms)", e.max); culpa("b", e.culpa);
        await dormir(400);
      }
    }

    pasoPerfil = "c";
    // ---- (c) rueda sobre la rejilla del Inicio 2 s: fps, cuadros > 50 y > 100 ms
    for (let i = 0; i < 3; i++) {
      app.irSeccion("inicio");
      await esperar(() => fActual() === "inicio" && tarjetas().length, 8000);
      const sc = scroller(); sc.scrollTop = 0;
      await dormir(600);
      const r = sc.getBoundingClientRect(), x = r.left + r.width / 2, y = r.top + r.height / 2;
      const t0 = performance.now(), p = cuadros(2000);
      // sin entrada simulada del sistema: el evento de rueda cada 60 ms (para los oyentes de la página) y el desplazamiento
      // de una rueda girada sin parar (1200 px/s, una muesca de 120 px cada 100 ms), puesto en cada cuadro según el reloj
      let vivoC = true;
      const mover = () => { if (!vivoC) return; sc.scrollTop = (performance.now() - t0) * 1.2; requestAnimationFrame(mover); };
      requestAnimationFrame(mover);
      while (performance.now() - t0 < 2000) {
        sc.dispatchEvent(new WheelEvent("wheel", {deltaY: 120, deltaMode: 0, clientX: x, clientY: y, bubbles: true, cancelable: true}));
        await dormir(60);
      }
      vivoC = false;
      const d = await p, tot = d.reduce((a, b) => a + b, 0) || 1;
      let peorVentana = Infinity;   // fps mínimos: la peor ventana de 250 ms
      for (let a = 0, s = 0, b = 0; b < d.length; b++) { s += d[b]; while (s > 250 && a < b) { s -= d[a]; a++; } if (s >= 200) peorVentana = Math.min(peorVentana, (b - a + 1) / (s / 1000)); }
      const e = entre(t0, t0 + 2100);
      ap("c rueda", "fps medios", d.length / (tot / 1000)); ap("c rueda", "fps mínimos (250 ms)", peorVentana === Infinity ? 0 : peorVentana);
      ap("c rueda", "cuadros >50 ms (n)", d.filter((v) => v > 50).length); ap("c rueda", "cuadros >100 ms (n)", d.filter((v) => v > 100).length);
      ap("c rueda", "peor cuadro (ms)", Math.max(...d)); ap("c rueda", "desplazado (px)", sc.scrollTop); culpa("c", e.culpa);
    }

    pasoPerfil = "d";
    // ---- (d) clic en una tarjeta → el vídeo local empieza (t > 0), por tramos, cada vez en una pestaña nueva
    for (let i = 0; i < 3; i++) {
      await pestanaLimpia();
      const n = videos()[i];
      if (!n) { fallo("d", "sin tarjeta"); continue; }
      n.scrollIntoView({block: "center"});
      await dormir(300);
      const nm = msgs.length, nf = red.perfil.length, hito = {};
      const t0 = performance.now();
      let vivo = true;
      const vigia = () => { if (!vivo) return; const t = performance.now(), r = repA();
        if (!hito.nav && fActual() === "_mostrar_video") hito.nav = t;
        if (!hito.ficha && cuerpo() && ($(".pv-titulo", cuerpo()) || {}).textContent) hito.ficha = t;
        if (!hito.iframe && r && r.iframe && r.iframe.isConnected) hito.iframe = t;
        requestAnimationFrame(vigia); };
      requestAnimationFrame(vigia);
      raton(n, "click");
      const t = await hasta(() => { const r = repA(); return r && r.actual && r.ultimo && r.ultimo.t > 0; }, 15000);
      vivo = false;
      const r = repA(), w = r && r.iframe && r.iframe.contentWindow;
      const m = (tipo, c) => { const x = msgs.slice(nm).find((y) => y[1] === tipo && (!w || y[3] === w) && (!c || c(y))); return x ? x[0] - t0 : -1; };
      const f = (re) => { const x = red.perfil.slice(nf).find((y) => re.test(y[2])); return x ? x[1] - t0 : -1; };
      const rel = (v) => v ? v - t0 : -1;
      const e = entre(t0, t < 0 ? t0 + 15000 : t);
      ap("d abrir vídeo", "clic → t>0 (ms)", t < 0 ? 99999 : t - t0);
      ap("d abrir vídeo", "navegar (ms)", rel(hito.nav)); ap("d abrir vídeo", "ficha pintada (ms)", rel(hito.ficha));
      ap("d abrir vídeo", "iframe en el DOM (ms)", rel(hito.iframe)); ap("d abrir vídeo", "iframe «listo» (ms)", m("listo"));
      ap("d abrir vídeo", "fin /api/resolver (ms)", f(/resolver/)); ap("d abrir vídeo", "fin /api/video/ficha (ms)", f(/video\/ficha/));
      ap("d abrir vídeo", "«cargado» (ms)", m("cargado")); ap("d abrir vídeo", "primer avance (ms)", m("estado", (y) => y[2] > 0));
      ap("d abrir vídeo", "tareas largas (n)", e.n); ap("d abrir vídeo", "peor tarea larga (ms)", e.max); culpa("d", e.culpa);
      if (i === 0) post({registro: `perfil d: peticiones ${red.perfil.slice(nf).map((y) => `${y[2]} ${Math.round(y[0] - t0)}→${Math.round(y[1] - t0)}`).join(" · ").slice(0, 900)}`});
      pararTodo();
      P().cerrar(P().actual());
      await dormir(500);
    }

    pasoPerfil = "e";
    // ---- (e) pestaña nueva con vídeo y cambio de pestaña ida y vuelta
    for (let i = 0; i < 3; i++) {
      await pestanaLimpia();
      app.abrirVideo(videos()[0]._e, {});
      await esperar(() => { const r = repA(); return r && r.actual && r.pos > 0; }, 15000);
      const a = P().actual();
      const otro = ((await C.api.get("/api/pagina/historial")).elementos || []).filter((x) => x.tipo === "VIDEO")[1 + i];
      if (!otro) { fallo("e", "sin vídeo en el historial"); continue; }
      let t0 = performance.now();
      app.abrirVideo(otro, {nueva: true});
      const t = await hasta(() => { const r = repA(); return r && r.actual && r.actual.url === otro.url && r.pos > 0; }, 15000);
      let e = entre(t0, t < 0 ? t0 + 15000 : t);
      ap("e pestañas", "pestaña nueva → t>0 (ms)", t < 0 ? 99999 : t - t0); ap("e pestañas", "pestaña nueva peor tarea larga (ms)", e.max); culpa("e", e.culpa);
      const b = P().actual();
      for (const dest of [a, b]) {
        t0 = performance.now();
        P().activar(dest);
        const t2 = await hasta(() => P().actual() === dest && cuerpo() && cuerpo().offsetParent !== null, 3000);
        e = entre(t0, t2 < 0 ? t0 + 3000 : t2 + 50);
        ap("e pestañas", "cambio de pestaña (ms)", t2 < 0 ? 99999 : t2 - t0); ap("e pestañas", "cambio peor tarea larga (ms)", e.max); culpa("e", e.culpa);
        await dormir(300);
      }
      pararTodo();
      P().cerrar(P().actual()); P().cerrar(P().actual());
      await dormir(400);
    }

    pasoPerfil = "f";
    // ---- (f) pantalla completa y vuelta: hasta que la capa cambia y la ventana responde (cambia de tamaño)
    await pestanaLimpia();
    app.abrirVideo(videos()[0]._e, {});
    await esperar(() => { const r = repA(); return r && r.actual && r.pos > 0; }, 15000);
    await dormir(500);
    for (let i = 0; i < 3; i++) {
      for (const si of [true, false]) {
        const w0 = innerWidth, h0 = innerHeight, t0 = performance.now(), e0 = Date.now();
        CatodeM7.pantallaCompleta(si);
        const tc = await hasta(() => CatodeM7.enCompleta() === si, 3000);
        const tv = await hasta(() => innerWidth !== w0 || innerHeight !== h0, 2500);
        const d = await cuadros(500);
        const e = entre(t0, (tv > 0 ? tv : tc) + 500);
        const nom = si ? "entrar" : "salir";
        ap("f completa", `${nom}: capa (ms)`, tc < 0 ? 99999 : tc - t0);
        ap("f completa", `${nom}: ventana responde (ms)`, tv < 0 ? 99999 : tv - t0);
        ap("f completa", `${nom}: peor cuadro después (ms)`, Math.max(...d)); culpa("f", e.culpa);
        ventanasF.push([e0, Date.now()]);
        await dormir(600);
      }
    }
    pararTodo();
    P().cerrar(P().actual());
    await dormir(400);

    pasoPerfil = "g";
    // ---- (g) 4 letras en el buscador (110 ms entre teclas) hasta que salen las sugerencias
    for (let i = 0; i < 3; i++) {
      const campo = $("#campo");
      campo.focus(); campo.value = ""; campo.dispatchEvent(new Event("input", {bubbles: true}));
      app.cerrarSugerencias && app.cerrarSugerencias();
      await dormir(400);
      const palabra = ["gato", "musi", "pelo"][i];
      let t1 = 0;
      const t0 = performance.now();
      for (const letra of palabra) {
        tecla(letra, {}, campo);
        campo.value += letra;
        campo.dispatchEvent(new InputEvent("input", {bubbles: true, data: letra, inputType: "insertText"}));
        t1 = performance.now();
        await dormir(110);
      }
      const t = await hasta(() => !$("#sugerencias").hidden && $$("#sugerencias .sug").length && campo.value === palabra, 5000);
      const e = entre(t0, t < 0 ? t0 + 5000 : t);
      ap("g buscador", "última letra → sugerencias (ms)", t < 0 ? 99999 : t - t1); ap("g buscador", "peor tarea larga (ms)", e.max); culpa("g", e.culpa);
      tecla("Escape", {}, campo);
      campo.value = ""; campo.dispatchEvent(new Event("input", {bubbles: true})); campo.blur();
      await dormir(300);
    }

    pasoPerfil = "h";
    // ---- (h) /api/estado y /api/ventana: 20 seguidas de cada en reposo, y las vistas por la página durante todo el perfil
    for (const m of apiTodas) {
      // las de la pantalla completa aparte: mientras la ventana cambia de tamaño, Edge tarda en entregar la respuesta
      const en = ventanasF.some(([a, b]) => m.t >= a && m.t <= b + 200) ? " (en pantalla completa)" : "";
      (apiVistas[m.n + en] = apiVistas[m.n + en] || []).push(m.ms);
      if (m.s >= 0) (apiVistas["servidor:" + m.n.slice(4) + en] = apiVistas["servidor:" + m.n.slice(4) + en] || []).push(m.s);
    }
    C.medir.api = apiOrig;
    const lentas = apiTodas.filter((m) => m.ms > 50).map((m) => `${m.n.slice(4)} ${Math.round(m.ms)}ms (servidor ${m.s}) en ${m.p}, ${m.v} en vuelo`);
    if (lentas.length) post({registro: "perfil h lentas: " + lentas.join(" · ").slice(0, 1100)});
    for (let i = 0; i < 20; i++) {
      let t = performance.now();
      await C.api.get("/api/estado");
      ap("h api", "/api/estado en reposo (ms)", performance.now() - t);
      t = performance.now();
      await C.api.post("/api/ventana", {accion: "titulo", valor: i % 2 ? "Cat-ode" : "Cat-ode · perfil"});
      ap("h api", "/api/ventana en reposo (ms)", performance.now() - t);
    }
    for (const [k, v] of Object.entries(apiVistas)) for (const x of v) ap("h api", `${k.replace(/^api:/, "").replace(/^servidor:/, "en el servidor ")} durante el uso (ms)`, x);

    // ---- la tabla: una fila por medida con mediana, máximo y n
    const filas = Object.entries(T).map(([k, v]) => ({k, med: Math.round(mediana(v) * 10) / 10, max: Math.round(Math.max(...v) * 10) / 10, n: v.length}));
    await post({fin_perfil: true, filas, culpas});
    if (enviar) try { await C.api.post("/api/prueba", {fin: true, bien: 1, total: 1}); } catch (e) { /* nada */ }
    return {bien: 1, total: 1, resultados};
  }

  async function correr(op) {
    op = op || {};
    enviar = op.enviar !== false;
    resultados.length = 0;
    await esperar(() => window.app && app.listo, 15000);
    if (String(op.solo || "").toLowerCase().split(",").map((x) => x.trim()).includes("perfil")) return await perfil(op);

    // ---- 06/10/2026: «Reproducir un vídeo real» (manual, CON red): SOLO si CATODE_PRUEBA_SOLO lo nombra y NO es la
    // prueba de interfaz (sin fixtures, sin motor falso, sin proxy). Es lo único que se hace en esa pasada.
    const sinTildes = (t) => String(t || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim();
    const solo = String(op.solo || "").split(",").map(sinTildes).filter(Boolean);
    if (solo.includes("recordado")) {   // 07/10/2026: prueba corta: el vídeo recordado al arrancar, con cronología
      await paso("vídeo recordado al arrancar: doble clic → pantalla completa y vuelta (traza)", () => videoRecordado(true));
      const b0 = resultados.filter((r) => r.bien).length;
      if (enviar) try { await C.api.post("/api/prueba", {fin: true, bien: b0, total: resultados.length}); } catch (e) { /* nada */ }
      return {bien: b0, total: resultados.length, resultados};
    }
    if (solo.includes("completa")) {   // 06/10/2026: prueba corta y repetida de la pantalla completa (la carrera de Windows)
      P().crear();   // en una pestaña limpia (la app reabre las de la pasada anterior, que puede ser la del vídeo)
      const hay = await esperar(() => fActual() === "inicio" && document.querySelectorAll(".pestana-cuerpo.activa .tj").length > 0, 15000);
      if (!hay) {
        await paso("completa: Inicio con tarjetas para abrir un vídeo", () => ({bien: false, detalle: "sin tarjetas en 15 s (" + fActual() + ")"}));
        if (enviar) try { await C.api.post("/api/prueba", {fin: true, bien: 0, total: 1}); } catch (e) { /* nada */ }
        return {bien: 0, total: 1, resultados};
      }
      document.querySelector(".pestana-cuerpo.activa .tj").click();
      await esperar(() => rep() && rep().actual && rep().pos > 0.5, 15000);
      const real = async () => { try { const r = await C.api.ventana("estado"); return r && typeof r.completa === "boolean" ? r.completa : null; } catch (e) { return null; } };
      const coherente = async (quiero) => {
        const ok = await esperar(() => app.enCompleta() === quiero && (CatodeM7.capa.modo === "completa") === quiero, 3000);
        await dormir(150);
        const v = await real();
        return {ok: ok && app.enCompleta() === quiero && (CatodeM7.capa.modo === "completa") === quiero && (v === null || v === quiero),
          txt: `clase=${app.enCompleta()} capa=${CatodeM7.capa.modo} ventana=${v}`};
      };
      // quién manda el vídeo al mini (traza de pila, solo en esta prueba)
      const trazas = [], mini0 = CatodeM7.capa.mini;
      const pila = () => (new Error().stack || "").split("\n").slice(3, 9).map((x) => x.trim().replace(/https?:\/\/[^/]+\//, "").replace(/\?v=[^:]+/, "").replace(/^at /, "")).join(" < ");
      CatodeM7.capa.mini = function () {
        if (CatodeM7.capa.modo !== "completa") trazas.push("mini(): " + pila());
        return mini0.apply(this, arguments);
      };
      let antes0 = CatodeM7.capa.antes;   // quién deja «antes» en mini o sin sitio estando a pantalla completa
      Object.defineProperty(CatodeM7.capa, "antes", {configurable: true, get: () => antes0, set: (v) => {
        if (v && (v.modo === "mini" || !v.sitio || !v.sitio.isConnected)) trazas.push(`antes←${v.modo}${v.sitio ? (v.sitio.isConnected ? "" : "+SUELTO") : "+sin sitio"} [suena «${((rep() && rep().actual && rep().actual.titulo) || "").slice(0, 18)}» pos ${Math.round((rep() && rep().pos) || 0)}]: ` + pila());
        antes0 = v;
      }});
      // registro de todo lo que toca la pantalla completa, con su hora (ms) y el estado en ese momento
      const cron = [], t00 = performance.now();
      const est = () => `${app.enCompleta() ? "C" : "c"}${CatodeM7.capa.modo[0]}${antes0 ? "a" : "-"}`;
      const apunta = (t) => { cron.push(`${Math.round(performance.now() - t00)}:${t}[${est()}]`); if (cron.length > 60) cron.shift(); };
      const pc0 = CatodeM7.pantallaCompleta, po0 = app.ponerCompleta;
      CatodeM7.pantallaCompleta = function (q) { apunta(`pC(${q === undefined ? "" : q})<${pila().split(" < ").slice(0, 3).map((x) => x.split(" ")[0]).join("<")}`); const r = pc0.apply(this, arguments); apunta("·"); return r; };
      app.ponerCompleta = function (si) { apunta(`poner(${si})`); return po0.apply(this, arguments); };
      app.on("completa", (si) => apunta(`ev completa ${si}`));
      app.on("ventana", (d) => apunta(`sse ${d && d.completa} n${d && d.n}`));
      let comoDoble = "";   // 07/10/2026: doble clic REAL si la ventana lo admite (el detalle dice cuál fue)
      const entrar = {F: () => tecla("f", {}, document.body), doble: async () => { comoDoble = await dobleEnVideo(); }};
      const salir = {Esc: () => tecla("Escape", {}, document.body), doble: entrar.doble, F: entrar.F};
      const esperas = [0, 60, 150, 300, 600, 1000, 0, 100, 250, 0, 400, 50];
      let i = 0;
      for (const [e, s] of [["F", "F"], ["doble", "F"], ["F", "Esc"], ["doble", "doble"], ["doble", "Esc"], ["F", "doble"], ["F", "F"], ["doble", "doble"],
        ["F", "Esc"], ["doble", "doble"], ["doble", "F"], ["F", "doble"], ["doble", "Esc"], ["doble", "doble"]]) {
        const pausa = esperas[i++ % esperas.length];
        await paso(`completa ${i}: entra con ${e}, sale con ${s} (pausa ${pausa} ms)`, async () => {
          apunta(`>> ${i} entra ${e}`);
          await entrar[e]();
          const a = await coherente(true);
          apunta(`>> ${i} sale ${s}`);
          await dormir(pausa);
          await salir[s]();
          const b = await coherente(false);
          await dormir(pausa);
          const mini = CatodeM7.capa.modo === "mini";
          const tr = trazas.splice(0).join(" || ");
          if (mini || !(a.ok && b.ok)) { try { await C.api.post("/api/prueba", {registro: "traza mini: " + tr.slice(0, 500) + " ## CRON " + cron.splice(0).join(" | ").slice(0, 2600)}); } catch (err) { /* nada */ } }
          else cron.splice(0, Math.max(0, cron.length - 6));
          return {bien: a.ok && b.ok && !mini, detalle: `${comoDoble ? "(doble: " + comoDoble + ") " : ""}dentro: ${a.txt} · fuera: ${b.txt}`};
        });
      }
      // ráfagas: entrar, salir y entrar (o al revés) sin esperar entre medias; cuenta dónde acaba
      for (const [nombre, gestos, fin] of [["F·F·F acaba dentro", ["F", "F", "F"], true], ["doble·Esc·doble acaba dentro", ["doble", "Esc", "doble"], true],
        ["F·doble acaba fuera", ["F", "doble"], false], ["doble·doble·F·Esc acaba fuera", ["doble", "doble", "F", "Esc"], false]]) {
        await paso(`completa ráfaga: ${nombre}`, async () => {
          apunta(`>> ráfaga ${nombre}`);
          for (const g of gestos) await (entrar[g] || salir[g])();
          const a = await coherente(fin);
          if (fin) { salir.Esc(); await coherente(false); }
          const mini = CatodeM7.capa.modo === "mini";
          if (!a.ok || mini) { try { await C.api.post("/api/prueba", {registro: "traza mini: ## CRON " + cron.splice(0).join(" | ").slice(0, 2600)}); } catch (err) { /* nada */ } }
          await dormir(300);
          return {bien: a.ok && !mini, detalle: a.txt};
        });
      }
      const b0 = resultados.filter((r) => r.bien).length;
      if (enviar) try { await C.api.post("/api/prueba", {fin: true, bien: b0, total: resultados.length}); } catch (e) { /* nada */ }
      return {bien: b0, total: resultados.length, resultados};
    }
    if (!op.interfaz && solo.some((x) => x.includes("video real"))) {
      await paso("Reproducir un vídeo real", videoReal);
      // 07/10/2026: con el vídeo REAL sonando (HLS de YouTube, como el autor): doble clic real → pantalla completa, los
      // mandos se ocultan solos, vuelven al mover el ratón y el doble clic vuelve a ventana. Lo que las baterías sin red no
      // reproducen (su registro del 07/10: ni una petición de pantalla completa en toda la tarde)
      if (rep() && rep().actual && rep().ultimo && rep().ultimo.t > 3) {
        await paso("vídeo real: doble clic → pantalla completa", async () => {
          const como = await dobleEnVideo();
          const a = await esperar(() => app.enCompleta() && CatodeM7.capa.modo === "completa", 4000);
          await dormir(300);
          const v = await C.api.ventana("estado").catch(() => null);
          return {bien: a && !!(v && v.completa), detalle: `(${como}) clase=${app.enCompleta()} capa=${CatodeM7.capa.modo} ventana=${v && v.completa} t=${(rep().ultimo.t || 0).toFixed(1)} pausa=${rep().pausa}`};
        });
        await paso("vídeo real: los mandos se ocultan solos y vuelven con el ratón", async () => {
          const capaM = document.querySelector(".cm-capa");
          if (rep().pausa) rep().alternar();
          const como = await moverEnVideo();
          const vistos = await esperar(() => !capaM.classList.contains("oculta"), 1500);
          const t0 = performance.now();
          const oculta = vistos && await esperar(() => capaM.classList.contains("oculta"), 6000);
          const ms = Math.round(performance.now() - t0);
          await ratonReal("mover", 0.6, 0.55) || rep()._mensaje({tipo: "raton"});
          const vuelve = await esperar(() => !capaM.classList.contains("oculta"), 1500);
          return {bien: vistos && oculta && ms > 1500 && vuelve, detalle: `(${como}) a la vista=${vistos} ocultos=${oculta} en ${ms} ms vuelven=${vuelve} pausa=${rep().pausa}`};
        });
        await paso("vídeo real: doble clic → vuelve a ventana y sigue sonando", async () => {
          const t1 = rep().ultimo.t;
          const como = await dobleEnVideo();
          const b = await esperar(() => !app.enCompleta() && CatodeM7.capa.modo === "video", 4000);
          await dormir(2500);
          const v = await C.api.ventana("estado").catch(() => null);
          const t2 = rep().ultimo.t;
          return {bien: b && !!(v && v.completa === false) && t2 > t1, detalle: `(${como}) clase=${app.enCompleta()} capa=${CatodeM7.capa.modo} ventana=${v && v.completa} t ${(+t1).toFixed(1)}→${(+t2).toFixed(1)} pausa=${rep().pausa}`};
        });
      }
      const r0 = repSuena();
      try { if (r0) r0.parar(); } catch (e) { /* nada */ }
      const b0 = resultados.filter((r) => r.bien).length;
      if (enviar) try { await C.api.post("/api/prueba", {fin: true, bien: b0, total: resultados.length}); } catch (e) { /* nada */ }
      return {bien: b0, total: resultados.length, resultados};
    }

    // ---- arranque: todos los módulos cargados y las páginas de la Qt registradas (los talones, sustituidos)
    await paso("arranque: módulos y páginas", () => {
      const faltan = ["inicio", "shorts", "suscripciones", "explorar", "historial", "despues", "megusta", "listas", "descargas",
        "nut", "ajustes_pagina", "_canal", "_mostrar_video", "_resultados", "_lista_yt", "_lista_propia", "_gestionar"]
        .filter((n) => typeof app.paginas[n] !== "function");
      const glob = ["Reproductor", "Mandos", "Barra", "Rejilla", "Tarjeta", "Menu", "CatodeM7"].filter((g) => !window[g]);
      return {bien: (app.modulos || []).length >= 14 && !faltan.length && !glob.length,
        detalle: `módulos ${(app.modulos || []).length}; faltan páginas ${json(faltan)}; faltan globales ${json(glob)}`};
    });
    if (op.pestanas) {
      await paso("pestañas recordadas al arrancar", () => {
        const n = P().lista.length, fs = P().lista.map((p) => p.pila.length ? p.pila[p.pila.length - 1].f : "");
        return {bien: n === op.pestanas, detalle: `${n} abiertas ${json(fs)} (esperadas ${op.pestanas})`};
      });
      // 07/10/2026: como arranca la app del autor: la pestaña activa es la del vídeo de ayer, reanudado. Sobre ESE vídeo,
      // doble clic (real si se puede) → pantalla completa y vuelta; antes solo se probaba con un vídeo abierto desde una tarjeta
      await paso("vídeo recordado al arrancar: doble clic → pantalla completa y vuelta", () => videoRecordado(false));
    }
    // de aquí en adelante, en una pestaña limpia
    P().crear();
    await esperar(() => fActual() === "inicio", 3000);

    // ---- secciones del menú lateral: ≥1 tarjeta cada una (fixtures)
    for (const [clave, f, nombre] of [["inicio", "inicio", "Inicio"], ["suscripciones", "suscripciones", "Suscripciones"],
      ["explorar", "explorar", "Explorar"], ["historial", "historial", "Historial"], ["despues", "despues", "Ver más tarde"],
      ["megusta", "megusta", "Me gusta"], ["listas", "listas", "Listas"], ["nut", "nut", "Para Nut"]]) {
      await paso(`sección ${nombre}`, () => seccion(clave, f));
    }
    await paso("sección Descargas (página y botones)", async () => {
      app.irSeccion("descargas");
      const ok = await esperar(() => fActual() === "descargas" && cuerpo() && $(".pr-cab, .pr-cabeza", cuerpo()) && !$(".m5-cargando:not([hidden])", cuerpo()), 6000);
      return {bien: !!ok && !$(".cartel", cuerpo()), detalle: `${tarjetas().length} descargas · ${(cuerpo().textContent || "").trim().slice(0, 80)}`};
    });
    await paso("sección Shorts (marco 9:16 y capa)", async () => {
      app.irSeccion("shorts");
      const ok = await esperar(() => fActual() === "shorts" && window.CatodeM7 && CatodeM7.capa.modo === "shorts", 8000);
      const modo = window.CatodeM7 && CatodeM7.capa.modo;
      return {bien: !!ok, detalle: `capa ${modo} · ${(cuerpo().textContent || "").trim().slice(0, 60)}`};
    });
    await paso("salir de Shorts para el vídeo", async () => {
      app.irSeccion("inicio");
      const ok = await esperar(() => fActual() === "inicio" && CatodeM7.capa.modo !== "shorts" && tarjetas().length, 6000);
      return {bien: !!ok, detalle: `capa ${CatodeM7.capa.modo}`};
    });

    // ---- chips del Inicio
    await paso("chips: cambiar de tema", async () => {
      await esperar(() => tarjetas().length, 5000);
      const chips = $$(".pr-chip", cuerpo());
      if (chips.length < 2) return {bien: false, detalle: `${chips.length} chips`};
      const otro = chips.find((c) => !c.classList.contains("activo"));
      const texto = otro.textContent;
      otro.click();
      const ok = await esperar(() => { const a = $(".pr-chip.activo", cuerpo()); return a && a.textContent === texto && tarjetas().length; }, 6000);
      const vuelta = $$(".pr-chip", cuerpo())[0];
      if (vuelta) vuelta.click();
      await esperar(() => tarjetas().length, 5000);
      return {bien: !!ok, detalle: `${chips.length} chips; «${texto}» → ${tarjetas().length} tarjetas`};
    });

    // ---- buscar y sugerencias
    await paso("buscar: sugerencias al escribir", async () => {
      const campo = $("#campo");
      campo.focus();
      campo.value = "gato";
      campo.dispatchEvent(new Event("input", {bubbles: true}));
      const ok = await esperar(() => !$("#sugerencias").hidden && $$("#sugerencias .sug").length, 5000);
      return {bien: !!ok, detalle: `${$$("#sugerencias .sug").length} sugerencias: ${$$("#sugerencias .sug").slice(0, 3).map((s) => s.textContent).join(" | ")}`};
    });
    await paso("buscar: Intro → resultados", async () => {
      const campo = $("#campo");
      tecla("Enter", {}, campo);
      const ok = await esperar(() => fActual() === "_resultados" && tarjetas().length, 8000);
      const a = activa().pila[activa().pila.length - 1].a;
      return {bien: !!ok && a[0] === "gato", detalle: `${fActual()} ${json(a)} · ${tarjetas().length} tarjetas`};
    });
    await paso("buscar: sugerencias ⟲ propias", async () => {
      const campo = $("#campo");
      campo.focus();
      campo.value = "ga";
      campo.dispatchEvent(new Event("input", {bubbles: true}));
      const ok = await esperar(() => $$("#sugerencias .sug.propia").some((s) => s.textContent.includes("gato")), 5000);
      tecla("Escape", {}, campo);
      campo.value = "";
      campo.dispatchEvent(new Event("input", {bubbles: true}));
      campo.blur();
      return {bien: !!ok, detalle: $$("#sugerencias .sug").map((s) => s.textContent).slice(0, 4).join(" | ")};
    });

    // ---- abrir una tarjeta → página del vídeo y el archivo local sonando (t > 0 en 10 s)
    let primero = null;
    await paso("abrir tarjeta → vídeo local suena", async () => {
      app.irSeccion("inicio");
      await esperar(() => fActual() === "inicio" && tarjetas().some((n) => n._e.tipo === "VIDEO"), 6000);
      const n = tarjetas().find((x) => x._e.tipo === "VIDEO");
      if (!n) return {bien: false, detalle: "sin tarjetas de vídeo"};
      primero = n._e;
      raton(n, "click");
      const ok = await esperar(() => fActual() === "_mostrar_video" && rep() && rep().actual && rep().pos > 0.3 && !rep().pausa, 10000);
      const r = rep();
      return {bien: !!ok, detalle: `página ${fActual()} · actual ${r && r.actual && r.actual.titulo} · t=${r && (+r.pos).toFixed(1)} de ${r && r.dur}`};
    });
    await paso("página del vídeo: ficha, relacionados y capa", async () => {
      // con fixtures la ficha es siempre la misma: el título que se espera es el de la ficha que da el servidor para ese vídeo
      const fi = await C.api.get("/api/video/ficha", {url: primero.url}).catch(() => ({}));
      const tit = ((fi && fi.ok !== false && fi.titulo) || primero.titulo).slice(0, 20);
      const ok = await esperar(() => $(".pv", cuerpo()) && CatodeM7.capa.modo === "video" && $$(".pv-rel-fila", cuerpo()).length &&
        ($(".pv", cuerpo()).textContent || "").includes(tit), 10000);
      const t = ($(".pv", cuerpo()) || {}).textContent || "";
      return {bien: !!ok && t.includes(tit), detalle: `capa ${CatodeM7.capa.modo} · ${$$(".pv-rel-fila", cuerpo()).length} relacionados` +
        (ok ? "" : ` · busco «${tit}» en «${t.replace(/\s+/g, " ").slice(0, 120)}»`)};
    });
    await paso("capítulos de la ficha en el reproductor (barra y mandos)", async () => {
      const ok = await esperar(() => rep().capitulos && rep().capitulos.length > 0, 4000);
      const marcas = document.querySelectorAll(".cm-cap").length;
      return {bien: !!ok, detalle: `${(rep().capitulos || []).length} capítulos en el reproductor · ${marcas} marcas`};
    });
    await paso("ventana: título con el vídeo", () => ({bien: document.title.endsWith("· Cat-ode") && document.title.length > 10, detalle: document.title}));

    // ---- mandos del vídeo con el teclado (Espacio, J/L, M, F, T, Esc)
    await paso("mandos: Espacio pausa y reanuda", async () => {
      document.body.focus();
      tecla(" ", {}, document.body);
      const p1 = await esperar(() => rep().pausa === true, 2000);
      tecla(" ", {}, document.body);
      const p2 = await esperar(() => rep().pausa === false, 2000);
      return {bien: p1 && p2, detalle: `pausa=${p1} sigue=${p2}`};
    });
    await paso("mandos: L adelanta y J retrocede 10 s", async () => {
      const t0 = rep().pos;
      tecla("l", {}, document.body);
      const a = await esperar(() => rep().pos >= t0 + 5 ? rep().pos : 0, 3000);
      tecla("j", {}, document.body);
      const b = await esperar(() => rep().pos <= a - 5 ? rep().pos : 0, 3000) || (rep().pos <= a - 5);
      return {bien: !!a && b !== null && b !== false, detalle: `${(+t0).toFixed(1)} → ${(+a).toFixed(1)} → ${(+rep().pos).toFixed(1)}`};
    });
    await paso("mandos: M silencia y quita el silencio", async () => {
      const m0 = !!rep().mute;
      tecla("m", {}, document.body);
      const a = await esperar(() => !!rep().mute !== m0, 2000);
      tecla("m", {}, document.body);
      const b = await esperar(() => !!rep().mute === m0, 2000);
      return {bien: a && b, detalle: `mute ${m0} → ${!m0} → ${!!rep().mute}`};
    });
    await paso("mandos: T modo cine", async () => {
      const raiz = $(".pv", cuerpo());
      const c0 = raiz.classList.contains("cine");
      tecla("t", {}, document.body);
      const a = await esperar(() => raiz.classList.contains("cine") !== c0, 2000);
      tecla("t", {}, document.body);
      const b = await esperar(() => raiz.classList.contains("cine") === c0, 2000);
      return {bien: a && b, detalle: `cine ${c0} → ${!c0} → ${raiz.classList.contains("cine")}`};
    });
    await paso("mandos: F pantalla completa y Esc", async () => {
      tecla("f", {}, document.body);
      const a = await esperar(() => app.enCompleta() && CatodeM7.capa.modo === "completa", 3000);
      tecla("Escape", {}, document.body);
      const b = await esperar(() => !app.enCompleta() && CatodeM7.capa.modo === "video", 3000);
      return {bien: a && b, detalle: `completa=${a} vuelta=${b} capa ${CatodeM7.capa.modo}`};
    });
    await paso("mandos: doble clic DENTRO del vídeo = pantalla completa, y vuelta", async () => {   // 06/10/2026: el aviso «doble» del iframe
      const p0 = rep().pausa;
      const como = await dobleEnVideo();   // 07/10/2026: ratón REAL en el centro del vídeo (antes, el aviso inyectado)
      const a = await esperar(() => app.enCompleta() && CatodeM7.capa.modo === "completa", 3000);
      await dormir(600);   // el doble clic deshace la pausa del primer clic: se mira cuando ya ha pasado todo
      const sigue = rep().pausa === p0;
      await dobleEnVideo();
      const b = await esperar(() => !app.enCompleta() && CatodeM7.capa.modo === "video", 3000);
      return {bien: a && b && sigue, detalle: `(${como}) completa=${a} vuelta=${b} pausa igual=${sigue} capa ${CatodeM7.capa.modo}`};
    });
    await paso("pantalla completa: los mandos se ocultan solos y vuelven con el ratón", async () => {   // 06/10/2026
      const capaM = document.querySelector(".cm-capa");
      tecla("f", {}, document.body);
      const dentro = await esperar(() => app.enCompleta() && CatodeM7.capa.modo === "completa", 3000);
      if (rep().pausa) rep().alternar();
      const como = await moverEnVideo();   // se enseñan (ratón REAL sobre el vídeo si se puede) y desde ahí se mide el ocultado
      const vistos = await esperar(() => !capaM.classList.contains("oculta"), 1500);
      const t0 = performance.now();
      const oculta = vistos && await esperar(() => capaM.classList.contains("oculta") && getComputedStyle(document.querySelector(".cm-abajo")).pointerEvents === "none", 6000);
      const ms = Math.round(performance.now() - t0);
      const sobre = document.querySelector(".cm-abajo").matches(":hover");
      await ratonReal("mover", 0.6, 0.55) || rep()._mensaje({tipo: "raton"});   // otro movimiento (real si se puede)
      const vuelve = await esperar(() => !capaM.classList.contains("oculta"), 1500);
      tecla("Escape", {}, document.body);
      const fuera = await esperar(() => !app.enCompleta() && CatodeM7.capa.modo === "video", 3000);
      return {bien: dentro && oculta && ms > 1500 && vuelve && fuera, detalle: `(${como}) completa=${dentro} a la vista=${vistos} ocultos=${oculta} en ${ms} ms (ratón sobre la barra: ${sobre}) vuelven=${vuelve} salida=${fuera}`};
    });
    await paso("cortes: un tropiezo = UN reintento (no dos)", async () => {   // 07/10/2026: el registro del autor (13:50:39)
      // el vigilante ve el vídeo sonando y quieto 8 s: debe recargar UNA vez; antes, en el mismo tick, «sin imagen 20 s
      // después de cargar» veía el _t_cargar del arranque anterior y pedía un segundo reintento (se gastaban los 3 en 1,5 cortes)
      const r = rep();
      if (!r || !r.actual) return {bien: false, detalle: "sin vídeo"};
      if (r.pausa) r.alternar();
      await esperar(() => r._arrancado && r.ultimo && !r.ultimo.idle && r.pos > 0.5, 5000);
      const url = r.actual.url, antes = r._reintentos[url] || 0, posFija = r.pos;
      const orig = r._reintentar, llamadas = [];
      r._reintentar = function () { llamadas.push(r._t_cargar ? Math.round(performance.now() - r._t_cargar) : -1); return orig.apply(this, arguments); };
      Object.defineProperty(r, "pos", {configurable: true, get: () => posFija, set: () => {}});   // no avanza
      r._t_cargar = performance.now() - 60000;   // el arranque fue «hace un minuto», como en un vídeo largo
      r._ult = posFija; r._quieto = 6;
      try {
        r._mirar_parado();   // tick 1: quieto 8 s → recarga
        r._mirar_parado();   // tick 2 (justo después, la recarga aún resolviendo): no debe reintentar otra vez
        await dormir(100);
      } finally {
        delete r.pos; r._reintentar = orig;
      }
      const n = (r._reintentos[url] || 0) - antes;
      await esperar(() => r.ultimo && !r.ultimo.idle && r.pos > 0.5, 8000);   // la recarga acaba y el vídeo vuelve a sonar
      return {bien: llamadas.length === 1 && n === 1 && !!r.actual, detalle: `reintentos pedidos=${llamadas.length} (ms desde cargar: ${llamadas.join(",")}) contador +${n} suena=${!!(r.ultimo && !r.ultimo.idle)} pos ${(r.pos || 0).toFixed(1)}`};
    });
    await paso("cortes: parado con datos ya bajados = calidad más baja, sin recargar", async () => {   // 19/10/2026
      // «la descarga de vídeos se queda en 4 segundos»: el mini PC, con el descodificador lleno, paraba el vídeo con datos
      // por delante; las recargas no servían y acababan en «no se puede reproducir». Ahora: un escalón menos y sin reintento
      const r = rep(), g = G();
      if (!r || !r.actual || !g) return {bien: false, detalle: "sin vídeo"};
      if (r.pausa) r.alternar();
      await esperar(() => r._arrancado && r.ultimo && !r.ultimo.idle && r.pos > 0.5, 5000);
      const url = r.actual.url, antes = r._reintentos[url] || 0, posFija = r.pos, tipoAntes = r.tipo;
      const origR = r._reintentar, origO = r._orden, reintentos = [], calidades = [];
      r._reintentar = function () { reintentos.push(1); return origR.apply(this, arguments); };
      r._orden = function (f, ...a) { if (f === "calidad") calidades.push(a[0]); return origO.call(this, f, ...a); };
      Object.defineProperty(r, "pos", {configurable: true, get: () => posFija, set: () => {}});
      Object.defineProperty(r, "tipo", {configurable: true, get: () => "hls", set: () => {}});
      g.topeCarga = {alto: 0, hasta: 0};
      let primero, segundo, sinDatos;
      try {
        r.ultimo = Object.assign({}, r.ultimo, {delante: 6.5, alto: 1080, idle: false, notas: []});
        r._ult = posFija; r._quieto = 6; r._salto = 0;
        r._mirar_parado();   // quieto 8 s con 6,5 s bajados → 720p
        primero = r._altoIframe();
        r.ultimo = Object.assign({}, r.ultimo, {delante: 5, alto: 720});
        r._ult = posFija; r._quieto = 6;
        r._mirar_parado();   // sigue parado a 720p → 480p
        segundo = r._altoIframe();
        r.ultimo = Object.assign({}, r.ultimo, {delante: 0.2, alto: 480});
        r._ult = posFija; r._quieto = 6;
        r._mirar_parado();   // parado SIN datos (la red): recarga como siempre
        sinDatos = reintentos.length;
      } finally {
        delete r.pos; delete r.tipo; r.tipo = tipoAntes; r._reintentar = origR; r._orden = origO;
        g.topeCarga = {alto: 0, hasta: 0}; r._orden("calidad", r._altoIframe());
      }
      const n = (r._reintentos[url] || 0) - antes;
      await esperar(() => r.ultimo && !r.ultimo.idle && r.pos > 0.5, 8000);
      return {bien: primero === 720 && segundo === 480 && calidades[0] === 720 && calidades[1] === 480 && sinDatos === 1 && n === 1 && r._altoIframe() === 0,
              detalle: `con datos: ${primero}p y ${segundo}p (órdenes ${calidades.join(",")}); sin datos: ${sinDatos} recarga(s), contador +${n}; al acabar ${r._altoIframe()}`};
    });
    await paso("mini (3.9): la ✕ la quita y el vídeo SIGUE sonando; no vuelve sola con el mismo vídeo", async () => {   // 22/10/2026
      // audio de Mateo (20/10): «si le doy a la X se me cierra el vídeo y se me para todo»
      const r = rep(), M7 = window.CatodeM7;
      if (!r || !M7 || !M7.capa || typeof M7.quitarMini !== "function") return {bien: false, detalle: "sin reproductor o sin M7.quitarMini"};
      if (r.pausa) r.alternar();
      await esperar(() => r._arrancado && r.ultimo && !r.ultimo.idle && r.pos > 0.5, 5000);
      app.irSeccion("historial");   // como de verdad: se sale de la página del vídeo y sale la mini
      const enMini = await esperar(() => M7.capa.modo === "mini", 4000);
      const boton = M7.capa.el && M7.capa.el.querySelector(".fl-quitar");
      const visible = !!boton && getComputedStyle(boton).display !== "none";
      const p0 = r.pos;
      if (boton) boton.click();
      await esperar(() => M7.capa.modo === "oculta", 2000);
      await esperar(() => r.pos > p0 + 1, 5000);
      const sigue = !r.pausa && !!r.actual && r.pos > p0 + 1;
      app.irSeccion("inicio"); await esperar(() => false, 1200);   // otra sección: con el mismo vídeo, no vuelve
      const noVuelve = M7.capa.modo === "oculta";
      M7.volverDelFlotante(); await esperar(() => M7.capa.modo === "video", 4000);   // a su página: vuelve a su sitio
      return {bien: enMini && visible && sigue && noVuelve && M7.capa.quitada === null,
              detalle: `mini ${enMini} · ✕ visible ${visible} · sigue sonando ${sigue} (pos ${p0.toFixed(1)} → ${r.pos.toFixed(1)}) · no vuelve ${noVuelve} · de vuelta: modo ${M7.capa.modo}, quitada=${M7.capa.quitada}`};
    });
    await paso("calidad (3.6): el selector dice lo que se ve y, si no es lo elegido, por qué; la rebaja avisa", async () => {   // 22/10/2026
      // «la calidad de los vídeos no es correlativa a la que sale elegida en el selector… debe coincidir»
      const r = rep(), g = G(), M = window.Mandos;
      if (!r || !M || !M.valorCalidad) return {bien: false, detalle: "sin reproductor o sin Mandos.valorCalidad"};
      const antesC = r.ajustes.calidad, antesU = r.ultimo, antesT = g.topeCarga, origA = r._aviso, avisos = [];
      const res = {};
      try {
        const pon = (c, alto, niveles) => { r.ajustes.calidad = c; r.ultimo = Object.assign({}, antesU || {}, {alto, niveles: niveles || []}); };
        g.topeCarga = {alto: 0, hasta: 0};
        pon(1080, 1080); res.igual = M.valorCalidad(r);
        pon(1080, 720, [360, 720]); res.noTiene = M.valorCalidad(r);
        res.cv = JSON.stringify(r.calidad_vista());
        g.topeCarga = {alto: 720, hasta: performance.now() + 60000};
        pon(1080, 720, [360, 720, 1080]); res.rebajada = M.valorCalidad(r);
        pon("auto", 720, [360, 720, 1080]); res.auto = M.valorCalidad(r);
        g.topeCarga = {alto: 0, hasta: 0};
        pon("auto", 1080); res.autoBien = M.valorCalidad(r);
        // la rebaja por no dar abasto avisa
        r._aviso = (t) => avisos.push(t);
        const origO = r._orden, tipoAntes = r.tipo; r._orden = () => {};
        Object.defineProperty(r, "tipo", {configurable: true, get: () => "hls", set: () => {}});
        r.ultimo = Object.assign({}, antesU || {}, {delante: 6, alto: 1080, idle: false, notas: []}); r._abasto_visto = null;
        try { r._sin_abasto(); } finally { delete r.tipo; r.tipo = tipoAntes; r._orden = origO; }
      } finally {
        r.ajustes.calidad = antesC; r.ultimo = antesU; g.topeCarga = {alto: 0, hasta: 0}; r._aviso = origA;
        clearTimeout(g._t_tope); r._orden("calidad", r._altoIframe());
      }
      const bien = res.igual === "1080p" && res.noTiene === "720p (este vídeo no tiene 1080p)" && res.rebajada === "720p (el equipo no da abasto)"
        && res.auto === "Automática (720p, el equipo no da abasto)" && res.autoBien === "Automática (1080p)"
        && avisos.length === 1 && /no da abasto con 1080p: 720p durante 15 min/.test(avisos[0]);
      return {bien, detalle: `${JSON.stringify(res)} · avisos ${JSON.stringify(avisos)}`};
    });
    await paso("cortes: un «final» lejos del final sigue en ese punto y uno de verdad pasa al siguiente", async () => {   // 19/10/2026
      // «los vídeos siguen interrumpiéndose a veces y pasa a otro»: en el mini PC el <video> avisaba «acabado» con t = 0 a las
      // 4 h de un vídeo de 11 h y Cat-ode pasaba al siguiente. Ahora: lejos del final = reintento en el último segundo bueno
      const r = rep();
      if (!r || !r.actual) return {bien: false, detalle: "sin vídeo"};
      await esperar(() => r._arrancado && r.pos > 0.5, 5000);
      const url = r.actual.url, antes = r._reintentos[url] || 0, i0 = r.i, elegido0 = r._elegido, pos0 = r.pos, dur0 = r.dur;
      const origR = r._reintentar, origC = r._cargar, origM = r._pide_mas, reint = [], siguiente = [];
      r._reintentar = function () { reint.push(Math.round(r.pos)); };
      r._cargar = function () { siguiente.push("cola"); };
      r._pide_mas = function () { siguiente.push("más"); };
      Object.defineProperty(r, "dur", {configurable: true, get: () => 600, set: () => {}});
      let falso, deVerdad;
      try {
        r.pos = 0; r._pos_antes = 0; r._pos_bueno = 245.6;
        r._al_acabar();
        falso = {reint: reint.slice(), siguiente: siguiente.slice()};
        reint.length = 0; siguiente.length = 0;
        r.pos = 0; r._pos_antes = 0; r._pos_bueno = 599.4;
        r._al_acabar();
        deVerdad = {reint: reint.slice(), siguiente: siguiente.slice()};
      } finally {
        delete r.dur; r.dur = dur0; r._reintentar = origR; r._cargar = origC; r._pide_mas = origM; r._reintentos[url] = antes;
        r.i = i0; r._elegido = elegido0; r.pos = pos0;
      }
      await esperar(() => r.ultimo && !r.ultimo.idle && r.pos > 0.5, 8000);
      return {bien: falso.reint.length === 1 && falso.reint[0] === 246 && !falso.siguiente.length && !deVerdad.reint.length && deVerdad.siguiente.length === 1,
              detalle: `a 246 s de 600: reintento en ${falso.reint.join(",") || "-"} y siguiente ${falso.siguiente.join(",") || "no"}; a 599 s: reintento ${deVerdad.reint.length}, siguiente ${deVerdad.siguiente.join(",") || "no"}`};
    });
    await paso("cortes: un vídeo que ya sonaba NUNCA pasa solo al siguiente (intentos lentos y, al final, quieto)", async () => {
      // 21/10/2026 «catode sigue saltando videos a la mitad… se interrumpe y pasa al siguiente, arréglalo como sea»
      const r = rep(), g = G();
      if (!r || !r.actual || !g) return {bien: false, detalle: "sin vídeo"};
      await esperar(() => r._arrancado && r.pos > 0.5, 5000);
      const url = r.actual.url, origC = r._cargar, origN = r._no_se_puede, origT = window.setTimeout, origO = r._orden;
      // aislado del <video> de verdad (un vídeo de prueba de 25 s que se acaba y manda estados): ni estados ni vigilante
      const origE = r._estado, origP = r._mirar_parado, dur0 = r.dur;
      r._estado = function (m) { this.ultimo = m; }; r._mirar_parado = function () {}; r.dur = 600;
      const rein0 = r._reintentos[url] || 0, pb0 = r._pos_bueno, pausa0 = r.pausa, tipo0 = r.tipo, pos0 = r.pos;
      const cargas = [], nose = [], esperas = [];
      r._cargar = function (d, rec) { cargas.push([Math.round(d), !!rec]); };
      r._no_se_puede = function (aviso) { nose.push(aviso); };
      r._orden = function (f, ...a) { if (f !== "pausa") return origO.call(this, f, ...a); };   // el <video> real no se toca
      let quieto, nunca, viejo;
      try {
        r._reintentos[url] = 3; r._lentos[url] = 0; r._pos_bueno = 120; r.pausa = false; r._t_lento = 0;
        for (let k = 0; k < 7; k++) {
          // los intentos lentos, sin esperar de verdad (los demás temporizadores, como siempre)
          window.setTimeout = (f, ms, ...x) => ms >= 10000 && ms % 1000 === 0 ? (esperas.push(ms), origT(f, 0)) : origT(f, ms, ...x);
          try { r._reintentar(); } finally { window.setTimeout = origT; }
          await dormir(30);
        }
        quieto = {atascado: r._atascado, pausa: r.pausa};
        // un vídeo que NO ha llegado a sonar: como siempre, «no se puede» (y el siguiente)
        r._atascado = false; r.pausa = false; r._reintentos[url] = 3; r._lentos[url] = 0; r._pos_bueno = 0;
        Object.defineProperty(r, "pos", {configurable: true, get: () => 2, set: () => {}});
        r._reintentar();
        delete r.pos; r.pos = pos0;
        nunca = nose.length;
        // la calidad: con el MISMO estado del <video> no se decide dos veces (19/10: 31 bajadas seguidas, ninguna recarga)
        Object.defineProperty(r, "tipo", {configurable: true, get: () => "hls", set: () => {}});
        g.topeCarga = {alto: 0, hasta: 0};
        r.ultimo = Object.assign({}, r.ultimo, {delante: 6, alto: 1080, idle: false, notas: []});
        viejo = [r._sin_abasto(), r._sin_abasto()];
      } finally {
        window.setTimeout = origT; r._cargar = origC; r._no_se_puede = origN; r._orden = origO;
        r._estado = origE; r._mirar_parado = origP; r.dur = dur0;
        delete r._estado; delete r._mirar_parado;   // vuelven a ser los del prototipo
        if (r.pos === undefined || Object.getOwnPropertyDescriptor(r, "pos").get) { delete r.pos; r.pos = pos0; }
        delete r.tipo; r.tipo = tipo0;
        r._reintentos[url] = rein0; r._lentos[url] = 0; r._pos_bueno = pb0; r._atascado = false; r.pausa = pausa0;
        g.topeCarga = {alto: 0, hasta: 0}; r._orden("calidad", r._altoIframe());
      }
      await esperar(() => r.ultimo && !r.ultimo.idle && r.pos > 0.5, 8000);
      const bienEsperas = esperas.join(",") === "10000,20000,40000,60000,120000,120000";
      const bienCargas = cargas.length === 6 && cargas.every(([d, rec]) => d === 119 && rec);
      return {bien: bienEsperas && bienCargas && quieto.atascado && quieto.pausa && nunca === 1 && viejo[0] === true && viejo[1] === false,
              detalle: `esperas ${esperas.join(",")} s·1000; recargas ${cargas.map((c) => c[0]).join(",")}; al final quieto=${quieto.atascado} pausa=${quieto.pausa}; ` +
                       `«no se puede» (solo el que no sonó) ${nunca}; calidad con el mismo estado ${viejo.join("→")}`};
    });
    await paso("mandos: velocidad con > y <", async () => {
      tecla(">", {mayus: true}, document.body);
      const a = await esperar(() => rep().vel > 1 ? rep().vel : 0, 2000);
      tecla("<", {mayus: true}, document.body);
      const b = await esperar(() => rep().vel === 1, 2000);
      return {bien: !!a && b, detalle: `vel ${a} → ${rep().vel}`};
    });

    await paso("teclas del vídeo tras tocar el volumen o una casilla", async () => {
      const r = rep();
      const caja = document.createElement("div");
      caja.style.cssText = "position:fixed;left:0;top:0;opacity:0";
      const rango = Object.assign(document.createElement("input"), {type: "range"});
      const casilla = Object.assign(document.createElement("input"), {type: "checkbox"});
      caja.append(rango, casilla); document.body.appendChild(caja);
      const p0 = r.pausa;
      rango.focus(); tecla("k", {}, rango);
      const a = await esperar(() => r.pausa !== p0, 2000);
      const p1 = r.pausa;
      casilla.focus(); tecla("k", {}, casilla);
      const b = await esperar(() => r.pausa !== p1, 2000);
      caja.remove(); document.body.focus();
      if (r.pausa) r.pausar(false);
      return {bien: !!a && !!b, detalle: `deslizador ${!!a} · casilla ${!!b}`};
    });
    await paso("enlace al vídeo que suena con minuto: solo salta", async () => {
      const r = rep();
      const antes = r.cola.length, actual = r.actual, id = idDe(r.actual.url);
      if (!id) return {bien: false, detalle: "sin id: " + r.actual.url};
      await app.abrirEnlace(`https://youtu.be/${id}?t=7`, false);
      const ok = await esperar(() => Math.abs(r.pos - 7) < 2.5 && r.actual === actual && r.cola.length === antes, 4000);
      return {bien: !!ok, detalle: `t=${(+r.pos).toFixed(1)} · cola ${antes} → ${r.cola.length} · mismo vídeo ${r.actual === actual}`};
    });

    // ---- cola: encolar dos, siguiente, anterior
    await paso("cola: encolar, siguiente y anterior", async () => {
      const r = rep();
      const rel = (await C.api.get("/api/video/relacionados", {url: primero.url}).catch(() => ({}))).elementos || [];
      const otros = rel.filter((e) => e.tipo === "VIDEO" && e.url !== primero.url).slice(0, 2);
      if (otros.length < 2) return {bien: false, detalle: `relacionados ${rel.length}`};
      const n0 = r.cola.length;
      r.encolar(otros[0]); r.encolar(otros[1]);
      const enCola = r.cola.length;
      r.siguiente();
      const a = await esperar(() => r.actual && r.actual.url === r.cola[r.i].url && r.i >= 1 && r.pos > 0.2, 10000);
      const tras = r.actual && r.actual.titulo;
      r.anterior();
      const b = await esperar(() => r.actual && r.actual.url === primero.url, 8000);
      return {bien: enCola >= n0 + 2 && a && b, detalle: `cola ${n0}→${enCola}; siguiente «${tras}»; anterior «${r.actual && r.actual.titulo}»`};
    });
    await paso("cola: «A continuación» la enseña", async () => {
      const ok = await esperar(() => /Cola/.test((cuerpo() || {}).textContent || ""), 4000);
      return {bien: !!ok, detalle: ((($(".pv-cola, .m7-cola", cuerpo()) || {}).textContent) || "").slice(0, 60)};
    });

    await paso("anuncios del creador: /api/video/tramos", async () => {
      const x = await C.api.get("/api/video/tramos", {url: primero.url, dur: 25});
      return {bien: x.ok !== false && Array.isArray(x.tramos), detalle: `${(x.tramos || []).length} tramos`};
    });

    // ---- salir de la página del vídeo: mini y barra inferior
    await paso("mini: el vídeo sigue en 360×203", async () => {
      app.irSeccion("historial");
      const ok = await esperar(() => CatodeM7.capa.modo === "mini" && !rep().pausa, 4000);
      const r = CatodeM7.capa.rect ? CatodeM7.capa.rect() : null;
      return {bien: !!ok && r && Math.round(r.width) === 360 && Math.round(r.height) === 203, detalle: `capa ${CatodeM7.capa.modo} ${r ? Math.round(r.width) + "×" + Math.round(r.height) : ""}`};
    });
    await paso("barra inferior visible con el vídeo", async () => {
      const b = $("#barra-inferior");
      const ok = await esperar(() => !b.hidden && b.offsetHeight > 20 && document.body.classList.contains("con-barra"), 3000);
      return {bien: !!ok, detalle: `alto ${b.offsetHeight} · ${(b.textContent || "").trim().slice(0, 50)}`};
    });
    await paso("barra inferior: ⏯ pausa", async () => {
      const b = $("#barra-inferior");
      const boton = $$("button", b).find((x) => /⏯|⏸|▶/.test(x.textContent) || /pausa|reproducir/i.test(x.title || ""));
      if (!boton) return {bien: false, detalle: "sin botón ⏯"};
      boton.click();
      const a = await esperar(() => rep().pausa === true, 2000);
      boton.click();
      const c = await esperar(() => rep().pausa === false, 2000);
      return {bien: a && c, detalle: `pausa=${a} sigue=${c}`};
    });

    // ---- atrás y adelante (con el sitio de cada página)
    await paso("atrás y adelante recuerdan el sitio", async () => {
      app.irSeccion("explorar");
      await esperar(() => fActual() === "explorar" && tarjetas().length > 4, 6000);
      const pag = $(".pagina", cuerpo()) || cuerpo();
      const sc = [...cuerpo().querySelectorAll(".pagina")].find((x) => x.scrollHeight > x.clientHeight + 50) || pag;
      sc.scrollTop = Math.min(400, sc.scrollHeight - sc.clientHeight);
      await dormir(250);
      const antes = sc.scrollTop;
      app.irSeccion("megusta");
      await esperar(() => fActual() === "megusta" && tarjetas().length, 6000);
      app.volver();
      const ok = await esperar(() => fActual() === "explorar" && tarjetas().length, 6000);
      await dormir(400);
      const sc2 = [...cuerpo().querySelectorAll(".pagina")].find((x) => x.scrollHeight > x.clientHeight + 50);
      const despues = sc2 ? sc2.scrollTop : -1;
      app.adelante();
      const ade = await esperar(() => fActual() === "megusta", 6000);
      return {bien: !!ok && !!ade && Math.abs(despues - antes) < 40, detalle: `scroll ${antes} → ${despues}; adelante ${fActual()}`};
    });

    // ---- menú ⋮ de una tarjeta y Compartir (portapapeles simulado: M5.ultimoCopiado)
    await paso("menú del vídeo (clic derecho) y Compartir", async () => {
      app.irSeccion("historial");
      await esperar(() => fActual() === "historial" && tarjetas().some((n) => n._e.tipo === "VIDEO"), 6000);
      const n = tarjetas().find((x) => x._e.tipo === "VIDEO");
      raton(n, "contextmenu", {boton: 2});
      const m = await esperar(() => $(".m5-menu"), 2000);
      const items = m ? $$(".m5-item, [role=menuitem]", m).map((x) => x.textContent.trim()).filter(Boolean) : [];
      tecla("Escape", {}, document.activeElement || document.body);
      await esperar(() => !$(".m5-menu"), 2000);
      const ops = window.Menu && Menu.compartir ? Menu.compartir(n._e, 0) : [];
      const copiar = (ops || []).find((o) => o && /copiar/i.test(o.texto || ""));
      if (copiar && copiar.accion) await copiar.accion();
      const copiado = window.M5 && M5.ultimoCopiado;
      // 19/10/2026: el enlace es www.youtube.com/watch (con youtu.be WhatsApp no sacaba la vista previa) y WhatsApp va a
      // Python (compartir.py abre la app), no a wa.me en el navegador
      const wa = (ops || []).find((o) => o && o.texto === "WhatsApp");
      if (wa && wa.accion) await wa.accion();
      const comp = window.M5 && M5.ultimoCompartido;
      return {bien: items.length >= 10 && !!copiado && /^https:\/\/www\.youtube\.com\/watch\?v=[\w-]{11}$/.test(String(copiado)) &&
                    !!comp && comp.app === "whatsapp" && /youtube\.com\/watch/.test(comp.url) && !/wa\.me/.test(json(ops.map((o) => o.texto))),
        detalle: `${items.length} opciones (${items.slice(0, 4).join(" | ")}…); copiado ${json(copiado).slice(0, 80)}; WhatsApp → ${json(comp).slice(0, 120)}`};
    });

    // ---- datos: ver más tarde / me gusta (y el SSE «datos» repinta)
    await paso("ver más tarde: poner, SSE «datos» y quitar", async () => {
      let llego = null;
      const oir = (ev) => { if (ev.detail && ev.detail.col === "despues") llego = ev.detail.col; };
      window.addEventListener("catode:datos", oir);
      const r1 = await C.api.datos("alternar", {col: "despues", e: primero});
      const a = await esperar(() => llego === "despues", 4000);
      const r2 = await C.api.datos("alternar", {col: "despues", e: primero});
      window.removeEventListener("catode:datos", oir);
      return {bien: r1.puesto !== r2.puesto && !!a, detalle: `puesto ${r1.puesto} → ${r2.puesto}; SSE ${llego}`};
    });

    // ---- pestañas: Ctrl+T, Ctrl+W, duplicar, reabrir, Ctrl+Tab y recordar
    await paso("pestañas: Ctrl+T y Ctrl+W", async () => {
      const n0 = P().lista.length;
      tecla("t", {ctrl: true}, document.body);
      const a = await esperar(() => P().lista.length === n0 + 1 && P().actual() === n0 && fActual() === "inicio", 3000);
      tecla("w", {ctrl: true}, document.body);
      const b = await esperar(() => P().lista.length === n0, 3000);
      return {bien: a && b, detalle: `${n0} → ${n0 + 1} → ${P().lista.length}`};
    });
    await paso("pestaña nueva con vídeo: manda en teclado y mandos; Ctrl+W sin huérfanos", async () => {
      const g = G(), r1 = repSuena(), px = activa();
      if (!g || !r1) return {bien: false, detalle: "sin vídeo sonando"};
      const otro = (await C.api.get("/api/pagina/historial")).elementos.find((e) => e.tipo === "VIDEO" && e.url !== r1.actual.url);
      tecla("t", {ctrl: true}, document.body);
      await esperar(() => activa() !== px && fActual() === "inicio", 3000);
      const sinRep = g.activo !== r1;   // la pestaña nueva no hereda el reproductor de la otra
      app.abrirVideo(otro, {});
      const r2 = await esperar(() => activa().rep && activa().rep.actual && activa().rep.pos > 0.2 && activa().rep, 10000);
      const manda = !!r2 && g.activo === r2 && r2 !== r1;
      if (!manda && enviar) try {   // por qué no: el reproductor de la pestaña nueva visto desde su iframe y quién manda
        const rn = activa().rep;
        await C.api.post("/api/prueba", {registro: `diag B: nuevo=${!!rn} activo=${g.activo === rn ? "nuevo" : g.activo === r1 ? "antiguo" : g.activo ? "otro" : "nadie"} pos=${rn && rn.pos} ` +
          `${await diagRep(rn)} · manda=${g.porque} [${g.cambios.join(" | ")}] · vis=${document.visibilityState} [${cambiosVis}]`});
      } catch (x) { /* nada */ }
      const p1 = r1.pausa, p2 = r2 && r2.pausa;
      tecla("k", {}, document.body);
      const k = await esperar(() => r2 && r2.pausa !== p2, 2000);
      const r1igual = r1.pausa === p1;
      tecla("w", {ctrl: true}, document.body);
      await esperar(() => activa() === px, 3000);
      await dormir(300);
      const huerfanos = g.lista.filter((r) => !r._segundo && !P().lista.includes(r._pestana)).length;
      const zonas = [...document.querySelectorAll(".rep-de-pestana")].filter((z) => !P().lista.some((p) => String(p.id) === z.dataset.pestana)).length;
      const vuelve = g.activo === r1;
      return {bien: sinRep && manda && !!k && r1igual && !huerfanos && !zonas && vuelve,
        detalle: `avisos sin tipo antes de listo ${g.prematuros} · activo no es el de la otra ${sinRep} · nueva manda ${manda} · k a la nueva ${!!k}, la otra igual ${r1igual} · huérfanos ${huerfanos}/${zonas} · vuelve ${vuelve}`};
    });
    await paso("pestañas: duplicar", async () => {
      app.irSeccion("megusta");
      await esperar(() => fActual() === "megusta", 3000);
      const n0 = P().lista.length, i = P().actual();
      P().duplicar(i);
      const ok = await esperar(() => P().lista.length === n0 + 1 && fActual() === "megusta", 3000);
      return {bien: !!ok, detalle: `${n0} → ${P().lista.length}, activa ${P().actual()} con ${fActual()}`};
    });
    await paso("pestañas: Ctrl+Mayús+T reabre la cerrada", async () => {
      const n0 = P().lista.length;
      P().cerrar(P().actual());
      await esperar(() => P().lista.length === n0 - 1, 2000);
      tecla("T", {ctrl: true, mayus: true}, document.body);
      const ok = await esperar(() => P().lista.length === n0 && fActual() === "megusta", 3000);
      return {bien: !!ok, detalle: `${n0} → ${n0 - 1} → ${P().lista.length} (${fActual()})`};
    });
    await paso("pestañas: Ctrl+Tab y Ctrl+1", async () => {
      const i0 = P().actual(), n = P().lista.length;
      tecla("Tab", {ctrl: true}, document.body);
      const a = P().actual() === (i0 + 1) % n;
      tecla("1", {ctrl: true}, document.body);
      const b = P().actual() === 0;
      P().activar(n - 1);
      return {bien: a && b, detalle: `${i0} → ${(i0 + 1) % n} → 0`};
    });
    await paso("pestañas: altavoz en la que suena", async () => {
      const conRep = P().lista.find((p) => p.rep && p.rep.actual);
      const nodo = $$("#pestanas .pestana")[P().lista.indexOf(conRep)];
      return {bien: !!conRep && !!nodo && nodo.dataset.altavoz === "1" && !!$(".altavoz svg", nodo), detalle: conRep ? `pestaña ${P().lista.indexOf(conRep)} altavoz=${nodo && nodo.dataset.altavoz}` : "ninguna suena"};
    });
    await paso("pestañas: se recuerdan en los ajustes", async () => {
      await P().guardar(true);
      const aj = await ajustes();
      const n = P().lista.length, g = aj.pestanas || [];
      return {bien: g.length === n && aj.pestana_activa === P().actual() && g.every((x) => x.f && Array.isArray(x.a) && typeof x.t === "string"),
        detalle: `${g.length} guardadas de ${n}; activa ${aj.pestana_activa}; ${json(g.map((x) => x.f))}`};
    });

    // ---- atajos
    await paso("atajos: «?» abre la lista y Esc la cierra", async () => {
      tecla("?", {mayus: true}, document.body);
      const a = await esperar(() => C.atajos.abierto(), 2000);
      const filas = $$(".dialogo-atajos .atajo-fila").length;
      tecla("Escape", {}, document.body);
      const b = await esperar(() => !C.atajos.abierto(), 2000);
      return {bien: a && b && filas > 0 && filas === C.atajos.FILAS.filter((f) => f && (Array.isArray(f) ? f[1] : f.texto || f)).length, detalle: `abierta=${a} cerrada=${b} filas=${filas}`};
    });
    await paso("atajos: «/» lleva al buscador", async () => {
      document.body.focus();
      tecla("/", {}, document.body);
      const ok = document.activeElement === $("#campo");
      $("#campo").blur();
      return {bien: ok, detalle: (document.activeElement || {}).id || ""};
    });

    // ---- Ajustes: una casilla cambia el JSON y se relee igual
    await paso("Ajustes: casilla guarda y se relee", async () => {
      app.irSeccion("ajustes");
      const i = await esperar(() => $("input[data-clave=vista_previa]", cuerpo()), 6000);
      if (!i) return {bien: false, detalle: `sin la casilla (página ${fActual()})`};
      await dormir(1200);   // que acabe refrescar() (relee los ajustes al enseñarse), como una persona que mira antes de pulsar
      const antes = (await ajustes()).vista_previa !== false;
      i.click();
      let leido = null;
      for (let k = 0; k < 40; k++) { leido = (await ajustes()).vista_previa; if (leido === !antes) break; await dormir(100); }
      i.click();
      let vuelta = null;
      for (let k = 0; k < 40; k++) { vuelta = (await ajustes()).vista_previa; if (vuelta === antes) break; await dormir(100); }
      return {bien: leido === !antes && vuelta === antes, detalle: `vista_previa ${antes} → ${leido} → ${vuelta}`};
    });
    await paso("Ajustes: calidad guarda y se relee", async () => {
      const s = $("select[data-clave=calidad]", cuerpo());
      if (!s) return {bien: false, detalle: "sin el selector"};
      const antes = s.value, otro = [...s.options].map((o) => o.value).find((v) => v !== antes);
      s.value = otro; s.dispatchEvent(new Event("change", {bubbles: true}));
      let leido = null;
      for (let k = 0; k < 40; k++) { leido = String((await ajustes()).calidad); if (leido === String(otro)) break; await dormir(100); }
      s.value = antes; s.dispatchEvent(new Event("change", {bubbles: true}));
      await dormir(1600);   // el PUT del reproductor sale 1 s después: no puede pisar «auto» con 0
      const final = String((await ajustes()).calidad);
      return {bien: leido === String(otro) && final === String(antes), detalle: `calidad ${antes} → ${leido} → ${final}`};
    });

    await paso("remoto: un solo estado (SSE «remoto», F9, Ajustes y menú ⚙)", async () => {
      await C.api.post("/api/remoto", {apagar: true});
      const a = await esperar(() => app.remotoApagado() === true && G().ajustes.apagar_remoto === true, 3000);
      await C.api.post("/api/remoto", {apagar: false});
      const b = await esperar(() => app.remotoApagado() === false && G().ajustes.apagar_remoto === false, 3000);
      return {bien: !!a && !!b, detalle: `apagado ${!!a} · encendido ${!!b}`};
    });

    // ---- Traer mi YouTube (18/10/2026): los dos botones con la cuenta FALSA de cuenta_servicio (CATODE_PRUEBA_INTERFAZ):
    // ni una petición sale del equipo; las órdenes de «Actualizar YouTube desde Cat-ode» quedan apuntadas en falsa.llamadas
    if (op.interfaz !== false) {
      const estadoCuenta = async () => await C.api.get("/api/cuenta");
      const resumenCuenta = () => (($(".aj-cuenta-resumen", cuerpo()) || {}).textContent || "");
      await paso("Traer mi YouTube: entrada en el menú y sección en Ajustes", async () => {
        const menu = $("#menu .menu-item-lat[data-clave=cuenta]");
        if (menu) menu.click(); else app.irSeccion("ajustes");
        const b1 = await esperar(() => $(".aj-cuenta-traer", cuerpo()), 6000), b2 = $(".aj-cuenta-llevar", cuerpo());
        return {bien: !!menu && !!b1 && !!b2 && fActual() === "ajustes_pagina", detalle: `menú ${!!menu} · traer ${!!b1} · llevar ${!!b2} · página ${fActual()}`};
      });
      await paso("Traer mi YouTube: «Actualizar cuenta desde YouTube» trae lo nuevo", async () => {
        const e0 = await estadoCuenta();
        if (!e0.falsa) return {bien: false, detalle: "sin la cuenta falsa (¿servidor sin fixtures?): no pulso nada"};
        $(".aj-cuenta-traer", cuerpo()).click();
        const t = await esperar(() => /canal|nada nuevo/i.test(resumenCuenta()) && resumenCuenta(), 15000);
        const e1 = await estadoCuenta();
        const menu = await esperar(() => (app.canales || []).length >= e1.suscripciones && e1.suscripciones > 0, 4000);
        return {bien: !!t && e1.suscripciones > e0.suscripciones && !!menu,
          detalle: `«${t}» · suscripciones ${e0.suscripciones} → ${e1.suscripciones} · menú ${(app.canales || []).length}`};
      });
      await paso("Traer mi YouTube: la segunda vez solo lo nuevo (nada)", async () => {
        $(".aj-cuenta-traer", cuerpo()).click();
        await esperar(() => !resumenCuenta(), 2000);
        const t = await esperar(() => /nada nuevo/i.test(resumenCuenta()) && resumenCuenta(), 15000);
        return {bien: !!t, detalle: `«${resumenCuenta()}»`};
      });
      await paso("Traer mi YouTube: «Actualizar YouTube desde Cat-ode» con confirmación y aplicar", async () => {
        const e0 = await estadoCuenta();
        // una baja hecha en Cat-ode después de la foto: se lleva a YouTube
        const canal = (app.canales || []).find((c) => /Canal de prueba 2/.test(c.titulo || ""));
        if (!canal) return {bien: false, detalle: "sin el canal de prueba 2 en el menú"};
        await C.api.post("/api/datos", {accion: "quitar", url: canal.url, col: "suscripciones"});
        $(".aj-cuenta-llevar", cuerpo()).click();
        const dlg = await esperar(() => $(".cu-dialogo"), 15000);
        if (!dlg) return {bien: false, detalle: "sin diálogo de confirmación: " + resumenCuenta()};
        const numeros = ($(".cu-numeros", dlg) || {}).textContent || "";
        const quitar = $$(".cu-quitar li", dlg).map((x) => x.textContent);
        const selector = !!$(".cu-destino", dlg);
        $(".cu-aplicar", dlg).click();
        const t = await esperar(() => /En YouTube|Nada que llevar/.test(resumenCuenta()) && resumenCuenta(), 20000);
        const e1 = await estadoCuenta();
        const llamadas = (e1.falsa.llamadas || []).slice((e0.falsa.llamadas || []).length);
        const quitada = llamadas.some((l) => l.ep === "subscription/unsubscribe" && l.cuerpo.params === "CgIIAhgA");
        return {bien: /quitar 1 canal/.test(numeros) && quitar.includes("Canal de prueba 2") && selector && !!t && quitada && !$(".cu-dialogo"),
          detalle: `«${numeros}» quitar ${JSON.stringify(quitar)} selector ${selector} · «${t}» · órdenes ${llamadas.map((l) => l.ep).join(",")}`};
      });
      await paso("Traer mi YouTube: cancelar no toca YouTube", async () => {
        const e0 = await estadoCuenta();
        $(".aj-cuenta-llevar", cuerpo()).click();
        const dlg = await esperar(() => $(".cu-dialogo"), 15000);
        if (!dlg) return {bien: false, detalle: "sin diálogo"};
        const vacio = /Nada que llevar/.test(dlg.textContent);
        ($(".cu-cancelar", dlg) || $("button", dlg)).click();
        await dormir(400);
        const e1 = await estadoCuenta();
        return {bien: (e1.falsa.llamadas || []).length === (e0.falsa.llamadas || []).length && !e1.plan && !$(".cu-dialogo"),
          detalle: `vacío ${vacio} · órdenes ${(e0.falsa.llamadas || []).length} → ${(e1.falsa.llamadas || []).length} · plan ${!!e1.plan}`};
      });
      await paso("Traer mi YouTube: invitación del Inicio en un equipo nuevo", async () => {
        const caja = document.createElement("div");
        const si = await C.cuenta.invitar(caja, {historial: 0, suscripciones: 0});
        const no = await C.cuenta.invitar(document.createElement("div"), {historial: 3, suscripciones: 0});
        const b = $(".cuenta-invitacion-boton", caja);
        return {bien: si && !no && !!b && b.textContent === "Traer mi YouTube", detalle: `vacío ${si} · con historial ${no}`};
      });
    }

    // ---- zoom (Ctrl+«+», Ctrl+0): escala guardada en los ajustes
    await paso("zoom: Ctrl+«+» y Ctrl+0", async () => {
      const e0 = app.escala;
      tecla("+", {ctrl: true}, document.body);
      const a = Math.abs(app.escala - (e0 + 0.1)) < 0.001;
      let g = null;
      for (let k = 0; k < 30; k++) { g = (await ajustes()).escala; if (Math.abs((+g || 0) - app.escala) < 0.001) break; await dormir(100); }
      tecla("0", {ctrl: true}, document.body);
      return {bien: a && Math.abs((+g || 0) - (e0 + 0.1)) < 0.001 && app.escala === 1, detalle: `${e0} → ${(e0 + 0.1).toFixed(1)} (guardada ${g}) → ${app.escala}`};
    });

    // ---- rejilla virtual con 3000 elementos: ≤150 nodos y sin tareas largas al desplazar
    await paso("rejilla: 3000 elementos, ≤150 nodos", async () => {
      const caja = document.createElement("div");
      caja.style.cssText = "position:fixed;left:0;top:0;width:1300px;height:800px;overflow:auto;z-index:-1;opacity:0";
      document.body.appendChild(caja);
      const base = primero || {tipo: "VIDEO", url: "https://www.youtube.com/watch?v=aaaaaaaaaaa", titulo: "x", autor: "a"};
      const els = Array.from({length: 3000}, (_, k) => ({...base, url: base.url.split("&")[0] + "&n=" + k, titulo: `Elemento ${k}`}));
      // la página quieta antes de medir: sin peticiones en vuelo de los pasos anteriores (como mucho 5 s) y 300 ms de calma
      const vuelo0 = red.vuelo;
      await esperar(() => red.vuelo === 0, 5000);
      await dormir(300);
      red.urls = []; red.llegadas = []; red.t0 = performance.now(); red.oir = true;
      const sse = [];   // los eventos «datos» que llegan mientras se mide (cada uno puede recargar vetos o páginas)
      const oirDatos = (ev) => { if (sse.length < 12) sse.push((ev.detail && ev.detail.col || "-") + "@" + Math.round(performance.now() - red.t0)); };
      window.addEventListener("catode:datos", oirDatos);
      const carga = await cargaEquipo();
      console.log("CATODE_FRENO si");   // Linux con CATODE_PRUEBA_FRENO: la CPU frenada (CDP) solo en este paso; Windows: nada
      const g = new Rejilla(caja, {}).montar(caja);
      const t0 = performance.now();
      g.poner(els, {}, "");
      const tPoner = Math.round(performance.now() - t0);
      // se mide el scroll (DISENO_WEB «long task >100 ms en scroll»): poner() es la preparación y queda fuera, con sus
      // tandas (06/10/2026: una lista grande entra por tandas de 48 en tareas aparte; se espera a que acaben, como antes
      // se esperaba al poner() de una vez)
      await esperar(() => !(g._cola && g._cola.length) && !g._vaciando, 5000);
      await new Promise((ok) => requestAnimationFrame(() => ok()));
      await dormir(50);
      let largas = 0, largas50 = 0; const durs = [], cuadros = [];
      const obs = window.PerformanceObserver && PerformanceObserver.supportedEntryTypes.includes("longtask") ?
        new PerformanceObserver((l) => { for (const e of l.getEntries()) { largas50++; if (e.duration > 100) { largas++; durs.push(Math.round(e.duration) + e.name.slice(0, 12)); } } }) : null;
      if (obs) obs.observe({entryTypes: ["longtask"]});
      const loaf = [];   // diagnóstico: de qué está hecho cada cuadro largo (guion, estilo y maquetado, pintado)
      const obs2 = window.PerformanceObserver && PerformanceObserver.supportedEntryTypes.includes("long-animation-frame") ?
        new PerformanceObserver((l) => { for (const e of l.getEntries()) if (e.duration > 100) {
          // trabajo de la página en ese cuadro: guiones + estilo y maquetado. Un cuadro largo sin trabajo propio es el
          // equipo ocupado en otra cosa (en el N100, Syncthing y la gráfica se comían más de un núcleo): no es la rejilla
          // los guiones de la propia prueba (inyectada en Windows sin dirección, prueba_web.js en Linux) no son la página
          const deLaPrueba = (x) => !x.sourceURL || /prueba_web\.js/.test(x.sourceURL);
          const finC = e.startTime + e.duration, js = (e.scripts || []).reduce((a, x) => a + (deLaPrueba(x) ? 0 : x.duration), 0);
          cuadros.push({js, lay: e.styleAndLayoutStart ? finC - e.styleAndLayoutStart : 0});
          const fin = finC, scs = [...(e.scripts || [])].sort((a, b) => b.duration - a.duration), sc = scs[0], sc2 = scs[1];
          if (loaf.length < 12) loaf.push(`@${Math.round(e.startTime - red.t0)} ${Math.round(e.duration)}:js${Math.round((e.scripts || []).reduce((a, x) => a + x.duration, 0))}` +
            `,lay${e.styleAndLayoutStart ? Math.round(fin - e.styleAndLayoutStart) : "-"},ren${e.renderStart ? Math.round(fin - e.renderStart) : "-"}` +
            [sc, sc2].filter(Boolean).map((x) => `,${Math.round(x.duration)}(f${Math.round(x.forcedStyleAndLayoutDuration || 0)})${x.invokerType || ""}:${(x.invoker || "").slice(0, 28)}` +
              `@${(x.sourceURL || "").split("/").pop().split("?")[0]}:${(x.sourceFunctionName || "").slice(0, 20)}`).join("") +
            `,bloq${Math.round(e.blockingDuration || 0)}`);
        } }) : null;
      if (obs2) obs2.observe({type: "long-animation-frame"});
      for (let k = 0; k < 60; k++) { caja.scrollTop += 500; await new Promise((ok) => requestAnimationFrame(() => ok())); }
      await dormir(200);
      const nodos = caja.querySelectorAll(".tj").length, medida = `${caja.clientWidth}x${caja.clientHeight}`;
      if (obs) obs.disconnect();
      if (obs2) obs2.disconnect();
      red.oir = false;
      console.log("CATODE_FRENO no");
      window.removeEventListener("catode:datos", oirDatos);
      g.destruir();
      caja.remove();
      // el criterio (06/10/2026): un cuadro >100 ms cuenta si su trabajo PROPIO pasa de 100 ms. Con el equipo libre, propio
      // = guiones + estilo y maquetado del cuadro; con más del 60 % de la CPU ocupada por procesos ajenos (Syncthing, los
      // servicios de Intel… en el N100), solo los guiones de la página (el maquetado se estira con la CPU que no hay).
      const cargado = !!(carga && carga.ajena > 60);
      const propias = cuadros.filter((c) => (cargado ? c.js : c.js + c.lay) > 100).length;
      const maxPropio = Math.round(Math.max(0, ...cuadros.map((c) => cargado ? c.js : c.js + c.lay)));
      const tCarga = carga && !carga.error ? `equipo ${carga.cpu} % (ajeno ${carga.ajena} %, propio ${carga.propia} %)${cargado ? " CARGADO: solo guiones" : ""}` : "carga ¿?";
      const bien = nodos > 0 && nodos <= 150 && (obs2 ? propias === 0 : largas === 0);
      if (enviar) try { await C.api.post("/api/prueba", {registro: `rejilla ${tCarga}; cuadros: ${loaf.join(" ")} · llegadas [${red.llegadas}] · datos [${sse}]`}); } catch (e) { /* nada */ }
      return {bien, detalle: `${nodos} nodos; ${tCarga}; cuadros con trabajo propio >100 ms: ${obs2 ? propias : "-"} (máx ${obs2 ? maxPropio : "-"} ms); tareas largas >100 ms: ${largas} [${durs}] (>50 ms: ${largas50}); poner ${tPoner} ms; caja ${medida}; en vuelo antes ${vuelo0}, durante [${red.urls}]; cuadros ${loaf.join(" ")}`};
    });

    // ---- «Ver a la vez»: un segundo vídeo flotante mientras sigue el primero (Mayús+clic en una tarjeta)
    await paso("ver a la vez: segundo vídeo flotante", async () => {
      app.irSeccion("historial");
      await esperar(() => fActual() === "historial" && tarjetas().some((n) => n._e.tipo === "VIDEO" && n._e.url !== primero.url), 6000);
      const n = tarjetas().find((x) => x._e.tipo === "VIDEO" && x._e.url !== primero.url);
      raton(n, "click", {mayus: true});
      const s = await esperar(() => app.segundo && app.segundo.actual() && app.segundo.actual().rep.pos > 0.2 && app.segundo.actual(), 10000);
      const r1 = repSuena();
      const primeroSuena = !!(r1 && r1 !== (s && s.rep) && !r1.pausa && !r1.congelado);
      const t = s ? (+s.rep.pos).toFixed(1) : "-";
      let d2 = "";
      if (!s) try { const x = app.segundo && app.segundo.actual(); const e = x && x.rep && x.rep.estado;
        d2 = ` · segundo=${!!app.segundo} actual=${!!x} estado=${e ? JSON.stringify({t: e.t, rs: e.rs, ns: e.ns, p: e.p, error: e.error, notas: e.notas}) : "-"}` +
          (x && x.rep ? ` listo=${x.rep.listo} cargas=${x.rep._cargas} pendientes=${(x.rep._pendientes || []).length} iframe=${x.rep.iframe && x.rep.iframe.isConnected}` : ""); } catch (x) { d2 = " · " + x; }
      if (!s && enviar) try {
        const x = app.segundo && app.segundo.actual();
        await C.api.post("/api/prueba", {registro: `diag A: ${await diagRep(x && x.rep)} · el primero ${await diagRep(r1)} · vis=${document.visibilityState} [${cambiosVis}]`});
      } catch (x) { /* nada */ }
      app.segundo.cerrar();
      const fuera = !document.querySelector(".m8-segundo");
      return {bien: !!s && primeroSuena && fuera, detalle: `segundo t=${t}; el primero sigue=${primeroSuena}; cerrado=${fuera}; avisos sin tipo antes de listo ${G().prematuros}${d2}`};
    });

    // ---- Relleno (fichas.Relleno): lo que una fila no trae (duración, visualizaciones, fecha) llega por detrás
    await paso("relleno: duración y visualizaciones por detrás", async () => {
      const caja = document.createElement("div");
      caja.style.cssText = "position:fixed;left:0;top:0;width:900px;height:400px;overflow:auto;z-index:-1;opacity:0";
      document.body.appendChild(caja);
      const e = {...primero, duracion: -1, fecha: 0, detalle: ""};
      const g = new Rejilla(caja, {fila: true}).montar(caja);
      g.poner([e], {}, "");
      const ok = await esperar(() => e.duracion > 0 && /visualiz/.test(e.detalle), 6000);   // la fecha, solo si el fixture la trae
      await dormir(100);
      const n = caja.querySelector(".tj");
      const pinta = n ? n.textContent : "";
      g.destruir(); caja.remove();
      return {bien: !!ok && /visualiz/.test(pinta), detalle: `duración ${e.duracion}, «${e.detalle}», fecha ${e.fecha}`};
    });

    // ---- cerrar el vídeo y dejarlo todo como estaba
    await paso("parar el vídeo", async () => {
      const r = repSuena();
      if (!r) return {bien: false, detalle: "no suena ninguno"};
      r.parar();
      const ok = await esperar(() => !r.actual || r.pausa, 3000);
      return {bien: !!ok, detalle: `actual ${r.actual ? r.actual.titulo : "ninguno"}`};
    });

    const bien = resultados.filter((r) => r.bien).length;
    if (enviar) try { await C.api.post("/api/prueba", {fin: true, bien, total: resultados.length}); } catch (e) { /* nada */ }
    return {bien, total: resultados.length, resultados};
  }

  C.prueba = {correr, resultados, esperar, tecla, raton};
})();
