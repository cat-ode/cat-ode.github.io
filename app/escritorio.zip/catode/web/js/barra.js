// Cat-ode escritorio · interfaz web · la barra del reproductor de abajo (módulo M6). 06/10/2026.
// Puerto de Barra (interfaz.py 1211-1390): visible solo cuando suena algo y NO estás en la página del vídeo (ni en
// pantalla completa). Barra de posición con la miniatura del momento; miniatura 80×45 + título/autor (clic = ir a lo que
// suena), ⏮ ⏯ ⏭, tiempo, capítulo, ⏱ velocidad, CC, ⚙ calidad, 🔁 repetir, 🎧 solo sonido, ☾ temporizador, ☰ cola,
// ↗ compartir (desde el minuto actual), 🔊 silencio + volumen 0-130, ⛶ pantalla completa y ✕ parar.
//
// Uso: const b = new Barra({rep: () => repActivo, visible: () => bool, ir_a_lo_que_suena, menu_compartir, pantalla, guardar_cola})
//   Todas las opciones son funciones y opcionales. «visible» por defecto: <body> sin la clase «en-video» y sin pantalla
//   completa (M4/M7 ponen «en-video» en <body> mientras se ve la página del vídeo o los Shorts).
"use strict";
(function () {
  const R = window.Reproductor, M = window.Mandos;
  const tiempo = R.tiempo, api = R.api;

  class Barra {
    constructor(opciones) {
      this.o = Object.assign({}, opciones || {});
      this.rep = this.o.rep || (() => (R.gestor.vista ? R.gestor.vista() : R.gestor.activo));
      const r = () => this.rep();
      const caja = this.caja = document.createElement("div");
      caja.className = "cb-barra"; caja.hidden = true;
      caja.setAttribute("role", "region"); caja.setAttribute("aria-label", "Reproductor");
      this.vista = new M.VistaPrevia();
      this.posicion = new M.BarraPosicion(r, this.vista);
      const fila = document.createElement("div"); fila.className = "cb-fila";
      this.img = document.createElement("img");
      this.img.className = "cb-img"; this.img.alt = ""; this.img.decoding = "async"; this.img.referrerPolicy = "no-referrer";
      this.texto = document.createElement("div"); this.texto.className = "cb-texto";
      this.tTitulo = document.createElement("b"); this.tAutor = document.createElement("span");
      this.texto.append(this.tTitulo, this.tAutor);
      const ir = () => { if (this.o.ir_a_lo_que_suena) this.o.ir_a_lo_que_suena(r()); };
      this.img.addEventListener("click", ir); this.texto.addEventListener("click", ir);
      const texto = (t, ayuda, accion, clase) => {
        const b = document.createElement("button");
        b.type = "button"; b.className = "cb-boton" + (clase ? " " + clase : ""); b.textContent = t; b.title = ayuda;
        b.setAttribute("aria-label", ayuda); b.tabIndex = -1;
        b.addEventListener("click", (ev) => { ev.stopPropagation(); accion(b); });
        return b;
      };
      const conRep = (f) => () => { const x = r(); if (x) f(x); };
      const ant = M.boton("cb-svg", "anterior", "Anterior (Mayús+P)", conRep((x) => x.anterior()));
      this.play = M.boton("cb-svg", "pausa", "Pausa / seguir (espacio o k)", conRep((x) => x.alternar()));
      const sig = M.boton("cb-svg", "siguiente", "Siguiente (Mayús+N)", conRep((x) => x.siguiente()));
      this.tiempo = document.createElement("span"); this.tiempo.className = "cb-gris"; this.tiempo.textContent = "0:00 / 0:00";
      this.capitulo = document.createElement("span"); this.capitulo.className = "cb-gris cb-capitulo";
      const conMenu = (lista) => (b) => { const x = r(); if (x) M.menu(lista(x), b); };
      const bVel = texto("⏱", "Velocidad", conMenu((x) => M.menus.velocidad(x)));
      this.cc = texto("CC", "Subtítulos", conMenu((x) => M.menus.subtitulos(x)), "cb-cc");
      const bCal = texto("⚙", "Calidad", conMenu((x) => M.menus.calidad(x)));
      this.bucle = texto("🔁", "Repetir este vídeo", conRep((x) => x.bucle(!x.bucle_activo)), "cb-marcable");
      this.sonido = texto("🎧", "Solo sonido (sin imagen: gasta mucho menos)", conRep((x) => x.solo_sonido(!x.solo)), "cb-marcable");
      this.apagado = texto("☾", "Temporizador de apagado", conMenu((x) => M.menus.apagado(x)), "cb-marcable");
      const bCola = texto("☰", "Cola de reproducción", conMenu((x) => M.menus.cola(x, this.o.guardar_cola)));
      const bComp = texto("↗", "Compartir (desde el minuto actual)", (b) => this.compartir(b));
      this.mute = M.boton("cb-svg", "volumen", "Silenciar (m)", conRep((x) => x.silencio()));
      this.vol = M.deslizadorVolumen(r);
      const bCompleta = texto("⛶", "Pantalla completa (f)", () => {
        const f = this.o.pantalla; if (typeof f === "function") f(r()); else M.DE_SERIE.pantalla(r());
      });
      const bParar = texto("✕", "Parar", conRep((x) => x.parar()));
      fila.append(this.img, this.texto, ant, this.play, sig, this.tiempo, this.capitulo, bVel, this.cc, bCal, this.bucle, this.sonido,
        this.apagado, bCola, bComp, this.mute, this.vol, bCompleta, bParar);
      caja.append(this.posicion.caja, fila);
      caja.addEventListener("wheel", (ev) => {   // la rueda sobre el volumen lo cambia, como en los mandos
        if (!ev.target.closest(".cm-volumen")) return;
        ev.preventDefault();
        const x = r(); if (x) x.volumen(Math.max(0, Math.min(130, x.vol + (ev.deltaY < 0 ? 5 : -5))));
      }, {passive: false});
      // dentro de #barra-inferior del marco (M4) si existe; si no, fija abajo en <body>
      this.sitio = this.o.dentro || document.getElementById("barra-inferior");
      if (this.sitio) { caja.classList.add("en-sitio"); this.sitio.appendChild(caja); this.sitio.hidden = true; }
      else document.body.appendChild(caja);
      this._oyente = () => R.pintarPronto(this._pintar);
      this._pintar = () => this.refrescar();
      this._repDe = null; this._de = null;
      new MutationObserver(this._oyente).observe(document.body, {attributes: true, attributeFilter: ["class"]});
      document.addEventListener("fullscreenchange", this._oyente);
      window.addEventListener("catode:rep", this._oyente);   // el gestor cambia de reproductor activo
      const app = window.app;
      if (app && typeof app.on === "function") for (const n of ["pagina", "navega", "completa", "pestana:cambia"]) app.on(n, this._oyente);
      this._oyente();
    }
    enganchar() {
      const rep = this.rep();
      if (rep === this._repDe) return;
      if (this._repDe) this._repDe.removeEventListener("cambio", this._oyente);
      this._repDe = rep;
      if (rep) rep.addEventListener("cambio", this._oyente);
    }
    visible(rep) {
      if (!rep || !rep.actual) return false;
      if (typeof this.o.visible === "function") return !!this.o.visible(rep);
      if (M.esCompleta()) return false;
      const capa = window.CatodeM7 && window.CatodeM7.capa;   // M7: fuera de la página del vídeo y de los Shorts
      if (capa && capa.modo && capa.modo !== "oculta") return !["video", "shorts", "completa"].includes(capa.modo);
      return !document.body.classList.contains("en-video");
    }
    refrescar() {
      this.enganchar();
      const rep = this.rep();
      const ver = this.visible(rep);
      if (this.caja.hidden === ver) {
        this.caja.hidden = !ver; document.body.classList.toggle("con-barra", ver);
        if (this.sitio) this.sitio.hidden = !ver;
      }
      if (!ver) { this.vista.ocultar(); return; }
      const e = rep.actual;
      const clave = e.url + "\n" + e.titulo;
      if (this._de !== clave) {
        this._de = clave;
        const t = String(e.titulo || "");
        this.tTitulo.textContent = t.length < 70 ? t : t.slice(0, 68) + "…";
        this.tAutor.textContent = e.autor || "";
        this.texto.title = t;
        if (e.miniatura) this.img.src = e.miniatura; else this.img.removeAttribute("src");
      }
      M.ponerIcono(this.play, rep.pausa ? "play" : "pausa");
      const tx = rep.directo ? "●  EN DIRECTO" : `${tiempo(rep.pos)} / ${tiempo(rep.dur)}`;
      if (this.tiempo.textContent !== tx) this.tiempo.textContent = tx;
      const cap = M.capituloEn(rep), ct = cap ? `·  ${cap}` : "";
      if (this.capitulo.textContent !== ct) this.capitulo.textContent = ct;
      this.posicion.refrescar(rep);
      this.bucle.classList.toggle("marcado", rep.bucle_activo);
      this.sonido.classList.toggle("marcado", rep.solo);
      this.apagado.classList.toggle("marcado", !!rep.apagado_hora || rep._parar_al_acabar);
      this.cc.classList.toggle("marcado", !!rep._sid);
      M.ponerIcono(this.mute, rep.mute || rep.vol === 0 ? "silencio" : "volumen");
      this.vol.refrescar(rep);
    }
    compartir(b) {   // menu_compartir de M5 si está; si no, copia el enlace desde el minuto actual
      const rep = this.rep(); if (!rep || !rep.actual) return;
      const f = this.o.menu_compartir || (window.catode && window.catode.menu_compartir);
      const r = b.getBoundingClientRect();
      if (typeof f === "function") return f(rep.actual, rep.pos, {x: r.right, y: r.top});
      const id = R.idVideo(rep.actual.url), s = Math.floor(rep.pos);
      const enlace = /^[\w-]{11}$/.test(id) ? `https://www.youtube.com/watch?v=${id}${s > 0 ? "&t=" + s + "s" : ""}` : rep.actual.url;
      api("/api/ventana", {accion: "portapapeles", valor: enlace}).catch(() => {});
      try { navigator.clipboard && navigator.clipboard.writeText(enlace).catch(() => {}); } catch (e) { /* sin portapapeles */ }
      R.gestor.avisar(`Enlace copiado${s > 0 ? ` (desde ${tiempo(s)})` : ""}`);
    }
  }
  window.Barra = Barra;
  // con el marco (M4), la barra se pone sola en #barra-inferior
  const montar = () => {
    if (window.catode && window.catode.barra) return;
    if (document.getElementById("barra-inferior") && window.app) window.catode.barra = new Barra({
      ir_a_lo_que_suena: (rep) => {   // a la página del vídeo que suena (M7), o al menos a su pestaña
        const M7 = window.CatodeM7;
        if (rep && rep.actual && M7 && typeof M7.abrirVideo === "function") M7.abrirVideo(rep.actual, {sonar: false});
      },
    });
  };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", montar); else montar();
})();
