// Cat-ode escritorio · interfaz web · módulo M5 (DISENO_WEB.md §3), 06/10/2026.
// menus.js: el menú ⋮ de un vídeo (tarjetas.py menu_video 572-603) y el de Compartir (menu_compartir 546-570), completos
// y en el mismo orden; un menú emergente genérico con submenús y teclado (↑ ↓ ← → Intro Esc), y los diálogos que en la
// Qt eran QInputDialog/QMessageBox/QDialog (nombre de lista, confirmar, entorno al fulminar, elegir tele).
"use strict";
(function () {
  const M5 = window.M5;
  const Menu = window.Menu = {};

  // ------------------------------------------------------------------------------------------------ menú emergente
  // op = {texto, accion()} · {sep:true} · {texto, sub: [op…] | async () => [op…]} · {texto, desactivada:true}
  let abiertos = [];   // la pila de menús abiertos (el principal y sus submenús)

  function cerrarDesde(i) {
    while (abiertos.length > i) { const m = abiertos.pop(); m.nodo.remove(); }
    if (!abiertos.length) quitarOyentes();
  }
  Menu.cerrar = () => cerrarDesde(0);
  Menu.abierto = () => abiertos.length > 0;

  function alPulsarFuera(ev) { if (!ev.target.closest || !ev.target.closest(".m5-menu")) Menu.cerrar(); }
  function alTecla(ev) {
    const m = abiertos[abiertos.length - 1];
    if (!m) return;
    const ops = m.items.filter((x) => !x.op.sep && !x.op.desactivada);
    let i = ops.findIndex((x) => x.nodo.classList.contains("sel"));
    const marcar = (j) => { ops.forEach((x) => x.nodo.classList.remove("sel")); if (ops[j]) { ops[j].nodo.classList.add("sel"); ops[j].nodo.scrollIntoView({block: "nearest"}); } };
    if (ev.key === "ArrowDown") marcar((i + 1) % ops.length);
    else if (ev.key === "ArrowUp") marcar((i - 1 + ops.length) % ops.length);
    else if (ev.key === "ArrowRight" && i >= 0 && ops[i].op.sub) abrirSub(m, ops[i], true);
    else if (ev.key === "ArrowLeft" || ev.key === "Escape") { cerrarDesde(abiertos.length - 1); }
    else if ((ev.key === "Enter" || ev.key === " ") && i >= 0) elegir(m, ops[i], true);
    else return;
    ev.preventDefault(); ev.stopPropagation();
  }
  function alScroll(ev) { if (!ev.target.closest || !ev.target.closest(".m5-menu")) Menu.cerrar(); }
  function ponerOyentes() {
    document.addEventListener("mousedown", alPulsarFuera, true);
    document.addEventListener("keydown", alTecla, true);
    document.addEventListener("scroll", alScroll, true);
    window.addEventListener("blur", Menu.cerrar);
    window.addEventListener("resize", Menu.cerrar);
  }
  function quitarOyentes() {
    document.removeEventListener("mousedown", alPulsarFuera, true);
    document.removeEventListener("keydown", alTecla, true);
    document.removeEventListener("scroll", alScroll, true);
    window.removeEventListener("blur", Menu.cerrar);
    window.removeEventListener("resize", Menu.cerrar);
  }

  function colocar(nodo, x, y, junto) {
    document.body.appendChild(nodo);
    const r = nodo.getBoundingClientRect();
    const W = window.innerWidth, H = window.innerHeight;
    if (junto) {   // submenú: a la derecha de su opción o, si no cabe, a la izquierda del menú padre
      x = junto.right - 4; y = junto.top - 8;
      if (x + r.width > W - 4) x = Math.max(4, junto.left - r.width + 4);
    }
    if (x + r.width > W - 4) x = Math.max(4, W - r.width - 4);
    if (y + r.height > H - 4) y = Math.max(4, H - r.height - 4);
    nodo.style.left = Math.round(x) + "px";
    nodo.style.top = Math.round(y) + "px";
  }

  async function abrirSub(m, item, conTeclado) {
    const nivel = abiertos.indexOf(m);
    cerrarDesde(nivel + 1);
    let ops = item.op.sub;
    if (typeof ops === "function") ops = await ops();
    if (abiertos[nivel] !== m) return;   // se cerró mientras tanto
    const sub = construir(ops || []);
    colocar(sub.nodo, 0, 0, item.nodo.getBoundingClientRect());
    abiertos.push(sub);
    if (conTeclado) { const p = sub.items.find((x) => !x.op.sep && !x.op.desactivada); if (p) p.nodo.classList.add("sel"); }
  }

  function elegir(m, item, conTeclado) {
    if (item.op.sub) return abrirSub(m, item, conTeclado);
    if (item.op.desactivada) return;
    Menu.cerrar();
    try { const r = item.op.accion && item.op.accion(); if (r && r.catch) r.catch((e) => M5.avisar("Algo ha fallado: " + e)); }
    catch (e) { M5.avisar("Algo ha fallado: " + e); }
  }

  function construir(ops) {
    const nodo = document.createElement("div");
    nodo.className = "m5-menu";
    nodo.setAttribute("role", "menu");
    const m = {nodo, items: []};
    let relojSub = 0;
    for (const op of ops) {
      if (!op) continue;
      const d = document.createElement("div");
      if (op.sep) { d.className = "m5-sep"; nodo.appendChild(d); m.items.push({op, nodo: d}); continue; }
      d.className = "m5-op" + (op.desactivada ? " desactivada" : "");
      d.setAttribute("role", "menuitem");
      d.textContent = op.texto;
      if (op.sub) { const f = document.createElement("span"); f.className = "m5-flecha"; f.textContent = "▸"; d.appendChild(f); }
      const item = {op, nodo: d};
      d.addEventListener("click", (ev) => { ev.stopPropagation(); elegir(m, item, false); });
      d.addEventListener("mouseenter", () => {
        m.items.forEach((x) => x.nodo.classList && x.nodo.classList.remove("sel"));
        d.classList.add("sel");
        clearTimeout(relojSub);
        relojSub = setTimeout(() => {
          if (!abiertos.includes(m)) return;   // ese menú ya se cerró: el temporizador no toca al nuevo
          if (op.sub) abrirSub(m, item, false);
          else cerrarDesde(abiertos.indexOf(m) + 1);
        }, op.sub ? 120 : 250);
      });
      nodo.appendChild(d);
      m.items.push(item);
    }
    nodo.addEventListener("contextmenu", (ev) => ev.preventDefault());
    return m;
  }

  /** Abre un menú en (x, y) de la ventana. conTeclado: la primera opción ya marcada (tecla Menú). */
  Menu.abrir = function (ops, x, y, conTeclado) {
    Menu.cerrar();
    if (window.Previa) window.Previa.salir();   // con un menú abierto no hay vista previa
    const m = construir(ops);
    colocar(m.nodo, x, y);
    abiertos.push(m);
    ponerOyentes();
    if (conTeclado) { const p = m.items.find((i) => !i.op.sep && !i.op.desactivada); if (p) p.nodo.classList.add("sel"); }
    return m.nodo;
  };

  // ------------------------------------------------------------------------------------------------ diálogos
  function dialogo(construirCuerpo) {
    return new Promise((resolver) => {
      Menu.cerrar();
      const velo = document.createElement("div");
      velo.className = "m5-velo";
      const caja = document.createElement("div");
      caja.className = "m5-dlg";
      caja.setAttribute("role", "dialog");
      velo.appendChild(caja);
      const antes = document.activeElement;
      const acabar = (v) => {
        velo.remove();
        document.removeEventListener("keydown", tecla, true);
        if (antes && antes.focus) try { antes.focus({preventScroll: true}); } catch (e) {}
        resolver(v);
      };
      const tecla = (ev) => {
        if (ev.key === "Escape") { ev.preventDefault(); ev.stopPropagation(); acabar(null); }
        else if (ev.key === "Enter" && caja._aceptar && ev.target.tagName !== "BUTTON") { ev.preventDefault(); ev.stopPropagation(); caja._aceptar(); }
        else ev.stopPropagation();   // el teclado no llega a la página de debajo (atajos)
      };
      document.addEventListener("keydown", tecla, true);
      velo.addEventListener("mousedown", (ev) => { if (ev.target === velo) acabar(null); });
      construirCuerpo(caja, acabar);
      document.body.appendChild(velo);
      const f = caja.querySelector("input[type=text]") || caja.querySelector("button.principal");
      if (f) { f.focus(); if (f.select) f.select(); }
    });
  }
  function boton(texto, principal, accion) {
    const b = document.createElement("button");
    b.textContent = texto;
    if (principal) b.className = "principal";
    b.addEventListener("click", accion);
    return b;
  }
  function cabecera(caja, titulo, texto) {
    const h = document.createElement("h2"); h.textContent = titulo; caja.appendChild(h);
    if (texto) { const p = document.createElement("p"); p.textContent = texto; caja.appendChild(p); }
  }
  function botones(caja, ...bs) { const d = document.createElement("div"); d.className = "m5-botones"; bs.forEach((b) => d.appendChild(b)); caja.appendChild(d); }

  /** QInputDialog.getText: el texto escrito o null. */
  Menu.preguntar = (titulo, etiqueta, valor) => dialogo((caja, acabar) => {
    cabecera(caja, titulo, etiqueta);
    const i = document.createElement("input"); i.type = "text"; i.value = valor || ""; caja.appendChild(i);
    caja._aceptar = () => acabar(i.value.trim() ? i.value.trim() : null);
    botones(caja, boton("Cancelar", false, () => acabar(null)), boton("Aceptar", true, caja._aceptar));
  });
  /** QMessageBox.question: true si se acepta. */
  Menu.confirmar = (titulo, texto, aceptar) => dialogo((caja, acabar) => {
    cabecera(caja, titulo, texto);
    caja._aceptar = () => acabar(true);
    botones(caja, boton("Cancelar", false, () => acabar(false)), boton(aceptar || "Aceptar", true, caja._aceptar));
  }).then((v) => !!v);
  /** 22/10/2026 · el aviso de novedades al estrenar versión: título, la lista de puntos y «Entendido». */
  Menu.novedades = (titulo, puntos) => dialogo((caja, acabar) => {
    cabecera(caja, titulo, "");
    const ul = document.createElement("ul");
    ul.className = "m5-novedades";
    for (const t of puntos || []) { const li = document.createElement("li"); li.textContent = t; ul.appendChild(li); }
    caja.appendChild(ul);
    caja._aceptar = () => acabar(true);
    botones(caja, boton("Entendido", true, caja._aceptar));
  });
  /** QInputDialog.getItem: el índice elegido o null. */
  Menu.elegir = (titulo, texto, opciones) => dialogo((caja, acabar) => {
    cabecera(caja, titulo, texto);
    opciones.forEach((o, i) => { const b = boton(o, i === 0, () => acabar(i)); b.style.display = "block"; b.style.margin = "6px 0"; caja.appendChild(b); });
    botones(caja, boton("Cancelar", false, () => acabar(null)));
  });
  /** Casillas (_dialogo_entorno 3100): la lista de índices marcados, o null con «Ninguno». */
  Menu.marcar = (titulo, texto, opciones, aceptar, rechazar) => dialogo((caja, acabar) => {
    cabecera(caja, titulo, texto);
    const cajas = opciones.map((o) => {
      const l = document.createElement("label");
      const c = document.createElement("input"); c.type = "checkbox"; c.checked = !!o.marcado;
      l.appendChild(c); l.appendChild(document.createTextNode(o.texto)); caja.appendChild(l);
      return c;
    });
    caja._aceptar = () => acabar(cajas.map((c, i) => c.checked ? i : -1).filter((i) => i >= 0));
    botones(caja, boton(rechazar || "Cancelar", false, () => acabar(null)), boton(aceptar || "Aceptar", true, caja._aceptar));
  });

  // ------------------------------------------------------------------------------------------------ acciones compartidas
  /** Portapapeles por la ventana Qt (fiable en WebView2) y, además, por el navegador si lo deja. */
  M5.copiar = function (texto, aviso) {
    M5.ultimoCopiado = texto;
    M5.ventana("portapapeles", texto);
    try { if (navigator.clipboard && window.isSecureContext) navigator.clipboard.writeText(texto).catch(() => {}); } catch (e) {}
    M5.avisar(aviso || "Copiado");
  };
  M5.abrirFuera = function (url) { M5.ultimoFuera = url; M5.ventana("abrir_fuera", url); };

  /** enlace(e, segundos) de tarjetas.py 546. */
  M5.enlace = function (e, segundos) {
    // 19/10/2026: www.youtube.com/watch, no youtu.be (con youtu.be WhatsApp no sacaba la vista previa); compartir.py enlace_video
    const vid = M5.idVideo(e.url);
    return vid && vid !== e.url ? `https://www.youtube.com/watch?v=${vid}` + (segundos ? `&t=${Math.floor(segundos)}s` : "") : e.url;
  };

  /** menu_compartir 546-570: las opciones, para un menú o un submenú. */
  Menu.compartir = function (e, segundos) {
    const url = M5.enlace(e, segundos);
    const titulo = e.titulo || "";
    const ops = [{texto: "🔗  Copiar enlace", accion: () => M5.copiar(M5.enlace(e), "Enlace copiado")}];
    if (segundos) ops.push({texto: `⏱  Copiar enlace en el minuto ${M5.tiempo(segundos)}`, accion: () => M5.copiar(url, "Enlace con el minuto copiado")});
    ops.push({sep: true});
    // 19/10/2026 «tienen que abrirse directamente en las apps»: lo abre Python (compartir.py) en la app si la hay
    for (const [nombre, app] of [["WhatsApp", "whatsapp"], ["Telegram", "telegram"], ["Correo", "correo"],
      ["X (Twitter)", "x"], ["Facebook", "facebook"], ["Reddit", "reddit"]]) {
      ops.push({texto: nombre, accion: () => { M5.ultimoCompartido = {app, url, titulo}; M5.ventana("compartir", {app, url, titulo}); }});
    }
    ops.push({sep: true});
    ops.push({texto: "🌐  Abrir en el navegador", accion: () => M5.abrirFuera(url)});
    return ops;
  };
  // para el ↗ de la barra inferior y los mandos (M6): el menú de compartir entero en un punto {x, y}
  window.catode = window.catode || {};
  window.catode.menu_compartir = (e, segundos, p) => { if (e) Menu.abrir(Menu.compartir(e, segundos || 0), (p && p.x) || 0, (p && p.y) || 0); };

  /** Lo que hace falta para pintar el menú: si ya está en «Ver más tarde», «Me gusta» y en qué listas propias. */
  async function pertenencia(e) {
    const [despues, megusta, listas] = await Promise.all([M5.api("/api/pagina/coleccion/despues"), M5.api("/api/pagina/coleccion/megusta"), M5.api("/api/pagina/listas")]);
    const en = (r) => !!(r && r.ok && (r.elementos || []).some((x) => x.url === e.url));
    const propias = ((listas && listas.ok && listas.elementos) || []).filter((x) => (x.url || "").startsWith("propia:"));
    const contenidos = await Promise.all(propias.map((l) => M5.api("/api/pagina/lista_propia/" + encodeURIComponent(l.url))));
    return {despues: en(despues), megusta: en(megusta), listas: propias.map((l, i) => ({clave: l.url, nombre: l.titulo || "Lista", dentro: en(contenidos[i])}))};
  }
  M5.pertenencia = pertenencia;

  /** nueva_lista(e) 3175: pide el nombre, la crea y mete e si se pasa. Devuelve la clave o null. */
  M5.nuevaLista = async function (e, elementos) {
    const nombre = await Menu.preguntar("Nueva lista", "Nombre de la lista:");
    if (!nombre) return null;
    const r = await M5.datos("lista", {que: "nueva", nombre, e: e ? M5.limpio(e) : undefined, elementos: elementos ? elementos.map(M5.limpio) : undefined});
    if (!r.ok) { M5.avisar("No he podido crear la lista: " + (r.error || "")); return null; }
    M5.avisar(`Lista «${nombre}» creada`);
    M5.emitirDatos("listas");
    return r.clave;
  };

  /** poner_en_tele 3386: busca las teles (DIAL), elige si hay varias y la pone. */
  M5.ponerEnTele = async function (e) {
    if (!e) return M5.avisar("No hay ningún vídeo que poner");
    M5.avisar("Buscando la tele…");
    const r = await M5.api("/api/tele");
    const teles = (r.ok && r.teles) || [];
    if (!teles.length) return M5.avisar("No encuentro ninguna tele en la red");
    let i = 0;
    if (teles.length > 1) {
      i = await Menu.elegir("Poner en la tele", "¿En cuál?", teles.map((t) => t.nombre));
      if (i == null) return;
    }
    const p = await M5.api("/api/tele", {accion: "poner", tele: teles[i], url: e.url});
    M5.avisar(p.ok && p.puesto ? `En la tele: ${teles[i].nombre}` : "La tele no ha respondido");
  };

  /** descargar(e, solo_audio, alto) 3190: el progreso llega por SSE «descarga» (lo pinta el marco, M4). */
  M5.descargar = async function (e, soloAudio, alto) {
    const r = await M5.api("/api/descargar", {e: M5.limpio(e), solo_audio: !!soloAudio, alto: alto || 720});
    M5.avisar(r.ok ? (soloAudio ? "♪ " : "") + "Descargando: " + (e.titulo || "").slice(0, 40) : "No he podido descargarlo: " + (r.error || ""));
  };

  /** Aviso a las rejillas vivas de que algo de los datos ha cambiado (también lo dispara el SSE «datos» si M4 quiere). */
  M5.emitirDatos = (col, motivo) => window.dispatchEvent(new CustomEvent("catode:datos", {detail: {col, motivo}}));

  /** fulminar 3068 + _dialogo_entorno 3100: fuera el canal y, si se quiere, su entorno. */
  M5.fulminar = async function (e) {
    const url = e.tipo === "CANAL" ? e.url : e.autorUrl;
    const nombre = e.tipo === "CANAL" ? e.titulo : e.autor;
    if (!(url || nombre)) return false;
    M5.avisar(`«${nombre}» fulminado: no volverá a salir. Buscando su entorno…`);
    const vetarYa = M5.vetarLocal && M5.vetarLocal(url, nombre);   // la rejilla lo quita ya, sin esperar
    const r = await M5.datos("fulminar", {url: url || "", nombre: nombre || ""});
    if (!r.ok) { M5.avisar("No he podido fulminarlo: " + (r.error || "")); return false; }
    M5.emitirDatos("ocultos", "fulminar");
    const res = r.entorno || [];
    if (!res.length) { M5.avisar(`«${nombre}» fulminado (no tiene un entorno claro)`); return true; }
    const marcados = await Menu.marcar(`Fulminar también el entorno de «${nombre}»`,
      "Canales que YouTube pone a su lado. Marcados, los de su misma burbuja (comparten audiencia).\nDesmarca los que quieras conservar.",
      res.map((x) => ({texto: `${x.nombre}   ·   burbuja ${x.pct} %`, marcado: x.marcado !== undefined ? x.marcado : x.pct >= 35})),
      "Fulminar los marcados", "Ninguno");
    if (marcados && marcados.length) {
      const urls = marcados.map((i) => ({url: res[i].url, nombre: res[i].nombre}));
      const l = await M5.datos("fulminar_lote", {urls});
      if (l.ok) { M5.avisar(`${urls.length} canales más fulminados`); M5.emitirDatos("ocultos", "fulminar"); }
    }
    return vetarYa !== false;
  };

  /** menu_video 572-603, en el mismo orden. o = {rejilla, quitarDeVista(e)}: «No me interesa» lo quita de la vista. */
  Menu.video = async function (e, x, y, o) {
    o = o || {};
    const p = await pertenencia(e);
    const alternar = async (col, si, no) => {
      const r = await M5.datos("alternar", {col, e: M5.limpio(e)});
      if (!r.ok) return M5.avisar("No he podido guardarlo: " + (r.error || ""));
      M5.avisar(r.puesto ? si : no);
      M5.emitirDatos(col);
    };
    const listas = () => {
      const ops = p.listas.map((l) => ({texto: (l.dentro ? "✓ " : "") + l.nombre, accion: async () => {
        const r = await M5.datos("lista", {que: l.dentro ? "quitar" : "poner", clave: l.clave, e: M5.limpio(e)});
        M5.avisar(r.ok ? "Lista actualizada" : "No he podido cambiar la lista");
        M5.emitirDatos("listas");
      }}));
      ops.push({sep: true}, {texto: "Nueva lista…", accion: () => M5.nuevaLista(e)});
      return ops;
    };
    const ops = [
      {texto: "▶  Reproducir", accion: () => M5.abrir(e)},
      {texto: "⧉  Abrir en pestaña nueva", accion: () => M5.nuevaPestana(e)},
      {texto: "▣  Ver a la vez (segundo vídeo)", accion: () => M5.rep("verALaVez", e)},
      {texto: "📺  Poner en la tele", accion: () => M5.ponerEnTele(e)},
      {texto: "⏭  Reproducir a continuación", accion: () => M5.rep("aContinuacion", e)},
      {texto: "☰  Añadir a la cola", accion: () => M5.rep("encolar", e)},
      {sep: true},
      {texto: p.despues ? "✓  Quitar de «Ver más tarde»" : "🕒  Guardar para ver más tarde",
        accion: () => alternar("despues", "Guardado en «Ver más tarde»", "Quitado de «Ver más tarde»")},
      {texto: p.megusta ? "👍  Quitar de «Me gusta»" : "👍  Me gusta",
        accion: () => alternar("megusta", "Añadido a «Me gusta»", "Quitado de «Me gusta»")},
      {texto: "➕  Guardar en una lista", sub: listas},
      {texto: "⬇  Descargar", sub: [360, 720, 1080].map((a) => ({texto: `Vídeo ${a}p`, accion: () => M5.descargar(e, false, a)}))
        .concat([{texto: "Solo el sonido (m4a)", accion: () => M5.descargar(e, true)}])},
      {texto: "Compartir", sub: Menu.compartir(e, o.segundos || 0)},
      {sep: true},
      e.autorUrl ? {texto: "👤  Ir al canal", accion: () => M5.abrirCanal(e.autorUrl, false)} : null,
      {texto: "🚫  No me interesa", accion: async () => {
        const r = await M5.datos("ocultar", {e: M5.limpio(e)});
        if (!r.ok) return M5.avisar("No he podido ocultarlo");
        if (o.quitarDeVista) o.quitarDeVista(e);
        M5.avisar("Vale: no te lo volveré a enseñar");
      }},
      {texto: `⊘  Fulminar «${e.tipo !== "CANAL" ? (e.autor || "") : (e.titulo || "")}» y su entorno`, accion: () => M5.fulminar(e)},
    ];
    return Menu.abrir(ops, x, y, !!o.conTeclado);
  };
  /** Solo el submenú de listas (PaginaVideo.guardar): para M7. */
  Menu.listas = async function (e, x, y) {
    const p = await pertenencia(e);
    const ops = p.listas.map((l) => ({texto: (l.dentro ? "✓ " : "") + l.nombre, accion: async () => {
      const r = await M5.datos("lista", {que: l.dentro ? "quitar" : "poner", clave: l.clave, e: M5.limpio(e)});
      M5.avisar(r.ok ? "Lista actualizada" : "No he podido cambiar la lista");
    }}));
    ops.push({sep: true}, {texto: "Nueva lista…", accion: () => M5.nuevaLista(e)});
    return Menu.abrir(ops, x, y);
  };
})();
