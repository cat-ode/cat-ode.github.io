// Cat-ode escritorio · interfaz web, módulo M7 (06/10/2026): la transcripción de la página del vídeo (interfaz.py 980-1027).
// Botón ▸/▾ Transcripción (plegada; se pide a GET /api/video/transcripcion solo al abrirla, una vez por vídeo),
// «Buscar en la transcripción…» que filtra las líneas (Ctrl+F lo enfoca si está abierta), lista de 300 px con
// «mm:ss  frase»; clic = ir a ese momento (central o Ctrl = en una pestaña nueva). Sigue el tiempo del vídeo: la línea
// que suena se marca y la lista la acompaña, salvo si el ratón está encima (no le quita la lectura al autor).
//   CatodeM7.transcripcion(contenedor, url, {saltar(s, ev), tiempo()}) → {destruir(), alTiempo(t), enfocar(), abierta(), abrir()}
"use strict";
(function () {
  const M7 = window.CatodeM7 = window.CatodeM7 || {};

  M7.transcripcion = function (cont, url, op) {
    const U = M7.util, el = U.el;
    op = op || {};
    let lineas = null, nodos = [], actual = -1, vivo = true, encima = false, pedida = false;
    const ctl = new AbortController();
    const boton = el("button", {class: "tr-boton", text: "▸ Transcripción", "aria-expanded": "false"});
    const buscar = el("input", {class: "tr-buscar", type: "search", placeholder: "Buscar en la transcripción…", "aria-label": "Buscar en la transcripción"});
    const aviso = el("div", {class: "tr-aviso m7-gris"});
    const lista = el("div", {class: "tr-lista", role: "list", tabindex: "0"});
    const cuerpo = el("div", {class: "tr-cuerpo", hidden: true}, buscar, aviso, lista);
    const raiz = el("section", {class: "tr"}, boton, cuerpo);
    cont.textContent = "";
    cont.append(raiz);

    async function pedir() {
      if (pedida) return;
      pedida = true;
      aviso.textContent = "Cargando la transcripción…";
      let r;
      try { r = await M7.api("/api/video/transcripcion?url=" + encodeURIComponent(url), undefined, "GET", ctl.signal); }
      catch (err) { return; }
      if (!vivo) return;
      if (!r.ok) { pedida = false; aviso.textContent = (r.error || "No he podido cargar la transcripción") + " · ábrela otra vez para reintentar"; return; }
      lineas = r.lineas || [];
      if (!lineas.length) { aviso.textContent = r.aviso || "Este vídeo no tiene subtítulos: no hay transcripción."; return; }
      pintar();
    }
    function pintar() {
      lista.textContent = "";
      const f = document.createDocumentFragment();
      nodos = lineas.map(([s, frase], i) => {
        const n = el("div", {class: "tr-linea", role: "listitem", tabindex: "-1", "data-s": s},
          el("span", {class: "tr-t", text: U.tiempo(s)}), el("span", {class: "tr-frase", text: frase}));
        n.addEventListener("click", (ev) => op.saltar && op.saltar(s, ev));
        n.addEventListener("auxclick", (ev) => { if (ev.button === 1) { ev.preventDefault(); op.saltar && op.saltar(s, ev); } });
        f.append(n);
        return n;
      });
      lista.append(f);
      filtrar();
      if (op.tiempo) alTiempo(op.tiempo() || 0);
    }
    function filtrar() {
      const q = buscar.value.trim().toLowerCase();
      let n = 0;
      nodos.forEach((x, i) => { const si = !q || lineas[i][1].toLowerCase().includes(q); x.hidden = !si; if (si) n++; });
      aviso.textContent = q ? `${n} de ${nodos.length} líneas con «${buscar.value.trim()}»` : `${nodos.length} líneas · clic en una para ir a ese momento`;
    }
    function alTiempo(t) {
      if (!lineas || !lineas.length || cuerpo.hidden) return;
      let k = -1;
      for (let i = 0; i < lineas.length && lineas[i][0] <= t + 0.25; i++) k = i;
      if (k === actual) return;
      if (actual >= 0 && nodos[actual]) nodos[actual].classList.remove("actual");
      actual = k;
      if (k < 0 || !nodos[k]) return;
      nodos[k].classList.add("actual");
      if (!encima && !nodos[k].hidden) {   // acompañar sin mover la página entera: solo el scroll de la lista
        const n = nodos[k], arriba = n.offsetTop;   // .tr-lista es position:relative
        if (arriba < lista.scrollTop || arriba + n.offsetHeight > lista.scrollTop + lista.clientHeight) lista.scrollTop = Math.max(0, arriba - lista.clientHeight / 3);
      }
    }
    function abrir(si) {
      cuerpo.hidden = !si;
      boton.textContent = (si ? "▾" : "▸") + " Transcripción";
      boton.setAttribute("aria-expanded", si ? "true" : "false");
      if (si) { pedir(); actual = -1; if (lineas && op.tiempo) alTiempo(op.tiempo() || 0); }
    }
    boton.addEventListener("click", () => abrir(cuerpo.hidden));
    buscar.addEventListener("input", filtrar);
    buscar.addEventListener("keydown", (ev) => { if (ev.key === "Escape" && buscar.value) { ev.stopPropagation(); buscar.value = ""; filtrar(); } });
    lista.addEventListener("mouseenter", () => { encima = true; });
    lista.addEventListener("mouseleave", () => { encima = false; });
    return {
      alTiempo, abrir, abierta: () => !cuerpo.hidden, lineas: () => lineas,
      enfocar() { abrir(true); buscar.focus(); buscar.select(); },
      destruir() { vivo = false; ctl.abort(); raiz.remove(); },
    };
  };
})();
