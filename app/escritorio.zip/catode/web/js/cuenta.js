// Cat-ode escritorio · interfaz web: «Traer mi YouTube» en dos sentidos (18/10/2026, orden del autor: «la opción traer desde
// youtube tiene que tener una opción de "actualizar cuenta desde youtube", por si se han suscrito nuevos canales y otra de
// "actualizar youtube desde cat-ode"»). Habla con /api/cuenta (servidor_web.py → cuenta_servicio.py) y escucha el SSE
// «cuenta» ({fase: leer|plan|aplicar, texto, fraccion, hecho, resumen, error, plan}).
//   catode.cuenta.seccion(caja)  → la sección de Ajustes (botones, progreso, resumen, cerrar sesión)
//   catode.cuenta.ir({empezar})  → abre Ajustes en esa sección (entrada del menú e invitación del Inicio)
//   catode.cuenta.invitar(nodo)  → la invitación «Trae tu YouTube» del Inicio vacío (equipo nuevo), como en Android
//   catode.cuenta.confirmar(plan)→ el diálogo de B con números, nombres y la cuenta o canal destino
"use strict";
(function () {
  const C = window.catode = window.catode || {};
  const M7 = () => window.CatodeM7 || {};
  const el = (t, a, ...hijos) => {
    const n = document.createElement(t);
    for (const [k, v] of Object.entries(a || {})) {
      if (v === undefined || v === null || v === false) continue;
      if (k === "text") n.textContent = v; else if (k === "class") n.className = v;
      else if (k.startsWith("on")) n.addEventListener(k.slice(2), v); else n.setAttribute(k, v === true ? "" : v);
    }
    for (const h of hijos.flat()) if (h !== null && h !== undefined && h !== false) n.append(h instanceof Node ? h : String(h));
    return n;
  };
  const api = (ruta, cuerpo) => M7().api(ruta, cuerpo);
  const avisar = (t) => (M7().avisar ? M7().avisar(t) : (window.app && window.app.avisar && window.app.avisar(t)));
  const plural = (n, uno, varios) => `${n} ${n === 1 ? uno : varios}`;

  // el SSE «cuenta»: los de app.js (M4) si están; si no, los de M7 (que abre su propia conexión)
  function oir(fn) {
    const app = window.app;
    if (app && typeof app.on === "function") { app.on("cuenta", fn); return () => app.off && app.off("cuenta", fn); }
    return M7().on ? M7().on("cuenta", fn) : () => {};
  }
  // espera el final («hecho») de una fase; el oyente se pone ANTES de pedirla
  function esperarFin(fase, pedir) {
    return new Promise((ok) => {
      let soltar = () => {};
      soltar = oir((d) => { if (d && d.fase === fase && d.hecho) { soltar(); ok(d); } });
      Promise.resolve(pedir()).then((r) => {
        if (!r || !r.ok) { soltar(); ok({fase, hecho: true, error: (r && r.error) || "No ha salido"}); }
        else if (r.ocupado) { soltar(); ok({fase, hecho: true, error: "Ya estoy con ello: espera a que acabe"}); }
      });
    });
  }

  // ------------------------------------------------------------------ diálogo de confirmación de B
  function confirmar(plan) {
    return new Promise((fin) => {
      const n = plan.numeros || {};
      const fondo = el("div", {class: "m7-dialogo-fondo"});
      const caja = el("div", {class: "m7-dialogo cu-dialogo", role: "dialog", "aria-modal": "true"});
      caja.append(el("h2", {text: "Actualizar YouTube desde Cat-ode"}));
      const ids = plan.identidades || [];
      let elegida = (plan.identidad || {}).clave || "";
      if (ids.length > 1) {
        const sel = el("select", {class: "cu-destino", "aria-label": "Cuenta o canal de YouTube"},
          ids.map((i) => { const o = el("option", {value: i.clave, text: i.nombre || i.clave}); if (i.clave === elegida) o.selected = true; return o; }));
        sel.addEventListener("change", () => cerrar({boton: "otra", destino: sel.value}));
        caja.append(el("label", {class: "m7-campo"}, el("span", {text: "En qué cuenta o canal de YouTube"}), sel));
      } else if (plan.identidad) {
        caja.append(el("p", {class: "m7-gris", text: `En ${plan.identidad.nombre || "tu cuenta"}`}));
      }
      if (plan.vacio) {
        caja.append(el("p", {class: "cu-numeros", text: "Nada que llevar: tu YouTube ya tiene lo de Cat-ode."}));
      } else {
        const partes = [];
        if (n.suscribir) partes.push(`suscribirse a ${plural(n.suscribir, "canal", "canales")}`);
        if (n.quitar) partes.push(`quitar ${plural(n.quitar, "canal", "canales")}`);
        if (n.megusta) partes.push(`${n.megusta} «Me gusta»`);
        if (n.despues) partes.push(`${n.despues} en «Ver más tarde»`);
        caja.append(el("p", {class: "cu-numeros", text: "Voy a " + partes.join(", ").replace(/, ([^,]*)$/, " y $1") + "."}));
      }
      const lista = (titulo, nombres, clase) => {
        if (!nombres || !nombres.length) return;
        caja.append(el("p", {class: "cu-lista-titulo", text: titulo}),
          el("ul", {class: "cu-lista " + clase}, nombres.map((x) => el("li", {text: x}))));
      };
      lista("Suscribirse a:", plan.suscribir, "cu-suscribir");
      lista("Quitar la suscripción a:", plan.quitar, "cu-quitar");
      const notas = [];
      if (n.quedan_megusta || n.quedan_despues) notas.push(`Como mucho 150 de cada en cada pasada: quedan ${n.quedan_megusta || 0} «Me gusta» y ${n.quedan_despues || 0} «Ver más tarde» para la siguiente.`);
      if (n.sin_identificar) notas.push(`${plural(n.sin_identificar, "canal", "canales")} sin identificar: se saltan (${(plan.sin_identificar || []).slice(0, 5).join(", ")}).`);
      if ((plan.sin_leer || []).length) notas.push("No he podido leer " + plan.sin_leer.map((k) => k === "megusta" ? "«Me gusta»" : "«Ver más tarde»").join(" ni ") + " en YouTube: eso no lo toco.");
      if (!plan.vacio) notas.push("Va despacio (una cosa cada segundo y medio) y para si YouTube frena.");
      for (const t of notas) caja.append(el("p", {class: "m7-gris cu-nota", text: t}));
      const pie = el("div", {class: "m7-dialogo-pie"});
      const botones = plan.vacio ? [{texto: "Cerrar", valor: null, principal: true}]
        : [{texto: "Cancelar", valor: null}, {texto: "Aplicar", valor: "aplicar", principal: true}];
      for (const b of botones) {
        pie.append(el("button", {class: "m7-boton" + (b.principal ? " principal" : "") + (b.valor === "aplicar" ? " cu-aplicar" : " cu-cancelar"),
          text: b.texto, onclick: () => cerrar(b.valor ? {boton: b.valor, destino: elegida} : null)}));
      }
      caja.append(pie);
      const tecla = (ev) => { if (ev.key === "Escape") { ev.preventDefault(); ev.stopPropagation(); cerrar(null); } };
      function cerrar(v) { fondo.remove(); document.removeEventListener("keydown", tecla, true); fin(v); }
      document.addEventListener("keydown", tecla, true);
      fondo.append(caja);
      document.body.append(fondo);
      (caja.querySelector(".cu-cancelar") || caja.querySelector("button")).focus();
    });
  }

  // ------------------------------------------------------------------ la sección de Ajustes
  function seccion(caja) {
    const limpiar = [];
    let vivo = true, estado = {};
    const bloque = el("div", {class: "aj-bloque aj-cuenta", id: "aj-cuenta"});
    caja.append(bloque);
    bloque.append(el("h2", {class: "aj-seccion", text: "Traer mi YouTube"}));
    const texto = el("p", {class: "aj-texto", text: "Con tu cuenta de Google, Cat-ode trae tus suscripciones, tu historial, «Me gusta», «Ver más tarde» y tus listas, y los guarda en este equipo. También puede llevar a YouTube lo que hagas aquí."});
    const origen = el("p", {class: "aj-texto m7-gris aj-cuenta-origen"});
    const bTraer = el("button", {class: "m7-boton principal aj-cuenta-traer", text: "Actualizar cuenta desde YouTube",
      title: "Trae lo nuevo de YouTube (canales que has seguido allí, vídeos vistos, «Me gusta»…). Nunca borra nada de Cat-ode"});
    const bLlevar = el("button", {class: "m7-boton aj-cuenta-llevar", text: "Actualizar YouTube desde Cat-ode",
      title: "Lleva a YouTube tus canales, «Me gusta» y «Ver más tarde» de Cat-ode (antes te enseño qué voy a hacer)"});
    const fila = el("div", {class: "aj-cuenta-botones"}, bTraer, bLlevar);
    const progreso = el("div", {class: "aj-cuenta-progreso", hidden: true},
      el("div", {class: "aj-cuenta-carril"}, el("div", {class: "aj-cuenta-relleno"})), el("span", {class: "aj-cuenta-texto"}));
    const resumen = el("p", {class: "aj-texto aj-cuenta-resumen"});
    const bFirefox = el("button", {class: "m7-boton aj-cuenta-firefox", text: "Usar la sesión de Firefox de este equipo", hidden: true,
      title: "Si Google no te deja entrar en la ventana de Cat-ode"});
    const bApp = el("button", {class: "m7-boton aj-cuenta-app", text: "Entrar con Google en Cat-ode", hidden: true});
    const bSalir = el("button", {class: "m7-boton aj-cuenta-salir", text: "Cerrar sesión", hidden: true});
    const bCancelar = el("button", {class: "m7-boton aj-cuenta-cancelar", text: "Cancelar", hidden: true});
    bloque.append(texto, origen, fila, progreso, resumen, el("div", {class: "aj-cuenta-botones"}, bCancelar, bFirefox, bApp, bSalir));
    const relleno = progreso.querySelector(".aj-cuenta-relleno"), ptexto = progreso.querySelector(".aj-cuenta-texto");

    function ocupado(si, fase) {
      bTraer.disabled = bLlevar.disabled = bFirefox.disabled = bApp.disabled = bSalir.disabled = !!si;
      progreso.hidden = !si;
      bCancelar.hidden = !si;   // 18/10/2026 (hallazgo 4): también mientras lee (A)
      if (!si) { relleno.style.width = "0"; ptexto.textContent = ""; }
    }
    function pintarEstado(e) {
      estado = e || {};
      origen.textContent = estado.nombre_origen ? `Con ${estado.nombre_origen}.` : "Sin sesión de YouTube todavía.";
      bFirefox.hidden = !(estado.ventana && estado.origen === "app");
      bApp.hidden = !(estado.ventana && estado.origen && estado.origen !== "app" && estado.origen !== "falsa");
      bSalir.hidden = !(estado.sesion || (estado.origen && estado.origen !== "app"));
      if (estado.ultimo && (estado.ultimo.resumen || estado.ultimo.error) && !resumen.textContent) {
        resumen.textContent = estado.ultimo.resumen || estado.ultimo.error;
        resumen.classList.toggle("error", !!estado.ultimo.error);
      }
      ocupado(!!estado.trabajando, estado.trabajando);
    }
    async function refrescar() {
      const r = await api("/api/cuenta");
      if (vivo && r.ok) pintarEstado(r);
      return r;
    }
    limpiar.push(oir((d) => {
      if (!vivo || !d) return;
      if (!d.hecho) {
        ocupado(true, d.fase);
        if (d.texto) ptexto.textContent = d.texto;
        if (typeof d.fraccion === "number") relleno.style.width = Math.round(100 * Math.max(0, Math.min(1, d.fraccion))) + "%";
        return;
      }
      ocupado(false);
      if (d.fase === "plan" && !d.error) return;   // el plan lo enseña el diálogo
      resumen.textContent = d.resumen || d.error || "";
      resumen.classList.toggle("error", !!d.error);
      refrescar();
    }));

    async function traer(origenNuevo) {
      resumen.textContent = "";
      ocupado(true, "leer");
      ptexto.textContent = estado.ventana && (origenNuevo || estado.origen) === "app" ? "Abriendo la ventana de Google…" : "Leyendo tu YouTube…";
      const d = await esperarFin("leer", () => api("/api/cuenta", Object.assign({accion: "actualizar_cuenta"}, origenNuevo ? {origen: origenNuevo} : {})));
      if (!vivo) return d;
      ocupado(false);
      resumen.textContent = d.resumen || d.error || "";
      resumen.classList.toggle("error", !!d.error);
      if (d.resumen) {
        avisar(d.resumen);
        const app = window.app;
        if (app && typeof app.refrescarCanales === "function") app.refrescarCanales();
      }
      refrescar();
      return d;
    }
    async function llevar(destino) {
      resumen.textContent = "";
      ocupado(true, "plan");
      ptexto.textContent = "Mirando qué falta en YouTube…";
      const d = await esperarFin("plan", () => api("/api/cuenta", Object.assign({accion: "plan"}, destino ? {destino} : {})));
      if (!vivo) return d;
      ocupado(false);
      if (d.error || !d.plan) { resumen.textContent = d.error || "No ha salido"; resumen.classList.add("error"); return d; }
      const r = await confirmar(d.plan);
      if (r && r.boton === "otra") return llevar(r.destino);
      if (!r || r.boton !== "aplicar") { api("/api/cuenta", {accion: "olvidar_plan"}); resumen.textContent = d.plan.vacio ? "Nada que llevar a YouTube" : "Cancelado: no he tocado tu YouTube"; return d; }
      ocupado(true, "aplicar");
      ptexto.textContent = "Aplicando…";
      const f = await esperarFin("aplicar", () => api("/api/cuenta", {accion: "aplicar", plan: d.plan.id}));
      if (!vivo) return f;
      ocupado(false);
      resumen.textContent = f.resumen || f.error || "";
      resumen.classList.toggle("error", !!f.error);
      if (f.resumen) avisar(f.resumen);
      return f;
    }
    bTraer.addEventListener("click", () => traer());
    bLlevar.addEventListener("click", () => llevar());
    bFirefox.addEventListener("click", () => traer("firefox"));
    bApp.addEventListener("click", () => traer("app"));
    bCancelar.addEventListener("click", () => api("/api/cuenta", {accion: "cancelar"}));
    bSalir.addEventListener("click", async () => {
      const r = await api("/api/cuenta", {accion: "cerrar_sesion"});
      if (!r.ok) return M7().fallo ? M7().fallo(r) : avisar(r.error || "No ha salido");
      resumen.textContent = "";
      pintarEstado(r);
      avisar("Sesión de YouTube cerrada en Cat-ode");
    });
    refrescar();
    const s = {nodo: bloque, traer, llevar, refrescar, estado: () => estado,
      destruir() { vivo = false; for (const f of limpiar) try { f && f(); } catch (e) { /* nada */ } }};
    C.cuenta._seccion = s;   // para las pruebas y para ir({empezar})
    return s;
  }

  // ------------------------------------------------------------------ ir a la sección (menú e invitación)
  async function ir(op) {
    op = op || {};
    const app = window.app;
    if (app && typeof app.irSeccion === "function") app.irSeccion("ajustes", {nueva: !!op.nueva});
    const fin = performance.now() + 6000;
    let nodo = null;
    while (performance.now() < fin && !(nodo = document.querySelector(".pestana-cuerpo.activa #aj-cuenta") || document.getElementById("aj-cuenta"))) {
      await new Promise((ok) => setTimeout(ok, 50));
    }
    if (!nodo) return null;
    nodo.scrollIntoView({block: "start"});
    nodo.classList.add("aj-cuenta-destacada");
    setTimeout(() => nodo.classList.remove("aj-cuenta-destacada"), 1600);
    if (op.empezar && C.cuenta._seccion && C.cuenta._seccion.nodo === nodo) C.cuenta._seccion.traer();
    return nodo;
  }

  // ------------------------------------------------------------------ la invitación del Inicio vacío (equipo nuevo)
  async function invitar(nodo, forzar) {
    if (!nodo || nodo.querySelector(".cuenta-invitacion")) return false;
    const app = window.app;
    if (!forzar && app && (app.canales || []).length) return false;
    let e = forzar || null;
    if (!e) {
      const r = await api("/api/cuenta");
      if (!r.ok) return false;
      e = r;
    }
    if (e.historial || e.suscripciones || nodo.querySelector(".cuenta-invitacion")) return false;
    nodo.append(el("div", {class: "cuenta-invitacion"},
      el("h2", {text: "Trae tu YouTube"}),
      el("p", {text: "Entra con tu cuenta de Google y Cat-ode traerá tus suscripciones, tu historial, tus «Me gusta», «Ver más tarde» y tus listas. Así el Inicio te recomienda lo que te interesa desde el primer momento."}),
      el("button", {class: "m7-boton principal cuenta-invitacion-boton", text: "Traer mi YouTube", onclick: () => ir({empezar: true})})));
    return true;
  }

  C.cuenta = {seccion, ir, invitar, confirmar, _seccion: null};
})();
