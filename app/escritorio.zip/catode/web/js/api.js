// Cat-ode escritorio · interfaz web: el cliente del servidor local (módulo M4, DISENO_WEB.md §2.1, §2.2 y §2.4).
// - Base absoluta configurable (plan B del §5.1: la SPA por NavigateToString): window.CATODE_BASE o el origen de la página.
// - Token de la URL (?t=) en la cabecera X-Catode de todo /api; EventSource no admite cabeceras: /api/eventos lleva ?t=.
// - Errores: {ok:false, error, clase, reintentar} → se lanza ErrorApi con .clase ∈ sin_red | bloqueo | imposible |
//   servidor_autor (y «abortado» si se canceló la navegación). cartel(el, err, reintentar) pinta el aviso de cada clase:
//   sin_red reintenta solo a los 15 s; bloqueo NUNCA reintenta (regla 24); imposible es un cartel fijo; servidor_autor, un
//   aviso discreto.
// - Cada navegación lleva su AbortController (app.js): api.get(ruta, params, {senal}).
// - SSE: api.escuchar(fn(tipo, datos)) abre /api/eventos y reconecta solo (EventSource manda Last-Event-ID).
"use strict";
(function () {
  const C = window.catode = window.catode || {};
  const qs = new URLSearchParams(location.search);
  const token = window.CATODE_TOKEN || qs.get("t") || "";
  const base = (window.CATODE_BASE || (/^https?:$/.test(location.protocol) ? location.origin : "")).replace(/\/$/, "");
  const EVENTOS = ["datos", "sincro", "descarga", "novedades", "actualizacion", "aviso", "abrir", "remoto", "voz", "tecla",
    "ventana", "archivo", "cerrar", "abrir_campana", "adios", "cuenta"];   // cuenta: 18/10/2026, «Traer mi YouTube» (cuenta.js)   // sin addEventListener, un evento con nombre se pierde

  class ErrorApi extends Error {
    constructor(mensaje, clase, reintentar, estado, ruta) {
      super(mensaje || "Error");
      this.clase = clase || "servidor";
      this.reintentar = !!reintentar;
      this.estado = estado || 0;
      this.ruta = ruta || "";
    }
  }

  function url(ruta, params) {
    let u = base + ruta;
    if (params) {
      const p = new URLSearchParams();
      for (const [k, v] of Object.entries(params)) if (v !== undefined && v !== null && v !== "") p.set(k, String(v));
      const s = p.toString();
      if (s) u += (u.includes("?") ? "&" : "?") + s;
    }
    return u;
  }

  async function pedir(metodo, ruta, params, cuerpo, op) {
    op = op || {};
    const t0 = performance.now();
    const cab = {"X-Catode": token};
    let body;
    if (cuerpo !== undefined) {
      if (cuerpo instanceof FormData || typeof cuerpo === "string") body = cuerpo;
      else { cab["Content-Type"] = "application/json"; body = JSON.stringify(cuerpo); }
    }
    let r;
    try {
      r = await fetch(url(ruta, params), {method: metodo, headers: cab, body, signal: op.senal, keepalive: !!op.keepalive});
    } catch (e) {
      if (e && e.name === "AbortError") throw new ErrorApi("abortado", "abortado", false, 0, ruta);
      throw new ErrorApi("Cat-ode no responde (el servidor local se ha parado)", "sin_red", true, 0, ruta);
    }
    let datos = {};
    if (r.status !== 204) {
      try { datos = await r.json(); } catch (e) {
        if (op.senal && op.senal.aborted) throw new ErrorApi("abortado", "abortado", false, 0, ruta);
        datos = {ok: false, error: "Respuesta no válida (" + r.status + ")", clase: "servidor"};
      }
    }
    if (C.medir) C.medir.api(ruta, performance.now() - t0, r.headers.get("Server-Timing"));
    if (op.senal && op.senal.aborted) throw new ErrorApi("abortado", "abortado", false, r.status, ruta);
    if (!r.ok || (datos && datos.ok === false)) {
      throw new ErrorApi((datos && datos.error) || ("Error " + r.status), (datos && datos.clase) ||
        (r.status === 403 ? "token" : "servidor"), datos && datos.reintentar, r.status, ruta);
    }
    return datos;
  }

  const api = {
    token, base, ErrorApi, url,
    get: (ruta, params, op) => pedir("GET", ruta, params, undefined, op),
    post: (ruta, cuerpo, op) => pedir("POST", ruta, null, cuerpo === undefined ? {} : cuerpo, op),
    put: (ruta, cuerpo, op) => pedir("PUT", ruta, null, cuerpo === undefined ? {} : cuerpo, op),
    abortado: (e) => !!e && (e.clase === "abortado" || e.name === "AbortError"),
    // POST /api/datos {accion, …} (subacciones de lista/historial en «que», ver informe del bloque 0)
    datos: (accion, args, op) => pedir("POST", "/api/datos", null, Object.assign({accion}, args || {}), op),
    ventana: (accion, valor) => pedir("POST", "/api/ventana", null, {accion, valor}),

    // cartel de error por clase (§2.2) dentro de «el»; «reintentar» se llama al pulsar (y solo a los 15 s si sin_red)
    cartel(el, err, reintentar) {
      if (!el || api.abortado(err)) return null;
      const clase = (err && err.clase) || "servidor";
      const textos = {
        sin_red: ["Sin conexión", "Lo vuelvo a intentar solo en 15 s…"],
        bloqueo: ["YouTube ha frenado las peticiones", "No se reintenta solo, para no empeorarlo. Prueba más tarde."],
        imposible: ["No se puede abrir", "El vídeo es privado, se ha borrado o no existe."],
        servidor_autor: ["Tu servidor no responde", "Lo de los otros equipos llegará cuando vuelva."],
      };
      const [titulo, ayuda] = textos[clase] || ["Algo ha fallado", ""];
      const c = document.createElement("div");
      c.className = "cartel cartel-" + clase;
      const h = document.createElement("div"); h.className = "cartel-titulo"; h.textContent = titulo;
      const p = document.createElement("div"); p.className = "cartel-texto";
      p.textContent = (err && err.message && err.message !== titulo ? err.message + " · " : "") + ayuda;
      c.append(h, p);
      let reloj = null;
      if (reintentar && clase !== "bloqueo" && clase !== "imposible") {
        const b = document.createElement("button"); b.className = "boton"; b.textContent = "Reintentar";
        b.addEventListener("click", () => { clearTimeout(reloj); reintentar(); });
        c.append(b);
        if (clase === "sin_red") reloj = setTimeout(() => { if (c.isConnected) reintentar(); }, 15000);
      }
      el.replaceChildren(c);
      return c;
    },

    // SSE: fn(tipo, datos) por cada evento; devuelve el EventSource (reconecta solo con Last-Event-ID)
    escuchar(fn) {
      const es = new EventSource(url("/api/eventos", {t: token}));
      for (const tipo of EVENTOS) {
        es.addEventListener(tipo, (ev) => {
          let d = {};
          try { d = JSON.parse(ev.data || "{}"); } catch (e) { d = {}; }
          if (tipo === "adios") { try { es.close(); } catch (e) { /* nada */ } }   // el servidor se para: sin reconectar
          try { fn(tipo, d || {}); } catch (e) { console.warn("evento " + tipo, e); }
        });
      }
      api.fuente = es;
      return es;
    },
  };
  C.api = api;
})();
