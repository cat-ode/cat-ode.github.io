// Cat-ode escritorio · interfaz web: TODOS los atajos de teclado de la Qt (módulo M4; interfaz.py _atajos 2257-2296,
// _tecla_video 2298-2375, eventFilter 2377-2419 y ver_atajos 2721). 06/10/2026.
// Globales: F11 · F9 (solo Windows: apagar/encender el remoto) · Ctrl+V con un enlace (evento «paste», app.js) ·
//   Alt+←/→ · Ctrl+T · Ctrl+W · Ctrl+Tab/Ctrl+AvPág · Ctrl+Mayús+Tab/Ctrl+RePág · Ctrl+1…8 · Ctrl+9 · Ctrl+Mayús+T ·
//   multimedia (Play/Pausa, Siguiente, Anterior; también por SSE «tecla») · «/», Ctrl+L, Ctrl+K, Ctrl+E al buscador ·
//   F5/Ctrl+R recargar · Ctrl+F (transcripción o buscador) · «?» esta lista · Esc suelta el buscador.
// Del vídeo (solo con vídeo en pantalla, en Shorts, en pantalla completa o con el mini, y sin escribir en un campo):
//   Espacio/K · J/L · ←/→ · ↑/↓ volumen · 0-9 · F · T · I · M · C · Esc · Inicio/Fin · , y . fotograma · < y > velocidad ·
//   Mayús+N/Mayús+P. Con el mini sobre una lista solo Espacio/K/M/J/L/N/P/Esc; en Shorts ↑/↓/AvPág/RePág son de la página.
// CONTRATO con M6/M7: app.teclado.video = () => null | {modo: "pagina"|"mini"|"shorts"|"completa", alternar(), mover(s),
//   irA(s), dur(), pausado(), volumen(delta), completa(), cine(), pip(), silencio(), subtitulos(), fotograma(±1),
//   velocidad(±0.25), siguiente(), anterior(), escape()}; app.teclado.rep = () => el de la pestaña activa (multimedia).
"use strict";
(function () {
  const C = window.catode = window.catode || {};
  const app = window.app;
  const $ = (s) => document.querySelector(s);
  const P = () => C.pestanas;

  const FILAS = [
    ["Vídeo", "Espacio / K: pausa y sigue · J / L: −10 / +10 s · ← / →: −5 / +5 s · ↑ / ↓: volumen · 0-9: ir al 0-90 %"],
    ["", "F: pantalla completa · T: modo cine · I: imagen en imagen · M: silencio · C: subtítulos · Esc: salir"],
    ["", "Mayús+N / Mayús+P: siguiente / anterior · , / .: fotograma (en pausa) · < / >: velocidad · Inicio / Fin"],
    ["Pestañas", "Ctrl+T: nueva · Ctrl+W: cerrar · Ctrl+Mayús+T: reabrir la cerrada · Ctrl+Tab / Ctrl+AvPág: siguiente"],
    ["", "Ctrl+Mayús+Tab / Ctrl+RePág: anterior · Ctrl+1…8: esa pestaña · Ctrl+9: la última"],
    ["", "Botón central o Ctrl+clic: abrir en pestaña nueva · Mayús+clic en un vídeo: ventana aparte"],
    ["Navegar", "Alt+← / Alt+→ y botones 4 / 5 del ratón: atrás / adelante · F5 / Ctrl+R: recargar"],
    ["", "/ · Ctrl+L · Ctrl+K · Ctrl+E: al buscador · Ctrl+F: buscar en la transcripción · Ctrl+V: abrir un enlace"],
    ["", "Ctrl+rueda: tamaño de la interfaz · F11: pantalla completa · ?: esta lista"],
  ];

  function alBuscador() {
    const c = $("#campo");
    if (!c) return;
    c.focus();
    c.select();
  }
  function llamar(o, nombre, ...a) {
    if (o && typeof o[nombre] === "function") { try { return o[nombre](...a); } catch (e) { console.warn("tecla " + nombre, e); } }
    return undefined;
  }
  function controlVideo() {
    try { return typeof app.teclado.video === "function" ? app.teclado.video() : null; } catch (e) { return null; }
  }
  function repActivo() {
    try {
      if (typeof app.teclado.rep === "function") return app.teclado.rep();
    } catch (e) { /* nada */ }
    return controlVideo();
  }

  // ---- el diálogo «?» (ver_atajos 2721)
  let dialogo = null;
  function verAtajos() {
    if (dialogo) { dialogo.querySelector("button").focus(); return; }
    const fondo = document.createElement("div");
    fondo.className = "dialogo-fondo";
    const d = document.createElement("div");
    d.className = "dialogo dialogo-atajos";
    d.setAttribute("role", "dialog");
    d.setAttribute("aria-label", "Atajos de teclado");
    const h = document.createElement("h2"); h.textContent = "Atajos de teclado"; d.appendChild(h);
    for (const [grupo, texto] of FILAS) {
      if (grupo) { const g = document.createElement("div"); g.className = "seccion"; g.textContent = grupo; d.appendChild(g); }
      const t = document.createElement("div"); t.className = "atajo-fila"; t.textContent = texto; d.appendChild(t);
    }
    const pie = document.createElement("div"); pie.className = "dialogo-pie";
    const b = document.createElement("button"); b.className = "boton"; b.textContent = "Cerrar";
    b.addEventListener("click", cerrarAtajos);
    pie.appendChild(b); d.appendChild(pie);
    fondo.appendChild(d);
    fondo.addEventListener("pointerdown", (ev) => { if (ev.target === fondo) cerrarAtajos(); });
    $("#capas").appendChild(fondo);
    dialogo = fondo;
    b.focus();
  }
  function cerrarAtajos() {
    if (!dialogo) return false;
    dialogo.remove();
    dialogo = null;
    return true;
  }

  // ---- F9: el remoto (solo Windows). Alterna ajustes.apagar_remoto, el mismo estado que la casilla de Ajustes y el check
  // del menú ⚙ (app.ponerRemoto; el SSE «remoto» los pone a todos al día)
  async function alternarRemoto() {
    const quiero = !(typeof app.remotoApagado === "function" ? app.remotoApagado() : false);
    try {
      const r = await C.api.post("/api/remoto", {apagar: quiero});
      if (typeof app.ponerRemoto === "function") app.ponerRemoto(r && typeof r.apagado === "boolean" ? r.apagado : quiero);
      if (r && r.texto) app.avisar(r.texto);
    } catch (e) { app.avisar(e.message); }
  }

  // ---- multimedia (teclas del teclado o SSE «tecla»: play, pausa, siguiente, anterior, parar)
  function multimedia(nombre) {
    if (typeof app.ganchos.multimedia === "function" && app.ganchos.multimedia(nombre) === true) return;
    const r = repActivo();
    if (!r) return;
    if (nombre === "siguiente") llamar(r, "siguiente");
    else if (nombre === "anterior") llamar(r, "anterior");
    else if (nombre === "parar") { if (typeof r.parar === "function") llamar(r, "parar"); else if (!llamar(r, "pausado")) llamar(r, "alternar"); }
    else if (nombre === "pausa") { if (!llamar(r, "pausado")) llamar(r, "alternar"); }
    else llamar(r, "alternar");
  }

  // ---- las teclas del vídeo (_tecla_video_con 2335): true si eran suyas
  const SOLO_MINI = new Set([" ", "k", "m", "j", "l", "n", "p", "escape"]);
  function teclaVideo(ev) {
    const v = controlVideo();
    if (!v) return false;
    if (campoTexto(document.activeElement)) return false;   // solo un campo de texto (no el volumen ni una casilla)
    if (ev.ctrlKey || ev.altKey || ev.metaKey) return false;
    const k = ev.key.length === 1 ? ev.key.toLowerCase() : ev.key.toLowerCase();
    if (v.modo === "shorts" && ["arrowup", "arrowdown", "pageup", "pagedown"].includes(k)) return false;
    if (v.modo === "mini" && !SOLO_MINI.has(k)) return false;
    const mayus = ev.shiftKey;
    if (mayus && k === "n") { llamar(v, "siguiente"); return true; }
    if (mayus && k === "p") { llamar(v, "anterior"); return true; }
    if (mayus && (ev.code === "Comma" || ev.code === "Period") && ev.key !== "<" && ev.key !== ">") {
      llamar(v, "velocidad", ev.code === "Comma" ? -0.25 : 0.25); return true;   // teclados donde < y > son Mayús+, y Mayús+.
    }
    if (/^[0-9]$/.test(ev.key) && !mayus) {
      const d = +llamar(v, "dur") || 0;
      if (d) llamar(v, "irA", d * (+ev.key) / 10);
      return true;
    }
    const acciones = {
      " ": () => llamar(v, "alternar"), k: () => llamar(v, "alternar"),
      j: () => llamar(v, "mover", -10), l: () => llamar(v, "mover", 10),
      arrowleft: () => llamar(v, "mover", -5), arrowright: () => llamar(v, "mover", 5),
      arrowup: () => llamar(v, "volumen", 5), arrowdown: () => llamar(v, "volumen", -5),
      f: () => llamar(v, "completa"), t: () => llamar(v, "cine"), i: () => llamar(v, "pip"), m: () => llamar(v, "silencio"),
      escape: () => llamar(v, "escape"),
      home: () => llamar(v, "irA", 0), end: () => { const d = +llamar(v, "dur") || 0; if (d) llamar(v, "irA", Math.max(0, d - 1)); },
      c: () => llamar(v, "subtitulos"),
      ",": () => { if (llamar(v, "pausado")) llamar(v, "fotograma", -1); },
      ".": () => { if (llamar(v, "pausado")) llamar(v, "fotograma", 1); },
      "<": () => llamar(v, "velocidad", -0.25), ">": () => llamar(v, "velocidad", 0.25),
    };
    const f = acciones[k];
    if (!f) return false;
    if (mayus && !["<", ">"].includes(k)) return false;
    f();
    return true;
  }

  // ---- todas las teclas pasan por aquí (fase de captura: antes que botones y listas, como el eventFilter global)
  let pegadoPorEvento = false;
  document.addEventListener("paste", () => { pegadoPorEvento = true; }, true);
  // solo un campo de TEXTO anula las teclas del vídeo (como la Qt, pantallas[34]): el deslizador de volumen, una casilla o
  // un botón con el foco tras pulsarlos no dejan sin Esc, F, espacio, K, J, L…
  const TEXTO = /^(text|search|url|email|password|tel|number|)$/i;
  const campoTexto = (el) => !!el && (el.isContentEditable || el.tagName === "TEXTAREA" ||
    el.tagName === "SELECT" || (el.tagName === "INPUT" && TEXTO.test(el.getAttribute("type") || "")));
  function alTeclear(ev) {
    if (ev.defaultPrevented) return;
    const enCampo = campoTexto(ev.target) || campoTexto(document.activeElement);
    const ctrl = ev.ctrlKey || ev.metaKey, alt = ev.altKey, mayus = ev.shiftKey;
    const k = ev.key;
    const hecho = () => { ev.preventDefault(); ev.stopPropagation(); return true; };

    // menús y diálogos abiertos: Esc los cierra
    if (k === "Escape" && dialogo) return cerrarAtajos() && hecho();
    if (k === "Escape" && app.menuAbierto()) return app.cerrarMenu() && hecho();
    if (dialogo) return;   // con la lista abierta, el teclado es suyo

    // teclas multimedia del propio navegador (en Windows las captura la ventana Qt y llegan por SSE)
    const media = {MediaPlayPause: "play", MediaPlay: "play", MediaPause: "pausa", MediaTrackNext: "siguiente",
      MediaTrackPrevious: "anterior", MediaStop: "parar"}[k];
    if (media) { multimedia(media); return hecho(); }

    if (k === "F11") { if (typeof app.ganchos.completa === "function") app.ganchos.completa(); else if (app.enCompleta()) app.ponerCompleta(false); return hecho(); }
    if (k === "F9") { if (app.so === "nt") alternarRemoto(); return hecho(); }
    if (k === "F5" || (ctrl && !alt && k.toLowerCase() === "r")) { app.recargar(); return hecho(); }
    if (alt && !ctrl && k === "ArrowLeft") { app.volver(); return hecho(); }
    if (alt && !ctrl && k === "ArrowRight") { app.adelante(); return hecho(); }
    if (ctrl && !alt) {
      const l = k.length === 1 ? k.toLowerCase() : k;
      if (l === "t" && mayus) { P().reabrir(); return hecho(); }
      if (l === "t") { P().crear(); return hecho(); }
      if (l === "w") { P().cerrar(P().actual()); return hecho(); }
      if (k === "Tab") { P().siguiente(mayus ? -1 : 1); return hecho(); }
      if (k === "PageDown") { P().siguiente(1); return hecho(); }
      if (k === "PageUp") { P().siguiente(-1); return hecho(); }
      const dig = /^Digit([1-9])$/.exec(ev.code) || /^([1-9])$/.exec(k);
      if (dig && !mayus) {
        const n = +dig[1], total = P().lista.length;
        P().activar(n === 9 ? total - 1 : Math.min(n - 1, total - 1));
        return hecho();
      }
      if (["l", "k", "e"].includes(l) && !mayus) { alBuscador(); return hecho(); }
      if (l === "f" && !mayus) {
        if (!(typeof app.ganchos.buscarEnPagina === "function" && app.ganchos.buscarEnPagina())) alBuscador();
        return hecho();
      }
      if (l === "v" && !enCampo) {   // si el navegador no da el evento «paste», se lee el portapapeles por la ventana
        pegadoPorEvento = false;
        setTimeout(async () => {
          if (pegadoPorEvento) return;
          try { const r = await C.api.ventana("portapapeles", null); if (r && typeof r.texto === "string") app.pegarEnlace(r.texto); } catch (e) { /* nada */ }
        }, 120);
        return;   // sin preventDefault: que llegue el «paste»
      }
      // el zoom propio del navegador, no: Ctrl+«+», Ctrl+«-» y Ctrl+0 cambian el tamaño como Ctrl+rueda
      if (k === "+" || k === "=") { app.ponerEscala(app.escala + 0.1); return hecho(); }
      if (k === "-") { app.ponerEscala(app.escala - 0.1); return hecho(); }
      if (k === "0") { app.ponerEscala(1); return hecho(); }
    }
    if (enCampo) return;   // escribiendo: «/», «?», el espacio y las flechas son del campo

    if (teclaVideo(ev)) return hecho();
    if (k === "Escape") {
      if (typeof app.ganchos.escape === "function" && app.ganchos.escape()) return hecho();
      if (app.enCompleta()) { app.ponerCompleta(false); return hecho(); }
      return;
    }
    if (k === "/" && !ctrl && !alt) { alBuscador(); return hecho(); }
    if (k === "?" && !ctrl && !alt) { verAtajos(); return hecho(); }
  }
  document.addEventListener("keydown", alTeclear, true);

  C.atajos = {verAtajos, cerrarAtajos, multimedia, teclaVideo, alternarRemoto, FILAS, abierto: () => !!dialogo};
  app.verAtajos = verAtajos;
})();
