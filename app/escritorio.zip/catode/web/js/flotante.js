// Cat-ode escritorio · interfaz web, módulo M7 (06/10/2026): la capa del vídeo, el mini reproductor (Flotante,
// interfaz.py 1785-1899 y 4057-4123), la imagen en imagen nativa y la pantalla completa (4130-4179).
//
// La capa: el <iframe> del reproductor NUNCA se mueve en el DOM (moverlo lo recarga y corta el vídeo). Se coloca con
// position: fixed encima del sitio que le toque:
//   "video"   → sobre la zona de la página del vídeo (ponerEn(zona, "video"))
//   "shorts"  → sobre el marco 9:16 de Shorts (ponerEn(marco, "shorts"))
//   "mini"    → 360×203 abajo a la derecha, arrastrable dentro de la ventana, mandos al posar (⏯ ⧉ ↩ ✕)
//   "completa"→ toda la ventana (app.ponerCompleta de M4, o POST /api/ventana {accion:"completa"}; al salir, "normal":
//                la ventana vuelve maximizada si lo estaba, eso lo recuerda VentanaWeb)
//   "oculta"
// CatodeM7.capa.el (#m7-capa) es siempre el mismo elemento: mandos.js (M6) pone ahí sus mandos. Con el reproductor de
// M6, el iframe vive en la zona de cada pestaña (rep.zona, un <div class="rep-zona"> en <body>) y aquí se coloca esa
// zona debajo de #m7-capa con el mismo rectángulo. Sin M6, #m7-capa lleva su propio iframe y el talón de reproductor
// de abajo, que habla con reproductor.html por postMessage (DISENO_WEB.md §2.5) y pide la fuente a /api/resolver.
"use strict";
(function () {
  // el reproductor que se enseña (mini, completa, ⏯ de la capa): el de la pestaña activa si tiene vídeo, si no el que
  // suena. Nunca lo crea (leer catode.reproductor crea uno en la pestaña activa: quedaban iframes huérfanos)
  function repVista() {
    const g = window.Reproductor && window.Reproductor.gestor;
    return g && typeof g.vista === "function" ? g.vista() : M7.rep();
  }
  const M7 = window.CatodeM7 = window.CatodeM7 || {};
  // 22/10/2026 (3.9): a catode.log (POST /api/registro), como los cortes del reproductor
  const registro = (t) => { try { if (typeof M7.api === "function") M7.api("/api/registro", {t}).catch(() => {}); } catch (e) { /* nada */ } };
  const conM6 = () => !!(window.Reproductor && window.Reproductor.gestor);
  const MODOS = ["oculta", "video", "shorts", "mini", "completa"];

  // ------------------------------------------------------------------ la capa
  const capa = M7.capa = {
    el: null, iframe: null, mandos: null, modo: "oculta", sitio: null, movido: null, antes: null, oyentes: [], zona: null,
    asegurar() {
      if (capa.el) return capa.el;
      const el = document.createElement("div");
      el.id = "m7-capa"; el.className = "m7-capa oculta";
      if (!conM6()) {   // talón: el iframe propio
        const fr = document.createElement("iframe");
        fr.setAttribute("sandbox", "allow-scripts");
        fr.setAttribute("allow", "autoplay; picture-in-picture; fullscreen");
        fr.setAttribute("referrerpolicy", "no-referrer");
        fr.setAttribute("title", "Reproductor");
        fr.className = "m7-capa-marco";
        fr.src = "/reproductor.html";
        el.append(fr);
        capa.iframe = fr;
      } else {
        el.classList.add("sobre-zona");
      }
      const mandos = document.createElement("div");
      mandos.className = "fl-mandos";
      const boton = (txt, titulo, f, clase) => { const b = document.createElement("button"); b.className = "fl-boton " + (clase || ""); b.textContent = txt;
        b.title = titulo; b.setAttribute("aria-label", titulo); b.addEventListener("click", (ev) => { ev.stopPropagation(); f(); }); return b; };
      mandos.append(
        boton("⏯", "Pausa / seguir (espacio)", () => { const r = repVista(); if (r) r.alternar(); }, "fl-alternar"),
        boton("⧉", "Imagen en imagen (I)", () => M7.pip(), "fl-pip"),
        boton("↩", "Volver a Cat-ode", () => M7.volverDelFlotante(), "fl-volver"),
        boton("⏹", "Parar el vídeo", () => M7.volverDelFlotante(true), "fl-cerrar"));
      el.append(mandos);
      document.body.append(el);
      capa.el = el; capa.mandos = mandos;
      // 22/10/2026 · orden del autor (20/10/2026): «cuando se quiere quitar el mini reproductor no hay manera de quitarlo sin
      // cerrarlo, busca una alternativa» (audio de Mateo del 20/10: «si le doy a la X se me cierra el vídeo y se me para todo;
      // no hay manera de quitar el mini reproductor sin parar la música»). Un ✕ que se ve SIEMPRE y arrastrarla fuera de la
      // ventana (más de media mini) la QUITAN y el vídeo SIGUE SONANDO; no vuelve a salir hasta abrir su página. Parar: ⏹.
      const quitar = boton("✕", "Quitar el minirreproductor (sigue sonando); también arrastrándolo fuera", () => M7.quitarMini("✕"), "fl-quitar");
      el.append(quitar);
      arrastre(el, mandos);
      // 07/10/2026 · CAUSA de «sin barra de progreso y el doble clic no hace nada» en Windows: los mandos grandes (M6,
      // mandos.js) solo se creaban al navegar (eventos pagina/navega/completa/pestaña). Con la pestaña del vídeo RECORDADA al
      // arrancar (como la app del autor), la página se pinta sin capa (no suena) y la capa nace después, al pulsar ▶: ya no
      // llega ningún evento y la capa se quedaba SIN mandos (ni barra, ni botones; el doble clic caía en el iframe). Ahora,
      // en cuanto existe la capa, se le ponen los mandos.
      queueMicrotask(() => { try { if (window.Mandos && typeof window.Mandos.enCapa === "function") window.Mandos.enCapa(); } catch (e) { /* nada */ } });
      // con M6 la capa tapa al iframe: en Shorts el clic pausa y la rueda pasa de short (sin M6 lo avisa el iframe)
      el.addEventListener("click", (ev) => { if (capa.modo === "shorts" && conM6() && ev.target === el) { const r = repVista(); if (r) r.alternar(); } });
      el.addEventListener("wheel", (ev) => { if (capa.modo === "shorts" && M7._shorts && M7._shorts.visible) { ev.preventDefault(); M7._shorts.rueda(ev.deltaY); } }, {passive: false});
      new ResizeObserver(() => capa.recolocar()).observe(document.documentElement);
      addEventListener("resize", () => capa.recolocar());
      // 06/10/2026 (N100): este oyente oye TODOS los scroll del documento (también el de cada rejilla). Solo hace falta
      // cuando la capa sigue a su sitio (vídeo, Shorts) y lo que se desplaza contiene ese sitio; el mini y la pantalla
      // completa no se mueven con el scroll. Antes recolocaba (y medía) en cada evento de cualquier lista
      document.addEventListener("scroll", (ev) => {
        if (capa.modo !== "video" && capa.modo !== "shorts") return;
        const t = ev.target, sitio = capa.sitio;
        if (t && t !== document && t.nodeType === 1 && sitio && sitio.isConnected && !t.contains(sitio)) return;
        capa.recolocar();
      }, true);
      setInterval(() => { if (capa.modo === "video" || capa.modo === "shorts") capa.recolocar(); }, 400);
      return el;
    },
    _modo(m) {
      const antes = capa.modo;
      capa.modo = m;
      const el = capa.asegurar();
      for (const x of MODOS) el.classList.toggle(x, x === m);
      if (antes !== m) for (const f of capa.oyentes.slice()) try { f(m, antes); } catch (e) { /* nada */ }
    },
    on(fn) { capa.oyentes.push(fn); return () => { capa.oyentes = capa.oyentes.filter((x) => x !== fn); }; },
    ponerEn(sitio, modo) {
      if (capa.modo === "completa") { capa.antes = {modo: modo || "video", sitio}; return; }
      capa.asegurar();
      // 06/10/2026 (perfil de uso): con un sitio nuevo, el primer aviso del ResizeObserver (llega tras el maquetado y antes
      // de pintar, en ese mismo cuadro) coloca la capa: leer el rectángulo aquí forzaba un maquetado de la página del vídeo
      // recién hecha que se repetía al llegar la ficha (≈ 100 ms con la CPU del N100)
      if ((modo || "video") === "video") capa.quitada = null;   // 22/10/2026 (3.9): ha vuelto a la página del vídeo
      const nuevo = capa.sitio !== sitio;
      if (nuevo) { if (capa._ro) capa._ro.disconnect(); capa._ro = new ResizeObserver(() => capa.recolocar()); capa._ro.observe(sitio); }
      capa.sitio = sitio;
      capa._ultimo = null;
      capa._modo(modo || "video");
      if (!nuevo) capa.recolocar();
    },
    mini() {
      if (capa.modo === "completa") { capa.antes = {modo: "mini", sitio: null}; return; }
      if (capa.quitada) {   // quitada con el mismo vídeo (o sin saber cuál, «*»): sigue fuera; con otro vídeo, vuelve
        const x = repVista();
        if (capa.quitada === "*" || (x && x.actual && x.actual.url === capa.quitada)) return capa.ocultar();
        capa.quitada = null;
      }
      capa.sitio = null;
      if (capa._ro) { capa._ro.disconnect(); capa._ro = null; }
      capa._modo("mini");
      capa.recolocar();
    },
    ocultar() {
      if (capa._ro) { capa._ro.disconnect(); capa._ro = null; }
      capa.sitio = null;
      capa._modo("oculta");
      capa.recolocar();
    },
    rect() { return capa.el ? capa.el.getBoundingClientRect() : null; },
    // la zona del iframe de M6 que toca enseñar (la del reproductor de la pestaña activa)
    zonaActual() {
      if (!conM6() || capa.modo === "oculta") return null;
      // sin crear reproductores (leer catode.reproductor lo crea): el de la pestaña que se ve o, si no tiene, el que suena
      const r = repVista();
      return r && r.zona instanceof Element ? r.zona : null;
    },
    recolocar() {
      const el = capa.el;
      if (!el) return;
      const s = el.style;
      if (capa.modo === "video" || capa.modo === "shorts") {
        const sitio = capa.sitio;
        const r = sitio && sitio.isConnected ? sitio.getBoundingClientRect() : null;
        if (!r || r.width < 2 || r.height < 2) {
          const x = repVista();
          if (x && x.actual) capa.mini(); else capa.ocultar();
          return;
        }
        const v = `${Math.round(r.left)}px|${Math.round(r.top)}px|${Math.round(r.width)}px|${Math.round(r.height)}px`;
        if (capa._ultimo !== v) { capa._ultimo = v; [s.left, s.top, s.width, s.height] = v.split("|"); }
      } else if (capa.modo === "mini") {
        capa._ultimo = null;
        const w = 360, h = 203, m = 16;
        let x = innerWidth - w - m, y = innerHeight - h - m;
        if (capa.movido) { x = Math.max(0, Math.min(innerWidth - w, capa.movido.x)); y = Math.max(0, Math.min(innerHeight - h, capa.movido.y)); }
        s.left = x + "px"; s.top = y + "px"; s.width = w + "px"; s.height = h + "px";
      } else if (capa.modo === "completa") {
        capa._ultimo = null;
        s.left = s.top = "0px"; s.width = "100vw"; s.height = "100vh";
      } else {
        capa._ultimo = null;
      }
      // la zona del iframe de M6, debajo y con el mismo rectángulo; la de antes (otra pestaña), fuera de la vista
      const z = capa.zonaActual();
      if (capa.zona && capa.zona !== z) { for (const x of MODOS) capa.zona.classList.toggle(x, x === "oculta"); }
      capa.zona = z || capa.zona;
      if (z) {
        z.classList.add("m7-zona");
        for (const x of MODOS) z.classList.toggle(x, x === capa.modo);
        const zs = z.style;
        zs.left = s.left; zs.top = s.top; zs.width = s.width; zs.height = s.height;
      }
    },
  };

  // el mini se arrastra dentro de la ventana (_movido: deja de recolocarse solo); doble clic = volver
  function arrastre(el, mandos) {
    let ini = null;
    mandos.addEventListener("pointerdown", (ev) => {
      if (capa.modo !== "mini" || ev.target.closest("button")) return;
      const r = el.getBoundingClientRect();
      ini = {x: ev.clientX - r.left, y: ev.clientY - r.top, id: ev.pointerId};
      mandos.setPointerCapture(ev.pointerId);
    });
    mandos.addEventListener("pointermove", (ev) => {
      if (!ini || ev.pointerId !== ini.id) return;
      const x = ev.clientX - ini.x, w = el.getBoundingClientRect().width;
      // 22/10/2026 (3.9): más de media mini fuera por un lado = al soltar, se quita (no por un toque sin querer)
      el.classList.toggle("saliendo", x < -w / 2 || x > window.innerWidth - w / 2);
      capa.movido = {x, y: ev.clientY - ini.y};
      capa.recolocar();
    });
    const fin = (ev) => {
      if (!ini || ev.pointerId !== ini.id) return;
      try { mandos.releasePointerCapture(ev.pointerId); } catch (e) { /* nada */ }
      ini = null;
      if (el.classList.contains("saliendo")) { el.classList.remove("saliendo"); M7.quitarMini("arrastrándola fuera"); }
    };
    mandos.addEventListener("pointerup", fin);
    mandos.addEventListener("pointercancel", fin);
    mandos.addEventListener("dblclick", (ev) => { if (capa.modo === "mini" && !ev.target.closest("button")) M7.volverDelFlotante(); });
    // mandos visibles al posar, 2,5 s
    let t = null;
    el.addEventListener("pointermove", () => { el.classList.add("posado"); clearTimeout(t); t = setTimeout(() => el.classList.remove("posado"), 2500); });
    el.addEventListener("pointerleave", () => { clearTimeout(t); el.classList.remove("posado"); });
  }

  // 22/10/2026 (3.9): quitar la mini SIN parar: el vídeo sigue sonando (la capa, fuera de la vista) hasta abrir su página
  M7.quitarMini = function (como) {
    const r = repVista();
    capa.quitada = (r && r.actual && r.actual.url) || "*";
    capa.ocultar();
    registro(`mini: quitada con ${como} (sigue sonando)`);
    const g = window.Reproductor && window.Reproductor.gestor;
    if (g && typeof g.avisar === "function") g.avisar("Sigue sonando. Para volver a verlo, abre el vídeo");
  };
  // volver_de_flotante: a la página del vídeo que suena; con parar=True, cerrar = parar el vídeo
  M7.volverDelFlotante = function (parar) {
    const r = repVista();
    if (parar) { if (r) r.parar(); capa.ocultar(); return; }
    if (!r || !r.actual) { capa.ocultar(); return; }
    const c = M7.cat();
    if (typeof c.volverAlVideo === "function") return c.volverAlVideo(r.actual);   // M4: a la pestaña del vídeo
    M7.ir("video", [r.actual, {sonar: false}]);
  };
  M7.pip = function () { const r = repVista(); if (r) (r.pip ? r.pip() : r.orden && r.orden("pip")); };

  // ------------------------------------------------------------------ pantalla completa
  M7._ventana = {completa: false, maximizada: false};
  function entrar() {
    capa.antes = {modo: capa.modo === "oculta" ? "mini" : capa.modo, sitio: capa.sitio};
    capa._modo("completa");
    capa.recolocar();
    document.body.classList.add("m7-completa");
    try { capa.el.focus(); } catch (e) { /* nada */ }
  }
  function restaurar() {
    // 06/10/2026: solo si de verdad se está a pantalla completa. Al salir, ponerCompleta(false) avisa «completa» y el oyente
    // de más abajo ya restaura; la segunda llamada (pantallaCompleta) encontraba «antes» vacío y mandaba el vídeo al MINI
    // de la esquina (medido en el mini PC con el registro de la prueba «completa»).
    if (capa.modo !== "completa") return;
    const a = capa.antes || {modo: "mini"};
    capa.antes = null;
    document.body.classList.remove("m7-completa");
    M7._ventana._vista = false;
    const r = repVista();
    capa.modo = "oculta";   // sin avisar: enseguida se pone el de antes
    if (a.sitio && a.sitio.isConnected && a.modo !== "mini") capa.ponerEn(a.sitio, a.modo);
    else if (r && r.actual) capa.mini();
    else capa.ocultar();
  }
  M7.pantallaCompleta = function (quiero) {
    const r = repVista();
    const app = window.app;
    const ahora = capa.modo === "completa" || !!(app && app.enCompleta && app.enCompleta());   // 06/10/2026: capa O ventana
    if (quiero === undefined) quiero = !ahora;
    if (quiero === ahora && !(quiero && capa.modo !== "completa")) return ahora;
    const anota = (t) => { try { window.Reproductor.apuntar("pantalla completa: " + t); } catch (e) {} };   // 07/10/2026: rastro en catode.log
    if (quiero) {
      if (!r || !r.actual) { anota("rechazada, no hay vídeo sonando"); M7.avisar("No hay ningún vídeo sonando"); return false; }
      if (capa.modo === "shorts") { anota("rechazada, Shorts"); M7.avisar("Los Shorts no van a pantalla completa"); return false; }
      anota(`entra (capa ${capa.modo} → completa)`);
      entrar();
      if (app && typeof app.ponerCompleta === "function") app.ponerCompleta(true);
      else M7.ventana("completa");
      // en Windows a veces no entra a la primera: se reintenta a los 400 ms (interfaz.py 4138), solo con ventana real
      setTimeout(() => { if (capa.modo === "completa" && M7._ventana._sse && !M7._ventana.completa) M7.ventana("completa"); }, 400);
      return true;
    }
    // 06/10/2026: primero se devuelve el marco (body sin «completa»: la página vuelve a maquetarse con su estado guardado)
    // y después se recoloca la capa en su sitio, ya con las medidas buenas (al revés, leía el sitio con la cabecera aún
    // oculta y forzaba un maquetado de más de la página de debajo)
    anota("sale");
    if (app && typeof app.ponerCompleta === "function") app.ponerCompleta(false);
    else M7.ventana("normal");
    restaurar();
    return false;
  };
  M7.enCompleta = () => capa.modo === "completa";
  // Esc (app.ganchos.escape): sale de la pantalla completa o, desde el mini, vuelve al vídeo
  M7.escape = function () {
    if (capa.modo === "completa") { M7.pantallaCompleta(false); return true; }
    if (capa.modo === "mini") { M7.volverDelFlotante(); return true; }
    return false;
  };

  // ------------------------------------------------------------------ teclas (solo sin el marco de M4: allí manda atajos.js)
  function tecla(k, ev) {
    const c = M7.cat();
    if (ev && ((window.app && window.app.teclado) || c.atajos)) return false;
    const r = repVista();
    const conVideo = r && r.actual && capa.modo !== "oculta";
    if (ev && ev.target && /^(INPUT|TEXTAREA|SELECT)$/.test(ev.target.tagName) && k !== "Escape") return false;
    if (document.querySelector(".m7-dialogo-fondo, .m7-menu")) return false;
    if (k === "Escape") return M7.escape();
    if (!ev && M7._shorts && M7._shorts.visible && M7._shorts.tecla(k)) return true;   // del iframe (la página la oye Shorts)
    if (k === "f" || k === "F" || k === "F11") { if (conVideo) { M7.pantallaCompleta(); return true; } return false; }
    if (k === "t" || k === "T") { if (M7._paginaVideo && M7._paginaVideo.visible) { M7.alternarCine(); return true; } return false; }
    if (k === "i" || k === "I") { if (conVideo) { M7.pip(); return true; } return false; }
    if (!conVideo) return false;
    if (k === " " || k === "k" || k === "K") { r.alternar(); return true; }
    if (k === "j" || k === "J") { r.mover(-10); return true; }
    if (k === "l" || k === "L") { r.mover(10); return true; }
    if (k === "m" || k === "M") { M7.silenciar(r, !(r.talon ? r._silencio : r.mute)); return true; }
    return false;
  }
  document.addEventListener("keydown", (ev) => { if (!ev.defaultPrevented && !ev.ctrlKey && !ev.altKey && tecla(ev.key, ev)) ev.preventDefault(); });
  M7.tecla = tecla;

  // ------------------------------------------------------------------ talón del reproductor (lo sustituye M6)
  let talon = null;
  M7.talonRep = function () {
    if (talon) return talon;
    capa.asegurar();
    const fr = capa.iframe;
    if (!fr) return null;
    const oy = {};
    const r = talon = {
      talon: true, iframe: fr, cola: [], i: -1, actual: null, estado: {}, listo: false, _pend: [], _bucle: false, _silencio: false, _fin: false,
      on(ev, fn) { (oy[ev] = oy[ev] || []).push(fn); return () => { oy[ev] = (oy[ev] || []).filter((x) => x !== fn); }; },
      _emit(ev, x) { for (const f of (oy[ev] || []).slice()) try { f(x); } catch (e) { console.warn(e); } },
      orden(f, ...a) { if (!r.listo) { r._pend.push([f, a]); return; } fr.contentWindow.postMessage({f, a}, "*"); },
      async _cargar(e, inicio) {
        r.actual = e; r._fin = false; r.estado = {};
        r._emit("empieza", e); r._emit("cola");
        M7.api("/api/visto", {e});
        const x = await M7.api(`/api/resolver?url=${encodeURIComponent(e.url)}&alto=${(M7.ajuste("calidad", "auto") | 0) || 1080}`);
        if (r.actual !== e) return;
        if (!x.ok) { M7.fallo(x, "No se puede reproducir"); r._emit("error", x); M7.api("/api/fallo", {url: e.url, error: x.error || ""}); return; }
        r.resuelto = x;
        let ini = inicio;
        const dur = x.duracion > 0 ? x.duracion : (x.reanudar && x.reanudar.dur) || 0;
        if ((ini === undefined || ini === null) && M7.ajuste("reanudar", true) !== false && x.reanudar && x.reanudar.seg > 5 && (!dur || x.reanudar.seg < dur - 10)) ini = x.reanudar.seg;
        r.orden("volumen", M7.ajuste("volumen", 100));
        r.orden("cargar", x.fuente, x.tipo, ini || 0);
        if (r._bucle) r.orden("bucle", true);
        (x.subs || []).forEach((s) => r.orden("subtitulo", s.url, s.nombre, s.lengua));
      },
      reproducir(e, inicio) { r.cola = [e]; r.i = 0; return r._cargar(e, inicio); },
      todo(lista, i) { r.cola = lista.slice(); r.i = Math.max(0, Math.min(lista.length - 1, i || 0)); return r._cargar(r.cola[r.i]); },
      encolar(e) { if (!r.cola.length || !r.actual) return r.reproducir(e); r.cola.push(e); r._emit("cola"); M7.avisar(`En la cola: ${e.titulo || ""}`); },
      insertar_siguiente(e) { if (!r.actual) return r.reproducir(e); r.cola.splice(r.i + 1, 0, e); r._emit("cola"); },
      saltar_a(i) { if (i >= 0 && i < r.cola.length) { r.i = i; r._cargar(r.cola[i]); } },
      siguiente() { if (r.i + 1 < r.cola.length) r.saltar_a(r.i + 1); else r._emit("pide_mas"); },
      anterior() { if ((r.estado.t || 0) > 3 || r.i <= 0) r.ir_a(0); else r.saltar_a(r.i - 1); },
      quitar(i) { if (i === r.i || i < 0 || i >= r.cola.length) return; r.cola.splice(i, 1); if (i < r.i) r.i--; r._emit("cola"); },
      reordenar(de, a) { const act = r.cola[r.i]; const [x] = r.cola.splice(de, 1); r.cola.splice(a, 0, x); r.i = r.cola.indexOf(act); r._emit("cola"); },
      parar() { r.guardarPosicion(); r.orden("parar"); r.actual = null; r.cola = []; r.i = -1; r.estado = {}; r._emit("para"); r._emit("cola"); },
      alternar() { r.orden("alternar"); },
      pausa(p) { r.orden("pausa", p); },
      ir_a(s) { r.orden("saltar", s, "absolute"); },
      mover(d) { r.orden("saltar", d, "relative"); },
      bucle(b) { r._bucle = !!b; r.orden("bucle", !!b); },
      volumen(v) { r.orden("volumen", v); },
      silencio(m) { r._silencio = !!m; r.orden("silencio", !!m); },
      velocidad(x) { r.orden("velocidad", x); },
      calidad(alto) { r.orden("calidad", alto); },
      pip() { r.orden("pip"); },
      guardarPosicion() {
        const st = r.estado;
        if (r.actual && st && st.t > 0) M7.api("/api/posicion", {url: r.actual.url, seg: st.t, dur: st.d || 0});
      },
    };
    window.addEventListener("message", (ev) => {
      if (ev.source !== fr.contentWindow || !ev.data) return;
      const d = ev.data;
      if (d.tipo === "listo") {
        r.listo = true;
        const p = r._pend.splice(0);
        for (const [f, a] of p) fr.contentWindow.postMessage({f, a}, "*");
      } else if (d.tipo === "estado") {
        r.estado = d;
        r._emit("estado", d);
        if (d.fin && !r._fin && !r._bucle && r.actual) { r._fin = true; r.guardarPosicion(); r.siguiente(); }
      } else if (d.tipo) {
        r._emit(d.tipo, d);
      }
    });
    // del iframe: clic = pausa, doble clic = pantalla completa, teclas como en la página (solo con el talón)
    r.on("clic", () => { if (capa.modo === "mini") return; r.alternar(); });
    r.on("doble", () => { if (capa.modo === "mini") M7.volverDelFlotante(); else if (capa.modo !== "shorts") M7.pantallaCompleta(); });
    r.on("tecla", (d) => tecla(d.key, null));
    r.on("rueda", (d) => { if (M7._shorts && M7._shorts.visible) M7._shorts.rueda(d.dy); });
    setInterval(() => { if (r.actual && r.estado && r.estado.t > 0 && !r.estado.p) r.guardarPosicion(); }, 5000);
    return r;
  };

  // eventos de fuera: la ventana Qt (SSE «ventana») y el marco (app «completa», p. ej. al navegar en pantalla completa)
  let intentos = 0;
  function oir() {
    // M7.on lo pone pagina_video.js, que app.js (M4) puede cargar después de este fichero
    if (typeof M7.on !== "function") { if (intentos++ < 200) setTimeout(oir, 50); return; }
    M7.on("ventana", (d) => {
      M7._ventana = Object.assign(M7._ventana, d || {}, {_sse: true});
      // (06/10/2026: solo si no se acaba de pedir entrar; app.js ya no reparte los avisos viejos ni los intermedios)
      const o = window.app && window.app._ordenCompleta;
      const entrando = !!(o && o.si && performance.now() - o.t < 1500);
      if (d && d.completa === false && capa.modo === "completa" && M7._ventana._vista && !entrando) M7.pantallaCompleta(false);
      if (d && d.completa) M7._ventana._vista = true;
    });
    if (window.app && typeof window.app.on === "function") {
      window.app.on("completa", (si) => {
        if (!si && capa.modo === "completa") restaurar();
        else if (si && capa.modo !== "completa" && capa.modo !== "shorts") { const r = repVista(); if (r && r.actual) entrar(); }
      });
      // al cambiar de pestaña, la capa se recoloca (la zona de M6 es otra: la de la pestaña nueva)
      window.app.on("pestana:cambia", () => setTimeout(() => {
        if (capa.modo === "oculta" || capa.modo === "completa") return;
        const r = repVista();
        if ((capa.modo === "video" || capa.modo === "shorts") && capa.sitio && capa.sitio.getClientRects().length) return capa.recolocar();
        if (r && r.actual) capa.mini(); else capa.ocultar();
      }, 0));
    }
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", oir); else oir();
})();
