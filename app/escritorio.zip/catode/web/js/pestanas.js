// Cat-ode escritorio · interfaz web: las pestañas, como en el navegador (módulo M4; interfaz.py BarraPestanas 1454-1500,
// fila 1950-2005, gestión 2465-2700 y 2798-2875). 06/10/2026.
//   crear / cerrar (la última se queda limpia en el Inicio) / cerrar las otras / las de la derecha / duplicar / silenciar /
//   mover (arrastrando) / reabrir la cerrada (Ctrl+Mayús+T, hasta 20) · nombre ≤ 40 letras con el título entero de ayuda ·
//   altavoz rojo si suena, gris tachado si está silenciada (clic en él = silenciar) · botón central = cerrar · doble clic en
//   el hueco = nueva · clic derecho = menú · flechas atrás/adelante con historial (clic derecho o pulsación larga = lista,
//   central = esa página en pestaña nueva).
// Recordar: ajustes.pestanas = [{f, a, t}] y pestana_activa, el MISMO formato que _pestanas_guardables (2636): f = nombre de
// la función de interfaz.py, a = argumentos con cada Elemento como {_e: {...}}, t = nombre de la pestaña. Se guarda al
// cambiar (PUT /api/ajustes, 0,8 s después) y al cerrar la ventana (evento «cerrar»).
// Cada pestaña: {id, pila, ade, titulo, mute, suena, cuerpo (su caja), zona (caja fija para el vídeo de M6), pagina, vista}.
"use strict";
(function () {
  const C = window.catode = window.catode || {};
  const app = window.app;
  const api = C.api;
  const $ = (s, r) => (r || document).querySelector(s);
  const NOMBRES_QT = new Set(["inicio", "shorts", "suscripciones", "explorar", "historial", "despues", "megusta", "listas",
    "descargas", "nut", "ajustes_pagina", "_canal", "_mostrar_video", "_resultados", "_lista_yt", "_lista_propia",
    "_gestionar", "_canales", "musica", "_lista_musica"]);   // 22/10/2026: las de Música se guardaban como «Inicio»
  const lista = [];
  let actual = -1, siguienteId = 1;
  const cerradas = [];

  function activa() { return lista[actual] || null; }
  function indice(p) { return lista.indexOf(p); }

  // ------------------------------------------------------------------------------------------------ crear y activar
  // op: {vacia, pila, titulo, activar=true, reabriendo}
  function crear(op) {
    op = op || {};
    const p = {id: siguienteId++, pila: [], ade: [], titulo: op.titulo || "Inicio", mute: false, suena: false,
      cuerpo: null, zona: null, pagina: null, vista: null, ctrl: null, pintada: false, scroll: 0, nodo: null};
    p.cuerpo = document.createElement("section");
    p.cuerpo.className = "pestana-cuerpo";
    p.cuerpo.dataset.id = p.id;
    p.zona = document.createElement("div");
    p.zona.className = "zona";
    p.cuerpo.appendChild(p.zona);
    $("#paginas").appendChild(p.cuerpo);
    lista.push(p);
    if (op.pila && op.pila.length) p.pila.push(...op.pila.map((e) => ({f: e.f, a: app.normalizar(e.a)})));
    app.emitir("pestana:nueva", p);
    if (op.activar !== false) activar(lista.length - 1, {sinPintar: true});
    if (p.pila.length) {
      if (op.activar !== false) app.ejecutar(p, {reabriendo: !!op.reabriendo, restaurar: true, titulo: op.titulo});
    } else if (!op.vacia) {
      app.irSeccion("inicio");
    }
    pintar();
    guardar();
    return p;
  }

  function activar(i, op) {
    op = op || {};
    if (i < 0 || i >= lista.length || i === actual) return;
    const antes = activa();
    if (antes) { antes.scroll = antes.pagina ? antes.pagina.scrollTop : 0; antes.cuerpo.classList.remove("activa"); }
    actual = i;
    const p = lista[i];
    p.cuerpo.classList.add("activa");
    if (!op.sinPintar) {
      if (!p.pintada && p.pila.length) app.ejecutar(p, {reabriendo: true, restaurar: true, titulo: p.titulo});
      else if (!p.pila.length) app.irSeccion("inicio");
      else if (p.pagina) p.pagina.scrollTop = p.scroll;
    }
    app.tituloVentana(p.titulo);
    app.emitir("pestana:cambia", {p, antes});
    app.actualizarFlechas();
    pintar();
    guardar();
    if (p.nodo) p.nodo.scrollIntoView({block: "nearest", inline: "nearest"});
  }

  // ------------------------------------------------------------------------------------------------ cerrar y reabrir
  function apuntarCerrada(p) {
    if (p.pila.length) {
      cerradas.push({pila: p.pila.map((e) => ({f: e.f, a: e.a})), titulo: p.titulo});
      if (cerradas.length > 20) cerradas.splice(0, cerradas.length - 20);
    }
  }
  function cerrar(i) {
    if (i < 0 || i >= lista.length) return;
    const p = lista[i];
    app.emitir("pestana:cierra", p);   // M6: guarda la posición y para su vídeo
    apuntarCerrada(p);
    if (lista.length === 1) {   // la última también se cierra: se queda limpia en el Inicio (03/10/2026)
      if (p.ctrl) p.ctrl.abort();
      p.pila.length = 0; p.ade.length = 0;
      p.mute = false; p.suena = false;
      p.tituloFijo = null;
      app.irSeccion("inicio");
      pintar();
      return;
    }
    if (p.ctrl) p.ctrl.abort();
    if (p.vista && typeof p.vista.destruir === "function") { try { p.vista.destruir(); } catch (e) { /* nada */ } }
    lista.splice(i, 1);
    p.cuerpo.remove();
    if (p.nodo) p.nodo.remove();
    const era = actual;
    actual = -1;
    const nueva = i < era ? era - 1 : Math.min(era, lista.length - 1);
    activar(nueva);
    pintar();
    guardar();
  }
  function cerrarOtras(i) {
    const p = lista[i];
    for (let j = lista.length - 1; j >= 0; j--) if (lista[j] !== p) cerrar(j);
  }
  function cerrarDerecha(i) { for (let j = lista.length - 1; j > i; j--) cerrar(j); }
  function reabrir() {
    const c = cerradas.pop();
    if (c) crear({pila: c.pila, titulo: c.titulo});
  }
  function duplicar(i) {
    const p = lista[i];
    if (p && p.pila.length) crear({pila: p.pila.map((e) => ({f: e.f, a: e.a})), titulo: p.titulo});
    else crear();
  }
  function silenciar(i) {
    const p = lista[i];
    if (!p) return;
    let m = !p.mute;
    if (typeof app.ganchos.silenciar === "function") {
      try { const r = app.ganchos.silenciar(p); if (typeof r === "boolean") m = r; } catch (e) { /* nada */ }
    }
    p.mute = m;
    pintar();
  }
  // M6 avisa de qué suena: marcar(p, {suena, mute})
  function marcar(p, estado) {
    if (typeof p === "number") p = lista[p];
    if (!p) return;
    if ("suena" in estado) p.suena = !!estado.suena;
    if ("mute" in estado) p.mute = !!estado.mute;
    pintar();
  }
  function mover(de, a) {
    if (de === a || de < 0 || a < 0 || de >= lista.length || a >= lista.length) return;
    const act = activa();
    const [p] = lista.splice(de, 1);
    lista.splice(a, 0, p);
    actual = lista.indexOf(act);
    app.emitir("pestana:mueve", {p, de, a});
    pintar();
    guardar();
  }

  // ------------------------------------------------------------------------------------------------ pintar la fila
  function nodoDe(p) {
    if (p.nodo) return p.nodo;
    const n = document.createElement("div");
    n.className = "pestana";
    n.dataset.id = p.id;
    n.setAttribute("role", "tab");
    n.innerHTML = '<span class="altavoz"></span><span class="nombre"></span><button class="cerrar" title="Cerrar pestaña (Ctrl+W)" tabindex="-1"></button>';
    n.querySelector(".cerrar").innerHTML = C.iconos.svg("cerrar", "#AAAAAA", 14);
    p.nodo = n;
    return n;
  }
  function pintar() {
    const fila = $("#pestanas");
    if (!fila) return;
    lista.forEach((p, i) => {
      const n = nodoDe(p);
      if (fila.children[i] !== n) fila.insertBefore(n, fila.children[i] || null);
      n.classList.toggle("activa", i === actual);
      n.setAttribute("aria-selected", i === actual ? "true" : "false");
      const t = String(p.titulo || "Inicio");
      const nombre = n.querySelector(".nombre");
      if (nombre.textContent !== t.slice(0, 40)) nombre.textContent = t.slice(0, 40);
      n.title = t;
      const estado = p.suena ? (p.mute ? 2 : 1) : (p.mute ? 2 : 0);
      if (n.dataset.altavoz !== String(estado)) {
        n.dataset.altavoz = String(estado);
        n.querySelector(".altavoz").innerHTML = estado === 2 ? C.iconos.svg("silencio", "#AAAAAA", 16)
          : estado === 1 ? C.iconos.svg("volumen", "#FF0033", 16) : "";
        n.querySelector(".altavoz").title = estado === 2 ? "Activar sonido" : estado === 1 ? "Silenciar pestaña" : "";
      }
    });
    while (fila.children.length > lista.length) fila.lastElementChild.remove();
    app.actualizarFlechas();
  }

  // ------------------------------------------------------------------------------------------------ recordar
  function valor(x) {
    if (app.esElemento(x)) return {_e: app.limpioE(x)};
    if (x === null || ["string", "number", "boolean"].includes(typeof x)) return x;
    if (typeof x === "object") return JSON.parse(JSON.stringify(x));   // los filtros de una búsqueda
    throw new TypeError("no guardable");
  }
  function guardables() {
    return lista.map((p) => {
      try {
        const en = p.pila[p.pila.length - 1];
        if (!en || !NOMBRES_QT.has(en.f)) throw new TypeError("sin entrada");
        return {f: en.f, a: (en.a || []).map(valor), t: String(p.titulo || "Inicio").slice(0, 40)};
      } catch (e) {
        return {f: "inicio", a: [], t: "Inicio"};
      }
    });
  }
  let relojGuardar = 0, ultimoGuardado = "";
  function guardar(ya) {
    clearTimeout(relojGuardar);
    const hacer = () => {
      if (!lista.length) return Promise.resolve();
      const datos = {pestanas: guardables(), pestana_activa: Math.max(0, actual)};
      const s = JSON.stringify(datos);
      if (s === ultimoGuardado) return Promise.resolve();
      ultimoGuardado = s;
      return api.put("/api/ajustes", datos).catch((e) => { ultimoGuardado = ""; console.warn("no se guardan las pestañas", e); });
    };
    if (ya) return hacer();
    relojGuardar = setTimeout(hacer, 800);
    return Promise.resolve();
  }
  // _reabrir_pestanas 2657: las guardadas, sin reproducir nada; solo se pinta la activa
  function reabrirGuardadas(estado) {
    const guardadas = (estado && estado.pestanas) || [];
    const entradas = guardadas.filter((g) => g && typeof g.f === "string" && NOMBRES_QT.has(g.f));
    if (!entradas.length || (entradas.length === 1 && entradas[0].f === "inicio")) {
      ultimoGuardado = JSON.stringify({pestanas: [{f: "inicio", a: [], t: "Inicio"}], pestana_activa: 0});
      crear();
      return false;
    }
    const n = entradas.length;
    const act = Math.min(Math.max(0, parseInt(estado.pestana_activa, 10) || 0), n - 1);
    entradas.forEach((g) => {
      const p = crear({vacia: true, activar: false, titulo: g.t || "Inicio"});
      p.pila.push({f: g.f, a: app.normalizar(g.a || [])});
    });
    activar(act);
    return true;
  }

  // ------------------------------------------------------------------------------------------------ ratón y menús
  function prepararFila() {
    const fila = $("#pestanas");
    const caja = $("#fila-pestanas");
    const pestanaDe = (ev) => { const n = ev.target.closest(".pestana"); return n ? lista.findIndex((p) => p.nodo === n) : -1; };
    fila.addEventListener("mousedown", (ev) => { if (ev.button === 1) ev.preventDefault(); });
    fila.addEventListener("auxclick", (ev) => {
      if (ev.button !== 1) return;
      ev.preventDefault();
      const i = pestanaDe(ev);
      if (i >= 0) cerrar(i);   // botón central = cerrarla (03/10/2026)
    });
    fila.addEventListener("click", (ev) => {
      const i = pestanaDe(ev);
      if (i < 0 || arrastre.movido) return;
      if (ev.target.closest(".cerrar")) { ev.stopPropagation(); return cerrar(i); }
      if (ev.target.closest(".altavoz") && lista[i].nodo.dataset.altavoz !== "0") return silenciar(i);
      activar(i);
    });
    caja.addEventListener("dblclick", (ev) => {
      if (ev.target.closest(".pestana, button")) return;
      crear();   // doble clic en el hueco = pestaña nueva
    });
    fila.addEventListener("contextmenu", (ev) => {
      const i = pestanaDe(ev);
      if (i < 0) return;
      ev.preventDefault();
      const p = lista[i];
      app.menu([
        {texto: "Cerrar pestaña", accion: () => cerrar(lista.indexOf(p)), atajo: "Ctrl+W"},
        {texto: "Cerrar las otras", accion: () => cerrarOtras(lista.indexOf(p))},
        {texto: "Cerrar las de la derecha", accion: () => cerrarDerecha(lista.indexOf(p)), desactivado: i === lista.length - 1},
        null,
        {texto: "Duplicar", accion: () => duplicar(lista.indexOf(p))},
        {texto: p.mute ? "Activar sonido" : "Silenciar pestaña", accion: () => silenciar(lista.indexOf(p))},
        null,
        {texto: "Reabrir pestaña cerrada", accion: reabrir, desactivado: !cerradas.length, atajo: "Ctrl+Mayús+T"},
      ], ev.clientX, ev.clientY);
    });
    // la rueda mueve la fila en horizontal cuando no caben
    fila.addEventListener("wheel", (ev) => {
      if (ev.ctrlKey || fila.scrollWidth <= fila.clientWidth) return;
      ev.preventDefault();
      fila.scrollLeft += ev.deltaY || ev.deltaX;
    }, {passive: false});
    // arrastrar para reordenar (tabMoved, 05/10/2026)
    const arrastre = {p: null, x0: 0, movido: false};
    fila.addEventListener("pointerdown", (ev) => {
      if (ev.button !== 0 || ev.target.closest(".cerrar")) return;
      const i = pestanaDe(ev);
      if (i < 0) return;
      arrastre.p = lista[i]; arrastre.x0 = ev.clientX; arrastre.movido = false;
    });
    addEventListener("pointermove", (ev) => {
      const p = arrastre.p;
      if (!p || !(ev.buttons & 1)) return;
      if (!arrastre.movido && Math.abs(ev.clientX - arrastre.x0) < 6) return;
      if (!arrastre.movido) { arrastre.movido = true; p.nodo.classList.add("arrastrando"); }
      // su sitio nuevo = cuántas de las otras tienen el centro a la izquierda del puntero
      const de = lista.indexOf(p);
      let a = 0;
      lista.forEach((q, k) => {
        if (k === de) return;
        const r = q.nodo.getBoundingClientRect();
        if (r.left + r.width / 2 < ev.clientX) a++;
      });
      if (a !== de) mover(de, a);
    });
    addEventListener("pointerup", () => {
      const p = arrastre.p;
      if (!p) return;
      if (p.nodo) p.nodo.classList.remove("arrastrando");
      arrastre.p = null;
      if (arrastre.movido) setTimeout(() => { arrastre.movido = false; }, 0);
    });
    $("#mas").addEventListener("click", () => crear());

    // flechas atrás / adelante: clic, clic derecho o pulsación larga (550 ms) = historial, central = pestaña nueva
    for (const [id, ade] of [["#atras", false], ["#adelante", true]]) {
      const b = $(id);
      let larga = 0, menuPorLarga = false;
      b.addEventListener("click", () => {
        if (menuPorLarga) { menuPorLarga = false; return; }
        if (ade) app.adelante(); else app.volver();
      });
      b.addEventListener("contextmenu", (ev) => { ev.preventDefault(); menuHistorial(ade, b); });
      b.addEventListener("pointerdown", (ev) => {
        if (ev.button !== 0) return;
        clearTimeout(larga);
        larga = setTimeout(() => { menuPorLarga = true; menuHistorial(ade, b); }, 550);
      });
      for (const t of ["pointerup", "pointerleave", "pointercancel"]) b.addEventListener(t, () => clearTimeout(larga));
      b.addEventListener("mousedown", (ev) => { if (ev.button === 1) ev.preventDefault(); });
      b.addEventListener("auxclick", (ev) => { if (ev.button === 1) { ev.preventDefault(); app.historialEnPestana(ade); } });
    }
  }
  // menu_historial 2775: las páginas de ese lado, la más cercana arriba
  function menuHistorial(adelante, boton) {
    const p = activa();
    if (!p) return;
    const items = adelante
      ? p.ade.slice().reverse().map((en, k) => ({texto: app.nombreEntrada(en), accion: () => app.saltarHistorial(k + 1)}))
      : p.pila.slice(0, -1).reverse().map((en, k) => ({texto: app.nombreEntrada(en), accion: () => app.saltarHistorial(-(k + 1))}));
    if (!items.length) return;
    const r = boton.getBoundingClientRect();
    app.menu(items, r.left, r.bottom + 2);
  }

  C.pestanas = {lista, activa, indice, crear, activar, cerrar, cerrarOtras, cerrarDerecha, reabrir, duplicar, silenciar,
    marcar, mover, pintar, guardar, guardables, reabrirGuardadas, menuHistorial, cerradas,
    actual: () => actual, siguiente: (d) => { if (lista.length) activar(((actual + d) % lista.length + lista.length) % lista.length); }};
  app.pestanas = C.pestanas;
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", prepararFila);
  else prepararFila();
})();
