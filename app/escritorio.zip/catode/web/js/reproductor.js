// Cat-ode escritorio · interfaz web · el reproductor (módulo M6, DISENO_WEB.md §1.5-1.6, §1.9 y §2.5). 06/10/2026.
// Puerto de la clase Reproductor de catode/reproductor.py (cola, automática, saltar_a, velocidad, calidad, subtítulos, bucle,
// solo sonido, apagar_en, volumen 0-130, reanudar, precalentar, tramos de SponsorBlock, reintentos y la posición cada 5 s).
// Cada pestaña con vídeo tiene su Reproductor, que maneja UN <iframe sandbox="allow-scripts"> con reproductor.html (origen
// opaco: así funciona el HLS de YouTube). Se le habla por postMessage {f, a} y contesta {tipo: "estado", …} (§2.5).
// El iframe no puede llamar a /api: el reproductor resuelve aquí (GET /api/resolver) y le pasa la dirección ya resuelta.
//
// Uso (lo que necesitan las otras partes):
//   const rep = Reproductor.gestor.crear(zona)   // zona = elemento donde va el iframe (ojo: mover un iframe en el DOM lo
//                                                // recarga; para el mini, mover la zona con CSS, no cambiarla de padre)
//   rep.reproducir(e, desde)  · encolar(e) · insertar_siguiente(e) · todo(lista, aleatorio) · saltar_a(i) · siguiente()
//   anterior() · alternar() · pausar(p) · ir_a(s) · mover(s) · ir_al_directo() · silencio() · volumen(0-130) · velocidad(r)
//   calidad("auto"|alto) · subtitulos() → [{id, nombre}] · poner_subtitulos(id|null) · bucle(si) · solo_sonido(si)
//   apagar_en(min | -1 | 0) · reproducir_local(ruta, e) · precalentar(elementos) · parar() · cerrar()
//   estado: rep.actual, cola, i, pausa, pos, dur, directo, storyboard, tramos, subs, vol, mute, vel, bucle_activo, solo
//   eventos (rep.on(nombre, f) o addEventListener): cambio · aviso {detail: texto} · empieza {detail: e} · pide_mas {detail: e}
//   (preventDefault() para no hacer la automática de serie) · pide_pantalla · pide_menu · volumen_cambia {detail: v}
//   Reproductor.gestor: activar(rep) (pestaña visible: tope de 2 vídeos vivos, el de fondo a 360p) · activo · guardar_todo()
//   (antes del POST /api/guardado del cierre) · tecla_multimedia("play"|"pausa"|"siguiente"|"anterior"|"parar")
"use strict";
(function () {
  // ------------------------------------------------------------------ llamadas al servidor (talón propio de api.js, M4)
  const C0 = () => window.catode || {};
  const token = () => (C0().api && C0().api.token) || window.CATODE_TOKEN || C0().token || new URLSearchParams(location.search).get("t") || "";
  const base = () => (C0().api && C0().api.base) || window.CATODE_BASE || C0().base || location.origin;
  async function api(ruta, cuerpo, opciones) {
    const o = Object.assign({}, opciones || {});
    const r = await fetch(base() + ruta, {
      method: o.metodo || (cuerpo === undefined ? "GET" : "POST"),
      headers: Object.assign({"X-Catode": token()}, cuerpo === undefined ? {} : {"Content-Type": "application/json"}),
      body: cuerpo === undefined ? undefined : JSON.stringify(cuerpo),
      keepalive: !!o.keepalive, signal: o.signal,
    });
    if (r.status === 204) return {ok: true};
    try { return await r.json(); } catch (e) { return {ok: false, error: "respuesta no válida (" + r.status + ")", clase: "servidor_autor"}; }
  }
  const tiempo = (s) => {   // motor.tiempo: 0:00, 1:02:03
    s = Math.max(0, Math.floor(Number(s) || 0));
    const h = Math.floor(s / 3600), m = Math.floor(s / 60) % 60, x = String(s % 60).padStart(2, "0");
    return h ? `${h}:${String(m).padStart(2, "0")}:${x}` : `${m}:${x}`;
  };
  const idVideo = (u) => { const m = /(?:v=|youtu\.be\/|shorts\/|live\/|embed\/)([\w-]{11})/.exec(u || ""); return m ? m[1] : (u || ""); };
  const registro = (t) => { try { console.debug("Cat-ode reproductor: " + t); } catch (e) {} };
  // 06/10/2026: los cortes y reintentos, además, a catode.log (POST /api/registro): sin esto no se sabía por qué paraba un vídeo
  const apuntar = (t) => { registro(t); try { api("/api/registro", {t}).catch(() => {}); } catch (e) {} };

  // un solo requestAnimationFrame para todo lo que se repinta (mandos, barra): §1.11
  const enCuadro = new Set();
  let cuadroPedido = false;
  // 19/10/2026 «la descarga de vídeos se queda en 4 segundos»: en el mini PC (gráfica frenada por calor, descodificador al
  // 100 % con un 1080p) bastaba otro programa descodificando para que el vídeo se parase con datos ya bajados; recargar no
  // servía (a los 4-8 s, otra vez) y tres recargas daban «no se puede reproducir» y un falso «YouTube roto». Ahora, parado
  // con datos por delante = el equipo no da abasto: se baja la calidad un escalón durante 15 min para todos los vídeos
  // (gestor.topeCarga, común a todas las pestañas).
  const ESCALONES = [720, 480, 360];
  // 21/10/2026 «catode sigue saltando videos a la mitad, empieza el video y muchas veces se interrumpe y pasa al siguiente,
  // arréglalo como sea»: un vídeo que YA ha sonado nunca pasa solo al siguiente por un fallo. Tras los 3 reintentos rápidos,
  // estos intentos lentos (segundos de espera antes de cada uno; dirección nueva y el mismo segundo) y, si tampoco, se queda
  // quieto en ese punto con el aviso (▶ lo vuelve a intentar). Pocos y espaciados: nada repetido contra YouTube (regla 24).
  const LENTOS = [10, 20, 40, 60, 120, 120];
  function pintarPronto(f) {
    enCuadro.add(f);
    if (cuadroPedido) return;
    cuadroPedido = true;
    requestAnimationFrame(() => {
      cuadroPedido = false;
      const fs = [...enCuadro]; enCuadro.clear();
      for (const g of fs) { try { g(); } catch (e) { registro("pintar: " + e); } }
    });
  }

  const AVISOS_TRAMO = {sponsor: "Patrocinio saltado", selfpromo: "Autopromoción saltada", interaction: "«Suscríbete» saltado",
    intro: "Intro saltada", outro: "Final saltado", music_offtopic: "Parte sin música saltada", anuncio: "Anuncio saltado"};

  // los avisos del iframe se reparten por su contentWindow
  const porVentana = new Map();
  window.addEventListener("message", (ev) => {
    const rep = porVentana.get(ev.source);
    if (rep && ev.data && typeof ev.data === "object") rep._mensaje(ev.data);
  });

  class Reproductor extends EventTarget {
    constructor(zona, ajustes) {
      super();
      this.ajustes = ajustes || gestor.ajustes;
      this.cola = []; this.i = -1; this.actual = null;
      this.pausa = true; this.pos = 0; this.dur = 0; this.directo = false;
      this.storyboard = null; this.tramos = []; this._saltados = new Set(); this.subs = []; this.capitulos = [];
      this.vol = Number(this.ajustes.volumen ?? 80); this.mute = false; this.vel = 1; this.bucle_activo = false; this.solo = false;
      this.fondo = false; this.congelado = null; this.alto_auto = 720; this.tipo = null; this.fuente = null;
      this.subs_activos = !!this.ajustes.subtitulos; this._sid = null;
      this._turno = 0; this._locales = {}; this._parar_al_acabar = false; this._apagado = null; this._reintentos = {};
      this._lentos = {}; this._t_lento = 0; this._atascado = false; this._abasto_visto = null;
      this._elegido = true; this._arrancado = true; this._t_pedido = 0; this._fin_visto = false; this._error_visto = false;
      this._quieto = 0; this._ult = -1; this._salto = 0; this._guardada = {url: null, seg: -1};
      this.listo = false; this._pendientes = []; this.ultimo = null; this.pip_activa = false; this.pip_armado = false;
      this.zona = zona || this._zonaPropia();
      this.iframe = document.createElement("iframe");
      this.iframe.className = "rep-iframe";
      this.iframe.setAttribute("sandbox", "allow-scripts");
      this.iframe.setAttribute("allow", "autoplay; picture-in-picture; fullscreen");
      this.iframe.setAttribute("referrerpolicy", "no-referrer");
      this.iframe.setAttribute("title", "Reproductor");
      this.iframe.setAttribute("tabindex", "-1");
      this.iframe.src = "/reproductor.html";
      this.zona.appendChild(this.iframe);
      porVentana.set(this.iframe.contentWindow, this);
      this._cargas = 0;
      this.iframe.addEventListener("load", () => {
        // mover el iframe en el DOM lo recarga: se vuelve a esperar «listo» y lo que sonaba se retoma en su punto
        if (++this._cargas > 1) {
          registro("el iframe se ha recargado (¿movido en el DOM?): retomo");
          this.listo = false;
          porVentana.set(this.iframe.contentWindow, this);
          this._retomar = !!(this.actual && !this.congelado);
        }
      });
    }

    _zonaPropia() {
      const z = document.createElement("div");
      z.className = "rep-zona";
      document.body.appendChild(z);
      return z;
    }

    on(nombre, f) { this.addEventListener(nombre, f); return this; }
    get estado() { return this.ultimo || {t: this.pos, d: this.dur, p: this.pausa}; }   // el último {tipo:"estado", …} del iframe
    orden(f, ...a) { this._orden(f, ...a); }
    _emitir(nombre, detalle, cancelable) {
      const ev = new CustomEvent(nombre, {detail: detalle, cancelable: !!cancelable});
      this.dispatchEvent(ev);
      return ev;
    }
    _cambio() { this._emitir("cambio"); }
    _aviso(t) { this._emitir("aviso", t); gestor.avisar(t); }

    // ---- hablar con el iframe ----
    _orden(f, ...a) {
      if (!this.listo) { this._pendientes.push([f, a]); return; }
      try { this.iframe.contentWindow.postMessage({f, a}, "*"); } catch (e) { registro("orden " + f + ": " + e); }
    }
    _mensaje(m) {
      // 06/10/2026 (fallos A y B de Windows): solo cuenta lo que manda reproductor.html ({tipo: …}). En la prueba de
      // Windows, la consola inyectada (CONSOLA_JS de interfaz_web.py) también corre en el about:blank inicial del iframe y
      // avisa «iframe: arranca blank» por postMessage desde la MISMA ventana: eso daba el iframe por listo, la orden
      // «cargar» iba al about:blank (que enseguida se sustituye por reproductor.html) y se perdía: el vídeo no arrancaba
      if (!m || typeof m.tipo !== "string") {
        if (!this.listo) { this._prematuros = (this._prematuros || 0) + 1; gestor.prematuros++; }
        return;
      }
      if (!this.listo) {   // «listo» (o cualquier aviso de reproductor.html: ya escucha) → lo que se pidió antes de que cargara
        this.listo = true;
        const p = this._pendientes; this._pendientes = [];
        if (this._retomar) { this._retomar = false; this._pausar_al_cargar = this.pausa; this._cargar(this.pos, true); }
        else for (const [f, a] of p) this._orden(f, ...a);
      }
      if (m.tipo === "cargado") {   // la confirmación de «cargar» (06/10/2026): qué orden llegó y si el marco se ve
        this._cargado = m;
        if (m.n === this._n_cargar) { clearTimeout(this._reenvio); this._reenvio = 0; }
        if (m.vis !== "visible") registro(`cargar con el marco ${m.vis}: Edge aplaza el vídeo de un marco nuevo hasta que se vea`);
        return;
      }
      if (m.tipo === "estado") return this._estado(m);
      if (m.tipo === "clic") { this.alternar(); return; }
      // 06/10/2026: en Windows el doble clic y el clic derecho caen DENTRO del iframe (encima de la capa de mandos) y nadie
      // atendía estos avisos: ni pantalla completa ni menú. Ahora, si nadie cancela el evento, van a los ganchos del marco.
      if (m.tipo === "multimedia") {   // 06/10/2026: pausa/play/siguiente/anterior DEL SISTEMA (teclas, mandos, Ralph)
        if (m.accion === "siguiente") this.siguiente("tecla multimedia del sistema (teclado, auriculares o mando)");
        else if (m.accion === "anterior") this.anterior();
        else { this.pausa = m.accion === "pausa"; this._cambio(); }   // el iframe ya ha pausado o reanudado
        return;
      }
      if (m.tipo === "raton") {   // 06/10/2026: movimiento dentro del iframe → los mandos vuelven
        const g = (window.app && window.app.ganchos) || {};
        if (typeof g.ratonVideo === "function") g.ratonVideo();
        return;
      }
      if (m.tipo === "doble") {
        apuntar(`doble clic DENTRO del vídeo (iframe) · vídeo=${!!this.actual} pausa=${this.pausa}`);   // 07/10/2026: rastro en catode.log
        if (!this._emitir("pide_pantalla", null, true).defaultPrevented) {
          this.alternar();   // el clic anterior pausó: se deshace, como en la Qt
          const g = (window.app && window.app.ganchos) || {};
          if (typeof g.completa === "function") g.completa();
        }
        return;
      }
      if (m.tipo === "menu") {
        if (!this._emitir("pide_menu", null, true).defaultPrevented) {
          const g = (window.app && window.app.ganchos) || {};
          if (typeof g.menuVideo === "function") g.menuVideo({x: Math.round(innerWidth / 2), y: Math.round(innerHeight / 2)});
        }
        return;
      }
      if (m.tipo === "rueda") { this.volumen(Math.max(0, Math.min(130, this.vol + (m.dy < 0 ? 5 : -5)))); return; }
      if (m.tipo === "tecla") {   // el iframe tenía el foco (tras un clic dentro): la tecla vuelve a la página y el foco también
        const ev = this._emitir("tecla", m, true);
        try { if (document.activeElement === this.iframe) this.iframe.blur(); } catch (e) { /* nada */ }
        if (!ev.defaultPrevented) document.dispatchEvent(new KeyboardEvent("keydown", {key: m.key, code: m.code, ctrlKey: !!m.ctrl,
          shiftKey: !!m.shift, altKey: !!m.alt, bubbles: true, cancelable: true}));
        return;
      }
      if (m.tipo === "pip") {   // imagen en imagen: activa, o «armada» (falta un clic sobre el vídeo: los mandos lo dejan pasar)
        const antes = this.pip_armado;
        this.pip_activa = !!m.activa; this.pip_armado = !!m.armado;
        if (this.pip_armado && !antes) this._aviso("Pulsa sobre el vídeo para verlo en imagen en imagen");
        this._emitir("pip", {activa: this.pip_activa, armado: this.pip_armado});
        this._cambio();
      }
    }
    _estado(m) {   // _propiedad de reproductor.py: lo que avisa el <video>
      this.ultimo = m;
      if (this.congelado) return;
      // mientras se resuelve otro vídeo, el <video> sigue con el anterior: su estado no vale para el nuevo (guardaba la
      // posición del viejo con la URL del nuevo, cancelaba el «desde» o lo daba por acabado). Tras la orden «cargar», lo que
      // ya venía de camino (listo y sin error) se descarta hasta el primer estado del vídeo nuevo, con un tope de 1 s.
      if (this._resolviendo) return;
      if (this._tras_cargar) {
        if (performance.now() < this._tras_cargar && m.listo && !m.error) return;
        this._tras_cargar = 0;
      }
      if (m.notas && m.notas.length) for (const n of m.notas) registro(n);
      if (m.t !== null && m.t !== undefined && !this._recargando) {
        if (!m.fin) this._pos_antes = m.t;   // 15/10/2026: con «fin» el <video> da t = 0; _al_acabar mira la de antes
        if (!m.fin && m.t > 0.5) this._pos_bueno = m.t;   // 19/10/2026: también el aviso de justo antes llega con t = 0
        this.pos = m.t;
        if (!this._arrancado && this.pos > 0 && this.actual) {
          this._arrancado = true;
          registro(`empieza «${(this.actual.titulo || "").slice(0, 50)}» en ${((performance.now() - this._t_pedido) / 1000).toFixed(1)} s`);
        }
      } else if (this._recargando && m.t > 0) { this._recargando = false; this.pos = m.t; if (!m.fin) this._pos_bueno = m.t; }
      if (m.d || !this._recargando) this.dur = m.d || this.dur || 0;
      if (this._desde && m.d > 0) {   // un punto de reanudar que no cabe en el vídeo real (datos de otra duración): desde el principio
        const d = this._desde; this._desde = 0;
        if (!this.directo && d > m.d - 5) { registro(`reanudar en ${d.toFixed(0)} s no cabe en ${m.d.toFixed(0)} s: desde 0`); this.ir_a(0); return; }
      }
      this.pausa = !!m.p || (!!m.fin && !this.bucle_activo);   // acabado y sin nada detrás: en pausa (⏯ lo vuelve a poner)
      if (this.ajustes.patrocinios !== false) {
        for (const [a, b, cat] of this.tramos) {
          const k = a + ":" + b;
          // 19/10/2026: un tramo que llega al final no se salta (se acabaría el vídeo y empezaría otro)
          if (a <= this.pos && this.pos < b - 0.5 && !this._saltados.has(k) && this.dur > 0 && b < this.dur - 3) {   // 21/10/2026: sin la duración, nada
            this._saltados.add(k);
            apuntar(`salto de tramo ${cat} de ${a.toFixed(0)} s a ${b.toFixed(0)} s (de ${(this.dur || 0).toFixed(0)} s)`);   // 19/10/2026: rastro
            this.ir_a(b);
            this._aviso(AVISOS_TRAMO[cat] || "Tramo saltado");
          }
        }
      }
      if (!m.fin) this._fin_visto = false;   // vuelto a poner tras acabar (⏯): al acabar otra vez, se atiende
      if (m.fin && !this._fin_visto) { this._fin_visto = true; this._al_acabar(); }
      if (m.error && !this._error_visto && this.actual) {
        this._error_visto = true;
        apuntar(`el vídeo ha cortado por un error (${m.error}) en ${this.pos.toFixed(0)} s · ${(m.notas || []).slice(-4).join(" | ")}`);
        this._reintentar();
      }
      this._cambio();
    }

    // ---- la cola ----
    alto() {   // la altura que se pide al resolver: la elegida o, en «auto», hasta 1080 (Edge elige el nivel, §2.5)
      const c = this.ajustes.calidad || "auto";
      return c === "auto" ? 1080 : parseInt(c, 10) || 1080;
    }
    _altoIframe() {
      const pedido = this.fondo ? 360 : ((this.ajustes.calidad || "auto") === "auto" ? 0 : parseInt(this.ajustes.calidad, 10) || 0);
      const tope = gestor.topeCarga;
      if (tope.alto && performance.now() < tope.hasta && (!pedido || pedido > tope.alto)) return tope.alto;
      return pedido;
    }

    async _cargar(desde, recarga, fresco) {   // fresco: solo _reintentar (olvida la URL en caché del Resolutor)
      const turno = ++this._turno;
      const e = this.cola[this.i];
      if (!e) return;
      if (!recarga) this._guardar_posicion();   // el que sonaba, antes de cambiar
      this.actual = e;
      this._recargando = !!recarga;
      this._resolviendo = !recarga; this._tras_cargar = 0;
      // 07/10/2026: el tope de 20 s cuenta desde AHORA. Antes se ponía al final (tras el await del Resolutor) y, en una
      // recarga, _mirar_parado veía _arrancado=false con el _t_cargar del arranque anterior (minutos atrás): «sin imagen
      // 20 s después de cargar» saltaba en el MISMO segundo que «parado 8 s» y un solo tropiezo gastaba dos reintentos
      // (registro del autor: 13:50:39 reintento 1 y 2 a la vez; a las 13:51:45 «falla tras 3 reintentos» y el vídeo parado)
      this._t_cargar = performance.now();
      this.congelado = null;
      if (recarga) this.pos = desde || 0;
      else {
        clearTimeout(this._t_lento); this._t_lento = 0; this._atascado = false;
        this.pos = 0; this.dur = 0; this.directo = false; this.storyboard = null; this.subs = []; this._sid = null;
        this.tramos = []; this._saltados = new Set(); this.capitulos = gestor._caps.get(idVideo(e.url)) || [];
        this._emitir("empieza", e);
        if (String(e.url || "").startsWith("http")) api("/api/visto", {e}).catch(() => {});
      }
      this.pausa = false;
      this._t_pedido = performance.now(); this._arrancado = false; this._fin_visto = false; this._error_visto = false; this._pos_antes = 0;
      this._pos_bueno = Number(desde) || 0;   // 19/10/2026: el último segundo que de verdad sonó (para un «final» falso)
      gestor._vive(this);
      this._cambio();
      const local = this._locales[e.url];
      const url = local ? "file:" + local : e.url;
      let r;
      try {
        r = await api(`/api/resolver?url=${encodeURIComponent(url)}&alto=${this.alto()}&fondo=0${fresco ? "&fresco=1" : ""}`);   // fresco SOLO en los reintentos
      } catch (err) {
        r = {ok: false, error: String(err), clase: "sin_red"};
      }
      if (turno !== this._turno) return;
      if (!r.ok) return this._no_resuelto(e, r, desde, recarga, turno, fresco);
      if (r.url && String(e.url || "").startsWith("cancion:")) {   // 22/10/2026: canción importada (Spotify, Amazon): ya tiene vídeo
        e.cancion = e.url;   // la página del vídeo pudo abrirse con esta dirección: sigue siendo «la que suena» (esActual)
        e.url = r.url;
        if (!e.miniatura) e.miniatura = "https://i.ytimg.com/vi/" + (r.url.split("v=")[1] || "").slice(0, 11) + "/mqdefault.jpg";
        if (!recarga) api("/api/visto", {e}).catch(() => {});
        this._cambio();
      }
      this.tipo = r.tipo; this.fuente = r.fuente;
      this.directo = !!r.directo;
      if (!recarga) {
        this.storyboard = r.storyboard || null;
        this.tramos = (r.tramos || []).map((x) => [Number(x[0]), Number(x[1]), x[2]]);
        this.subs = (r.subs || []).map((s, k) => ({id: k + 1, url: s.url, nombre: s.nombre || s.lengua || `Pista ${k + 1}`, lengua: s.lengua || ""}));
        if (!this.dur && r.duracion) this.dur = Number(r.duracion) || 0;
        // M8 (reproductor.py 312-325): sin tramos «sponsor» de SponsorBlock, los anuncios del creador (anuncios.detectar,
        // por capítulos/descripción/subtítulos), por detrás para no retrasar el arranque
        if (this.ajustes.patrocinios !== false && /^https?:/.test(String(e.url || "")) && !this.tramos.some((x) => x[2] === "sponsor")) {
          const sub = this.subs.find((x) => !/tlang=/.test(x.url)) || this.subs[0];
          const vtt = sub && /^https?:/.test(sub.url) ? "&vtt=" + encodeURIComponent(sub.url) : "";
          api(`/api/video/tramos?url=${encodeURIComponent(e.url)}&dur=${Number(r.duracion) || 0}${vtt}`).then((x) => {
            if (turno === this._turno && x && x.ok && Array.isArray(x.tramos) && x.tramos.length)
              this.tramos = x.tramos.map((t) => [Number(t[0]), Number(t[1]), t[2]]);
          }).catch(() => {});
        }
        // reanudar (interfaz.py 3016-3030): si no se pidió un punto, donde se dejó (entre 15 s y 20 s antes del final)
        if ((desde === null || desde === undefined) && !this.directo && this.ajustes.reanudar !== false && r.reanudar) {
          const s = Number(r.reanudar.seg) || 0, d = Number(r.reanudar.dur) || 0;
          if (d && s > 15 && s < d - 20) { desde = s; this._aviso(`Sigue donde lo dejaste (${tiempo(s)})`); }
        }
      }
      desde = Number(desde) || 0;
      if (desde) this.pos = desde;
      this._desde = desde;
      // la orden lleva un número y el iframe la confirma con «cargado»; sin confirmación en 3 s (el marco se recargó, el
      // mensaje se perdió) se manda otra vez, una sola
      const n = this._n_cargar = (this._n_cargar || 0) + 1, args = [r.fuente, r.tipo === "hls" ? "hls" : "archivo", desde, n];
      this._orden("cargar", ...args); this._meta();
      clearTimeout(this._reenvio);
      this._reenvio = setTimeout(() => {
        this._reenvio = 0;
        if (turno !== this._turno || n !== this._n_cargar || (this._cargado && this._cargado.n === n)) return;
        registro(`«cargar» ${n} sin confirmar en 3 s (listo=${this.listo}, pendientes ${this._pendientes.length}): la mando otra vez`);
        this._orden("cargar", ...args); this._meta(); this._aplicar();
      }, 3000);
      this._t_cargar = performance.now();   // tope de arranque (_mirar_parado): sin imagen en 20 s, reintento
      if (this._resolviendo) { this._resolviendo = false; this._tras_cargar = performance.now() + 1000; }
      this._aplicar();
      for (const s of this.subs) this._orden("subtitulo", s.url, s.nombre, s.lengua);
      if (this.subs_activos && this.subs.length) { this._sid = this.subs[0].id; this._orden("verSubtitulo", String(this._sid)); }
      if (this._pausar_al_cargar) { this._pausar_al_cargar = false; this.pausar(true); }
      this._cambio();
      setTimeout(() => this._adelantar(), 1500);
    }
    _aplicar() {   // lo que el <video> nuevo no conserva: volumen, silencio, velocidad, bucle, solo sonido, calidad
      this._orden("volumen", this.vol);
      this._orden("silencio", this.mute);
      this._orden("velocidad", this.vel);
      this._orden("bucle", this.bucle_activo);
      this._orden("soloSonido", this.solo);
      this._orden("calidad", this._altoIframe());
    }
    _no_resuelto(e, r, desde, recarga, turno, fresco) {
      registro(`no he podido resolver ${e.url}: ${r.error || ""} (${r.clase || ""})`);
      // lo que sonaba antes (otro vídeo) no puede seguir sonando bajo el título de este; con bloqueo, tampoco el mismo
      if (!recarga || r.clase === "bloqueo") this._orden("parar");
      // 21/10/2026: en una recarga (el vídeo ya sonaba) tampoco se pasa al siguiente: intentos lentos y, si no, quieto
      if (r.clase === "imposible" && recarga && Math.max(this._pos_bueno || 0, this.pos || 0) > 5) return this._reintento_lento(e.url);
      if (r.clase === "imposible") return this._no_se_puede(r.error || "Este vídeo no se puede ver");
      if (r.clase === "bloqueo") {   // regla 24: sin reintentos automáticos
        this.pausa = true; this._cambio();
        return this._aviso(r.error || "YouTube ha cortado el acceso por ahora: no se reintenta");
      }
      // sin red (o el servidor): aviso y reintento a los 15 s (§2.2), si sigue siendo el mismo vídeo
      this._aviso((r.error || "Sin conexión") + ": lo reintento en 15 s");
      setTimeout(() => { if (turno === this._turno && this.actual === e) this._cargar(recarga ? this.pos : desde, recarga, fresco); }, 15000);
    }

    _meta() {   // lo que el sistema enseña de lo que suena (título, canal y portada)
      const e = this.actual;
      if (e) this._orden("meta", e.titulo || "", e.autor || "", e.miniatura || "");
    }
    _reintentar() {
      if (!this.actual || this._t_lento) return;   // ya hay un intento lento esperando: no se gasta otro
      const u = this.actual.url;
      const n = (this._reintentos[u] || 0) + 1;
      this._reintentos[u] = n;
      if (n > 3) {
        // 21/10/2026: solo un vídeo que no ha llegado a sonar se da por imposible y deja paso al siguiente (ver LENTOS)
        if (Math.max(this._pos_bueno || 0, this.pos || 0) > 5 && !this.directo) return this._reintento_lento(u);
        apuntar(`«${(this.actual.titulo || "").slice(0, 50)}» falla tras 3 reintentos seguidos sin haber sonado`);
        return this._no_se_puede("Este vídeo no se puede reproducir ahora");
      }
      this._sano = 0;
      apuntar(`reintento ${n} de «${(this.actual.titulo || "").slice(0, 50)}» en ${this.pos.toFixed(0)} s`);
      if (n === 2) api("/api/fallo", {url: u, error: "dos reintentos seguidos"}).catch(() => {});
      this._cargar(Math.max(0, this.pos - 1), true, true);
    }
    _reintento_lento(u) {   // 21/10/2026 (ver LENTOS): nunca al siguiente; espera, el mismo segundo y, al final, quieto
      const e = this.actual, titulo = (e.titulo || "").slice(0, 50), k = this._lentos[u] = (this._lentos[u] || 0) + 1;
      const pos = Math.max(0, Math.max(this.pos || 0, this._pos_bueno || 0) - 1);
      if (k > LENTOS.length) {
        apuntar(`«${titulo}» no sigue tras ${3 + LENTOS.length} intentos: me quedo en ${pos.toFixed(0)} s en pausa (no paso al siguiente)`);
        this._atascado = true; this.pausa = true; this.pos = pos; this._orden("pausa", true); this._cambio();
        return this._aviso("Este vídeo no consigue seguir cargando: pulsa ▶ para intentarlo otra vez");
      }
      const s = LENTOS[k - 1];
      apuntar(`«${titulo}» falla tras 3 reintentos en ${pos.toFixed(0)} s: NO paso al siguiente; intento lento ${k}/${LENTOS.length} en ${s} s`);
      this._aviso(`El vídeo se ha cortado: lo vuelvo a intentar en ${s} s, en el mismo punto`);
      this._t_lento = setTimeout(() => {
        this._t_lento = 0;
        if (this.actual !== e) return;
        if (this.pausa) { this._atascado = true; return; }   // lo ha pausado él: ▶ lo vuelve a intentar
        this._sano = 0; this._quieto = 0;
        this._cargar(pos, true, true);
      }, s * 1000);
    }
    _informe_calidad() {   // 19/10/2026: cada minuto sonando, calidad y fotogramas perdidos a catode.log. Su vídeo de las 10:01
      // en el mini PC iba a tirones (gráfica frenada por calor) y el registro no dejó rastro: solo veía los parones.
      const m = this.ultimo;
      if (!m || !this.actual || this.pausa || this.congelado || !this._arrancado) { this._cal = null; return; }
      const drop = Number(m.drop) || 0, tot = Number(m.tot) || 0, antes = this._cal;
      this._cal = {drop, tot};
      if (!antes || tot < antes.tot) return;   // primera vez o vídeo nuevo (los contadores vuelven a cero)
      const d = drop - antes.drop, t = tot - antes.tot;
      if (t <= 0) return;
      const pct = 100 * d / t;
      apuntar(`calidad: ${m.alto || "?"}p · ${(t / 60).toFixed(0)} fps · ${d} de ${t} fotogramas perdidos (${pct.toFixed(1)} %)${pct > 2 ? " · TIRONES" : ""}`);
    }
    _sin_abasto() {   // parado con 3 s o más ya bajados (HLS): un escalón menos de calidad en vez de recargar (ver ESCALONES)
      const m = this.ultimo || {}, ya = Number(m.delante) || 0;
      if (this.tipo !== "hls" || ya < 3) return false;
      // 21/10/2026 (medido en el mini PC el 19/10, 16:09-16:14): parado, el <video> no manda estado nuevo y aquí se decidía
      // 31 veces seguidas con el MISMO estado («98.1 s ya bajados»): bajaba sin parar y la recarga no llegaba nunca. Con el
      // mismo estado de la vez anterior no se decide otra vez: sigue la recarga de siempre (ya a la calidad rebajada).
      if (this._abasto_visto === this.ultimo) return false;
      this._abasto_visto = this.ultimo;
      const ahora = Number(m.alto) || 1080, siguiente = ESCALONES.find((a) => a < ahora);
      if (!siguiente) return false;   // ya en lo más bajo: se recarga como siempre
      gestor.topeCarga = {alto: siguiente, hasta: performance.now() + 15 * 60 * 1000};
      // 22/10/2026 (3.6): se dice (aviso y selector) y, pasados los 15 min, vuelve sola a la calidad de antes
      this._aviso(`El equipo no da abasto con ${ahora}p: ${siguiente}p durante 15 min`);
      clearTimeout(gestor._t_tope);
      gestor._t_tope = setTimeout(() => { for (const r of gestor.lista) if (r.actual) { r._orden("calidad", r._altoIframe()); r._cambio(); } }, 15 * 60 * 1000 + 1000);
      apuntar(`parado en ${this.pos.toFixed(0)} s con ${ya.toFixed(1)} s ya bajados: el equipo no da abasto con ${ahora}p (no es la red ni YouTube) → ${siguiente}p durante 15 min · ${(m.notas || []).slice(-3).join(" | ")}`);
      this._orden("calidad", this._altoIframe());
      this._cambio();
      return true;
    }
    _mirar_parado() {   // vigilante (cada 2 s): suena, no avanza en 8 s (4 s tras un salto) → recarga en el mismo punto
      const activo = this.actual && !this.pausa && !this.congelado && this._arrancado && this.ultimo && !this.ultimo.idle;
      if (activo && Math.abs(this.pos - this._ult) < 0.1) {
        this._quieto += 2;
        const limite = performance.now() - this._salto < 30000 ? 4 : 8;
        if (this._quieto >= limite && this._sin_abasto()) { this._quieto = 0; this._ult = this.pos; return; }
        if (this._quieto >= limite) { apuntar(`parado ${limite} s en ${this.pos.toFixed(0)} s: recargo · ${((this.ultimo && this.ultimo.notas) || []).slice(-4).join(" | ")}`); this._quieto = 0; this._ult = this.pos; this._reintentar(); return; }   // 07/10/2026: un tropiezo, UN reintento (no también el de «sin imagen 20 s»)
      } else {
        this._quieto = 0;
        // 06/10/2026: el contador de reintentos NUNCA volvía a cero: en un vídeo largo, el cuarto tropiezo suelto lo paraba
        // para siempre. Con 30 s sonando y avanzando, el vídeo está sano y los reintentos empiezan de nuevo.
        if (activo) {
          this._sano = (this._sano || 0) + 2;
          if (this._sano >= 30 && (this._reintentos[this.actual.url] || this._lentos[this.actual.url])) {
            this._reintentos[this.actual.url] = 0; this._lentos[this.actual.url] = 0; this._error_visto = false;
          }
        }
      }
      this._ult = this.pos;
      // sin el primer fotograma en 20 s desde «cargar» (manifiesto o nivel con 403, dirección caducada): reintento
      if (this.actual && !this.pausa && !this.congelado && !this._arrancado && !this._resolviendo && this._t_cargar &&
          performance.now() - this._t_cargar > 20000) {
        this._t_cargar = 0;
        apuntar(`sin imagen 20 s después de cargar: reintento`);
        this._reintentar();
      }
    }

    precalentar(elementos) {   // deja resueltos (por detrás) los primeros vídeos de una página
      const lista = (elementos || []).filter((e) => e && e.tipo === "VIDEO" && String(e.url || "").startsWith("http")).slice(0, 4);
      (async () => {
        for (const e of lista) {
          try { await api(`/api/resolver?url=${encodeURIComponent(e.url)}&alto=${this.alto()}&fondo=1`); } catch (err) { /* da igual */ }
        }
      })();
    }
    _adelantar() {   // el siguiente de la cola, resuelto para que empiece sin esperar
      const e = this.cola[this.i + 1];
      if (e && String(e.url || "").startsWith("http") && !this._locales[e.url])
        api(`/api/resolver?url=${encodeURIComponent(e.url)}&alto=${this.alto()}&fondo=1`).catch(() => {});
    }

    _no_se_puede(aviso) {
      registro(`no se puede: «${this.actual ? (this.actual.titulo || "").slice(0, 50) : ""}» · ${aviso}`);
      this._orden("parar");
      if (this.i + 1 < this.cola.length) {
        this._aviso(aviso + ": paso al siguiente");
        this.i += 1; this._elegido = false;
        this._cargar();
      } else if (this._elegido) {
        this._aviso(aviso); this.pausa = true; this._cambio();
      } else {
        this._aviso(aviso);
        if (this.actual) this._pide_mas(this.actual);
      }
    }
    _al_acabar() {
      // 15/10/2026 «youtube me salta los vídeos a mitad de vídeo y me pasa al siguiente» (en el Dell, sin rastro en el
      // registro): cada paso automático al siguiente queda apuntado con dónde iba, para ver la causa la próxima vez
      const total = this.dur > 0 ? this.dur : Number(this.actual && this.actual.duracion) || 0;
      const visto = Math.max(this.pos || 0, this._pos_antes || 0, this._pos_bueno || 0);
      // 19/10/2026 «los vídeos siguen interrumpiéndose a veces y pasa a otro»: en el mini PC, un vídeo de 11 h «acabó» a las
      // 4 h 15 min (18/10 21:09) y uno de 167 s a los 5 s (19/10 11:11), y Cat-ode pasó al siguiente. Como en Linux
      // (reproductor.py «final falso»): si acaba lejos del final, se sigue en el último segundo bueno (_reintentar, 3 como
      // mucho; después, «no se puede» de siempre)
      const local = this.actual && this._locales[this.actual.url];
      if (this.actual && !this.bucle_activo && !this.directo && !local && total > 30 && visto < total - 10) {
        const m = this.ultimo || {};
        apuntar(`final falso en ${visto.toFixed(0)} s de ${total.toFixed(0)} s (d ${Number(m.d || 0).toFixed(0)}, rs ${m.rs}, ns ${m.ns}, ` +
                `delante ${m.delante}, err ${m.err || "-"}, ${m.ct || ""} ${m.src || ""}): sigo en ese punto`);
        this.pos = visto;
        return this._reintentar();
      }
      apuntar(`acabado en ${visto.toFixed(0)} s de ${total.toFixed(0)} s (arrancado ${this._arrancado}, recargando ${this._recargando}) → lo siguiente`);
      if (this.bucle_activo) return this._cargar(0, false);
      if (this._parar_al_acabar) {
        this._parar_al_acabar = false;
        this.pausa = true; this._orden("pausa", true); this._cambio();
        return this._aviso("Temporizador: parado al acabar el vídeo");
      }
      if (this.i + 1 < this.cola.length) { this.i += 1; this._elegido = false; this._cargar(); }
      else if (this.actual) this._pide_mas(this.actual);
    }
    _pide_mas(ultimo) {   // la cola se acabó: reproducción automática (interfaz.py _automatica 3949), salvo que alguien la haga
      const ev = this._emitir("pide_mas", ultimo, true);
      if (!ev.defaultPrevented) this._automatica(ultimo);
    }
    async _automatica(ultimo) {
      if (this.ajustes.automatica === false) return;
      try {
        const [rel, hist] = await Promise.all([
          api("/api/video/relacionados?automatica=1&url=" + encodeURIComponent(ultimo.url)),
          gestor._historial(),
        ]);
        if (this.actual !== ultimo) return;   // mientras, el autor ha puesto otro
        const vistos = new Set([...hist, ...this.cola.map((e) => idVideo(e.url))]);
        const lista = (rel && rel.elementos) || [];   // ya vienen sin ocultos ni vetados (servicio.relacionados)
        // 22/10/2026 (encargo 3.8): el servicio elige OTRA canción (cancion.py: nunca la misma en otra subida ni lo ya sonado)
        const enCola = new Set(this.cola.map((e) => idVideo(e.url)));
        const sig = (rel && rel.siguiente && !enCola.has(idVideo(rel.siguiente.url)) ? rel.siguiente : null)
          || lista.find((e) => e.tipo === "VIDEO" && !vistos.has(idVideo(e.url))) || lista[0];
        if (sig) registro(`automática: «${String(ultimo.titulo || "").slice(0, 40)}» → «${String(sig.titulo || "").slice(0, 40)}»`);
        if (sig) { this.encolar(sig); this.siguiente("reproducción automática"); }
      } catch (err) { registro("automática: " + err); }
    }

    reproducir(e, desde) {
      this._elegido = true;
      this.cola = [e]; this.i = 0;
      return this._cargar(desde === undefined ? null : desde);
    }
    encolar(e) {
      if (!this.actual || !this.cola.length) return this.reproducir(e);
      this.cola.push(e);
      if (this.cola.length === this.i + 2) this._adelantar();
      this._cambio();
    }
    insertar_siguiente(e) {   // «Reproducir a continuación»
      if (!this.actual || !this.cola.length) return this.reproducir(e);
      this.cola.splice(this.i + 1, 0, e);
      this._adelantar();
      this._cambio();
    }
    todo(lista, aleatorio) {
      const videos = (lista || []).filter((e) => e && e.tipo === "VIDEO");
      if (aleatorio) for (let k = videos.length - 1; k > 0; k--) { const j = Math.floor(Math.random() * (k + 1)); [videos[k], videos[j]] = [videos[j], videos[k]]; }
      if (!videos.length) return;
      this._elegido = true;
      this.cola = videos; this.i = 0;
      return this._cargar(null);
    }
    saltar_a(i) {
      if (i >= 0 && i < this.cola.length) { this.i = i; this._elegido = true; return this._cargar(null); }
    }
    mover_en_cola(de, a) {   // la cola arrastrable (M7): mueve sin cortar lo que suena
      if (de < 0 || de >= this.cola.length || a < 0 || a >= this.cola.length || de === a) return;
      const actual = this.cola[this.i];
      const [x] = this.cola.splice(de, 1); this.cola.splice(a, 0, x);
      this.i = this.cola.indexOf(actual);
      this._cambio();
    }
    quitar_de_cola(i) {
      if (i < 0 || i >= this.cola.length || i === this.i) return;
      this.cola.splice(i, 1);
      if (i < this.i) this.i -= 1;
      this._cambio();
    }

    // ---- mandos ----
    alternar() {
      if (this.congelado) return this._descongelar(false);
      if (this._atascado && this.pausa && this.actual) {   // 21/10/2026: quieto tras los intentos lentos: ▶ lo intenta otra vez
        const u = this.actual.url;
        this._atascado = false; this._reintentos[u] = 0; this._lentos[u] = 0; this.pausa = false;
        apuntar(`▶ tras quedarse quieto en ${this.pos.toFixed(0)} s: lo intento otra vez`);
        return this._cargar(Math.max(0, this.pos), true, true);
      }
      this.pausa = !this.pausa; this._orden("alternar"); this._cambio();
    }
    pausar(p) { this.pausa = !!p; this._orden("pausa", !!p); this._cambio(); }
    siguiente(origen) {
      // 21/10/2026: todo paso al siguiente a mitad de un vídeo queda en catode.log con quién lo pidió (antes, el del botón,
      // las teclas multimedia o los auriculares no dejaba rastro y no se podía saber si era un salto solo o una pulsación)
      if (this.actual && this.dur > 30 && this.pos > 5 && this.pos < this.dur - 10)
        apuntar(`siguiente a mitad de «${(this.actual.titulo || "").slice(0, 50)}» (${this.pos.toFixed(0)} de ${this.dur.toFixed(0)} s), pedido por: ${origen || "botón o atajo de Cat-ode"}`);
      if (this.i + 1 < this.cola.length) { this.i += 1; this._elegido = true; this._cargar(null); }
      else if (this.actual) this._pide_mas(this.actual);
    }
    anterior() {
      if (this.pos > 5 || this.i <= 0) this.ir_a(0);
      else { this.i -= 1; this._elegido = true; this._cargar(null); }
    }
    ir_a(s) {
      this.pos = Math.max(0, Number(s) || 0);
      this._salto = performance.now();
      if (this.congelado) { this.congelado.pos = this.pos; this._cambio(); return; }
      this._fin_visto = false;
      this._orden("saltar", this.pos, "absolute");
      this._cambio();
    }
    ir_al_directo() { if (this.dur) this.ir_a(Math.max(0, this.dur - 3)); }
    mover(s) {
      const destino = Math.max(0, this.pos + (Number(s) || 0));
      this.ir_a(this.dur ? Math.min(destino, Math.max(0, this.dur - 0.5)) : destino);
    }
    paso(n) { if (this.pausa) this.ir_a(this.pos + n / 30); }   // , y . con pausa: un fotograma
    silencio() { this.mute = !this.mute; this._orden("silencio", this.mute); this._cambio(); return this.mute; }
    volumen(v) {
      v = Math.max(0, Math.min(130, Math.round(Number(v) || 0)));
      this.vol = v; this.ajustes.volumen = v;
      if (this.mute && v > 0) { this.mute = false; this._orden("silencio", false); }
      this._orden("volumen", v);
      for (const r of gestor.lista) if (r !== this) { r.vol = v; r._orden("volumen", v); }   // el volumen es de la app
      gestor.guardar_ajustes({volumen: v});
      this._emitir("volumen_cambia", v);
      this._cambio();
    }
    velocidad(r) {
      r = Math.round(Math.min(3, Math.max(0.25, Number(r) || 1)) * 100) / 100;
      this.vel = r; this._orden("velocidad", r); this._cambio();
    }
    solo_sonido(si) { this.solo = !!si; this._orden("soloSonido", this.solo); this._cambio(); }
    de_fondo(si) {   // pestaña que no se ve y sigue sonando: a 360p (§1.6)
      si = !!si;
      if (si === this.fondo) return;
      this.fondo = si; this._orden("calidad", this._altoIframe());
    }
    calidad(alto) {   // «auto» o una altura; con HLS lo cambia Edge en el sitio; un archivo remoto se vuelve a resolver
      this.ajustes.calidad = alto === "auto" ? "auto" : parseInt(alto, 10);
      gestor.guardar_ajustes({calidad: this.ajustes.calidad});
      registro(`calidad elegida: ${alto}`);
      if (this.tipo === "hls" || !this.actual) this._orden("calidad", this._altoIframe());
      else if (this.tipo === "archivo" && /^https?:/.test(this.fuente || "") && !/^https?:\/\/127\.0\.0\.1/.test(this.fuente)) this._cargar(this.pos, true);
      this._cambio();
    }
    poner_alto_auto(alto) { this.alto_auto = alto; }   // con Edge la calidad la fija la página: no se recarga nada
    calidad_vista() {   // 22/10/2026 (3.6): la calidad que se ve de verdad y, si no es la elegida, por qué
      const c = this.ajustes.calidad || "auto", visto = Number(this.ultimo && this.ultimo.alto) || 0;
      const tope = gestor.topeCarga, rebajada = !!tope.alto && performance.now() < tope.hasta && visto > 0 && visto <= tope.alto;
      if (this.solo) return {alto: visto, motivo: "solo sonido"};
      if (this.fondo) return {alto: visto, motivo: "pestaña de fondo"};
      if (c === "auto") return {alto: visto, motivo: rebajada ? "el equipo no da abasto" : ""};
      const pedido = parseInt(c, 10) || 0;
      if (!visto || visto === pedido) return {alto: visto || pedido, motivo: ""};
      if (rebajada && pedido > tope.alto) return {alto: visto, motivo: "el equipo no da abasto"};
      return {alto: visto, motivo: visto < pedido ? `este vídeo no tiene ${pedido}p` : `este vídeo no baja de ${visto}p`};
    }
    subtitulos() { return this.subs.map((s) => ({id: s.id, nombre: s.nombre})); }
    poner_subtitulos(sid) {
      this._sid = sid || null;
      this._orden("verSubtitulo", sid ? String(sid) : "0");
      this.subs_activos = !!sid; this.ajustes.subtitulos = this.subs_activos;
      gestor.guardar_ajustes({subtitulos: this.subs_activos});
      this._cambio();
    }
    alternar_subtitulos() {   // la tecla C y el botón CC (interfaz.py _alternar_subtitulos 2365)
      if (!this.subs.length) return this._aviso("Este vídeo no tiene subtítulos");
      if (!this._sid) { this.poner_subtitulos(this.subs[0].id); this._aviso(`Subtítulos: ${this.subs[0].nombre}`); }
      else { this.poner_subtitulos(null); this._aviso("Subtítulos desactivados"); }
    }
    bucle(si) { this.bucle_activo = !!si; this._orden("bucle", this.bucle_activo); this._cambio(); }
    apagar_en(minutos) {   // pausa dentro de «minutos» (0 lo quita; -1, al acabar este vídeo)
      if (this._apagado) { clearTimeout(this._apagado); this._apagado = null; }
      this._parar_al_acabar = minutos === -1;
      this.apagado_hora = null;
      if (minutos > 0) {
        this.apagado_hora = Date.now() + minutos * 60000;
        this._apagado = setTimeout(() => { this._apagado = null; this.apagado_hora = null; this.pausar(true); this._aviso("Temporizador: pausado"); }, minutos * 60000);
        this._aviso(`Se pausará dentro de ${minutos >= 1 ? Math.round(minutos) + " min" : Math.round(minutos * 60) + " s"}`);
      } else if (minutos === -1) this._aviso("Se parará al acabar este vídeo");
    }
    reproducir_local(ruta, e) { this._locales[e.url] = ruta; return this.reproducir(e); }   // un vídeo descargado: sin red
    parar() {
      this._guardar_posicion();
      this._turno += 1;
      this.cola = []; this.i = -1; this.actual = null; this.congelado = null; this.pausa = true; this.pos = 0; this.dur = 0;
      this._orden("parar");
      gestor._vive(this);
      this._cambio();
    }
    cerrar() {
      this._guardar_posicion(true);
      this._turno += 1;
      if (this._apagado) clearTimeout(this._apagado);
      this.cola = []; this.i = -1; this.actual = null; this.congelado = null; this.pausa = true; this._t_cargar = 0;
      this.cerrado = true;
      porVentana.delete(this.iframe.contentWindow);
      this.iframe.remove();
      if (this.zona && this.zona.classList.contains("rep-zona") && !this.zona.children.length) this.zona.remove();
      gestor._quitar(this);
    }
    pip() { this._orden("pip"); }

    // ---- posición (cada 5 s, al cambiar de vídeo, al parar y al cerrar) ----
    _guardar_posicion(alCerrar) {
      const e = this.actual;
      // 24/10/2026: un directo no guarda posición, pero la actualización tiene que saber que suena (VentanaWeb.
      // reiniciar_cuando_libre): al publicar la 1.2.18 se reinició la tele a mitad del directo de gatos que veía Nut
      if (e && this.directo && !this.pausa && !alCerrar) { api("/api/sonando", {}).catch(() => {}); return; }
      if (!e || !this.dur || this.pos <= 5 || this.directo || !String(e.url || "").startsWith("http")) return;
      if (this._guardada.url === e.url && Math.abs(this._guardada.seg - this.pos) < 1) return;
      this._guardada = {url: e.url, seg: this.pos};
      return api("/api/posicion", {url: e.url, seg: Math.round(this.pos * 10) / 10, dur: Math.round(this.dur * 10) / 10}, {keepalive: !!alCerrar}).catch(() => {});
    }

    // ---- tope de vídeos vivos (§1.6): congelar conserva la posición y para; al volver, recarga ahí ----
    _congelar() {
      if (!this.actual || this.congelado) return;
      this._guardar_posicion();
      this.congelado = {pos: this.pos, pausa: this.pausa};
      this._turno += 1;
      this._orden("parar");
      this.pausa = true;
      registro(`congelado «${(this.actual.titulo || "").slice(0, 40)}» en ${this.pos.toFixed(0)} s`);
      this._cambio();
    }
    _descongelar(conservarPausa) {
      const c = this.congelado;
      if (!c) return;
      this._pausar_al_cargar = conservarPausa !== false && c.pausa;
      this._cargar(c.pos, true);
    }
  }

  function pestanaActiva() {
    const P = window.catode && window.catode.pestanas;
    try { return P && typeof P.activa === "function" ? P.activa() : null; } catch (e) { return null; }
  }
  function pestanaVista(rep) { const pa = pestanaActiva(); return !pa ? !rep._segundo : rep._pestana === pa; }

  // ------------------------------------------------------------------ el gestor: todos los reproductores de la página
  const gestor = {
    lista: [],
    orden: [],   // del más reciente al más antiguo (activar)
    activo: null,
    topeCarga: {alto: 0, hasta: 0},   // 19/10/2026: calidad rebajada porque el equipo no daba abasto (_sin_abasto)
    ajustes: {volumen: 80, calidad: "auto", automatica: true, patrocinios: true, reanudar: true, subtitulos: false},
    tope: 2,
    crear(zona, ajustes) {
      const r = new Reproductor(zona, ajustes);
      this.lista.push(r);
      return r;   // no se activa aquí: lo activa su pestaña si es la que se ve (de_pestana) o el getter sin pestañas
    },
    _caps: new Map(),   // capítulos por vídeo (los trae la ficha: pagina_video.js → poner_capitulos)
    poner_capitulos(url, caps) {   // [[seg, nombre]]: marcas en la barra roja y «· capítulo» junto al tiempo
      const id = idVideo(url);
      if (!id) return;
      const lista = (caps || []).map((c) => [Number(c[0]) || 0, String(c[1] || "")]);
      this._caps.delete(id); this._caps.set(id, lista);
      if (this._caps.size > 50) this._caps.delete(this._caps.keys().next().value);
      for (const r of this.lista) if (r.actual && idVideo(r.actual.url) === id) { r.capitulos = lista; r._cambio(); }
    },
    desactivar() {   // la pestaña que se ve no tiene reproductor: ninguno manda (el que sonaba sigue, a 360p)
      if (!this.activo) return;
      this._manda(null, "pestaña sin vídeo");
      this.activo = null;
      this._repartir();
      window.dispatchEvent(new CustomEvent("catode:rep", {detail: null}));
    },
    vista() {   // el que se enseña (mini, capa): el de la pestaña activa si tiene vídeo; si no, el que suena. Sin crear
      const pa = pestanaActiva();
      const propio = pa && !pa._cerrando ? pa.rep : null;
      if (propio && propio.actual) return propio;
      if (this.activo && this.activo.actual) return this.activo;
      return this.orden.find((r) => r.actual && !r.congelado && !r._segundo) || propio || null;
    },
    prematuros: 0,   // avisos sin «tipo» llegados de un iframe aún no listo (la consola del about:blank): ya no cuentan
    porque: "", cambios: [],   // diagnóstico: por qué manda el que manda (las 6 últimas decisiones, con la hora)
    _manda(rep, motivo) {
      this.porque = motivo;
      this.cambios.push(`${Math.round(performance.now() / 100) / 10}s ${motivo}→${rep ? (rep._segundo ? "segundo" : rep._pestana ? "pestaña " + rep._pestana.id : "suelto") : "nadie"}`);
      if (this.cambios.length > 6) this.cambios.shift();
    },
    activar(rep, motivo) {   // la pestaña que se ve: la suya suena entera, la anterior a 360p y las demás congeladas
      if (!rep) return;
      const cambia = this.activo !== rep;
      if (cambia) this._manda(rep, motivo || "activar");
      this.activo = rep;
      this.orden = [rep, ...this.orden.filter((r) => r !== rep && this.lista.includes(r))];
      this._repartir();
      if (cambia) window.dispatchEvent(new CustomEvent("catode:rep", {detail: rep}));   // mandos y barra cambian de reproductor
    },
    _vive(rep) {   // un reproductor empieza o para: se revisa el tope sin cambiar cuál se ve; el que empieza a sonar fuera
      // del tope (una pestaña nueva que suena antes de activarse) pasa justo detrás del activo
      const k = this.orden.indexOf(rep);
      if (rep.actual && !rep.congelado && (k < 0 || k >= this.tope)) {
        if (k >= 0) this.orden.splice(k, 1);
        this.orden.splice(this.activo && this.activo !== rep ? 1 : 0, 0, rep);
        if (!this.activo && pestanaVista(rep)) { this._manda(rep, "suena en la pestaña que se ve"); this.activo = rep; window.dispatchEvent(new CustomEvent("catode:rep", {detail: rep})); }
      } else if (k < 0) this.orden.push(rep);
      this._repartir();
    },
    _repartir() {
      let vivos = 0;
      for (const r of this.orden) {
        if (!r.actual) { r.de_fondo(false); continue; }
        if (r === this.activo) { r.de_fondo(false); if (r.congelado) r._descongelar(true); vivos++; continue; }
        if (vivos < this.tope && !r.congelado) { r.de_fondo(true); vivos++; }
        else if (!r.congelado) r._congelar();
      }
    },
    _quitar(rep) {
      this.lista = this.lista.filter((r) => r !== rep);
      this.orden = this.orden.filter((r) => r !== rep);
      if (this.activo === rep) {   // el de la pestaña que se ve (si tiene); nunca el de una oculta ni el segundo vídeo
        const pa = pestanaActiva();
        this.activo = pa && pa.rep && pa.rep !== rep && !pa._cerrando ? pa.rep : null;
        this._manda(this.activo, "cerrado el que mandaba");
        window.dispatchEvent(new CustomEvent("catode:rep", {detail: this.activo}));
      }
      this._repartir();
    },
    guardar_todo() { return Promise.all(this.lista.map((r) => r._guardar_posicion(true))); },
    tecla_multimedia(nombre) {
      const r = this.activo && this.activo.actual ? this.activo : this.lista.find((x) => x.actual && !x.pausa);
      if (!r) return;
      if (nombre === "play") r.alternar();
      else if (nombre === "pausa") r.pausar(true);
      else if (nombre === "siguiente") r.siguiente("tecla multimedia (ventana)");
      else if (nombre === "anterior") r.anterior();
      else if (nombre === "parar") r.pausar(true);
    },
    _guardarT: null, _guardarDatos: {},
    guardar_ajustes(cambios) {   // al servidor (escritorio-ajustes.json), en un solo PUT tras 1 s sin cambios
      Object.assign(this._guardarDatos, cambios);
      clearTimeout(this._guardarT);
      this._guardarT = setTimeout(() => {
        const d = this._guardarDatos; this._guardarDatos = {};
        api("/api/ajustes", d, {metodo: "PUT"}).catch(() => {});
      }, 1000);
    },
    _hist: null, _histT: 0,
    async _historial() {   // ids de lo visto (para que la automática no repita), 5 min de caché
      if (this._hist && performance.now() - this._histT < 300000) return this._hist;
      try {
        const h = await api("/api/pagina/historial");
        this._hist = new Set(((h && h.elementos) || []).slice(0, 300).map((e) => idVideo(e.url)));
        this._histT = performance.now();
      } catch (e) { this._hist = new Set(); }
      return this._hist;
    },
    avisar(t) {   // avisos.js (M4) si está; si no, un aviso propio de 3,5 s
      if (window.catode && typeof window.catode.avisar === "function") return window.catode.avisar(t);
      let caja = document.getElementById("rep-aviso");
      if (!caja) { caja = document.createElement("div"); caja.id = "rep-aviso"; caja.setAttribute("role", "status"); document.body.appendChild(caja); }
      caja.textContent = t; caja.classList.add("visible");
      clearTimeout(this._avisoT);
      this._avisoT = setTimeout(() => caja.classList.remove("visible"), 3500);
    },
    async cargar_ajustes() {
      try { const r = await api("/api/ajustes"); if (r && r.ajustes) Object.assign(this.ajustes, r.ajustes); } catch (e) { /* los de serie */ }
      for (const r of this.lista) { r.vol = Number(this.ajustes.volumen ?? r.vol); r.subs_activos = !!this.ajustes.subtitulos; }
      return this.ajustes;
    },
  };

  // un solo reloj de 1 s para la posición (cada 5 s) y el vigilante de parados (cada 2 s)
  let tic = 0;
  setInterval(() => {
    tic++;
    for (const r of gestor.lista) {
      if (tic % 2 === 0) r._mirar_parado();
      if (tic % 5 === 0 && r.actual && !r.congelado) r._guardar_posicion();
      if (tic % 60 === 0) r._informe_calidad();
    }
  }, 1000);
  window.addEventListener("pagehide", () => { gestor.guardar_todo(); });

  // ------------------------------------------------------------------ enganche con el marco (M4: app.js / pestanas.js)
  // Una pestaña = un reproductor (p.rep), creado al pedirlo. Su zona es un <div class="rep-zona"> en <body>: quien lo
  // enseñe (M7) lo coloca con CSS (position fixed + left/top/width/height); nunca se cambia de padre (recargaría el iframe).
  // 06/10/2026 (perfil de uso, N100): un reproductor DE RESERVA con su iframe ya cargado (y hls.js evaluado), fuera de la
  // vista y fuera de gestor.lista. La pestaña que abre un vídeo se lo queda (solo cambia de clase: el iframe no se mueve y
  // no se recarga) y no espera a crear el marco (≈ 0,4 s del clic al vídeo en el N100). Se rehace en un hueco, al rato.
  gestor._reserva = null;
  gestor._relojReserva = 0;
  gestor.prepararReserva = function (ms) {
    if (this._reserva || this._relojReserva || !document.body) return;
    const hacer = () => {
      this._relojReserva = 0;
      if (this._reserva) return;
      const z = document.createElement("div");
      z.className = "rep-zona rep-reserva";
      document.body.appendChild(z);
      this._reserva = new Reproductor(z);
    };
    this._relojReserva = setTimeout(() => { if (window.requestIdleCallback) requestIdleCallback(hacer, {timeout: 4000}); else hacer(); },
      ms === undefined ? 2500 : ms);
  };
  gestor._tomarReserva = function (p) {
    const r = this._reserva;
    if (!r || r.cerrado || !r.iframe.isConnected) { this._reserva = null; return null; }
    this._reserva = null;
    r.ajustes = this.ajustes;
    r.vol = Number(this.ajustes.volumen ?? r.vol); r.subs_activos = !!this.ajustes.subtitulos;
    r.zona.classList.remove("rep-reserva");
    r.zona.classList.add("rep-de-pestana"); r.zona.dataset.pestana = p.id;
    this.lista.push(r);
    this.prepararReserva(3000);   // la siguiente, cuando haya hueco y no encima del arranque de este vídeo
    return r;
  };
  gestor.de_pestana = function (p) {
    if (!p) return this.activo || this.crear();
    if (!p.rep) {
      p.rep = this._tomarReserva(p);
      if (!p.rep) {
        const z = document.createElement("div");
        z.className = "rep-zona rep-de-pestana"; z.dataset.pestana = p.id;
        document.body.appendChild(z);
        p.rep = this.crear(z);
        this.prepararReserva(3000);
      }
      p.rep._pestana = p;
      let antes = "";
      p.rep.on("cambio", () => {   // pestanas.marcar(p, {suena, mute}): el altavoz de la pestaña
        const ahora = (p.rep.actual && !p.rep.pausa ? 1 : 0) + ":" + (p.rep.mute ? 1 : 0);
        if (ahora === antes) return;
        antes = ahora;
        const P = window.catode && window.catode.pestanas;
        if (P && typeof P.marcar === "function") { try { P.marcar(p, {suena: !!(p.rep.actual && !p.rep.pausa), mute: p.rep.mute}); } catch (e) { /* nada */ } }
      });
      if (pestanaActiva() === p) this.activar(p.rep, "reproductor nuevo en la pestaña que se ve");   // manda en mandos, teclado y calidad
    }
    return p.rep;
  };
  function engancharMarco() {
    const app = window.app;
    if (!app || typeof app.on !== "function" || gestor._marco) return;
    gestor._marco = true;
    const P = () => window.catode && window.catode.pestanas;
    app.on("pestana:cambia", (d) => { const p = d && d.p; if (p && p.rep) gestor.activar(p.rep, "cambio de pestaña"); else if (p) gestor.desactivar(); });
    app.on("pestana:cierra", (p) => {
      if (!p) return;
      const P2 = P(), ultima = P2 && P2.lista && P2.lista.length === 1;
      if (!ultima) p._cerrando = true;   // hasta que salga de la lista: nadie le crea un reproductor nuevo
      if (p.rep) { const r = p.rep; p.rep = null; r.cerrar(); }
    });
    app.ganchos = app.ganchos || {};
    if (typeof app.ganchos.silenciar !== "function") app.ganchos.silenciar = (p) => (p && p.rep ? p.rep.silencio() : !p.mute);
    if (typeof app.ganchos.guardar !== "function") app.ganchos.guardar = () => gestor.guardar_todo();
    if (typeof app.ganchos.multimedia !== "function") app.ganchos.multimedia = (nombre) => { gestor.tecla_multimedia(nombre); return true; };
    if (typeof app.ganchos.reproducir !== "function") app.ganchos.reproducir = (e, desde) => window.catode.reproductor.reproducir(e, desde);
    app.teclado = app.teclado || {};
    if (typeof app.teclado.rep !== "function") app.teclado.rep = () => gestor.vista();
    // un enlace (Ctrl+V, minuto de un comentario) al vídeo que ya suena: solo salta, sin recargar ni vaciar la cola (3051)
    if (typeof app.ganchos.saltarSiSuena !== "function") app.ganchos.saltarSiSuena = (url, t) => {
      const r = gestor.vista();
      if (!r || !r.actual || !url || idVideo(r.actual.url) !== idVideo(url)) return false;
      r.ir_a(Number(t) || 0);
      if (r.pausa && !r.congelado) r.pausar(false);
      return true;
    };
    const pa = P() && P().activa && P().activa();
    if (pa && pa.rep) gestor.activar(pa.rep);
  }
  // catode.reproductor: el de la pestaña activa (lo crea al pedirlo). Lo usan M5 (tarjeta.js) y M7.
  Object.defineProperty(window.catode = window.catode || {}, "reproductor", {
    configurable: true, enumerable: true,
    get() {
      const P = window.catode.pestanas;
      const p = P && typeof P.activa === "function" ? P.activa() : null;
      if (p && !p._cerrando) return gestor.de_pestana(p);
      if (p) return gestor.activo;   // la pestaña se está cerrando: no se le crea otro (quedaría huérfano)
      if (gestor.activo) return gestor.activo;
      const r = gestor.crear(); gestor.activar(r); return r;
    },
    set(v) { registro("catode.reproductor lo da reproductor.js: no se sustituye"); },
  });

  Reproductor.gestor = gestor;
  Reproductor.api = api;
  Reproductor.tiempo = tiempo;
  Reproductor.idVideo = idVideo;
  Reproductor.pintarPronto = pintarPronto;
  Reproductor.apuntar = apuntar;   // 07/10/2026: los gestos del autor (doble clic, pantalla completa), a catode.log
  window.Reproductor = Reproductor;
  window.catode.reproductores = gestor;
  engancharMarco();
  if (!gestor._marco) document.addEventListener("DOMContentLoaded", engancharMarco);
  gestor.cargar_ajustes();
  // la primera reserva, cuando el arranque ya ha pintado (app «listo» + un rato y un hueco)
  if (window.app && typeof window.app.on === "function") { try { window.app.on("listo", () => gestor.prepararReserva(2500)); } catch (e) { gestor.prepararReserva(4000); } }
  else gestor.prepararReserva(4000);
})();
