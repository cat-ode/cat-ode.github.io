// Cat-ode escritorio · interfaz web: avisos y progreso de descargas (módulo M4; interfaz.py 2161 «avisar» y la QProgressBar
// de la statusBar). catode.avisos.avisar(texto, ms=3500) enseña el aviso abajo a la izquierda 3,5 s (el último manda);
// catode.avisos.descarga({id, fraccion, texto, hecho, ruta}) mueve la barra de descargas (evento SSE «descarga», §2.4).
// En pantalla completa no se ven (como la statusBar oculta de la Qt).
"use strict";
(function () {
  const C = window.catode = window.catode || {};
  let reloj = null;
  const descargas = new Map();   // id → {fraccion, texto}
  const historial = [];          // los últimos 50 avisos (para las pruebas y el registro)

  function caja() { return document.getElementById("aviso"); }

  function avisar(texto, ms) {
    texto = String(texto == null ? "" : texto);
    if (!texto) return;
    historial.push({texto, h: Date.now()});
    if (historial.length > 50) historial.shift();
    const el = caja();
    if (!el) return;
    el.textContent = texto;
    el.classList.add("visible");
    clearTimeout(reloj);
    reloj = setTimeout(() => { el.classList.remove("visible"); }, ms || 3500);
  }

  function pintarDescargas() {
    const p = document.getElementById("progreso");
    if (!p) return;
    const vivas = [...descargas.values()];
    if (!vivas.length) { p.hidden = true; return; }
    const media = vivas.reduce((s, d) => s + (d.fraccion || 0), 0) / vivas.length;
    p.hidden = false;
    p.querySelector(".progreso-texto").textContent = vivas.length > 1
      ? `Descargando ${vivas.length} vídeos · ${Math.round(media * 100)} %`
      : `${vivas[0].texto || "Descargando…"} · ${Math.round(media * 100)} %`;
    p.querySelector(".progreso-relleno").style.width = (media * 100).toFixed(1) + "%";
  }

  function descarga(d) {
    if (!d || d.id == null) return;
    if (d.hecho) {
      const antes = descargas.get(d.id);
      descargas.delete(d.id);
      avisar(d.ruta ? `Descargado: ${(antes && antes.texto) || d.texto || ""}` : `No se pudo descargar: ${d.texto || ""}`);
    } else {
      descargas.set(d.id, {fraccion: Math.max(0, Math.min(1, +d.fraccion || 0)), texto: d.texto || ""});
    }
    pintarDescargas();
  }

  C.avisos = {avisar, descarga, historial, descargas};
})();
