// Cat-ode escritorio · interfaz web · módulo M5 (DISENO_WEB.md §3), 06/10/2026.
// previa.js: la vista previa al posar (PreviaTarjeta, interfaz.py 1524-1657). Tras 900 ms con el ratón quieto sobre una
// tarjeta de VÍDEO, el vídeo sin sonido a 360p encima de su miniatura. UN solo iframe opaco reutilizado (el mismo
// reproductor.html del §2.5, sandbox sin allow-same-origin): se carga una vez y luego solo recibe «cargar»/«parar».
// No recibe el ratón (pointer-events: none): los clics siguen siendo de la tarjeta (abrir; central = pestaña nueva).
// Se para al salir de la tarjeta, al hacer scroll, al cambiar de página y con ajustes.vista_previa = false.
"use strict";
(function () {
  const M5 = window.M5;
  const Previa = window.Previa = {RETARDO: 900};
  let marco = null, listo = false, colaListo = [];
  let reloj = 0, tarjeta = null, controlador = null, activa = false, ajusteLeido = null;
  Previa.estado = {cargas: 0, ultima: null, ultimoEstado: null};

  function crearMarco() {
    if (marco) return marco;
    marco = document.createElement("iframe");
    marco.className = "m5-previa";
    marco.setAttribute("sandbox", "allow-scripts");
    marco.setAttribute("allow", "autoplay");
    marco.setAttribute("referrerpolicy", "no-referrer");
    marco.setAttribute("tabindex", "-1");
    marco.setAttribute("aria-hidden", "true");
    marco.title = "Vista previa";
    marco.src = M5.base() + "/reproductor.html";
    document.body.appendChild(marco);
    return marco;
  }
  window.addEventListener("message", (ev) => {
    if (!marco || ev.source !== marco.contentWindow || !ev.data) return;
    if (ev.data.tipo === "listo") { listo = true; const c = colaListo; colaListo = []; c.forEach((f) => f()); }
    else if (ev.data.tipo === "estado") Previa.estado.ultimoEstado = ev.data;
  });
  function orden(f, ...a) {
    const mandar = () => marco && marco.contentWindow && marco.contentWindow.postMessage({f, a}, "*");
    if (listo) mandar(); else colaListo.push(mandar);
  }

  async function permitida() {
    const a = window.app;
    if (a && a.ajustes && a.ajustes.vista_previa !== undefined) return a.ajustes.vista_previa !== false;
    if (ajusteLeido === null) {
      const r = await M5.api("/api/estado");
      ajusteLeido = !(r.ok && r.ajustes && r.ajustes.vista_previa === false);
      setTimeout(() => { ajusteLeido = null; }, 60000);   // si se cambia en Ajustes, vale al minuto
    }
    return ajusteLeido;
  }

  function colocar() {
    if (!tarjeta || !marco) return;
    const img = tarjeta.querySelector(".tj-img");
    const r = (img || tarjeta).getBoundingClientRect();
    const s = marco.style;
    s.left = r.left + "px"; s.top = r.top + "px"; s.width = r.width + "px"; s.height = r.height + "px";
  }

  async function empezar(t) {
    const e = t._e;
    if (!e || e.tipo !== "VIDEO" || !t.isConnected) return;
    if (!(await permitida()) || tarjeta !== t || (window.Menu && window.Menu.abierto())) return;
    if (controlador) controlador.abort();
    controlador = new AbortController();
    const r = await M5.api("/api/resolver?url=" + encodeURIComponent(e.url) + "&alto=360&fondo=1", undefined, {signal: controlador.signal});
    if (tarjeta !== t || !r.ok || !r.fuente) return;
    crearMarco();
    colocar();
    const fuente = new URL(r.fuente, M5.base() + "/").href;   // el iframe es opaco: mejor absoluta
    orden("silencio", true);
    orden("calidad", 360);   // el HLS trae todos los niveles: sin esto el iframe elegía hasta 1080p para una caja de 300 px
    orden("cargar", fuente, r.tipo || "archivo", 0);
    marco.classList.add("visible");
    activa = true;
    Previa.estado.cargas++;
    Previa.estado.ultima = {url: e.url, fuente};
  }

  /** El ratón entra en (o se mueve dentro de) una tarjeta: cuenta 900 ms quieto. */
  Previa.posar = function (t) {
    if (t !== tarjeta) { Previa.salir(); tarjeta = t; }
    if (activa) return;
    clearTimeout(reloj);
    if (window.Menu && window.Menu.abierto()) return;
    if (!t || !t._e || t._e.tipo !== "VIDEO") return;
    reloj = setTimeout(() => empezar(t), Previa.RETARDO);
  };
  /** Fuera de la tarjeta, scroll o cambio de página: se para (stop asíncrono, sin destruir el iframe). */
  Previa.salir = function () {
    clearTimeout(reloj);
    if (controlador) { controlador.abort(); controlador = null; }
    tarjeta = null;
    if (activa) { activa = false; orden("parar"); }
    if (marco) marco.classList.remove("visible");
  };
  Previa.activa = () => activa;
  Previa.marco = () => marco;
  window.addEventListener("blur", () => Previa.salir());
  window.addEventListener("resize", () => Previa.salir());
  document.addEventListener("visibilitychange", () => { if (document.hidden) Previa.salir(); });
})();
