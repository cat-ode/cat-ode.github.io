// Cat-ode escritorio · interfaz web · los mandos sobre el vídeo (módulo M6). 06/10/2026.
// Puerto de ControlesVideo (catode/controles.py 106-443) como capa HTML encima del iframe del reproductor: título (solo en
// pantalla completa), barra roja con la miniatura del momento (storyboard recortado en un <canvas>, VistaPrevia 19-104),
// ⏯ ⏭ 🔊 + volumen 0-130, tiempo o «● EN DIRECTO», capítulo, CC, ⚙ (calidad, velocidad, subtítulos, temporizador,
// repetir, solo sonido), imagen en imagen, cine y pantalla completa. Aparecen al mover el ratón y se funden a los 2,5 s
// (no en pausa, ni con el ratón sobre ellos, ni con un menú abierto); en pantalla completa se esconde el cursor.
// Clic = pausa, doble clic = pantalla completa, rueda = volumen, clic derecho = menú del reproductor.
// Teclas (Mandos.teclado): espacio/K, J/L, ←/→, ↑/↓, M, F, T, I, C, Esc, Inicio/Fin, 0-9, < >, «,» «.», Mayús+N/P.
//
// Uso: const m = new Mandos(zona, {rep: () => repActivo, pantalla, cine, pip, menu_compartir})
//   zona = el contenedor del iframe (position: relative). Las opciones son funciones; las que falten hacen lo de serie
//   (pantalla completa: /api/ventana + clase «completa» en <body>; cine: clase «cine» en <body>; pip: la del navegador).
//   Mandos.teclado({rep, mini, ...}) engancha las teclas en document (respeta ev.defaultPrevented y los campos de texto).
//   Mandos.menu(items, x, y) / Mandos.VistaPrevia: los usa también barra.js.
"use strict";
(function () {
  const R = window.Reproductor;
  const tiempo = R.tiempo;
  const api = R.api;

  // la hoja de estilos de los mandos y la barra, con el mismo ?v= que este script (caché de Edge, §1.3)
  (function () {
    const v = document.currentScript ? new URL(document.currentScript.src).search : "";
    if (!document.querySelector('link[data-cat="mandos"]')) {
      const l = document.createElement("link");
      l.rel = "stylesheet"; l.href = "css/mandos.css" + v; l.dataset.cat = "mandos";
      document.head.appendChild(l);
    }
  })();

  // ------------------------------------------------------------------ iconos (trazos de 24×24)
  const TRAZOS = {
    play: "M8 5v14l11-7z",
    pausa: "M6 19h4V5H6v14zm8-14v14h4V5h-4z",
    siguiente: "M6 18l8.5-6L6 6v12zM16 6v12h2V6h-2z",
    anterior: "M6 6h2v12H6zm3.5 6l8.5 6V6z",
    volumen: "M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z",
    silencio: "M16.5 12c0-1.77-1.02-3.29-2.5-4.03v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51C20.63 14.91 21 13.5 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06c1.38-.31 2.63-.95 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z",
    subtitulos: "M19 4H5c-1.11 0-2 .9-2 2v12c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm-8 7H9.5v-.5h-2v3h2V13H11v1c0 .55-.45 1-1 1H7c-.55 0-1-.45-1-1v-4c0-.55.45-1 1-1h3c.55 0 1 .45 1 1v1zm7 0h-1.5v-.5h-2v3h2V13H18v1c0 .55-.45 1-1 1h-3c-.55 0-1-.45-1-1v-4c0-.55.45-1 1-1h3c.55 0 1 .45 1 1v1z",
    ajustes: "M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58a.49.49 0 0 0 .12-.61l-1.92-3.32a.49.49 0 0 0-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54a.48.48 0 0 0-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96a.49.49 0 0 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58a.49.49 0 0 0-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z",
    pip: "M19 11h-8v6h8v-6zm4 8V4.98C23 3.88 22.1 3 21 3H3c-1.1 0-2 .88-2 1.98V19c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2zm-2 .02H3V4.97h18v14.05z",
    cine: "M19 6H5c-1.1 0-2 .9-2 2v8c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm0 10H5V8h14v8z",
    completa: "M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z",
    cerrar_completa: "M5 16h3v3h2v-5H5v2zm3-8H5v2h5V5H8v3zm6 11h2v-3h3v-2h-5v5zm2-11V5h-2v5h5V8h-3z",
  };
  const icono = (n) => `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="${TRAZOS[n] || ""}"/></svg>`;

  function el(etiqueta, clase, html) {
    const x = document.createElement(etiqueta);
    if (clase) x.className = clase;
    if (html !== undefined) x.innerHTML = html;
    return x;
  }
  function boton(clase, nombre, ayuda, accion) {
    const b = el("button", "cm-boton " + clase, icono(nombre));
    b.type = "button"; b.title = ayuda; b.setAttribute("aria-label", ayuda); b.tabIndex = -1;
    b.dataset.icono = nombre;
    b.addEventListener("click", (ev) => { ev.stopPropagation(); accion(ev, b); });
    return b;
  }
  function ponerIcono(b, nombre) { if (b.dataset.icono !== nombre) { b.dataset.icono = nombre; b.innerHTML = icono(nombre); } }

  // ------------------------------------------------------------------ menú emergente (también lo usa la barra)
  let menuAbierto = null, menuCerradoEn = 0;
  function cerrarMenu() {
    if (!menuAbierto) return;
    menuCerradoEn = performance.now();   // el clic que cierra un menú no pausa el vídeo de debajo
    menuAbierto.caja.remove();
    document.removeEventListener("pointerdown", menuAbierto.fuera, true);
    document.removeEventListener("keydown", menuAbierto.tecla, true);
    const f = menuAbierto.alCerrar; menuAbierto = null;
    if (f) f();
  }
  // items: [{texto, marcado, accion, sub: () => items, desactivado, separador, valor}]; ancla: {x, y} o un elemento
  function menu(items, ancla, opciones) {
    cerrarMenu();
    const o = opciones || {};
    const caja = el("div", "cm-menu");
    caja.setAttribute("role", "menu");
    const pila = [];
    function pintar(lista, titulo) {
      caja.innerHTML = "";
      if (titulo) {
        const t = el("button", "cm-menu-titulo", "‹  " + titulo);
        t.type = "button";
        t.addEventListener("click", (ev) => { ev.stopPropagation(); const [l, ti] = pila.pop(); pintar(l, ti); });
        caja.appendChild(t);
      }
      for (const it of lista) {
        if (!it) continue;
        if (it.separador) { caja.appendChild(el("div", "cm-menu-sep")); continue; }
        const b = el("button", "cm-menu-item" + (it.desactivado ? " desactivado" : ""));
        b.type = "button"; b.setAttribute("role", it.marcado !== undefined ? "menuitemcheckbox" : "menuitem");
        if (it.marcado !== undefined) b.setAttribute("aria-checked", it.marcado ? "true" : "false");
        b.appendChild(el("span", "cm-menu-marca", it.marcado ? "✓" : ""));
        const tx = el("span", "cm-menu-texto"); tx.textContent = it.texto; b.appendChild(tx);
        if (it.valor) { const v = el("span", "cm-menu-valor"); v.textContent = it.valor; b.appendChild(v); }
        if (it.sub) b.appendChild(el("span", "cm-menu-flecha", "›"));
        b.disabled = !!it.desactivado;
        b.addEventListener("click", (ev) => {
          ev.stopPropagation();
          if (it.sub) { pila.push([lista, titulo]); pintar(it.sub(), it.texto); colocar(); return; }
          cerrarMenu();
          if (it.accion) it.accion();
        });
        caja.appendChild(b);
      }
    }
    pintar(items, o.titulo);
    (o.dentro || document.body).appendChild(caja);
    function colocar() {
      const w = caja.offsetWidth, h = caja.offsetHeight;
      let x, y;
      if (ancla instanceof Element) {
        const r = ancla.getBoundingClientRect();
        x = o.derecha ? r.right - w : r.left; y = r.top - h - 6;
        if (y < 4) y = r.bottom + 6;
      } else { x = ancla.x; y = ancla.y; if (y + h > innerHeight - 4) y = Math.max(4, ancla.y - h); }
      x = Math.max(4, Math.min(x, innerWidth - w - 4)); y = Math.max(4, Math.min(y, innerHeight - h - 4));
      caja.style.left = x + "px"; caja.style.top = y + "px";
    }
    colocar();
    const fuera = (ev) => { if (!caja.contains(ev.target)) cerrarMenu(); };
    const tecla = (ev) => { if (ev.key === "Escape") { ev.preventDefault(); ev.stopPropagation(); cerrarMenu(); } };
    setTimeout(() => {
      if (!menuAbierto || menuAbierto.caja !== caja) return;
      document.addEventListener("pointerdown", fuera, true);
      document.addEventListener("keydown", tecla, true);
    }, 0);
    menuAbierto = {caja, fuera, tecla, alCerrar: o.alCerrar};
    const primero = caja.querySelector(".cm-menu-item:not(.desactivado)");
    if (primero) primero.focus({preventScroll: true});
    return caja;
  }

  // los menús del reproductor (Barra._menu_* de interfaz.py 1300-1350), compartidos por mandos, barra y clic derecho
  const VELOCIDADES = [0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2, 3];
  const nombreVel = (x) => x === 1 ? "Normal" : `${String(x).replace(".", ",")}×`;
  // 22/10/2026 (encargo 3.6): lo que dice el selector es lo que se ve; si no es lo elegido, con el porqué
  function valorCalidad(rep) {
    const c = rep.ajustes.calidad || "auto", cv = rep.calidad_vista ? rep.calidad_vista() : {alto: 0, motivo: ""};
    if (c === "auto") return `Automática${cv.alto ? ` (${cv.alto}p${cv.motivo ? ", " + cv.motivo : ""})` : ""}`;
    return cv.alto && cv.motivo ? `${cv.alto}p (${cv.motivo})` : `${c}p`;
  }
  const menus = {
    velocidad: (rep) => VELOCIDADES.map((x) => ({texto: nombreVel(x), marcado: Math.abs(rep.vel - x) < 0.01, accion: () => rep.velocidad(x)})),
    subtitulos: (rep) => {
      const l = [{texto: "Desactivados", marcado: !rep._sid, accion: () => rep.poner_subtitulos(null)}];
      for (const s of rep.subtitulos()) l.push({texto: s.nombre, marcado: rep._sid === s.id, accion: () => rep.poner_subtitulos(s.id)});
      if (l.length === 1) l.push({texto: "Este vídeo no tiene subtítulos", desactivado: true});
      return l;
    },
    calidad: (rep) => {   // 22/10/2026 (3.6): solo las calidades que tiene este vídeo, y cuál se ve de verdad
      const actual = rep.ajustes.calidad || "auto", cv = rep.calidad_vista ? rep.calidad_vista() : {alto: 0, motivo: ""};
      const hay = (rep.ultimo && rep.ultimo.niveles && rep.ultimo.niveles.length) ? rep.ultimo.niveles : [144, 240, 360, 480, 720, 1080, 1440, 2160];
      const l = [{texto: `Automática (la mayor que quepa, hasta 1080p)` + (actual === "auto" && cv.alto ? ` · se ve ${cv.alto}p` : ""), marcado: actual === "auto", accion: () => rep.calidad("auto")}, {separador: true}];
      if (actual !== "auto" && !hay.includes(Number(actual)))
        l.push({texto: `${actual}p · este vídeo no la tiene${cv.alto ? `: se ve ${cv.alto}p` : ""}`, marcado: true, desactivado: true});
      for (const a of hay)
        l.push({texto: `${a}p` + (a === 2160 ? " (4K)" : a >= 720 ? " HD" : "") + (cv.alto === a && cv.motivo ? ` · se ve ahora (${cv.motivo})` : ""), marcado: Number(actual) === a, accion: () => rep.calidad(a)});
      return l;
    },
    apagado: (rep) => [
      ...[10, 15, 30, 45, 60, 90].map((x) => ({texto: `Dentro de ${x} min`, accion: () => rep.apagar_en(x)})),
      {texto: "Al acabar este vídeo", marcado: rep._parar_al_acabar, accion: () => rep.apagar_en(-1)},
      {separador: true},
      {texto: "Quitar el temporizador", accion: () => { rep.apagar_en(0); R.gestor.avisar("Temporizador quitado"); }},
    ],
    cola: (rep, alGuardar) => {
      const l = rep.cola.length ? rep.cola.map((e, i) => ({texto: (i === rep.i ? "▶ " : `${i + 1}. `) + String(e.titulo || "").slice(0, 70), accion: () => rep.saltar_a(i)}))
        : [{texto: "La cola está vacía", desactivado: true}];
      if (rep.cola.length > 1) l.push({separador: true}, {texto: "Guardar la cola como lista…", accion: () => (alGuardar || guardarCola)(rep)});
      return l;
    },
    ajustes: (rep) => {   // la rueda de YouTube (ControlesVideo._ajustes 415)
      const c = rep.ajustes.calidad || "auto";
      const l = [
        {texto: "Calidad", valor: valorCalidad(rep), sub: () => menus.calidad(rep)},
        {texto: "Velocidad", valor: nombreVel(rep.vel), sub: () => menus.velocidad(rep)},
        {texto: "Subtítulos", valor: rep._sid ? (rep.subs.find((s) => s.id === rep._sid) || {}).nombre || "Sí" : "No", sub: () => menus.subtitulos(rep)},
        {texto: "Temporizador de apagado", valor: rep.apagado_hora ? `${Math.max(1, Math.round((rep.apagado_hora - Date.now()) / 60000))} min` : (rep._parar_al_acabar ? "Al acabar" : ""), sub: () => menus.apagado(rep)},
        {texto: "Repetir este vídeo", marcado: rep.bucle_activo, accion: () => rep.bucle(!rep.bucle_activo)},
        {texto: "Solo sonido (sin imagen)", marcado: rep.solo, accion: () => rep.solo_sonido(!rep.solo)},
      ];
      const so = (window.app && window.app.so) || (window.app && window.app.estado && window.app.estado.so) || "";
      if (/win|nt/i.test(so)) {   // Windows: no mandar la imagen al escritorio remoto (F9)
        const A = window.app || {};
        const ap = typeof A.remotoApagado === "function" ? A.remotoApagado() : !!rep.ajustes.apagar_remoto;
        l.push({texto: "Apagar el remoto (no enviar la imagen a Moonlight)  ·  F9", marcado: ap,
          accion: () => api("/api/remoto", {apagar: !ap}).then((r) => {
            if (typeof A.ponerRemoto === "function") A.ponerRemoto(r && typeof r.apagado === "boolean" ? r.apagado : !ap);
            else rep.ajustes.apagar_remoto = !ap;
          }).catch(() => {})});
      }
      return l;
    },
  };
  async function guardarCola(rep) {
    const pedir = window.catode && window.catode.preguntar;
    const nombre = pedir ? await pedir("Nombre de la lista", "Cola de reproducción") : window.prompt("Nombre de la lista", "Cola de reproducción");
    if (!nombre) return;
    const r = await api("/api/datos", {accion: "lista", que: "guardar_cola", nombre, elementos: rep.cola}).catch((e) => ({ok: false, error: String(e)}));
    R.gestor.avisar(r && r.ok ? `Cola guardada en «${nombre}»` : (r && r.error) || "No se ha podido guardar la cola");
  }

  // ------------------------------------------------------------------ la miniatura del momento (storyboard)
  const mosaicos = new Map();   // url → Image (compartido entre mandos y barra)
  function mosaico(url, alLlegar) {
    let im = mosaicos.get(url);
    if (im) return im.complete && im.naturalWidth ? im : null;
    if (mosaicos.size > 400) mosaicos.clear();
    im = new Image();
    im.decoding = "async"; im.referrerPolicy = "no-referrer";
    im.onload = () => alLlegar && alLlegar(url);
    im.src = url;
    mosaicos.set(url, im);
    return null;
  }
  class VistaPrevia {
    constructor() {
      this.caja = el("div", "cm-vista");
      this.lienzo = el("canvas"); this.lienzo.width = 240; this.lienzo.height = 135;
      this.hora = el("div", "cm-vista-hora");
      this.caja.append(this.lienzo, this.hora);
      document.body.appendChild(this.caja);
      this.clave = null;
    }
    mostrar(rep, frac, x, yArriba) {   // x en la pantalla; yArriba = borde de arriba de la barra
      const dur = rep.dur || 0;
      if (!dur) return this.ocultar();
      const t = Math.max(0, Math.min(dur, frac * dur));
      this.hora.textContent = tiempo(t);
      const sb = rep.storyboard;
      const conImagen = !!(sb && sb.mosaicos && sb.mosaicos.length);
      this.caja.classList.toggle("solo-hora", !conImagen);
      if (conImagen) {
        const idx = Math.floor(t / Math.max(sb.paso || 1, 0.1));
        const por = (sb.filas || 1) * (sb.columnas || 1);
        const m = Math.min(Math.floor(idx / por), sb.mosaicos.length - 1);
        const celda = idx % por;
        const url = sb.mosaicos[m];
        this.clave = [url, celda, sb];
        this._pintar(url, celda, sb);
      }
      const w = this.caja.offsetWidth || 244, h = this.caja.offsetHeight || 159;
      this.caja.style.left = Math.max(4, Math.min(innerWidth - w - 4, x - w / 2)) + "px";
      this.caja.style.top = Math.max(4, yArriba - h - 12) + "px";
      this.caja.classList.add("visible");
    }
    _pintar(url, celda, sb) {
      const c = this.lienzo.getContext("2d");
      const im = mosaico(url, (u) => { if (this.clave && this.clave[0] === u) this._pintar(...this.clave); });
      if (!im) { c.fillStyle = "#000"; c.fillRect(0, 0, 240, 135); return; }
      const col = celda % sb.columnas, fila = Math.floor(celda / sb.columnas);
      try { c.drawImage(im, col * sb.ancho, fila * sb.alto, sb.ancho, sb.alto, 0, 0, 240, 135); } catch (e) { /* imagen rota */ }
    }
    ocultar() { this.caja.classList.remove("visible"); this.clave = null; }
  }

  // ------------------------------------------------------------------ barra de posición (roja) y volumen
  class BarraPosicion {
    constructor(obtenerRep, vista) {
      this.rep = obtenerRep; this.vista = vista;
      this.caja = el("div", "cm-posicion");
      this.caja.setAttribute("role", "slider"); this.caja.setAttribute("aria-label", "Posición del vídeo");
      this.pista = el("div", "cm-pista");
      this.hecho = el("div", "cm-hecho");
      this.bola = el("div", "cm-bola");
      this.marcas = el("div", "cm-marcas");   // capítulos y tramos saltados
      this.pista.append(this.marcas, this.hecho);
      this.caja.append(this.pista, this.bola);
      this.arrastrando = false; this.frac = 0; this._marcasDe = null;
      const frac = (ev) => { const r = this.pista.getBoundingClientRect(); return Math.max(0, Math.min(1, (ev.clientX - r.left) / Math.max(1, r.width))); };
      this.caja.addEventListener("pointerdown", (ev) => {
        if (ev.button !== 0) return;
        ev.stopPropagation(); ev.preventDefault();
        this.arrastrando = true; this.caja.setPointerCapture(ev.pointerId);
        this.poner(frac(ev));
      });
      this.caja.addEventListener("pointermove", (ev) => {
        const f = frac(ev); const r = this.pista.getBoundingClientRect();
        this.vista.mostrar(this.rep(), f, ev.clientX, r.top);
        if (this.arrastrando) this.poner(f);
      });
      const soltar = (ev) => {
        if (!this.arrastrando) return;
        this.arrastrando = false;
        const rep = this.rep();
        if (rep && rep.dur) rep.ir_a(frac(ev) * rep.dur);
      };
      this.caja.addEventListener("pointerup", soltar);
      this.caja.addEventListener("pointercancel", () => { this.arrastrando = false; });
      this.caja.addEventListener("pointerleave", () => { if (!this.arrastrando) this.vista.ocultar(); });
      this.caja.addEventListener("click", (ev) => ev.stopPropagation());
      this.caja.addEventListener("dblclick", (ev) => ev.stopPropagation());
    }
    poner(f) {
      this.frac = f;
      this.hecho.style.transform = `scaleX(${f})`;
      this.bola.style.left = (f * 100) + "%";
    }
    refrescar(rep) {
      if (!this.arrastrando) this.poner(rep.dur ? Math.min(1, rep.pos / rep.dur) : 0);
      const clave = rep.dur && (rep.actual ? rep.actual.url : "") + rep.dur + ":" + rep.capitulos.length + ":" + rep.tramos.length;
      if (clave !== this._marcasDe) {   // las separaciones de capítulos y los tramos de SponsorBlock, una vez por vídeo
        this._marcasDe = clave; this.marcas.innerHTML = "";
        if (rep.dur) {
          for (const [s] of rep.capitulos || []) if (s > 0) { const m = el("i", "cm-cap"); m.style.left = (s / rep.dur * 100) + "%"; this.marcas.appendChild(m); }
          for (const [a, b] of rep.tramos || []) { const m = el("i", "cm-tramo"); m.style.left = (a / rep.dur * 100) + "%"; m.style.width = ((b - a) / rep.dur * 100) + "%"; this.marcas.appendChild(m); }
        }
      }
      this.caja.setAttribute("aria-valuetext", `${tiempo(rep.pos)} de ${tiempo(rep.dur)}`);
    }
  }
  function deslizadorVolumen(obtenerRep) {
    const r = el("input", "cm-volumen");
    r.type = "range"; r.min = 0; r.max = 130; r.step = 1; r.tabIndex = -1; r.title = "Volumen (↑/↓, rueda)";
    r.setAttribute("aria-label", "Volumen");
    r.addEventListener("input", () => { const rep = obtenerRep(); if (rep) rep.volumen(Number(r.value)); });
    r.addEventListener("click", (ev) => ev.stopPropagation());
    r.addEventListener("pointerdown", (ev) => ev.stopPropagation());
    r.refrescar = (rep) => {
      if (document.activeElement !== r && Number(r.value) !== rep.vol) r.value = rep.vol;
      r.style.setProperty("--lleno", (rep.vol / 130 * 100) + "%");
      r.classList.toggle("alto", rep.vol > 100);
    };
    return r;
  }
  const capituloEn = (rep) => { let n = ""; for (const [s, nombre] of rep.capitulos || []) if (s <= rep.pos) n = nombre; return n; };
  const esCompleta = () => !!document.fullscreenElement || document.body.classList.contains("completa");

  // lo de serie de pantalla completa, cine e imagen en imagen (M7 los sustituye con sus opciones)
  const DE_SERIE = {
    pantalla() {
      const ir = !esCompleta();
      document.body.classList.toggle("completa", ir);
      api("/api/ventana", {accion: ir ? "completa" : "normal"}).catch(() => {});
    },
    cine() { document.body.classList.toggle("cine"); },
    pip(rep) {   // la del navegador, dentro del iframe; si el navegador lo niega (sin gesto en el iframe), la ventana
      rep.pip();
      api("/api/ventana", {accion: "pip"}).catch(() => {});
    },
  };

  // ------------------------------------------------------------------ los mandos
  class Mandos {
    constructor(zona, opciones) {
      this.o = Object.assign({}, opciones || {});
      this.zona = zona;
      this.rep = this.o.rep || (() => (R.gestor.vista ? R.gestor.vista() : R.gestor.activo));
      this.visibles = true; this._alfa = 1;
      const capa = this.capa = el("div", "cm-capa");
      capa.tabIndex = -1;
      const fondo = this.fondo = el("div", "cm-capa-fondo");
      this.titulo = el("div", "cm-titulo");
      this.abajo = el("div", "cm-abajo");
      this.vista = new VistaPrevia();
      this.posicion = new BarraPosicion(this.rep, this.vista);
      const fila = el("div", "cm-fila");
      const r = () => this.rep();
      this.play = boton("cm-play", "pausa", "Pausa / seguir (k)", () => r() && r().alternar());
      this.sig = boton("", "siguiente", "Siguiente (Mayús+N)", () => r() && r().siguiente());
      this.mute = boton("", "volumen", "Silenciar (m)", () => r() && r().silencio());
      this.vol = deslizadorVolumen(r);
      this.tiempo = el("span", "cm-tiempo"); this.tiempo.textContent = "0:00 / 0:00";
      this.vivo = el("button", "cm-vivo"); this.vivo.type = "button"; this.vivo.tabIndex = -1; this.vivo.title = "Ir al momento actual del directo";
      this.vivo.addEventListener("click", (ev) => { ev.stopPropagation(); r() && r().ir_al_directo(); });
      this.capitulo = el("span", "cm-capitulo");
      this.cc = boton("cm-cc", "subtitulos", "Subtítulos (c)", () => r() && r().alternar_subtitulos());
      this.ajustes = boton("", "ajustes", "Ajustes: calidad, velocidad, subtítulos, temporizador", (ev, b) => this.abrir_ajustes(b));
      this.bpip = boton("", "pip", "Imagen en imagen (i)", () => this.accion("pip"));
      this.bcine = boton("", "cine", "Modo cine (t)", () => this.accion("cine"));
      this.completa = boton("", "completa", "Pantalla completa (f)", () => this.accion("pantalla"));
      const hueco = el("span", "cm-hueco");
      fila.append(this.play, this.sig, this.mute, this.vol, this.tiempo, this.vivo, this.capitulo, hueco, this.cc, this.ajustes, this.bpip, this.bcine, this.completa);
      this.abajo.append(this.posicion.caja, fila);
      capa.append(fondo, this.titulo, this.abajo);
      zona.appendChild(capa);

      // ratón: clic = pausa, doble clic = pantalla completa (deshace la pausa del primer clic), rueda = volumen, derecho = menú
      // (en el DOM llegan clic, clic y dblclick: el segundo clic no cuenta y el dblclick deshace la pausa del primero, como la Qt)
      fondo.addEventListener("click", (ev) => { this.mostrar(); if (ev.detail <= 1 && performance.now() - menuCerradoEn > 400) r() && r().alternar(); });
      fondo.addEventListener("dblclick", () => { try { R.apuntar(`doble clic sobre la capa de mandos · vídeo=${!!(r() && r().actual)}`); } catch (e) {} r() && r().alternar(); this.accion("pantalla"); });   // 07/10/2026: rastro en catode.log
      capa.addEventListener("contextmenu", (ev) => { ev.preventDefault(); this.mostrar(); this.menu_reproductor({x: ev.clientX, y: ev.clientY}); });
      capa.addEventListener("wheel", (ev) => {
        ev.preventDefault();
        const rep = r(); if (!rep) return;
        this.mostrar();
        rep.volumen(Math.max(0, Math.min(130, rep.vol + (ev.deltaY < 0 ? 5 : -5))));
      }, {passive: false});
      let ultimo = [0, 0];
      capa.addEventListener("pointermove", (ev) => {
        if (Math.abs(ev.clientX - ultimo[0]) + Math.abs(ev.clientY - ultimo[1]) > 2) { ultimo = [ev.clientX, ev.clientY]; this.mostrar(); }
      });
      capa.addEventListener("pointerleave", () => { const rep = r(); if (rep && !rep.pausa) this._programar(800); });
      this._ocultarT = null;
      this._oyente = () => R.pintarPronto(this._pintar);
      this._pintar = () => this.refrescar();
      this._repDe = null;
      this.enganchar();
      document.addEventListener("fullscreenchange", this._oyente);
      window.addEventListener("catode:rep", this._oyente);   // el gestor cambia de reproductor activo
      this.mostrar();
    }
    enganchar() {   // escucha al reproductor de la pestaña activa (cambia con las pestañas)
      const rep = this.rep();
      if (rep === this._repDe) return;
      if (this._repDe) this._repDe.removeEventListener("cambio", this._oyente);
      this._repDe = rep;
      if (rep) rep.addEventListener("cambio", this._oyente);
      this._oyente();
    }
    accion(nombre) {
      const rep = this.rep();
      const f = this.o[nombre];
      if (typeof f === "function") f(rep); else DE_SERIE[nombre](rep);
      R.pintarPronto(this._pintar);
    }
    mostrar() {
      if (!this.visibles) {
        this.visibles = true;
        this.capa.classList.remove("oculta");
        this.capa.classList.remove("cursor-oculto");
      }
      this._programar(2500);
    }
    _programar(ms) { clearTimeout(this._ocultarT); this._ocultarT = setTimeout(() => this._ocultar_si_toca(), ms); }
    _ocultar_si_toca() {
      const rep = this.rep();
      // 06/10/2026 (orden del autor: «nadie quiere ver un vídeo a pantalla completa con los controles a la vista»): en
      // pantalla completa se ocultan a los 2,5 s SIN MOVER el ratón, esté donde esté (antes, con el ratón quieto encima de
      // la barra —donde queda tras pulsar ⛶ o cualquier mando— no se ocultaban nunca). En ventana, sobre la barra se quedan.
      const arrastrando = !!(this.posicion && this.posicion.arrastrando);
      if (!rep || rep.pausa || menuAbierto || arrastrando || (!esCompleta() && this.abajo.matches(":hover"))) return this._programar(2500);
      this.visibles = false;
      this.capa.classList.add("oculta");
      this.capa.classList.toggle("cursor-oculto", esCompleta());   // el cursor, a la vez (refrescar() lo hacía al siguiente cambio)
    }
    refrescar() {
      this.enganchar();
      const rep = this.rep();
      const hay = !!(rep && rep.actual) && (typeof this.o.visible !== "function" || !!this.o.visible(rep));
      this.capa.classList.toggle("sin-video", !hay);
      if (!hay) return;
      const completa = esCompleta();
      this.capa.classList.toggle("en-completa", completa);
      const t = rep.actual.titulo || "";
      if (this.titulo.textContent !== t) this.titulo.textContent = t;
      const n = rep.pausa ? "play" : "pausa";
      if (this.play.dataset.icono !== n) { ponerIcono(this.play, n); if (rep.pausa) this.mostrar(); }
      ponerIcono(this.completa, completa ? "cerrar_completa" : "completa");
      this.completa.title = completa ? "Salir de pantalla completa (Esc)" : "Pantalla completa (f)";
      ponerIcono(this.mute, rep.mute || rep.vol === 0 ? "silencio" : "volumen");
      this.vol.refrescar(rep);
      this.tiempo.hidden = rep.directo; this.vivo.hidden = !rep.directo;
      if (rep.directo) {
        const atras = Math.max(0, (rep.dur || 0) - rep.pos), alDia = atras < 20;
        this.vivo.textContent = "●  EN DIRECTO" + (alDia ? "" : `   −${tiempo(atras)}`);
        this.vivo.classList.toggle("al-dia", alDia);
      } else {
        const tx = `${tiempo(rep.pos)} / ${tiempo(rep.dur)}`;
        if (this.tiempo.textContent !== tx) this.tiempo.textContent = tx;
      }
      const cap = capituloEn(rep);
      const ct = cap ? `·  ${cap}` : "";
      if (this.capitulo.textContent !== ct) this.capitulo.textContent = ct;
      this.posicion.refrescar(rep);
      this.cc.classList.toggle("activo", !!rep._sid);
      this.capa.classList.toggle("cursor-oculto", completa && !this.visibles);
      this.capa.classList.toggle("pip-armado", !!rep.pip_armado);   // el clic sobre el vídeo va al iframe (gesto para el PiP)
      this.bpip.classList.toggle("activo", !!rep.pip_activa);
    }
    abrir_ajustes(b) {
      const rep = this.rep(); if (!rep) return;
      clearTimeout(this._ocultarT);
      menu(menus.ajustes(rep), b, {derecha: true, dentro: this.zona.ownerDocument.fullscreenElement || document.body, alCerrar: () => this._programar(2500)});
    }
    menu_reproductor(punto) {   // clic derecho sobre el vídeo (interfaz.py _menu_video_reproductor 3972)
      const rep = this.rep(); if (!rep || !rep.actual) return;
      clearTimeout(this._ocultarT);
      const items = [
        {texto: "⏸  Pausa / seguir  (espacio)", accion: () => rep.alternar()},
        {texto: esCompleta() ? "⛶  Salir de pantalla completa  (Esc)" : "⛶  Pantalla completa  (F)", accion: () => this.accion("pantalla")},
        {texto: "⏱  Velocidad", sub: () => menus.velocidad(rep)},
        {texto: "⚙  Calidad", sub: () => menus.calidad(rep)},
        {texto: "CC  Subtítulos", sub: () => menus.subtitulos(rep)},
        {texto: "🔁  Repetir este vídeo", marcado: rep.bucle_activo, accion: () => rep.bucle(!rep.bucle_activo)},
      ];
      // «Compartir ▸» como en la Qt (pantallas[31]): las opciones de menu_compartir (M5) como submenú
      const compartir = this.o.menu_compartir || (window.catode && window.catode.menu_compartir);
      if (rep.actual && window.Menu && typeof window.Menu.compartir === "function") {
        items.push({separador: true}, {texto: "↗  Compartir", sub: () => window.Menu.compartir(rep.actual, rep.pos)
          .map((o) => (o.sep ? {separador: true} : {texto: o.texto, accion: o.accion}))});
      } else if (compartir && rep.actual) items.push({separador: true}, {texto: "↗  Compartir", accion: () => compartir(rep.actual, rep.pos, punto)});
      menu(items, punto, {dentro: document.fullscreenElement || document.body, alCerrar: () => this._programar(2500)});
    }
    destruir() {
      if (this._repDe) this._repDe.removeEventListener("cambio", this._oyente);
      document.removeEventListener("fullscreenchange", this._oyente);
      window.removeEventListener("catode:rep", this._oyente);
      clearTimeout(this._ocultarT);
      this.capa.remove(); this.vista.caja.remove();
    }
  }

  // ------------------------------------------------------------------ teclas del vídeo (interfaz.py _tecla_video_con 2318)
  // o.rep() → el reproductor que recibe las teclas o null (por defecto, el activo si suena algo); o.mini() → true si solo
  // se ve el minirreproductor (entonces solo espacio, K, M, J, L, Mayús+N/P y Esc); o.pantalla/cine/pip como en Mandos;
  // o.salir_mini() para Esc con el mini.
  function teclado(opciones) {
    const o = Object.assign({}, opciones || {});
    const repDe = o.rep || (() => (R.gestor.vista ? R.gestor.vista() : R.gestor.activo));
    const accion = (n, rep) => { const f = o[n]; if (typeof f === "function") f(rep); else DE_SERIE[n](rep); };
    const oyente = (ev) => {
      if (ev.defaultPrevented || ev.ctrlKey || ev.altKey || ev.metaKey) return;
      const a = document.activeElement;
      // solo un campo de texto se queda las teclas (el deslizador de volumen o una casilla con el foco, no)
      if (a && (a.isContentEditable || /^(TEXTAREA|SELECT)$/.test(a.tagName) ||
        (a.tagName === "INPUT" && /^(text|search|url|email|password|tel|number|)$/i.test(a.getAttribute("type") || "")))) return;
      const rep = repDe();
      if (!rep || !rep.actual) return;
      const k = ev.key, mini = o.mini ? !!o.mini() : false;
      if (mini && !([" ", "k", "K", "m", "M", "j", "J", "l", "L", "N", "P", "Escape"].includes(k))) return;
      const vel = (paso) => { rep.velocidad(rep.vel + paso); R.gestor.avisar(`Velocidad: ${rep.vel === 1 ? "normal" : nombreVel(rep.vel)}`); };
      let hecho = true;
      if (ev.shiftKey && k === "N") rep.siguiente();
      else if (ev.shiftKey && k === "P") rep.anterior();
      else if (/^[0-9]$/.test(k)) { if (rep.dur) rep.ir_a(rep.dur * Number(k) / 10); }
      else switch (k) {
        case " ": case "k": case "K": rep.alternar(); break;
        case "j": case "J": rep.mover(-10); break;
        case "l": case "L": rep.mover(10); break;
        case "ArrowLeft": rep.mover(-5); break;
        case "ArrowRight": rep.mover(5); break;
        case "ArrowUp": rep.volumen(Math.min(130, rep.vol + 5)); break;
        case "ArrowDown": rep.volumen(Math.max(0, rep.vol - 5)); break;
        case "f": case "F": accion("pantalla", rep); break;
        case "t": case "T": accion("cine", rep); break;
        case "i": case "I": accion("pip", rep); break;
        case "m": case "M": rep.silencio(); break;
        case "c": case "C": rep.alternar_subtitulos(); break;
        case "Home": rep.ir_a(0); break;
        case "End": if (rep.dur) rep.ir_a(Math.max(0, rep.dur - 1)); break;
        case ",": rep.paso(-1); break;
        case ".": rep.paso(1); break;
        case "<": vel(-0.25); break;
        case ">": vel(0.25); break;
        case "Escape":
          if (esCompleta()) accion("pantalla", rep);
          else if (mini && o.salir_mini) o.salir_mini(rep);
          else hecho = false;
          break;
        default: hecho = false;
      }
      if (hecho) ev.preventDefault();
    };
    document.addEventListener("keydown", oyente);
    return () => document.removeEventListener("keydown", oyente);
  }

  // ------------------------------------------------------------------ enganche con el marco (M4) y la capa del vídeo (M7)
  // app.teclado.video (contrato de atajos.js): las teclas del vídeo las atiende atajos.js y llama a este adaptador.
  const M7 = () => window.CatodeM7 || {};
  function modoVideo(rep) {
    if (!rep || !rep.actual) return null;
    if (esCompleta()) return "completa";
    const capa = M7().capa;
    if (capa && capa.modo) return ({video: "pagina", shorts: "shorts", mini: "mini", completa: "completa"})[capa.modo] || null;
    return document.body.classList.contains("en-video") ? "pagina" : "mini";
  }
  function adaptadorTeclado() {
    const rep = (R.gestor.vista ? R.gestor.vista() : R.gestor.activo);   // el de la pestaña que se ve o el del mini
    const modo = modoVideo(rep);
    if (!modo) return null;
    const app = window.app || {};
    const g = app.ganchos || {};
    return {
      modo,
      alternar: () => rep.alternar(), mover: (s) => rep.mover(s), irA: (s) => rep.ir_a(s), dur: () => rep.dur, pausado: () => rep.pausa,
      volumen: (d) => rep.volumen(Math.max(0, Math.min(130, rep.vol + d))),
      completa: () => (typeof g.completa === "function" ? g.completa() : DE_SERIE.pantalla(rep)),
      cine: () => (typeof M7().alternarCine === "function" ? M7().alternarCine() : DE_SERIE.cine(rep)),
      pip: () => (typeof M7().pip === "function" ? M7().pip() : DE_SERIE.pip(rep)),
      silencio: () => rep.silencio(), subtitulos: () => rep.alternar_subtitulos(), fotograma: (n) => rep.paso(n),
      velocidad: (d) => { rep.velocidad(rep.vel + d); R.gestor.avisar(`Velocidad: ${rep.vel === 1 ? "normal" : nombreVel(rep.vel)}`); },
      siguiente: () => rep.siguiente(), anterior: () => rep.anterior(), parar: () => rep.parar(),
      escape: () => {
        if (menuAbierto) { cerrarMenu(); return true; }
        if (esCompleta()) { if (typeof g.completa === "function") g.completa(); else DE_SERIE.pantalla(rep); return true; }
        if (typeof g.escape === "function") return g.escape();
        return false;
      },
    };
  }
  // los mandos grandes sobre la capa del vídeo de M7 (#m7-capa), solo en la página del vídeo y en pantalla completa
  function mandosEnCapa() {
    const capa = M7().capa;
    if (!capa || !capa.el || capa.el._mandosM6) return;
    capa.el._mandosM6 = new Mandos(capa.el, {
      rep: () => (R.gestor.vista ? R.gestor.vista() : R.gestor.activo),
      visible: () => capa.modo === "video" || capa.modo === "completa",
      pantalla: () => { const g = (window.app && window.app.ganchos) || {}; if (typeof g.completa === "function") g.completa(); else DE_SERIE.pantalla(); },
      cine: () => (typeof M7().alternarCine === "function" ? M7().alternarCine() : DE_SERIE.cine()),
      pip: (rep) => (typeof M7().pip === "function" ? M7().pip() : DE_SERIE.pip(rep)),
    });
    // 06/10/2026: el clic derecho dentro del iframe del vídeo llega como aviso «menu» (reproductor.js) → el mismo menú
    const app = window.app;
    if (app) { app.ganchos = app.ganchos || {}; app.ganchos.ratonVideo = () => { const m = capa.el._mandosM6; if (m) m.mostrar(); };   // el ratón se movió DENTRO del iframe
      app.ganchos.menuVideo = (p) => { const m = capa.el._mandosM6; if (m) { m.mostrar(); m.menu_reproductor(p); } }; }
  }
  function engancharMarco() {
    const app = window.app;
    if (!app || typeof app.on !== "function" || Mandos._marco) return;
    Mandos._marco = true;
    app.teclado = app.teclado || {};
    if (typeof app.teclado.video !== "function") app.teclado.video = adaptadorTeclado;
    const repintar = () => { mandosEnCapa(); const m = M7().capa && M7().capa.el && M7().capa.el._mandosM6; if (m) m._oyente(); };
    for (const n of ["pagina", "navega", "completa", "pestana:cambia", "listo"]) app.on(n, repintar);
    window.addEventListener("catode:rep", repintar);   // 07/10/2026: también cuando cambia el reproductor activo (red de seguridad)
  }

  Mandos.enCapa = mandosEnCapa;   // 07/10/2026: la capa de M7 lo llama al nacer (ver flotante.js asegurar)
  Mandos.adaptadorTeclado = adaptadorTeclado;
  Mandos.teclado = teclado;
  Mandos.menu = menu;
  Mandos.cerrarMenu = cerrarMenu;
  Mandos.menus = menus;
  Mandos.VistaPrevia = VistaPrevia;
  Mandos.BarraPosicion = BarraPosicion;
  Mandos.deslizadorVolumen = deslizadorVolumen;
  Mandos.icono = icono;
  Mandos.boton = boton;
  Mandos.ponerIcono = ponerIcono;
  Mandos.capituloEn = capituloEn;
  Mandos.esCompleta = esCompleta;
  Mandos.DE_SERIE = DE_SERIE;
  Mandos.valorCalidad = valorCalidad;
  window.Mandos = Mandos;
  engancharMarco();
  if (!Mandos._marco) document.addEventListener("DOMContentLoaded", engancharMarco);
})();
