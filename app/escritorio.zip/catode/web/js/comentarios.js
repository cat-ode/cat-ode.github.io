// Cat-ode escritorio · interfaz web, módulo M7 (06/10/2026): los comentarios de la página del vídeo (interfaz.py 912-961).
// No se cargan solos: botón «Cargar comentarios» → «Más comentarios» (si hay cursor) / «No he podido… · reintentar» /
// «Este vídeo no tiene comentarios». Cada uno: foto redonda 36 px, autor + cuándo, texto con enlaces y minutos que se
// pueden pulsar, pie «Me gusta: n · n respuestas» (desplegables si el servidor manda la lista). Ordenar: relevantes
// (el orden de YouTube), más recientes o más me gusta, sobre lo ya cargado.
//   CatodeM7.comentarios(contenedor, url, {saltar(s, ev)}) → {destruir(), cargar(), n()}
"use strict";
(function () {
  const M7 = window.CatodeM7 = window.CatodeM7 || {};
  const UNIDADES = {segundo: 1, minuto: 60, hora: 3600, "día": 86400, dia: 86400, semana: 604800, mes: 2592000, "año": 31536000, ano: 31536000};
  function antiguedad(cuando) {   // «hace 6 horas» → segundos (para ordenar por recientes)
    const m = /(\d+)\s+([a-zñí]+)/i.exec(String(cuando || ""));
    if (!m) return /editado|ahora/i.test(cuando || "") ? 0 : 1e12;
    const u = m[2].toLowerCase().replace(/s$/, "").replace(/e$/, "");
    const k = Object.keys(UNIDADES).find((x) => u.startsWith(x.slice(0, 3)));
    return Number(m[1]) * (k ? UNIDADES[k] : 1e9);
  }

  M7.comentarios = function (cont, url, op) {
    const U = M7.util, el = U.el;
    op = op || {};
    let lista = [], cursor = null, pidiendo = false, vivo = true, orden = "relevantes";
    const ctl = new AbortController();
    const cab = el("div", {class: "cm-cab"});
    const titulo = el("h3", {class: "cm-titulo", text: "Comentarios"});
    const ordenar = el("select", {class: "cm-orden", "aria-label": "Ordenar comentarios", hidden: true},
      el("option", {value: "relevantes", text: "Más relevantes"}),
      el("option", {value: "recientes", text: "Más recientes"}),
      el("option", {value: "megusta", text: "Más «me gusta»"}));
    cab.append(titulo, ordenar);
    const caja = el("div", {class: "cm-lista"});
    const boton = el("button", {class: "m7-boton cm-boton", text: "Cargar comentarios"});
    const aviso = el("div", {class: "cm-aviso m7-gris", hidden: true});
    const raiz = el("section", {class: "cm"}, cab, caja, aviso, boton);
    cont.textContent = "";
    cont.append(raiz);

    function uno(c) {
      const foto = c.foto ? el("img", {class: "cm-foto", src: c.foto, alt: "", loading: "lazy", decoding: "async"})
        : el("div", {class: "cm-foto cm-inicial", text: (c.autor || "?").replace(/^@/, "").charAt(0).toUpperCase()});
      const texto = el("div", {class: "cm-texto"});
      texto.append(U.enlazar(c.texto || "", op.saltar));
      const pie = el("div", {class: "cm-pie m7-gris"}, el("span", {text: `Me gusta: ${U.corto(c.megusta || 0) || 0}`}));
      const resp = Array.isArray(c.respuestas) ? c.respuestas : null;
      const n = resp ? resp.length : Number(c.respuestas) || 0;
      let hijos = null;
      if (n > 0) {
        if (resp && resp.length) {
          const b = el("button", {class: "cm-resp-boton", text: `▸ ${n} respuesta${n === 1 ? "" : "s"}`});
          hijos = el("div", {class: "cm-respuestas", hidden: true}, resp.map(uno));
          b.addEventListener("click", () => { hijos.hidden = !hijos.hidden; b.textContent = `${hijos.hidden ? "▸" : "▾"} ${n} respuesta${n === 1 ? "" : "s"}`; });
          pie.append(b);
        } else pie.append(el("span", {class: "cm-resp", text: `${n} respuesta${n === 1 ? "" : "s"}`}));
      }
      return el("article", {class: "cm-uno"}, foto,
        el("div", {class: "cm-cuerpo"}, el("div", {class: "cm-autor"}, el("b", {text: c.autor || ""}), " ", el("span", {class: "m7-gris", text: c.cuando || ""})),
          texto, pie, hijos));
    }
    function pintar() {
      const l = lista.slice();
      if (orden === "recientes") l.sort((a, b) => antiguedad(a.cuando) - antiguedad(b.cuando));
      else if (orden === "megusta") l.sort((a, b) => (b.megusta || 0) - (a.megusta || 0));
      caja.textContent = "";
      const f = document.createDocumentFragment();
      l.forEach((c) => f.append(uno(c)));
      caja.append(f);
      ordenar.hidden = lista.length < 2;
      titulo.textContent = lista.length ? `Comentarios (${lista.length}${cursor ? "+" : ""})` : "Comentarios";
    }
    async function cargar() {
      if (pidiendo || !vivo) return;
      pidiendo = true;
      boton.disabled = true;
      boton.textContent = "Cargando…";
      aviso.hidden = true;
      let r;
      try {
        r = await M7.api(`/api/video/comentarios?url=${encodeURIComponent(url)}${cursor ? "&cursor=" + encodeURIComponent(cursor) : ""}`, undefined, "GET", ctl.signal);
      } catch (err) { pidiendo = false; return; }
      pidiendo = false;
      if (!vivo) return;
      boton.disabled = false;
      if (!r.ok) {
        boton.textContent = "No he podido cargarlos · reintentar";
        if (r.clase === "bloqueo") { boton.disabled = true; aviso.hidden = false; aviso.textContent = r.error || "YouTube está frenando las peticiones"; }
        return;
      }
      lista = lista.concat(r.comentarios || []);
      cursor = r.cursor || null;
      pintar();
      if (!lista.length) { boton.hidden = true; aviso.hidden = false; aviso.textContent = "Este vídeo no tiene comentarios"; return; }
      boton.hidden = !cursor;
      boton.textContent = "Más comentarios";
    }
    boton.addEventListener("click", cargar);
    ordenar.addEventListener("change", () => { orden = ordenar.value; pintar(); });
    return {
      cargar, n: () => lista.length,
      destruir() { vivo = false; ctl.abort(); raiz.remove(); },
    };
  };
})();
