// Cat-ode escritorio · interfaz web: los ganchos entre módulos que no son de ninguno (módulo M8, integración), 06/10/2026.
// Se carga el último (app.js, lista MODULOS). Hoy: «Ver a la vez (segundo vídeo)» (interfaz.py 2443 ver_a_la_vez →
// segundo.py SegundoVideo): un segundo reproductor flotante, con su propio iframe y sus mandos mínimos, que no es de
// ninguna pestaña (cuenta en el tope de 2 vídeos vivos del gestor de M6). Mayús+clic en una tarjeta o el menú «⋮».
(function () {
  "use strict";
  const app = window.app;
  if (!app || !app.ganchos) return;
  let segundo = null;

  function cerrarSegundo() {
    if (!segundo) return;
    const s = segundo;
    segundo = null;
    try { s.rep.cerrar(); } catch (e) { /* ya cerrado */ }   // guarda la posición y sale del gestor (gestor._quitar)
    s.caja.remove();
    s.zona.remove();
  }

  function verALaVez(e) {
    if (!e || !e.url) return;
    if (!window.Reproductor || !window.Reproductor.gestor) return app.abrirVideo(e, {nueva: true});
    cerrarSegundo();
    const zona = document.createElement("div");
    zona.className = "rep-zona m8-segundo";
    zona.style.cssText = "position:fixed;right:16px;bottom:96px;width:400px;height:225px;z-index:58;border-radius:10px;overflow:hidden;background:#000";
    document.body.appendChild(zona);
    const caja = document.createElement("div");   // encima: el título, ⏯ y ✕ (el iframe se queda quieto debajo)
    caja.className = "m8-segundo-mandos";
    caja.style.cssText = "position:fixed;right:16px;bottom:321px;width:400px;z-index:58;display:flex;gap:6px;align-items:center;" +
      "background:#212121;color:#F1F1F1;font:13px Roboto,sans-serif;padding:4px 6px;border-radius:8px 8px 0 0";
    const titulo = document.createElement("span");
    titulo.style.cssText = "flex:1;overflow:hidden;white-space:nowrap;text-overflow:ellipsis";
    titulo.textContent = e.titulo || "Segundo vídeo";
    titulo.title = (e.titulo || "") + " · arrastra para moverlo · doble clic: pasarlo al principal";
    const bPausa = document.createElement("button");
    bPausa.className = "boton"; bPausa.textContent = "⏯"; bPausa.title = "Pausa / sigue";
    const bCerrar = document.createElement("button");
    bCerrar.className = "boton"; bCerrar.textContent = "✕"; bCerrar.title = "Cerrar el segundo vídeo";
    caja.append(titulo, bPausa, bCerrar);
    document.body.appendChild(caja);
    const rep = window.Reproductor.gestor.crear(zona);
    rep._segundo = true;
    bPausa.addEventListener("click", () => rep.alternar());
    bCerrar.addEventListener("click", cerrarSegundo);
    // arrastrable por la barra del título (segundo.py: se mueve con el ratón); el iframe no cambia de padre, solo de sitio
    titulo.style.cursor = "move";
    titulo.addEventListener("pointerdown", (ev) => {
      if (ev.button !== 0) return;
      ev.preventDefault();
      const x0 = ev.clientX, y0 = ev.clientY, r = zona.getBoundingClientRect();
      const mover = (m) => {
        const izq = Math.max(0, Math.min(innerWidth - r.width, r.left + m.clientX - x0));
        const arr = Math.max(caja.offsetHeight, Math.min(innerHeight - r.height, r.top + m.clientY - y0));
        zona.style.left = izq + "px"; zona.style.top = arr + "px"; zona.style.right = zona.style.bottom = "auto";
        caja.style.left = izq + "px"; caja.style.top = (arr - caja.offsetHeight) + "px"; caja.style.right = caja.style.bottom = "auto";
      };
      const soltar = () => { removeEventListener("pointermove", mover); removeEventListener("pointerup", soltar); };
      addEventListener("pointermove", mover);
      addEventListener("pointerup", soltar);
    });
    titulo.addEventListener("dblclick", () => { const x = segundo && segundo.e; cerrarSegundo(); if (x) app.abrirVideo(x, {}); });   // «Pasar al principal»
    segundo = {rep, zona, caja, e};
    rep.reproducir(e, null);
    app.avisar("Segundo vídeo: «" + String(e.titulo || "").slice(0, 50) + "»");
    return rep;
  }

  if (typeof app.ganchos.verALaVez !== "function") app.ganchos.verALaVez = verALaVez;
  app.segundo = {abrir: verALaVez, cerrar: cerrarSegundo, actual: () => segundo};
})();
