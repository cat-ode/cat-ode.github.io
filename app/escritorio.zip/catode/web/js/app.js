// Cat-ode escritorio · interfaz web: el marco de la página (módulo M4, DISENO_WEB.md §3). 06/10/2026.
// Lo que hace la Ventana de interfaz.py fuera de las páginas de contenido:
//   - router ir(f, args) con pila ≤ 60 por pestaña (2957), atrás/adelante (2981-3002), saltar en el historial (2760),
//     sitios: scroll y nº de tarjetas al volver (_sitios 2893-2955);
//   - barra superior (2063-2126): ☰, logo, buscador con sugerencias (⟲ propias, Mayús+Supr, Ctrl+Enter/central = pestaña
//     nueva), micrófono (Win+H por POST /api/ventana «voz», búsqueda al callar 1,8 s), lupa, campana con número, sincro;
//   - menú lateral (MENU 1385-1410 + canales suscritos 2128-2159; central o Ctrl+clic = pestaña nueva);
//   - abrir(e), abrirVideo, abrirEnlace (3730-3768), buscar (3675), Ctrl+V con un enlace (3722), zoom (2684), título;
//   - eventos del servidor (SSE §2.4), menú contextual genérico, carga de los módulos de las páginas (M5, M6, M7).
//
// CONTRATO PARA LOS OTROS MÓDULOS (las páginas):
//   app.registrar(nombre, fn)  nombre = el de la función de interfaz.py, para que las pestañas guardadas sirvan en las dos
//     interfaces: inicio, shorts, suscripciones, explorar, historial, despues, megusta, listas, descargas, nut,
//     ajustes_pagina, _canal(url, pestana), _mostrar_video(e), _resultados(q, filtros), _lista_yt(url, titulo),
//     _lista_propia(clave), _gestionar.
//   fn(el, args, ctx) pinta en «el» (un div nuevo por navegación, con su scroll). Puede devolver una promesa o un objeto
//     {listo?: Promise, destruir?(), cuantos?() → nº de tarjetas, restaurar?(sitio{scroll, n})}.
//   ctx = {p (pestaña), entrada {f, a}, senal (AbortSignal de esta navegación), api (get/post/put/datos con la señal),
//     titulo(t) (nombre de la pestaña y de la ventana), recargar (F5), sitio (dónde estaba al volver, o null),
//     reabriendo (pestaña recordada o pintada al activarla: no reproducir nada)}.
//   Ganchos que rellenan M6/M7 (app.ganchos.*, todos opcionales): reproducir(e, desde), completa(), buscarEnPagina() → bool,
//     silenciar(p) → bool, saltarSiSuena(url, t) → bool, escape() → bool, guardar() (antes de cerrar), multimedia(nombre).
//   Teclado del vídeo: app.teclado.video = () => null | {modo:"pagina"|"mini"|"shorts"|"completa", …} (ver atajos.js).
//   Eventos internos: app.on("pestana:nueva|pestana:cambia|pestana:cierra|pestana:mueve|navega|pagina|completa", fn) y los
//     del servidor con su nombre (datos, sincro, descarga, novedades, aviso, abrir, remoto, voz, tecla, ventana, archivo…).
"use strict";
(function () {
  const C = window.catode = window.catode || {};
  const api = C.api;
  const $ = (s, r) => (r || document).querySelector(s);
  const scriptPropio = document.currentScript;
  const VERSION = scriptPropio && /[?&]v=([^&]+)/.exec(scriptPropio.src || "") ? /[?&]v=([^&]+)/.exec(scriptPropio.src)[1] : "";

  // las páginas de los otros módulos: se cargan solas, en este orden (las que aún no existan se saltan)
  const MODULOS = ["js/tarjeta.js", "js/menus.js", "js/previa.js", "js/rejilla.js", "js/paginas_listas.js",
    "js/reproductor.js", "js/mandos.js", "js/barra.js", "js/flotante.js", "js/pagina_video.js", "js/comentarios.js",
    "js/transcripcion.js", "js/shorts.js", "js/cuenta.js", "js/ajustes.js", "js/integracion.js"];   // cuenta.js: 18/10/2026, «Traer mi YouTube»   // integracion.js: M8, el último
  const HOJAS = ["css/video.css"];

  // MENU de interfaz.py 1385-1390 (None = separador; clave None = cabecera)
  const MENU = [["🏠  Inicio", "inicio"], ["⚡  Shorts", "shorts"], ["📺  Suscripciones", "suscripciones"],
    ["🧭  Explorar", "explorar"], null, ["Tú", null], ["🕘  Historial", "historial"], ["🕒  Ver más tarde", "despues"],
    ["👍  Vídeos que me gustan", "megusta"], ["☰  Listas", "listas"], ["🎵  Música", "musica"], ["⬇  Descargas", "descargas"],
    ["👤  Traer mi YouTube", "cuenta"], null,   // 18/10/2026: lleva a su sección de Ajustes (cuenta.js), como la fila de «Tú» en Android
    ["🐾  Para Nut", "nut"], ["⚙  Ajustes", "ajustes"]];
  const SECCION_A_F = {inicio: "inicio", shorts: "shorts", suscripciones: "suscripciones", explorar: "explorar",
    historial: "historial", despues: "despues", megusta: "megusta", listas: "listas", descargas: "descargas", nut: "nut",
    musica: "musica", ajustes: "ajustes_pagina"};
  const F_A_SECCION = Object.fromEntries(Object.entries(SECCION_A_F).map(([k, v]) => [v, k]));
  // nombres de _titulo_entrada (2746)
  const NOMBRES = {inicio: "Inicio", shorts: "Shorts", suscripciones: "Suscripciones", explorar: "Explorar",
    historial: "Historial", despues: "Ver más tarde", megusta: "Me gusta", listas: "Listas", descargas: "Descargas",
    musica: "Música", nut: "Nut", ajustes_pagina: "Ajustes", _canal: "Canal", _gestionar: "Gestionar", _canales: "Canales", _lista_propia: "Lista"};
  const ALIAS = {abrir_video: "_mostrar_video", ajustes: "ajustes_pagina", canal: "_canal", resultados: "_resultados",
    lista_yt: "_lista_yt", lista_propia: "_lista_propia", gestionar: "_gestionar", mostrar_video: "_mostrar_video"};
  const CAMPOS_E = ["tipo", "url", "titulo", "autor", "autorUrl", "miniatura", "duracion", "detalle", "fecha"];

  // ------------------------------------------------------------------------------------------------ utilidades
  const oyentes = {};
  function on(nombre, fn) { (oyentes[nombre] = oyentes[nombre] || []).push(fn); return () => off(nombre, fn); }
  function off(nombre, fn) { const l = oyentes[nombre]; if (l) { const i = l.indexOf(fn); if (i >= 0) l.splice(i, 1); } }
  function emitir(nombre, d) {
    for (const fn of (oyentes[nombre] || []).slice()) { try { fn(d); } catch (e) { console.warn("oyente " + nombre, e); } }
  }
  const esElemento = (x) => !!x && typeof x === "object" && typeof x.url === "string" && typeof x.tipo === "string";
  const limpioE = (x) => Object.fromEntries(CAMPOS_E.filter((k) => x[k] !== undefined).map((k) => [k, x[k]]));
  // argumentos en memoria: los {_e: …} de las pestañas guardadas pasan a Elemento llano
  const normalizar = (a) => (Array.isArray(a) ? a : (a === undefined || a === null ? [] : [a]))
    .map((x) => (x && typeof x === "object" && x._e && typeof x._e === "object" ? Object.assign({}, x._e) : x));
  const clave = (en) => en.f + "|" + JSON.stringify(en.a || []);
  function idVideo(url) {
    const m = /(?:v=|youtu\.be\/|shorts\/)([A-Za-z0-9_-]{11})/.exec(url || "");
    return m ? m[1] : (url || "");
  }
  const pideNueva = (ev) => !!ev && (ev.button === 1 || ev.ctrlKey || ev.metaKey);
  const editable = (el) => !!el && (el.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(el.tagName));
  function nombreEntrada(en) {
    const a = en.a || [];
    if (en.f === "_mostrar_video") return (a[0] && a[0].titulo) || "Vídeo";
    if (en.f === "_resultados" && a.length) return "Búsqueda: " + a[0];
    if ((en.f === "_lista_yt" || en.f === "_lista_musica") && a.length > 1) return String(a[1]);
    return NOMBRES[en.f] || (en.f.replace(/^_+|_+$/g, "").replace(/^./, (c) => c.toUpperCase()) || "Página");
  }

  const app = window.app = Object.assign(window.app || {}, {
    VERSION, token: api.token, base: api.base, api, paginas: (window.app && window.app.paginas) || {},
    ganchos: {}, teclado: {video: null, rep: null}, estado: null, ajustes: {}, so: "", sitios: {}, escala: 1,
    on, off, emitir, idVideo, pideNueva, editable, clave, nombreEntrada, normalizar, limpioE, esElemento, MENU,
  });

  // ------------------------------------------------------------------------------------------------ registro de páginas
  app.registrar = function (nombre, fn) {
    if (typeof fn !== "function") return;
    app.paginas[ALIAS[nombre] || nombre] = fn;
    if (ALIAS[nombre]) app.paginas[nombre] = fn;
  };
  for (const [n, f] of Object.entries(app.paginas)) app.registrar(n, f);
  function paginaDe(f) {
    return app.paginas[f] || app.paginas[ALIAS[f]] || (window.catodePaginas && (window.catodePaginas[f] || window.catodePaginas[ALIAS[f]]));
  }
  // talón: lo que se pinta mientras el módulo de esa página no exista
  function talon(el, args, ctx) {
    const t = document.createElement("div");
    t.className = "talon";
    t.innerHTML = '<div class="girando"></div><div>cargando…</div>';
    t.dataset.pagina = ctx.entrada.f;
    el.replaceChildren(t);
  }

  // ------------------------------------------------------------------------------------------------ pintar una entrada
  const P = () => C.pestanas;
  function guardarSitio(p) {
    p = p || (P() && P().activa());
    if (!p || !p.pila.length || !p.pagina) return;
    const v = p.vista;
    let n = 0;
    try { n = v && typeof v.cuantos === "function" ? v.cuantos() : 0; } catch (e) { n = 0; }
    app.sitios[clave(p.pila[p.pila.length - 1])] = {scroll: p.pagina.scrollTop, n};
  }

  function restaurarSitio(p, en, vista) {
    const sitio = app.sitios[clave(en)];
    if (!sitio) return;
    if (vista && typeof vista.restaurar === "function") { try { vista.restaurar(sitio); } catch (e) { /* nada */ } return; }
    const el = p.pagina;
    let veces = 30;
    const usuario = () => { veces = 0; };
    el.addEventListener("wheel", usuario, {once: true, passive: true});
    (function colocar() {   // la página aún puede estar creciendo (tandas): se insiste hasta 4 s, como _volver_al_sitio
      if (!el.isConnected || p.pagina !== el) return;
      el.scrollTop = Math.min(sitio.scroll, el.scrollHeight);
      if (el.scrollTop < sitio.scroll - 2 && veces-- > 0) setTimeout(colocar, 130);
    })();
  }

  // pinta la última entrada de la pestaña p (op: {recargar, restaurar, reabriendo})
  function ejecutar(p, op) {
    op = op || {};
    if (!p || !p.pila.length) return Promise.resolve();
    const en = p.pila[p.pila.length - 1];
    if (p.ctrl) p.ctrl.abort();
    if (p.vista && typeof p.vista.destruir === "function") { try { p.vista.destruir(); } catch (e) { /* nada */ } }
    p.vista = null;
    const ctrl = p.ctrl = new AbortController();
    const el = document.createElement("div");
    el.className = "pagina";
    el.dataset.f = en.f;
    el.tabIndex = -1;
    if (p.pagina) p.pagina.replaceWith(el); else p.cuerpo.appendChild(el);
    p.pagina = el;
    p.cuerpo.dataset.f = en.f;
    p.pintada = true;
    poner_titulo(p, op.titulo || nombreEntrada(en), true);   // la recordada conserva su nombre hasta que la página ponga el suyo
    const senal = ctrl.signal;
    const ctx = {
      p, entrada: en, senal, recargar: !!op.recargar, reabriendo: !!op.reabriendo, sitio: app.sitios[clave(en)] || null,
      titulo: (t) => { if (!senal.aborted) poner_titulo(p, t); },
      api: {
        get: (r, q, o) => api.get(r, q, Object.assign({senal}, o)),
        post: (r, c, o) => api.post(r, c, Object.assign({senal}, o)),
        put: (r, c, o) => api.put(r, c, Object.assign({senal}, o)),
        datos: (a, x, o) => api.datos(a, x, Object.assign({senal}, o)),
      },
      cartel: (err, reintentar) => api.cartel(el, err, reintentar || (() => ejecutar(p, op))),
    };
    const fin = C.medir ? C.medir.empezar("pagina:" + en.f) : () => {};
    const fn = paginaDe(en.f) || talon;
    let r;
    try { r = fn(el, en.a || [], ctx); } catch (err) { r = Promise.reject(err); }
    if (r && typeof r === "object" && typeof r.then !== "function") { p.vista = r; r = r.listo; }
    pintarMenuActual();
    emitir("navega", {p, entrada: en});
    actualizarFlechas();
    if (P()) P().guardar();
    return Promise.resolve(r).then((v) => {
      if (senal.aborted) return;
      if (v && typeof v === "object" && !p.vista) p.vista = v;
      requestAnimationFrame(() => {
        fin({tal: fn === talon ? 1 : 0});
        if (!app._pintada) { app._pintada = true; if (C.medir) C.medir.marca("arranque:pintada", performance.now()); }
      });
      if (op.restaurar) restaurarSitio(p, en, p.vista);
      emitir("pagina", {p, entrada: en});
    }, (err) => {
      if (senal.aborted || api.abortado(err)) return;
      console.warn("página " + en.f, err);
      api.cartel(el, err, () => ejecutar(p, op));
    });
  }
  app.ejecutar = ejecutar;

  function poner_titulo(p, t, provisional) {
    t = String(t || "").trim() || "Inicio";
    if (provisional && p.tituloFijo === clave(p.pila[p.pila.length - 1] || {f: ""})) return;
    if (!provisional) p.tituloFijo = clave(p.pila[p.pila.length - 1] || {f: ""});
    p.titulo = t;
    if (P()) P().pintar();
    if (P() && P().activa() === p) tituloVentana(t);
  }
  app.ponerTitulo = poner_titulo;
  let tituloPuesto = "", relojTitulo = 0;
  function tituloVentana(t) {
    const completo = t ? `${t} · Cat-ode` : "Cat-ode";
    document.title = completo;
    if (completo === tituloPuesto) return;
    tituloPuesto = completo;
    clearTimeout(relojTitulo);
    relojTitulo = setTimeout(() => api.ventana("titulo", completo).catch(() => {}), 300);
  }
  app.tituloVentana = tituloVentana;

  // ------------------------------------------------------------------------------------------------ navegación
  function activa() { return P() && P().activa(); }
  app.ir = function (f, args, op) {
    op = op || {};
    args = normalizar(args);
    if (f === "abrir_video") return app.abrirVideo(args[0], op);   // el de la Qt: suena y enseña su página
    f = ALIAS[f] || f;
    if (f === "_mostrar_video") return app.abrirVideo(args[0], Object.assign({sonar: false}, op));
    if (op.nueva) return app.nuevaPestana(f, args);
    const p = activa();
    if (!p) return null;
    if (document.body.classList.contains("completa")) app.ponerCompleta(false);
    guardarSitio(p);
    p.pila.push({f, a: args});
    if (p.pila.length > 60) p.pila.splice(0, 20);
    p.ade.length = 0;   // una página nueva borra el «adelante», como en el navegador
    return ejecutar(p, op);
  };
  // cambia la página actual sin apilar (chips, filtros: _refiltrar 3713)
  app.reemplazar = function (f, args) {
    const p = activa();
    if (!p) return null;
    f = ALIAS[f] || f;
    if (p.pila.length) p.pila.pop();
    p.pila.push({f, a: normalizar(args)});
    return ejecutar(p);
  };
  app.volver = function () {
    const p = activa();
    if (!p) return;
    if (p.pila.length > 1) {
      guardarSitio(p);
      p.ade.push(p.pila.pop());
      ejecutar(p, {restaurar: true});
    } else {
      app.irSeccion("inicio");
    }
    actualizarFlechas();
  };
  app.adelante = function () {
    const p = activa();
    if (!p || !p.ade.length) return;
    guardarSitio(p);
    p.pila.push(p.ade.pop());
    ejecutar(p, {restaurar: true});
  };
  // n pasos atrás (negativo) o adelante (positivo) de una vez (menú de las flechas, 2760)
  app.saltarHistorial = function (n) {
    const p = activa();
    if (!p || !n) return;
    guardarSitio(p);
    for (let i = 0; i < Math.abs(n); i++) {
      if (n < 0 && p.pila.length > 1) p.ade.push(p.pila.pop());
      else if (n > 0 && p.ade.length) p.pila.push(p.ade.pop());
    }
    ejecutar(p, {restaurar: true});
  };
  // botón central en las flechas: esa página en una pestaña nueva, con su historial hasta ahí (2788)
  app.historialEnPestana = function (adelante) {
    const p = activa();
    if (!p) return;
    if (adelante && p.ade.length) P().crear({pila: p.pila.concat([p.ade[p.ade.length - 1]])});
    else if (!adelante && p.pila.length > 1) P().crear({pila: p.pila.slice(0, -1)});
  };
  app.puedeVolver = () => { const p = activa(); return !!p && (p.pila.length > 1 || (p.pila.length === 1 && p.pila[0].f !== "inicio")); };
  app.puedeAdelante = () => { const p = activa(); return !!p && p.ade.length > 0; };
  function actualizarFlechas() {
    const a = $("#atras"), d = $("#adelante");
    if (a) a.disabled = !app.puedeVolver();
    if (d) d.disabled = !app.puedeAdelante();
  }
  app.actualizarFlechas = actualizarFlechas;

  app.irSeccion = function (seccion, op) {
    op = op || {};
    if (seccion === "cuenta" && C.cuenta) { C.cuenta.ir(op); return null; }   // 18/10/2026: «Traer mi YouTube» vive en Ajustes
    if (op.nueva) { P().crear({vacia: true}); }
    const p = activa();
    if (!p) return null;
    if (String(seccion).startsWith("canal:")) return app.ir("_canal", [seccion.slice(6), "videos"]);
    const f = SECCION_A_F[seccion] || seccion;
    const arriba = p.pila[p.pila.length - 1];
    if (!op.nueva && arriba && arriba.f === f && !(arriba.a || []).length && p.pagina) {   // ya estás ahí: no se apila
      p.pagina.scrollTop = 0;
      // 06/10/2026: pulsar Inicio (o el logo) estando en Inicio = otra mezcla, como en YouTube
      if (f === "inicio" && typeof app.recargar === "function") { app._inicioFresco = true; app.recargar(); }
      return null;
    }
    // 24/10/2026 («siguen saliéndome siempre los mismos vídeos sugeridos»): volver al Inicio desde el menú o el logo también
    // es una mezcla nueva (antes, dentro de 10 min, la misma página); solo «atrás» la deja como estaba
    if (f === "inicio") app._inicioFresco = true;
    return app.ir(f, []);
  };
  app.recargar = function () {
    const p = activa();
    if (!p || !p.pila.length) return app.irSeccion("inicio");
    ejecutar(p, {recargar: true});
    app.avisar("Recargado");
  };
  app.nuevaPestana = function (f, args, titulo) {
    if (!f) return P().crear();
    return P().crear({pila: [{f: ALIAS[f] || f, a: normalizar(args)}], titulo});
  };
  app.nuevaPestanaElemento = function (e) { P().crear({vacia: true}); return app.abrir(e); };

  // ------------------------------------------------------------------------------------------------ abrir cosas
  // ventana.abrir(e) 3003: vídeo, canal, lista propia o lista de YouTube (op.nueva = en pestaña nueva)
  app.abrir = function (e, op) {
    op = op || {};
    if (!e) return null;
    if (e._e) e = e._e;
    if (op.nueva) { P().crear({vacia: true}); op = Object.assign({}, op, {nueva: false}); }
    if (e.tipo === "VIDEO") return app.abrirVideo(e, op);
    if (e.tipo === "CANAL") return app.ir("_canal", [e.url, "videos"]);
    if (String(e.url || "").startsWith("propia:")) return app.ir("_lista_propia", [e.url]);
    // 22/10/2026 · «catode musica no funcional»: las listas del modo Música («biblioteca:…») iban a _lista_yt y no abrían
    if (String(e.url || "").startsWith("biblioteca:")) return app.ir("_lista_musica", [e.url.slice(11), e.titulo || "Lista"]);
    return app.ir("_lista_yt", [e.url, e.titulo || "Lista"]);
  };
  // abrir_video 3016: suena (gancho de M6) y se apila _mostrar_video sin repetir el mismo vídeo
  app.abrirVideo = function (e, op) {
    op = op || {};
    if (e && e._e) e = e._e;
    if (!e || !e.url) return null;
    if (op.nueva) P().crear({vacia: true});
    const p = activa();
    if (!p) return null;   // sin pestañas todavía (no debería pasar: los enlaces de fuera esperan a «listo»)
    if (op.sonar !== false && typeof app.ganchos.reproducir === "function") {
      try { app.ganchos.reproducir(e, op.desde === undefined ? null : op.desde); } catch (err) { console.warn("reproducir", err); }
    }
    if (document.body.classList.contains("completa") && op.sonar === false) app.ponerCompleta(false);
    guardarSitio(p);
    const arriba = p.pila[p.pila.length - 1];
    if (!(arriba && arriba.f === "_mostrar_video" && arriba.a[0] && idVideo(arriba.a[0].url) === idVideo(e.url))) {
      p.pila.push({f: "_mostrar_video", a: [limpioE(e)]});
      if (p.pila.length > 60) p.pila.splice(0, 20);
      p.ade.length = 0;
    }
    return ejecutar(p);
  };
  app.abrirCanal = (url, nueva) => (nueva ? app.nuevaPestana("_canal", [url, "videos"]) : app.ir("_canal", [url, "videos"]));

  const ES_YT = /https?:\/\/(www\.|m\.|music\.)?(youtube\.com|youtu\.be)\/|^(youtube\.com|youtu\.be|www\.youtube)/;
  // abrir_enlace 3730: lo clasifica el servidor (GET /api/enlace) y se abre aquí; lo que no es de YouTube, fuera
  app.abrirEnlace = async function (url, nueva) {
    url = String(url || "").trim();
    if (!url) return;
    let r;
    try { r = await api.get("/api/enlace", {url}); } catch (e) { app.avisar(e.message); return; }
    const conPestana = nueva && r.tipo !== "fuera";
    if (r.tipo === "video") {
      if (r.t != null && typeof app.ganchos.saltarSiSuena === "function" && app.ganchos.saltarSiSuena(r.url, r.t)) return;
      if (conPestana) P().crear({vacia: true});
      return app.abrirVideo({tipo: "VIDEO", url: r.url, titulo: r.titulo || "", autor: "", autorUrl: "",
        miniatura: r.miniatura || "", duracion: -1, detalle: "", fecha: 0}, {desde: r.t == null ? null : r.t});
    }
    if (r.tipo === "hashtag" || r.tipo === "busqueda") return app.buscar(r.url, null, conPestana);
    if (conPestana) P().crear({vacia: true});
    if (r.tipo === "canal") return app.ir("_canal", [r.url, "videos"]);
    if (r.tipo === "lista") return app.ir("_lista_yt", [r.url, r.titulo || "Lista"]);
    try { await api.ventana("abrir_fuera", r.url); } catch (e) { app.avisar(e.message); }
  };

  // buscar 3675: un enlace pegado se abre; si no, la página de resultados (el servidor apunta la búsqueda)
  app.buscar = function (q, filtros, nueva) {
    q = String(q || "").replace(/^⟲\s+/, "").trim();
    if (!q) return;
    const campo = $("#campo");
    if (campo && campo.value !== q) campo.value = q;
    cerrarSugerencias();
    if (/(youtube\.com|youtu\.be)\//.test(q)) return app.abrirEnlace(q, nueva);
    api.datos("buscado", {q}).catch(() => {});   // como datos.buscado(q) de la Qt: ya sale en las sugerencias «⟲»
    if (nueva) P().crear({vacia: true});
    return app.ir("_resultados", [q, Object.assign({}, filtros || {})]);
  };

  // Ctrl+V fuera de un campo (3722): el enlace del portapapeles
  app.pegarEnlace = function (texto) {
    const t = String(texto || "").trim();
    if (/(youtube\.com|youtu\.be)\//.test(t)) app.abrirEnlace(/^https?:/.test(t) ? t : "https://" + t);
    else app.avisar("Copia un enlace de YouTube y pulsa Ctrl+V para abrirlo aquí");
  };

  // ------------------------------------------------------------------------------------------------ ventana
  app.avisar = (t, ms) => C.avisos.avisar(t, ms);
  // 06/10/2026 (doble clic en Windows): la clase, la capa de M7 y la ventana real se desincronizaban por un aviso SSE
  // «ventana» tardío. Ahora la respuesta de la orden es la verdad, y los avisos que la contradigan en 1,5 s se ignoran.
  app._ventanaReal = null;   // último estado real de la ventana (true/false), de la respuesta de la orden o de un SSE
  app._ordenCompleta = null;
  let ordenVentana = 0, filaVentana = Promise.resolve();
  app._ventanaN = -1;   // el número del último estado de la ventana aceptado (VentanaWeb._estado_ventana)
  function aplicarCompleta(si, n) {
    if (typeof n === "number") {
      if (n < app._ventanaN) return false;   // más viejo que lo último aceptado: no cuenta
      app._ventanaN = n;
    }
    app._ventanaReal = si;
    if (document.body.classList.contains("completa") === si) return;
    document.body.classList.toggle("completa", si);
    emitir("completa", si);
  }
  app.ponerCompleta = function (si) {
    si = !!si;
    if (document.body.classList.contains("completa") === si && app._ventanaReal !== !si) return;
    document.body.classList.toggle("completa", si);
    emitir("completa", si);
    app._ordenCompleta = {si, t: performance.now()};
    // las órdenes a la ventana van EN FILA (dos peticiones a la vez podían llegar cambiadas: salir y entrar en milisegundos
    // dejaba la ventana al revés) y, si al llegar su turno ya hay una más nueva, la vieja se descarta
    const mia = ++ordenVentana;
    filaVentana = filaVentana.then(() => {
      if (mia !== ordenVentana) return null;
      return api.ventana(si ? "completa" : "normal").then((r) => {
        if (mia === ordenVentana && r && typeof r.completa === "boolean") aplicarCompleta(r.completa, r.n);
      });
    }).catch(() => {});
  };
  app.enCompleta = () => document.body.classList.contains("completa");
  // Ctrl+rueda (poner_escala 2684): 0,8-1,6 por pasos de 0,1, aplicado con ZoomFactor (POST /api/ventana «zoom»)
  let relojEscala = 0;
  app.ponerEscala = function (e) {
    e = Math.round(Math.min(1.6, Math.max(0.8, e)) * 100) / 100;
    if (e === app.escala) return;
    app.escala = e;
    app.ajustes.escala = e;
    clearTimeout(relojEscala);
    relojEscala = setTimeout(() => {
      api.ventana("zoom", e).catch(() => {});
      api.put("/api/ajustes", {escala: e}).catch(() => {});
    }, 180);
    app.avisar(`Tamaño: ${Math.round(e * 100)} %`);
  };
  app.alternarMenu = function (si) {
    const m = $("#menu");
    m.classList.toggle("oculto", si === undefined ? !m.classList.contains("oculto") : !si);
  };

  // ------------------------------------------------------------------------------------------------ menú contextual
  let menuAbierto = null;
  // items: [{texto, accion, desactivado, icono, marcado} | null (separador)]; x, y en px de la ventana
  app.menu = function (items, x, y, op) {
    app.cerrarMenu();
    const m = document.createElement("div");
    m.className = "menu-ctx";
    m.setAttribute("role", "menu");
    m.tabIndex = -1;
    const botones = [];
    for (const it of items) {
      if (!it) { const s = document.createElement("div"); s.className = "menu-sep"; m.appendChild(s); continue; }
      const b = document.createElement("button");
      b.className = "menu-item";
      b.setAttribute("role", "menuitem");
      const [ico, texto] = it.icono ? [it.icono, it.texto] : C.iconos.separar(it.texto);
      if (ico) b.appendChild(C.iconos.nodo(ico, null, 18));
      const sp = document.createElement("span"); sp.textContent = texto; b.appendChild(sp);
      if (it.atajo) { const k = document.createElement("span"); k.className = "menu-atajo"; k.textContent = it.atajo; b.appendChild(k); }
      if (it.desactivado) b.disabled = true;
      b.addEventListener("click", (ev) => { ev.stopPropagation(); app.cerrarMenu(); if (it.accion) it.accion(ev); });
      b.addEventListener("auxclick", (ev) => { if (ev.button === 1 && it.central) { ev.preventDefault(); app.cerrarMenu(); it.central(ev); } });
      m.appendChild(b);
      botones.push(b);
    }
    $("#capas").appendChild(m);
    const w = m.offsetWidth, h = m.offsetHeight;
    m.style.left = Math.max(4, Math.min(x, innerWidth - w - 4)) + "px";
    m.style.top = Math.max(4, Math.min(y, innerHeight - h - 4)) + "px";
    m.addEventListener("keydown", (ev) => {
      const vivos = botones.filter((b) => !b.disabled);
      const i = vivos.indexOf(document.activeElement);
      if (ev.key === "ArrowDown") { ev.preventDefault(); (vivos[(i + 1) % vivos.length] || m).focus(); }
      else if (ev.key === "ArrowUp") { ev.preventDefault(); (vivos[(i - 1 + vivos.length) % vivos.length] || m).focus(); }
      else if (ev.key === "Escape") { ev.preventDefault(); ev.stopPropagation(); app.cerrarMenu(); }
    });
    menuAbierto = {m, alCerrar: op && op.alCerrar, foco: document.activeElement};
    m.focus({preventScroll: true});
    return m;
  };
  app.cerrarMenu = function () {
    if (!menuAbierto) return false;
    const {m, alCerrar} = menuAbierto;
    menuAbierto = null;
    m.remove();
    if (alCerrar) { try { alCerrar(); } catch (e) { /* nada */ } }
    return true;
  };
  app.menuAbierto = () => !!menuAbierto;
  document.addEventListener("pointerdown", (ev) => {
    if (menuAbierto && !menuAbierto.m.contains(ev.target)) app.cerrarMenu();
  }, true);
  addEventListener("blur", () => app.cerrarMenu());
  addEventListener("resize", () => app.cerrarMenu());

  // ------------------------------------------------------------------------------------------------ menú lateral
  function pintarMenu(canales) {
    const nav = $("#menu");
    const lista = document.createElement("div");
    lista.className = "menu-lista";
    for (const x of MENU) {
      if (!x) { const s = document.createElement("div"); s.className = "menu-hueco"; lista.appendChild(s); continue; }
      const [texto, cl] = x;
      if (!cl) { const h = document.createElement("div"); h.className = "menu-cabecera"; h.textContent = texto; lista.appendChild(h); continue; }
      const [ico, t] = C.iconos.separar(texto);
      lista.appendChild(itemMenu(cl, t, ico));
    }
    const subs = canales || [];
    if (subs.length) {
      // 13/10/2026: la cabecera abre todos los canales en rejilla, como Inicio o Suscripciones
      const h = itemMenu("_canales", `Suscripciones (${subs.length})`, null);
      h.classList.add("menu-cabecera", "menu-subs");
      h.title = "Ver todos tus canales";
      lista.appendChild(h);
      for (const s of subs) lista.appendChild(itemMenu("canal:" + s.url, s.titulo, null, s));
    }
    nav.replaceChildren(lista);
    app.canales = subs;
    pintarMenuActual();
  }
  function itemMenu(cl, texto, ico, canal) {
    const a = document.createElement("a");
    a.className = "menu-item-lat" + (canal ? " menu-canal" : "");
    a.dataset.clave = cl;
    a.href = "#";
    a.title = texto;
    a.draggable = false;
    if (ico) a.appendChild(C.iconos.nodo(ico, null, 22));
    const sp = document.createElement("span"); sp.textContent = texto; a.appendChild(sp);
    return a;
  }
  function claveActual() {
    const p = activa();
    const en = p && p.pila[p.pila.length - 1];
    if (!en) return null;
    if (en.f === "_canal") return "canal:" + (en.a || [])[0];
    if (en.f === "_canales") return "_canales";
    return F_A_SECCION[en.f] || null;
  }
  function pintarMenuActual() {
    const c = claveActual();
    for (const a of document.querySelectorAll("#menu .menu-item-lat")) a.classList.toggle("actual", !!c && a.dataset.clave === c);
  }
  app.pintarMenu = pintarMenu;
  function prepararMenu() {
    const nav = $("#menu");
    nav.addEventListener("click", (ev) => {
      const a = ev.target.closest(".menu-item-lat");
      if (!a) return;
      ev.preventDefault();
      app.irSeccion(a.dataset.clave, {nueva: ev.ctrlKey || ev.metaKey});
    });
    nav.addEventListener("mousedown", (ev) => { if (ev.button === 1 && ev.target.closest(".menu-item-lat")) ev.preventDefault(); });
    nav.addEventListener("auxclick", (ev) => {
      const a = ev.target.closest(".menu-item-lat");
      if (!a || ev.button !== 1) return;
      ev.preventDefault();
      app.irSeccion(a.dataset.clave, {nueva: true});
    });
  }

  // ------------------------------------------------------------------------------------------------ barra superior
  let sug = {lista: [], i: -1, ctrl: null, reloj: 0};
  function cerrarSugerencias() {
    const caja = $("#sugerencias");
    if (caja) { caja.hidden = true; caja.replaceChildren(); }
    sug.lista = []; sug.i = -1;
    if (sug.ctrl) { sug.ctrl.abort(); sug.ctrl = null; }
    clearTimeout(sug.reloj);
  }
  app.cerrarSugerencias = cerrarSugerencias;
  function pintarSugerencias() {
    const caja = $("#sugerencias");
    if (!sug.lista.length) { caja.hidden = true; return; }
    caja.replaceChildren(...sug.lista.map((t, i) => {
      const d = document.createElement("div");
      d.className = "sug" + (i === sug.i ? " elegida" : "") + (t.startsWith("⟲") ? " propia" : "");
      d.dataset.i = i;
      d.textContent = t;
      if (t.startsWith("⟲")) d.title = "Mayús+Supr: quitarla de tus búsquedas";
      return d;
    }));
    caja.hidden = false;
    const el = caja.children[sug.i];
    if (el) el.scrollIntoView({block: "nearest"});
  }
  async function sugerir() {
    const campo = $("#campo");
    const q = campo.value;
    if (sug.ctrl) sug.ctrl.abort();
    const ctrl = sug.ctrl = new AbortController();
    try {
      const r = await api.get("/api/sugerencias", {q}, {senal: ctrl.signal});
      if (ctrl.signal.aborted || campo.value !== q || document.activeElement !== campo) return;
      const propias = (r.propias || []).map((b) => "⟲  " + b);
      sug.lista = propias.concat((r.youtube || []).filter((x) => !(r.propias || []).includes(x)));
      sug.i = -1;
      pintarSugerencias();
    } catch (e) { /* sin sugerencias: no pasa nada */ }
  }
  async function quitarSugerencia(i) {
    const t = sug.lista[i];
    if (!t || !t.startsWith("⟲")) return;
    const q = t.replace(/^⟲\s+/, "").trim().toLowerCase();
    sug.lista.splice(i, 1);
    sug.i = Math.min(sug.i, sug.lista.length - 1);
    pintarSugerencias();
    try { await api.datos("quitar_busqueda", {q}); } catch (e) { app.avisar(e.message); }
  }
  app.quitarSugerencia = quitarSugerencia;

  let voz = {activa: false, reloj: 0};
  app.buscarPorVoz = function () {
    const campo = $("#campo");
    campo.focus(); campo.select();
    voz.activa = true;
    clearTimeout(voz.reloj);
    api.ventana("voz").catch(() => {});
    app.avisar("Habla: se buscará en cuanto te calles");
  };
  function vozCambio() {
    if (!voz.activa || !$("#campo").value.trim()) return;
    clearTimeout(voz.reloj);
    voz.reloj = setTimeout(vozFin, 1800);
  }
  function vozFin() {
    if (!voz.activa) return;
    voz.activa = false;
    const q = $("#campo").value.trim();
    if (q) app.buscar(q);
  }
  app.vozActiva = () => voz.activa;

  function ponerIconos() {
    const I = C.iconos;
    const poner = (sel, n, color, tam) => { const b = $(sel); if (b && !b.querySelector("svg")) b.insertAdjacentHTML("afterbegin", I.svg(n, color, tam)); };
    poner("#b-menu", "menu", null, 24);
    poner("#limpiar", "cerrar", "#AAAAAA", 18);
    poner("#b-voz", "microfono", null, 20);
    poner("#b-lupa", "buscar", null, 20);
    poner("#campana", "campana", "#FFFFFF", 22);
    poner("#atras", "atras", "#FFFFFF", 22);
    poner("#adelante", "atras", "#FFFFFF", 22);
    poner("#mas", "mas_uno", "#FFFFFF", 18);
  }

  function prepararBarra() {
    ponerIconos();
    $("#b-menu").addEventListener("click", () => app.alternarMenu());
    const logo = $("#logo");
    logo.addEventListener("click", (ev) => { ev.preventDefault(); if (pideNueva(ev)) P().crear(); else app.irSeccion("inicio"); });
    logo.addEventListener("mousedown", (ev) => { if (ev.button === 1) ev.preventDefault(); });
    logo.addEventListener("auxclick", (ev) => { if (ev.button === 1) { ev.preventDefault(); P().crear(); } });
    const campo = $("#campo");
    campo.addEventListener("input", () => {
      clearTimeout(sug.reloj);
      sug.reloj = setTimeout(sugerir, 80);   // 06/10/2026 (perfil en el N100): 200 ms de espera dejaban las sugerencias en 335 ms
      $("#limpiar").hidden = !campo.value;
      vozCambio();
    });
    campo.addEventListener("keydown", (ev) => {
      const abierta = !$("#sugerencias").hidden && sug.lista.length;
      if (ev.key === "ArrowDown" && abierta) { ev.preventDefault(); sug.i = Math.min(sug.lista.length - 1, sug.i + 1); pintarSugerencias(); }
      else if (ev.key === "ArrowUp" && abierta) { ev.preventDefault(); sug.i = Math.max(-1, sug.i - 1); pintarSugerencias(); }
      else if (ev.key === "Enter") {
        ev.preventDefault();
        const t = (abierta && sug.i >= 0 ? sug.lista[sug.i] : "") || campo.value;
        app.buscar(t, null, ev.ctrlKey || ev.metaKey);
      } else if (ev.key === "Delete" && ev.shiftKey && abierta && sug.i >= 0) {
        ev.preventDefault();
        quitarSugerencia(sug.i);
      } else if (ev.key === "Escape") {
        ev.preventDefault();
        ev.stopPropagation();
        if (abierta) cerrarSugerencias(); else campo.blur();
      }
    });
    campo.addEventListener("blur", () => setTimeout(() => { if (document.activeElement !== campo) cerrarSugerencias(); }, 150));
    const caja = $("#sugerencias");
    caja.addEventListener("mousedown", (ev) => ev.preventDefault());   // que el campo no pierda el foco
    caja.addEventListener("click", (ev) => {
      const d = ev.target.closest(".sug");
      if (d) app.buscar(sug.lista[+d.dataset.i], null, ev.ctrlKey || ev.metaKey);
    });
    caja.addEventListener("auxclick", (ev) => {
      const d = ev.target.closest(".sug");
      if (d && ev.button === 1) { ev.preventDefault(); app.buscar(sug.lista[+d.dataset.i], null, true); }
    });
    $("#limpiar").addEventListener("click", () => { campo.value = ""; $("#limpiar").hidden = true; cerrarSugerencias(); campo.focus(); });
    $("#b-voz").addEventListener("click", () => app.buscarPorVoz());
    $("#b-lupa").addEventListener("click", (ev) => app.buscar(campo.value, null, ev.ctrlKey || ev.metaKey));
    $("#campana").addEventListener("click", () => app.abrirCampana());
  }

  // la campana (_abrir_campana 4049): vacía el número y lleva a Suscripciones · No vistos
  app.ponerNovedades = function (n) {
    n = +n || 0;
    const c = $("#campana-n");
    c.textContent = n ? String(n > 99 ? "99+" : n) : "";
    c.hidden = !n;
    app.novedades = n;
  };
  app.abrirCampana = async function () {
    app.ponerNovedades(0);
    api.get("/api/novedades").catch(() => {});
    return app.ir("suscripciones", ["No vistos"]);
  };
  app.ponerSincro = function (texto) {
    const s = String(texto || "");
    $("#sincro").textContent = s ? "⟳ " + s.replace("Sincronizado a las", "sincronizado").split(" (")[0] : "";
    $("#sincro").title = s;
  };

  // ------------------------------------------------------------------------------------------------ eventos del servidor
  let relojCanales = 0;
  async function refrescarCanales() {
    try {
      const e = await api.get("/api/estado");
      const antes = (app.canales || []).map((c) => c.url).join("\n");
      const musica = !!e.hay_musica, cambiaMusica = musica !== !!app.hayMusica;
      app.hayMusica = musica;
      if (cambiaMusica || (e.canales || []).map((c) => c.url).join("\n") !== antes) pintarMenu(e.canales || []);
      app.ponerSincro(e.sincro);
    } catch (err) { /* nada */ }
  }
  app.refrescarCanales = () => { clearTimeout(relojCanales); relojCanales = setTimeout(refrescarCanales, 400); };
  let cerrando = false;
  async function alCerrar() {
    if (cerrando) return;
    cerrando = true;
    try { if (typeof app.ganchos.guardar === "function") await Promise.race([app.ganchos.guardar(), new Promise((r) => setTimeout(r, 1500))]); } catch (e) { /* nada */ }
    try { await P().guardar(true); } catch (e) { /* nada */ }
    try { await C.medir.enviar(true); } catch (e) { /* nada */ }
    try { await api.post("/api/guardado", {}); } catch (e) { /* nada */ }
    cerrando = false;
  }
  app.alCerrar = alCerrar;
  // un enlace de fuera (instancia única, argv, navegador del sistema). Lo decide la página (la ventana no sabe qué suena):
  // con un vídeo cargado, pestaña nueva (05/10/2026); al arrancar, también si se reabrieron pestañas (no pisa ninguna)
  const colaAbrir = [];
  function abrirDeFuera(d, deArranque) {
    const g = window.Reproductor && window.Reproductor.gestor;
    const suena = !!(g && g.lista.some((r) => r.actual && !r._segundo));
    const ps = (P() && P().lista) || [];
    const pa = activa();
    const arriba = pa && pa.pila.length ? pa.pila[pa.pila.length - 1] : null;
    const ocupada = deArranque && (ps.length > 1 || !!(arriba && arriba.f !== "inicio"));
    Promise.resolve().then(() => app.abrirEnlace(d.url, !!d.nueva || suena || ocupada))
      .catch((e) => { console.warn("abrir enlace", e); app.avisar("No he podido abrir el enlace"); });
  }
  // el estado del remoto (F9, casilla de Ajustes y check del menú ⚙): uno solo, el de ajustes.apagar_remoto del servidor
  app.ponerRemoto = function (apagado) {
    apagado = !!apagado;
    app.ajustes = app.ajustes || {};
    app.ajustes.apagar_remoto = apagado;
    if (app.estado) app.estado.remoto = apagado;
    const g = window.Reproductor && window.Reproductor.gestor;
    if (g && g.ajustes) g.ajustes.apagar_remoto = apagado;
    const m7 = window.CatodeM7;
    if (m7 && m7._ajustes) m7._ajustes.apagar_remoto = apagado;
    for (const c of document.querySelectorAll("input.aj-remoto")) c.checked = apagado;
  };
  app.remotoApagado = () => !!(app.ajustes && app.ajustes.apagar_remoto);
  app.ultimosEventos = [];   // los 50 últimos eventos del servidor (para las pruebas y para depurar)
  function alEvento(tipo, d) {
    app.ultimosEventos.push({tipo, d, h: Date.now()});
    if (app.ultimosEventos.length > 50) app.ultimosEventos.shift();
    if (tipo === "cerrar") alCerrar();
    else if (tipo === "aviso" && d.texto) app.avisar(d.texto);
    else if (tipo === "sincro") app.ponerSincro(d.estado ? d.estado : "");
    else if (tipo === "descarga") C.avisos.descarga(d);
    else if (tipo === "novedades") app.ponerNovedades(d.n);
    else if (tipo === "datos") app.refrescarCanales();
    else if (tipo === "ajustes" && d.ajustes) {   // 22/10/2026 (cuenta única): ajustes cambiados en otro equipo
      const g = window.Reproductor && window.Reproductor.gestor;
      if (g && g.ajustes) Object.assign(g.ajustes, d.ajustes);
      Object.assign(app.ajustes || (app.ajustes = {}), d.ajustes);
      if (d.avisar) app.avisar("Ajustes cambiados en otro equipo: " + Object.keys(d.ajustes).sort().join(", "));
    }
    else if (tipo === "abrir" && d.url) { if (app.listo) abrirDeFuera(d, false); else colaAbrir.push(d); }   // antes de listo: en cola
    else if (tipo === "abrir_campana") app.abrirCampana();   // M8: clic en el aviso de la bandeja (VentanaWeb)
    else if (tipo === "remoto") {
      if (typeof d.apagado === "boolean") app.ponerRemoto(d.apagado);
      app.avisar(d.apagado ? "Remoto apagado (F9 para encenderlo)" : "Remoto encendido: el portátil vuelve a conectar solo");
    }
    else if (tipo === "voz" && d.texto) { const c = $("#campo"); c.value = d.texto; voz.activa = true; vozCambio(); }
    else if (tipo === "tecla" && d.nombre && C.atajos) C.atajos.multimedia(d.nombre);
    else if (tipo === "ventana" && typeof d.completa === "boolean") {
      const o = app._ordenCompleta;
      if (typeof d.n === "number" && d.n < app._ventanaN) return;   // viejo: ni se aplica ni se reparte a los módulos
      if (o && performance.now() - o.t < 1500 && d.completa !== o.si) return;   // intermedio: lo decide la respuesta de la orden
      aplicarCompleta(d.completa, d.n);
    } else if (tipo === "actualizacion" && d.estado) app.avisar(d.estado);
    emitir(tipo, d);
  }

  // ------------------------------------------------------------------------------------------------ arranque
  // errores de JS al evaluar un módulo (s.onerror solo salta con errores de red): sin «lista» → vuelta a la Qt
  const erroresModulo = [];
  let modulosCompletos = true;
  addEventListener("error", (ev) => {
    if (app.listo || !ev || !ev.filename || !/\/js\/[\w]+\.js/.test(ev.filename)) return;
    erroresModulo.push(String(ev.filename).replace(/^.*\/js\//, "").replace(/\?.*$/, "") + ": " + (ev.message || "error"));
  });
  function cargarModulos() {
    const v = VERSION ? "?v=" + VERSION : "";
    for (const h of HOJAS) {
      const l = document.createElement("link");
      l.rel = "stylesheet"; l.href = h + v;
      l.onerror = () => l.remove();
      document.head.appendChild(l);
    }
    const promesas = MODULOS.map((m) => new Promise((ok) => {
      const s = document.createElement("script");
      s.src = m + v;
      s.async = false;   // en orden
      s.onload = () => ok(m);
      s.onerror = () => { s.remove(); ok(null); };
      document.body.appendChild(s);
    }));
    // tope de 9 s (la ventana espera «lista» 10 s desde que hay controlador): si vence, sin «lista»
    return Promise.race([Promise.all(promesas), new Promise((ok) => setTimeout(() => { modulosCompletos = false; ok([]); }, 9000))]);
  }

  // 06/10/2026 (perfil de uso): los módulos se bajan EN PARALELO con /api/estado (antes empezaban al volver esta) y se
  // evalúan después, en orden, con cargarModulos (que los encuentra ya bajados). Las hojas, a la caché HTTP (rejilla.js
  // busca su <link> por href: un <link rel=preload> la engañaría)
  function precargar() {
    if (new URLSearchParams(location.search).get("modulos") === "0") return;
    const v = VERSION ? "?v=" + VERSION : "";
    for (const m of MODULOS) {
      const l = document.createElement("link");
      l.rel = "preload"; l.as = "script"; l.href = m + v;
      document.head.appendChild(l);
    }
    for (const h of HOJAS.concat(["css/rejilla.css", "css/mandos.css"])) fetch(h + v).catch(() => {});
  }

  // y el Inicio, si es lo que se va a ver: se pide al servidor mientras se evalúan los módulos (M5.api lo recoge una vez)
  function precargarInicio(e) {
    if (new URLSearchParams(location.search).get("modulos") === "0") return;
    const g = (e && e.pestanas) || [];
    const en = g.length ? g[Math.min(Math.max(0, parseInt(e.pestana_activa, 10) || 0), g.length - 1)] : {f: "inicio", a: []};
    if (!en || en.f !== "inicio" || (en.a && en.a.length)) return;
    const ruta = "/api/pagina/inicio?tema=Todo&recargar=0";
    const p = fetch(api.url(ruta), {headers: {"X-Catode": api.token}}).then(async (r) => {
      let d;
      try { d = await r.json(); } catch (x) { d = {ok: false, error: "Respuesta no válida (" + r.status + ")", clase: "servidor_autor"}; }
      if (d && d.ok === undefined) d.ok = r.ok;
      return d;
    }).catch((err) => ({ok: false, error: String((err && err.message) || err), clase: "sin_red", reintentar: 15}));
    C.precarga = {ruta, t: performance.now(), p};
  }

  async function arrancar() {
    try { precargar(); } catch (err) { /* nada: se bajan al cargarlos */ }
    C.medir.arrancar();
    prepararBarra();
    prepararMenu();
    pintarMenu([]);
    let e = {};
    try { e = await api.get("/api/estado"); } catch (err) { app.avisar(err.message); }
    app.estado = e;
    app.ajustes = e.ajustes || {};
    app.so = e.so || "";
    app.escala = +(app.ajustes.escala || 1) || 1;
    document.body.dataset.so = app.so;
    app.hayMusica = !!e.hay_musica;
    pintarMenu(e.canales || []);
    app.ponerSincro(e.sincro || "");
    app.ponerNovedades(e.novedades || 0);
    try { precargarInicio(e); } catch (err) { /* nada: lo pedirá la página */ }
    api.escuchar(alEvento);
    // ?modulos=0: solo el marco (las pruebas del módulo M4, pruebas/web/m4.py)
    const cargados = new URLSearchParams(location.search).get("modulos") === "0" ? [] : await cargarModulos();
    app.modulos = (cargados || []).filter(Boolean);
    for (const [n, f] of Object.entries(window.catodePaginas || {})) if (!app.paginas[n]) app.registrar(n, f);
    let roto = "";
    try { P().reabrirGuardadas(e); } catch (err) { roto = "reabrir: " + err; console.error("reabrir", err); }
    emitir("listo", e);
    app.listo = true;
    while (colaAbrir.length) abrirDeFuera(colaAbrir.shift(), true);   // el enlace con el que se abrió, tras reabrir
    // «lista» SOLO con los módulos evaluados sin errores y las pestañas reabiertas: si no, no se manda y la ventana vuelve
    // a la Qt a los 10 s (y el vigía cuenta el arranque fallido)
    if (!roto && erroresModulo.length) roto = "módulos: " + erroresModulo.join(" | ");
    if (!roto && !modulosCompletos) roto = "módulos sin cargar a tiempo";
    if (roto) { console.error("arranque roto, sin «lista»: " + roto); app.arranqueRoto = roto; return; }
    try {
      await api.post("/api/lista", {});   // sin esto la ventana vuelve a la Qt a los 10 s
      C.medir.marca("arranque:lista", performance.now());
    } catch (err) { console.warn("lista", err); }
    novedadesVersion(e.novedades_version);
  }

  /** 22/10/2026 (el autor: «ni hay mensaje con novedades de versión») · lo nuevo de esta versión, UNA vez por aparato y
   *  cuando ya se ha ido el logo de arranque. */
  async function novedadesVersion(n) {
    if (!n || !(n.puntos || []).length || !window.Menu || !window.Menu.novedades) return;
    for (let i = 0; i < 40 && document.getElementById("arranque"); i++) await new Promise((r) => setTimeout(r, 250));
    await window.Menu.novedades("Novedades de Cat-ode " + n.version, n.puntos);
    try { await api.post("/api/novedades_vistas", {}); } catch (err) { console.warn("novedades", err); }
  }

  // ganchos globales: Ctrl+rueda (zoom), botones 4/5 del ratón, pegar un enlace, menú del navegador fuera de campos
  addEventListener("wheel", (ev) => {
    if (ev.ctrlKey && ev.deltaY) { ev.preventDefault(); app.ponerEscala(app.escala + (ev.deltaY < 0 ? 0.1 : -0.1)); }
  }, {passive: false});
  addEventListener("mouseup", (ev) => {
    if (ev.button === 3 || ev.button === 4) { ev.preventDefault(); if (ev.button === 3) app.volver(); else app.adelante(); }
  });
  document.addEventListener("paste", (ev) => {
    if (editable(ev.target) || editable(document.activeElement)) return;
    ev.preventDefault();
    app.pegarEnlace((ev.clipboardData && ev.clipboardData.getData("text")) || "");
  });
  // clic derecho: lo que se abre con el central y no tiene menú propio → «Abrir» / «Abrir en pestaña nueva» (raton.js)
  document.addEventListener("contextmenu", (ev) => {
    if (editable(ev.target)) return;
    const propio = ev.defaultPrevented;
    ev.preventDefault();
    if (propio || !C.raton || !C.raton.abreConCentral(ev.target)) return;
    const n = ev.target, x = ev.clientX, y = ev.clientY;
    app.menu([{texto: "Abrir", accion: () => C.raton.clic(n, {clientX: x, clientY: y})},
      {texto: "⧉  Abrir en pestaña nueva", accion: () => C.raton.central(n, {clientX: x, clientY: y})}], x, y);
  });

  app.arrancar = arrancar;
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", arrancar);
  else setTimeout(arrancar, 0);
})();
