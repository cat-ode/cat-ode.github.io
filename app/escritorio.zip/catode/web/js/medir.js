// Cat-ode escritorio · interfaz web: tiempos medidos con la Performance API → POST /api/medidas [{n, ms, t}] → medidas.jsonl
// (módulo M4, DISENO_WEB.md §2.3 y §6.2). Qué se apunta:
//   arranque:dom, arranque:carga (Navigation Timing), arranque:lista (hasta POST /api/lista), arranque:pintada (primera
//   página pintada), pagina:<f> (cada navegación, hasta pintar), api:<ruta> (ida y vuelta) y servidor:<ruta> (Server-Timing),
//   tarea_larga (long tasks > 50 ms, PerformanceObserver) y lo que pidan otros módulos con catode.medir.marca(n, ms).
// Se envía en tandas cada 10 s y al cerrar (keepalive). Nunca rompe nada: todo va en try.
"use strict";
(function () {
  const C = window.catode = window.catode || {};
  const cola = [];
  const ultimas = [];   // las 200 últimas, para las pruebas (catode.medir.ultimas)
  let enviando = false;

  function marca(n, ms, extra) {
    try {
      const m = Object.assign({n: String(n), ms: Math.round((+ms || 0) * 10) / 10, t: Date.now()}, extra || {});
      cola.push(m);
      ultimas.push(m);
      if (ultimas.length > 200) ultimas.shift();
      if (cola.length > 500) cola.splice(0, cola.length - 500);
      try { performance.mark("cat:" + m.n); } catch (e) { /* sin marcas en este navegador */ }
    } catch (e) { /* nada */ }
  }

  // empezar("pagina:inicio") → fin() apunta lo que ha tardado
  function empezar(n) {
    const t0 = performance.now();
    let hecho = false;
    return (extra) => { if (!hecho) { hecho = true; marca(n, performance.now() - t0, extra); } };
  }

  // lo llama api.js tras cada petición: ida y vuelta y, si viene, la cabecera Server-Timing (api;dur=…)
  function api(ruta, ms, servidor) {
    const r = String(ruta).split("?")[0];
    if (r === "/api/medidas") return;
    marca("api:" + r, ms);
    const m = /dur=([\d.]+)/.exec(servidor || "");
    if (m) marca("servidor:" + r, +m[1]);
  }

  async function enviar(alCerrar) {
    if (enviando || !cola.length || !C.api) return;
    enviando = true;
    const lote = cola.splice(0, cola.length);
    try {
      await C.api.post("/api/medidas", lote, {keepalive: !!alCerrar});
    } catch (e) {
      if (!alCerrar && cola.length < 400) cola.unshift(...lote);
    } finally { enviando = false; }
  }

  function arrancar() {
    try {
      const nav = performance.getEntriesByType("navigation")[0];
      if (nav) {
        marca("arranque:dom", nav.domContentLoadedEventEnd || performance.now());
        if (nav.loadEventEnd) marca("arranque:carga", nav.loadEventEnd);
        else addEventListener("load", () => setTimeout(() => {
          const n2 = performance.getEntriesByType("navigation")[0];
          marca("arranque:carga", (n2 && n2.loadEventEnd) || performance.now());
        }, 0), {once: true});
      }
    } catch (e) { /* nada */ }
    try {
      if (window.PerformanceObserver && PerformanceObserver.supportedEntryTypes &&
          PerformanceObserver.supportedEntryTypes.includes("longtask")) {
        new PerformanceObserver((lista) => {
          for (const e of lista.getEntries()) marca("tarea_larga", e.duration, {inicio: Math.round(e.startTime)});
        }).observe({type: "longtask", buffered: true});
      }
    } catch (e) { /* nada */ }
    // 06/10/2026 · arranque:tarjetas: la primera tarjeta visible de la pestaña activa, ya pintada (rAF + tarea). Es lo que
    // el autor ve como «ya ha arrancado»; arranque:pintada solo dice que la página devolvió su esqueleto
    try {
      let hecho = false;
      const mo = new MutationObserver(() => {
        if (hecho) return;
        const n = document.querySelector(".pestana-cuerpo.activa .tj");
        if (n && n.offsetParent !== null) {
          hecho = true; mo.disconnect();
          requestAnimationFrame(() => setTimeout(() => marca("arranque:tarjetas", performance.now()), 0));
        }
      });
      mo.observe(document.documentElement, {childList: true, subtree: true});
      setTimeout(() => { if (!hecho) { hecho = true; mo.disconnect(); } }, 60000);
    } catch (e) { /* nada */ }
    setInterval(() => enviar(false), 10000);
  }

  C.medir = {marca, empezar, api, enviar, arrancar, ultimas, cola, enviando: () => enviando};
})();
