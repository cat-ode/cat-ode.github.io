// Cat-ode escritorio · interfaz web: el logo animado al abrir (22/10/2026). Orden del autor (19/10/2026): «Haz un logotipo en
// blender para cuando se abre, como hemos hecho con Dos Gatos y Rosbel's delight al iniciarla. Algo guapo, que mole» y
// (21/10/2026) «una figura giratoria en 3D con mucho brilli brilli»; (22/10/2026) «tiene demasiado brilli brilli» → menos chispas
// y sin fogonazo blanco. El vídeo (arte/arranque/blender/giro.py → WebM VP9 con
// alfa) suena una vez sobre el fondo de la app, se queda un momento en el logo quieto y se funde. Nunca estorba: no recoge
// clics (pointer-events: none), un clic o una tecla lo quitan, y como mucho dura 7 s aunque el vídeo no llegue a cargar.
"use strict";
(function () {
  const capa = document.getElementById("arranque");
  if (!capa) return;
  const v = capa.querySelector("video");
  let hecho = false;
  function quitar(motivo) {
    if (hecho) return;
    hecho = true;
    capa.classList.add("fuera");
    setTimeout(() => { capa.remove(); }, 600);
    try { console.debug("Cat-ode arranque: " + motivo); } catch (e) {}
  }
  // un <video> sin póster se ve como un cuadro gris con «play» hasta el primer fotograma (Dos Gatos 7.8.1): póster transparente
  v.poster = "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7";
  v.muted = true; v.playsInline = true;
  v.addEventListener("ended", () => setTimeout(() => quitar("acabado"), 500));
  v.addEventListener("error", () => quitar("sin vídeo"));
  v.src = "arranque/arranque.webm";
  const p = v.play();
  if (p && p.catch) p.catch(() => quitar("no arranca"));
  setTimeout(() => quitar("tope de 7 s"), 7000);
  for (const ev of ["mousedown", "keydown", "wheel", "touchstart"]) window.addEventListener(ev, () => quitar(ev), {once: true, capture: true});
})();
