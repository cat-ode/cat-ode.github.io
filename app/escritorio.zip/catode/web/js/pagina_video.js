// Cat-ode escritorio · interfaz web, módulo M7 (06/10/2026, DISENO_WEB.md §3): la página del vídeo (PaginaVideo,
// interfaz.py 533-1178) y la base común del módulo (utilidades y «talones» de lo que aún no exista de M4/M5/M6).
//
// Contrato hacia fuera (lo que usan M4 y M8):
//   window.CatodeM7.paginas.video(contenedor, a) → {salir(), titulo, url}; a = [url | elemento, {t, sonar}]
//   (también se copia en window.catode.paginas.video al cargar la página). salir() deja el vídeo en el mini.
//   CatodeM7.abrirVideo(e, {t, nueva}) · CatodeM7.fulminar(url, nombre) · CatodeM7.alternarCine()
// Lo que usa de otros módulos, siempre al llamarlo (el orden de carga de los <script> da igual):
//   catode.ir(f, a, {nueva}) y catode.atras() (M4) · catode.avisar(texto) (M4) · catode.on(tipo, fn) (SSE de M4)
//   catode.reproductor (M6: reproducir, todo, encolar, saltar_a, siguiente, parar, alternar, ir_a, bucle, cola, i,
//   actual, on(evento, fn)) · catode.menus.video(e, x, y) y catode.menus.compartir(e, x, y, t) (M5).
//   Si falta alguno, aquí (o en flotante.js para el reproductor) hay un talón mínimo que hace lo justo.
"use strict";
(function () {
  const M7 = window.CatodeM7 = window.CatodeM7 || {};
  M7.paginas = M7.paginas || {};
  M7.registro = M7.registro || [];   // navegaciones y avisos (para las pruebas)

  // ------------------------------------------------------------------ utilidades
  // 06/10/2026 (perfil de uso): «1.234.567» y «4,3 mil» sin Intl ni toLocaleString: el primer formateador de ICU para
  // es-ES costaba ≈ 30 ms en el ProBook (el triple en el N100) en el cuadro que pinta la página del vídeo. Mismo
  // resultado que es-ES: punto de miles solo desde 5 cifras (1234, 12.345) y coma decimal
  const conPuntos = (n) => { const x = Math.round(Math.abs(n)); let t = String(x);
    if (t.length >= 5) t = t.replace(/\B(?=(\d{3})+(?!\d))/g, "."); return (n < 0 && x ? "-" : "") + t; };
  const conComa = (v, dec) => { const x = dec ? Math.round(v * 10) / 10 : Math.round(v); const ent = Math.trunc(x);
    const fr = Math.round(Math.abs(x - ent) * 10); return conPuntos(ent) + (fr ? "," + fr : ""); };
  const U = M7.util = {
    el(tag, props, ...hijos) {
      const n = document.createElement(tag);
      for (const [k, v] of Object.entries(props || {})) {
        if (v === undefined || v === null || v === false) continue;
        if (k === "class") n.className = v;
        else if (k === "text") n.textContent = v;
        else if (k === "style") n.style.cssText = v;
        else if (k.startsWith("on") && typeof v === "function") n.addEventListener(k.slice(2), v);
        else if (k === "hidden") n.hidden = true;
        else n.setAttribute(k, v === true ? "" : v);
      }
      for (const h of hijos.flat()) if (h !== null && h !== undefined && h !== false) n.append(h instanceof Node ? h : String(h));
      return n;
    },
    tiempo(s) {
      s = Math.max(0, Math.floor(Number(s) || 0));
      const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = String(s % 60).padStart(2, "0");
      return h ? `${h}:${String(m).padStart(2, "0")}:${x}` : `${m}:${x}`;
    },
    miles(n) { n = Number(n); return isFinite(n) ? conPuntos(n) : String(n); },
    corto(n) {   // 4321 → «4,3 mil», como metadatos.cifra
      n = Number(n);
      if (!isFinite(n) || n < 0) return "";
      if (n < 1000) return String(n);
      if (n < 1e6) return conComa(n / 1000, n < 1e4) + " mil";
      return conComa(n / 1e6, n < 1e7) + " M";
    },
    segundos(txt) {   // «1:02:03» / «2:03» → segundos
      const p = String(txt).split(":").map(Number);
      return p.reduce((a, b) => a * 60 + b, 0);
    },
    // texto plano → nodos con enlaces (URL) y minutos («0:08») que se pueden pulsar (fichas._texto_con_enlaces)
    enlazar(texto, alMinuto, alEnlace) {
      const f = document.createDocumentFragment();
      const re = /(https?:\/\/[^\s<]+)|(\b(?:\d{1,2}:)?\d{1,2}:\d{2}\b)/g;
      let i = 0, m;
      texto = String(texto || "");
      while ((m = re.exec(texto))) {
        if (m.index > i) f.append(texto.slice(i, m.index));
        if (m[1]) f.append(U.enlace(m[1], m[1], alEnlace));
        else f.append(U.minuto(m[2], alMinuto));
        i = m.index + m[0].length;
      }
      if (i < texto.length) f.append(texto.slice(i));
      return f;
    },
    minuto(txt, alMinuto) {
      return U.el("a", {class: "m7-minuto", href: "#", text: txt, onclick: (ev) => { ev.preventDefault(); alMinuto && alMinuto(U.segundos(txt), ev); },
        onauxclick: (ev) => { if (ev.button === 1) { ev.preventDefault(); alMinuto && alMinuto(U.segundos(txt), ev); } }});
    },
    enlace(href, texto, alEnlace) {
      return U.el("a", {class: "m7-enlace", href, text: texto, title: href,
        onclick: (ev) => { ev.preventDefault(); (alEnlace || M7.abrirEnlace)(href, ev.ctrlKey || ev.metaKey); },
        onauxclick: (ev) => { if (ev.button === 1) { ev.preventDefault(); (alEnlace || M7.abrirEnlace)(href, true); } }});
    },
    // HTML del servidor (descripción, datos técnicos) → nodos con solo etiquetas inocuas; los enlaces, a abrirEnlace
    limpiarHtml(html, alMinuto) {
      const doc = new DOMParser().parseFromString(`<div>${html || ""}</div>`, "text/html");
      const permitidas = new Set(["A", "BR", "B", "I", "EM", "STRONG", "SPAN", "P", "DIV", "TABLE", "TBODY", "TR", "TD", "TH", "UL", "OL", "LI", "SMALL", "FONT"]);
      const copiar = (n) => {
        if (n.nodeType === 3) {
          return /\b(?:\d{1,2}:)?\d{1,2}:\d{2}\b/.test(n.data) && alMinuto ? U.enlazar(n.data, alMinuto) : document.createTextNode(n.data);
        }
        if (n.nodeType !== 1) return null;
        if (!permitidas.has(n.tagName)) { const f = document.createDocumentFragment(); n.childNodes.forEach((h) => { const c = copiar(h); if (c) f.append(c); }); return f; }
        let x;
        if (n.tagName === "A") {
          const href = n.getAttribute("href") || "";
          const t = /[?&]t=(\d+)/.exec(href);
          x = t && alMinuto && /youtu/.test(href) && /^\d/.test(n.textContent.trim()) ? U.minuto(n.textContent, () => alMinuto(Number(t[1]))) : U.enlace(href, "", null);
          x.textContent = "";
        } else {
          x = document.createElement(n.tagName);
          for (const at of ["style", "colspan", "valign", "align"]) if (n.hasAttribute(at)) x.setAttribute(at, n.getAttribute(at));
        }
        n.childNodes.forEach((h) => { const c = copiar(h); if (c) x.append(c); });
        return x;
      };
      return copiar(doc.body.firstChild);
    },
    elemento(x) {   // url o dict → Elemento mínimo del contrato
      if (typeof x === "string") return {tipo: "VIDEO", url: x, titulo: "", autor: "", autorUrl: "", miniatura: "", duracion: -1, detalle: "", fecha: 0};
      return Object.assign({tipo: "VIDEO", titulo: "", autor: "", autorUrl: "", miniatura: "", duracion: -1, detalle: "", fecha: 0}, x || {});
    },
  };

  // ------------------------------------------------------------------ servidor (fetch con token, §2.1/§2.2)
  M7.cat = () => window.catode || {};
  M7.token = () => M7.cat().token || new URLSearchParams(location.search).get("t") || "";
  M7.base = () => M7.cat().base || location.origin;
  M7.api = async function (ruta, cuerpo, metodo, senal) {
    let r;
    try {
      r = await fetch(M7.base() + ruta, {
        method: metodo || (cuerpo === undefined ? "GET" : "POST"), signal: senal,
        headers: Object.assign({"X-Catode": M7.token()}, cuerpo === undefined ? {} : {"Content-Type": "application/json"}),
        body: cuerpo === undefined ? undefined : JSON.stringify(cuerpo),
      });
    } catch (err) {
      if (err && err.name === "AbortError") throw err;
      return {ok: false, error: "No hay conexión con Cat-ode", clase: "sin_red", reintentar: 15};
    }
    if (r.status === 204) return {ok: true};
    try { return await r.json(); } catch (e) { return {ok: false, error: `Respuesta no válida (${r.status})`, clase: "imposible"}; }
  };
  M7.ventana = (accion, valor) => M7.api("/api/ventana", {accion, valor});
  M7.avisar = function (texto) {
    M7.registro.push({aviso: texto});
    const c = M7.cat(), app = window.app;
    if (app && typeof app.avisar === "function") return app.avisar(texto);
    if (typeof c.avisar === "function") return c.avisar(texto);
    // talón (M4 pinta los avisos de verdad): una línea abajo durante 3,5 s
    let caja = document.getElementById("m7-aviso");
    if (!caja) { caja = U.el("div", {id: "m7-aviso", class: "m7-aviso", role: "status"}); document.body.append(caja); }
    caja.textContent = texto;
    caja.classList.add("visible");
    clearTimeout(caja._t);
    caja._t = setTimeout(() => caja.classList.remove("visible"), 3500);
  };
  M7.fallo = function (r, que) {   // {ok:false, error, clase} → aviso por clase (api.js de M4 pinta el cartel)
    const c = M7.cat();
    if (typeof c.cartel === "function") { try { c.cartel(r); return; } catch (e) { /* sigue */ } }
    const txt = r.clase === "bloqueo" ? "YouTube está frenando las peticiones: no reintento solo." :
      r.clase === "sin_red" ? "Sin conexión: " + (r.error || que) : (r.error || que || "No ha salido");
    M7.avisar(txt);
  };
  // eventos del servidor (SSE): los de M4 si los hay; si no, una sola conexión propia
  M7.on = function (tipo, fn) {
    const c = M7.cat(), app = window.app;
    if (app && typeof app.on === "function") { app.on(tipo, fn); return () => { if (typeof app.off === "function") app.off(tipo, fn); }; }
    if (typeof c.on === "function") return c.on(tipo, fn);
    if (!M7._es) {
      M7._oyentes = {};
      try {
        M7._es = new EventSource(M7.base() + "/api/eventos?t=" + encodeURIComponent(M7.token()));
      } catch (e) { M7._es = {addEventListener() {}}; }
    }
    if (!M7._oyentes[tipo]) {
      M7._oyentes[tipo] = [];
      M7._es.addEventListener(tipo, (ev) => {
        let d = {}; try { d = JSON.parse(ev.data); } catch (e) { /* vacío */ }
        for (const f of M7._oyentes[tipo].slice()) try { f(d); } catch (e) { console.warn(e); }
      });
    }
    M7._oyentes[tipo].push(fn);
    return () => { const l = M7._oyentes[tipo]; const k = l.indexOf(fn); if (k >= 0) l.splice(k, 1); };
  };
  // ajustes (escritorio-ajustes.json): leídos una vez y escritos clave a clave con PUT
  M7._ajustes = null;
  M7.ajustes = async function (recargar) {
    if (!M7._ajustes || recargar) {
      const r = await M7.api("/api/ajustes");
      M7._ajustes = r.ok ? (r.ajustes || {}) : (M7._ajustes || {});
    }
    return M7._ajustes;
  };
  M7.ajuste = (clave, defecto) => (M7._ajustes && clave in M7._ajustes) ? M7._ajustes[clave] : defecto;
  M7.ponerAjuste = async function (clave, valor) {
    (M7._ajustes = M7._ajustes || {})[clave] = valor;
    const g = window.Reproductor && window.Reproductor.gestor;   // M6 lee automatica, calidad, reanudar… de aquí
    if (g && g.ajustes && typeof g.ajustes === "object") g.ajustes[clave] = valor;
    const r = await M7.api("/api/ajustes", {[clave]: valor}, "PUT");
    if (r.ok && r.ajustes) M7._ajustes = r.ajustes;
    else if (!r.ok) M7.fallo(r, "No he podido guardar el ajuste");
    for (const f of M7._alAjuste || []) try { f(clave, valor); } catch (e) { /* nada */ }
    return r;
  };
  M7.alAjuste = (fn) => { (M7._alAjuste = M7._alAjuste || []).push(fn); return () => { M7._alAjuste = M7._alAjuste.filter((x) => x !== fn); }; };

  // ------------------------------------------------------------------ navegación (talón si no hay router de M4)
  M7.ir = function (f, a, op) {
    op = op || {};
    a = a || [];
    M7.registro.push({ir: f, a, nueva: !!op.nueva});
    const app = window.app;
    if (app && typeof app.ir === "function") {   // el marco de M4: sus nombres son los de interfaz.py
      if (f === "video") return app.abrirVideo(a[0], {sonar: !!(a[1] && a[1].sonar), desde: a[1] && a[1].t, nueva: !!op.nueva});
      if (f === "canal") return app.abrirCanal(a[0], !!op.nueva);
      if (f === "buscar" && typeof app.buscar === "function") return app.buscar(a[0], null, !!op.nueva);
      const nombres = {ajustes: "ajustes_pagina", lista_yt: "_lista_yt", lista_propia: "_lista_propia"};
      return app.ir(nombres[f] || f, a, {nueva: !!op.nueva});
    }
    const c = M7.cat();
    if (typeof c.ir === "function") return c.ir(f, a, op);
    return M7._talonIr(f, a, op);
  };
  M7._pila = [];
  M7._talonIr = function (f, a) {
    const cont = document.getElementById("m7-paginas") || document.querySelector("main") || document.body;
    if (!M7.paginas[f]) { M7.avisar(`(sin marco) ir a «${f}»`); return; }
    if (M7._actual && M7._actual.salir) M7._actual.salir();
    if (M7._actual) M7._pila.push(M7._actualDe);
    cont.textContent = "";
    M7._actualDe = {f, a};
    M7._actual = M7.paginas[f](cont, a || []);
    return M7._actual;
  };
  M7.atras = function () {
    if (window.app && typeof window.app.volver === "function") return window.app.volver();
    const c = M7.cat();
    if (typeof c.atras === "function") return c.atras();
    const d = M7._pila.pop();
    if (!d) return;
    if (M7._actual && M7._actual.salir) M7._actual.salir();
    const cont = document.getElementById("m7-paginas") || document.querySelector("main") || document.body;
    cont.textContent = "";
    M7._actualDe = d;
    M7._actual = M7.paginas[d.f](cont, d.a || []);
  };
  M7.abrirVideo = (e, op) => M7.ir("video", [U.elemento(e), {t: op && op.t, sonar: !(op && op.sonar === false)}], {nueva: !!(op && op.nueva)});
  M7.irCanal = (url, nueva) => url && M7.ir("canal", [url], {nueva: !!nueva});
  // enlaces de YouTube en toda la app (abrir_enlace 3730-3768, clasificados por GET /api/enlace)
  M7.abrirEnlace = async function (href, nueva) {
    if (window.app && typeof window.app.abrirEnlace === "function") return window.app.abrirEnlace(href, nueva);
    const r = await M7.api("/api/enlace?url=" + encodeURIComponent(href));
    if (!r.ok) return M7.fallo(r, "No he podido abrir el enlace");
    if (r.tipo === "video") return M7.abrirVideo({url: r.url, titulo: r.titulo || ""}, {t: r.t, nueva});
    if (r.tipo === "canal") return M7.irCanal(r.url, nueva);
    if (r.tipo === "lista") return M7.ir("lista_yt", [r.url, r.titulo || "Lista"], {nueva});
    if (r.tipo === "busqueda" || r.tipo === "hashtag") return M7.ir("buscar", [r.titulo || r.url], {nueva});
    M7.ventana("abrir_fuera", r.url || href);
  };
  // el reproductor de M6 y el talón hablan un poco distinto: estas funciones lo igualan
  M7.oir = function (rep, nombre, fn) {   // → función para dejar de oír
    if (!rep || typeof rep.on !== "function") return () => {};
    if (rep.talon) return rep.on(nombre, fn);
    if (nombre === "pide_mas") return () => {};   // M6 hace la automática él mismo (Reproductor._automatica)
    const n = ({estado: "cambio", cola: "cambio", para: "cambio"})[nombre] || nombre;
    const h = (ev) => fn(nombre === "estado" ? rep.estado : (ev && ev.detail !== undefined ? ev.detail : ev), ev);
    if (typeof rep.addEventListener === "function") { rep.addEventListener(n, h); return () => rep.removeEventListener(n, h); }
    rep.on(n, h);
    return () => {};
  };
  M7.pausar = (rep, p) => (typeof rep.pausar === "function" ? rep.pausar(p) : rep.pausa(p));
  M7.quitarDeCola = (rep, i) => (typeof rep.quitar_de_cola === "function" ? rep.quitar_de_cola(i) : rep.quitar(i));
  M7.moverEnCola = (rep, de, a) => (typeof rep.mover_en_cola === "function" ? rep.mover_en_cola(de, a) : rep.reordenar(de, a));
  M7.silenciar = (rep, m) => { if (rep.talon) rep.silencio(m); else if (!!rep.mute !== !!m) rep.silencio(); };
  M7.rep = () => {   // el reproductor de M6; si no está, el talón de flotante.js
    const c = M7.cat();
    if (c.reproductor && typeof c.reproductor.reproducir === "function") return c.reproductor;
    return M7.talonRep ? M7.talonRep() : null;
  };
  M7.copiar = async function (texto) {
    const r = await M7.ventana("portapapeles", texto);
    if (!r.ok || r.simulado) { try { await navigator.clipboard.writeText(texto); } catch (e) { /* sin permiso: queda el de Qt */ } }
    M7.portapapeles = texto;
    M7.avisar("Enlace copiado");
  };

  // ------------------------------------------------------------------ menús y diálogos propios (talones de M5)
  M7.menu = function (items, x, y) {
    M7.cerrarMenu();
    const m = U.el("div", {class: "m7-menu", role: "menu"});
    for (const it of items) {
      if (!it) { m.append(U.el("div", {class: "m7-menu-sep"})); continue; }
      const b = U.el("button", {class: "m7-menu-item" + (it.marcado ? " marcado" : ""), role: "menuitem", text: it.texto, disabled: it.inactivo || undefined});
      b.addEventListener("click", (ev) => {
        ev.stopPropagation();
        if (it.sub) { M7.menu(it.sub, b.getBoundingClientRect().right, b.getBoundingClientRect().top); return; }
        M7.cerrarMenu(); it.hacer && it.hacer();
      });
      m.append(b);
    }
    document.body.append(m);
    const r = m.getBoundingClientRect();
    m.style.left = Math.max(4, Math.min(x, innerWidth - r.width - 4)) + "px";
    m.style.top = Math.max(4, Math.min(y, innerHeight - r.height - 4)) + "px";
    setTimeout(() => {
      M7._fueraMenu = (ev) => { if (!m.contains(ev.target)) M7.cerrarMenu(); };
      M7._escMenu = (ev) => { if (ev.key === "Escape") { ev.stopPropagation(); M7.cerrarMenu(); } };
      document.addEventListener("mousedown", M7._fueraMenu, true);
      document.addEventListener("keydown", M7._escMenu, true);
    }, 0);
    const primero = m.querySelector("button:not([disabled])");
    if (primero) primero.focus();
    return m;
  };
  M7.cerrarMenu = function () {
    document.querySelectorAll(".m7-menu").forEach((x) => x.remove());
    if (M7._fueraMenu) document.removeEventListener("mousedown", M7._fueraMenu, true);
    if (M7._escMenu) document.removeEventListener("keydown", M7._escMenu, true);
    M7._fueraMenu = M7._escMenu = null;
  };
  // diálogo modal: {titulo, texto, campos:[{etiqueta, valor}], casillas:[{texto, marcado}], botones:[{texto, valor, principal}]}
  M7.dialogo = function (op) {
    return new Promise((fin) => {
      const fondo = U.el("div", {class: "m7-dialogo-fondo"});
      const caja = U.el("div", {class: "m7-dialogo", role: "dialog", "aria-modal": "true"});
      caja.append(U.el("h2", {text: op.titulo || ""}));
      if (op.texto) caja.append(U.el("p", {class: "m7-gris", text: op.texto}));
      const campos = (op.campos || []).map((c) => {
        const i = U.el("input", {type: "text", value: c.valor || "", "aria-label": c.etiqueta});
        caja.append(U.el("label", {class: "m7-campo"}, U.el("span", {text: c.etiqueta}), i));
        return i;
      });
      const casillas = (op.casillas || []).map((c) => {
        const i = U.el("input", {type: "checkbox"}); i.checked = !!c.marcado;
        caja.append(U.el("label", {class: "m7-casilla"}, i, U.el("span", {text: c.texto})));
        return i;
      });
      const cerrar = (valor) => {
        fondo.remove(); document.removeEventListener("keydown", tecla, true);
        fin(valor === null ? null : {boton: valor, campos: campos.map((i) => i.value), casillas: casillas.map((i) => i.checked)});
      };
      const pie = U.el("div", {class: "m7-dialogo-pie"});
      for (const b of op.botones || [{texto: "Cancelar", valor: null}, {texto: "Aceptar", valor: "si", principal: true}]) {
        pie.append(U.el("button", {class: b.principal ? "m7-boton principal" : "m7-boton", text: b.texto, onclick: () => cerrar(b.valor)}));
      }
      caja.append(pie);
      const tecla = (ev) => {
        if (ev.key === "Escape") { ev.preventDefault(); ev.stopPropagation(); cerrar(null); }
        else if (ev.key === "Enter" && ev.target.tagName === "INPUT" && ev.target.type === "text") {
          ev.preventDefault(); const p = (op.botones || []).find((b) => b.principal); cerrar(p ? p.valor : "si");
        }
      };
      document.addEventListener("keydown", tecla, true);
      fondo.append(caja);
      document.body.append(fondo);
      (campos[0] || caja.querySelector(".principal") || caja.querySelector("button")).focus();
    });
  };
  M7.pedirTexto = async (titulo, etiqueta, valor) => {
    const r = await M7.dialogo({titulo, campos: [{etiqueta, valor}]});
    return r && r.boton ? r.campos[0] : null;
  };

  // ------------------------------------------------------------------ acciones sobre vídeos (las comparten las páginas)
  M7.alternar = async function (col, e) {
    const r = await M7.api("/api/datos", {accion: "alternar", col, e});
    if (!r.ok) { M7.fallo(r, "No ha salido"); return null; }
    if (r.puesto && (col === "megusta" || col === "nomegusta")) {   // 👍 y 👎 se excluyen, como en YouTube (interfaz.py 1061)
      await M7.api("/api/datos", {accion: "quitar", url: e.url, col: col === "megusta" ? "nomegusta" : "megusta"});
    }
    const nombres = {despues: "Ver más tarde", megusta: "Me gusta", nomegusta: "No me gusta"};
    M7.avisar(r.puesto ? `Añadido a ${nombres[col]}` : `Quitado de ${nombres[col]}`);
    return r.puesto;
  };
  M7.menuCompartir = function (e, x, y, t) {
    const c = M7.cat(), Menu = window.Menu;
    if (Menu && typeof Menu.compartir === "function" && typeof Menu.abrir === "function") return Menu.abrir(Menu.compartir(e, t > 0 ? Math.floor(t) : 0), x, y);
    if (c.menus && typeof c.menus.compartir === "function") return c.menus.compartir(e, x, y, t);
    const base = e.url;
    const items = [
      {texto: "Copiar enlace", hacer: () => M7.copiar(base)},
      t > 0 ? {texto: `Copiar enlace en el ${U.tiempo(t)}`, hacer: () => M7.copiar(base + (base.includes("?") ? "&" : "?") + "t=" + Math.floor(t))} : null,
      {texto: "Abrir en el navegador", hacer: () => M7.ventana("abrir_fuera", base)},
      {texto: "Enviar a la tele…", hacer: () => M7.aLaTele(e, x, y)},
    ].filter(Boolean);
    return M7.menu(items, x, y);
  };
  M7.aLaTele = async function (e, x, y) {
    const r = await M7.api("/api/tele");
    const teles = (r.ok && r.teles) || [];
    if (!teles.length) return M7.avisar("No encuentro ninguna tele en la red");
    M7.menu(teles.map((tv) => ({texto: tv.nombre, hacer: async () => {
      const p = await M7.api("/api/tele", {accion: "poner", tele: tv, url: e.url});
      M7.avisar(p.ok && p.puesto ? `En la tele: ${tv.nombre}` : "La tele no ha respondido");
    }})), x, y);
  };
  M7.menuListas = function (e, listas, enListas, x, y, alCambiar) {
    const items = (listas || []).map(([clave, nombre]) => {
      const dentro = (enListas || []).includes(clave);
      return {texto: (dentro ? "✓ " : "") + nombre, marcado: dentro, hacer: async () => {
        const r = await M7.api("/api/datos", {accion: "lista", que: dentro ? "quitar" : "poner", clave, e});
        if (!r.ok) return M7.fallo(r);
        M7.avisar(dentro ? `Quitado de «${nombre}»` : `Guardado en «${nombre}»`);
        alCambiar && alCambiar(clave, !dentro);
      }};
    });
    items.push(null, {texto: "＋ Nueva lista…", hacer: async () => {
      const nombre = await M7.pedirTexto("Nueva lista", "Nombre de la lista:");
      if (!nombre || !nombre.trim()) return;
      const r = await M7.api("/api/datos", {accion: "lista", que: "nueva", nombre: nombre.trim(), e});
      if (!r.ok) return M7.fallo(r);
      M7.avisar(`Guardado en «${nombre.trim()}»`);
      alCambiar && alCambiar(r.clave, true, nombre.trim());
    }});
    return M7.menu(items, x, y);
  };
  M7.menuDescargar = function (e, x, y) {
    const pedir = async (alto, solo_audio) => {
      const r = await M7.api("/api/descargar", {e, solo_audio, alto});
      if (!r.ok) return M7.fallo(r, "No he podido descargarlo");
      M7.avisar(`Descargando «${e.titulo || "el vídeo"}»…`);
    };
    return M7.menu([360, 720, 1080].map((a) => ({texto: `${a}p`, hacer: () => pedir(a, false)})).concat([{texto: "Solo sonido", hacer: () => pedir(720, true)}]), x, y);
  };
  M7.menuVideo = function (e, x, y, extra) {
    const c = M7.cat(), Menu = window.Menu;
    if (Menu && typeof Menu.video === "function") return Menu.video(e, x, y);
    if (c.menus && typeof c.menus.video === "function") return c.menus.video(e, x, y);
    return M7.menu([
      {texto: "Abrir en pestaña nueva", hacer: () => M7.abrirVideo(e, {nueva: true})},
      {texto: "Ver más tarde", hacer: () => M7.alternar("despues", e)},
      {texto: "Me gusta", hacer: () => M7.alternar("megusta", e)},
      {texto: "Guardar en una lista…", hacer: () => M7.menuListas(e, extra && extra.listas, extra && extra.enListas, x, y)},
      {texto: "Descargar…", hacer: () => M7.menuDescargar(e, x, y)},
      null,
      {texto: "Copiar enlace", hacer: () => M7.copiar(e.url)},
      {texto: "No me interesa", hacer: async () => { const r = await M7.api("/api/datos", {accion: "ocultar", e}); if (r.ok) M7.avisar("Vale: no te lo volveré a enseñar"); }},
      e.autorUrl || e.autor ? {texto: `⊘ Fulminar el canal «${e.autor || "?"}»`, hacer: () => M7.fulminar(e.autorUrl, e.autor)} : false,
    ].filter((v) => v !== false), x, y);
  };
  // fulminar el canal y, tras preguntar, su entorno (interfaz.py 3068-3130)
  M7.fulminar = async function (url, nombre) {
    if (!url && !nombre) return;
    M7.avisar(`«${nombre || url}» fulminado · buscando su entorno…`);
    const r = await M7.api("/api/datos", {accion: "fulminar", url, nombre});
    if (!r.ok) return M7.fallo(r, "No he podido fulminarlo");
    for (const f of M7._alVetar || []) try { f(); } catch (e) { /* nada */ }
    const entorno = r.entorno || [];
    if (!entorno.length) { M7.avisar(`«${nombre || url}» fulminado`); return {entorno: [], fulminados: 0}; }
    const d = await M7.dialogo({titulo: `Fulminar también el entorno de «${nombre}»`,
      texto: "Canales de su misma burbuja (el % es cuántos de sus relacionados son de este grupo). Marcados los de ≥35 % que no sigues.",
      casillas: entorno.map((c) => ({texto: `${c.nombre} · ${c.pct} %`, marcado: !!c.marcado})),
      botones: [{texto: "Ninguno", valor: "ninguno"}, {texto: "Fulminar los marcados", valor: "si", principal: true}]});
    if (!d || d.boton !== "si") return {entorno, fulminados: 0};
    const urls = entorno.filter((c, i) => d.casillas[i]).map((c) => ({url: c.url, nombre: c.nombre}));
    if (urls.length) {
      const x = await M7.api("/api/datos", {accion: "fulminar_lote", urls});
      if (!x.ok) return M7.fallo(x);
      for (const f of M7._alVetar || []) try { f(); } catch (e) { /* nada */ }
      M7.avisar(`${urls.length} canales más fulminados`);
    }
    return {entorno, fulminados: urls.length};
  };
  M7.alVetar = (fn) => { (M7._alVetar = M7._alVetar || []).push(fn); return () => { M7._alVetar = M7._alVetar.filter((x) => x !== fn); }; };

  // ambiente: dos colores de la miniatura (izquierda y derecha), calculados una vez por imagen (sin blur)
  const coloresCache = new Map();
  M7.ambiente = function (src) {
    if (!src) return Promise.resolve(null);
    if (coloresCache.has(src)) return Promise.resolve(coloresCache.get(src));
    return new Promise((fin) => {
      const img = new Image();
      img.crossOrigin = "anonymous";
      img.decoding = "async";
      img.onload = () => {
        let par = null;
        try {
          const c = document.createElement("canvas"); c.width = 16; c.height = 9;
          const g = c.getContext("2d", {willReadFrequently: true}); g.drawImage(img, 0, 0, 16, 9);
          const media = (x0) => { const d = g.getImageData(x0, 0, 8, 9).data; let r = 0, v = 0, a = 0;
            for (let i = 0; i < d.length; i += 4) { r += d[i]; v += d[i + 1]; a += d[i + 2]; }
            const n = d.length / 4; return `rgb(${Math.round(r / n)}, ${Math.round(v / n)}, ${Math.round(a / n)})`; };
          par = [media(0), media(8)];
        } catch (e) { par = null; }   // imagen de otro origen sin CORS: sin ambiente
        coloresCache.set(src, par); fin(par);
      };
      img.onerror = () => { coloresCache.set(src, null); fin(null); };
      img.src = src;
    });
  };

  // ------------------------------------------------------------------ PaginaVideo
  function PaginaVideo(cont, a, ctx) {
    const el = U.el;
    a = a || [];
    ctx = ctx || {};
    let e = U.elemento(a[0]);
    const op = Object.assign({}, a[1] || {});
    // ¿suena al abrir la página? Con el marco de M4 ya suena antes (app.abrirVideo → ganchos.reproducir), así que la
    // página no reproduce nada salvo que se le pida; una pestaña recordada o reabierta nunca reproduce sola.
    if (op.sonar === undefined) op.sonar = !window.app;
    if (ctx.reabriendo) op.sonar = false;
    const ctl = new AbortController();
    const limpiar = [];
    let ficha = null, completo = null, cargando = null, comentarios = null, transcripcion = null, rel = [];
    let cine = !!M7.ajuste("cine", false);

    const raiz = el("div", {class: "m7 pv" + (cine ? " cine" : ""), tabindex: "-1"});
    const ambiente = el("div", {class: "pv-ambiente"});
    const zona = el("div", {class: "pv-zona"});
    const cartel = el("div", {class: "pv-cartel", hidden: true},
      el("img", {class: "pv-cartel-img", alt: "", decoding: "async"}),
      el("button", {class: "pv-cartel-play", title: "Reproducir aquí", "aria-label": "Reproducir aquí", text: "▶", onclick: () => reproducirAqui()}));
    zona.append(cartel);
    const titulo = el("h1", {class: "pv-titulo"});
    const resumen = el("div", {class: "pv-resumen m7-gris"});
    const avatar = el("div", {class: "pv-avatar"});
    const canalNombre = el("a", {class: "pv-canal-nombre", href: "#"});
    const canalSubs = el("div", {class: "pv-canal-subs m7-gris"});
    const bSuscribir = el("button", {class: "m7-boton pv-suscribir", text: "Suscribirse"});
    const bFulminar = el("button", {class: "m7-boton pv-fulminar", text: "⊘ Fulminar canal", title: "Fuera este canal de todo Cat-ode (y, si quieres, su entorno)"});
    const bMeGusta = el("button", {class: "m7-boton pv-megusta", title: "Me gusta"});
    const bNoMeGusta = el("button", {class: "m7-boton pv-nomegusta", title: "No me gusta"});
    const bCompartir = el("button", {class: "m7-boton pv-compartir", text: "↗ Compartir"});
    const bDespues = el("button", {class: "m7-boton pv-despues", text: "🕒 Ver más tarde"});
    const bGuardar = el("button", {class: "m7-boton pv-guardar", text: "➕ Guardar"});
    const bDescargar = el("button", {class: "m7-boton pv-descargar", text: "⬇ Descargar"});
    const bCine = el("button", {class: "m7-boton pv-cine", text: "▭ Cine", title: "Modo cine (T)"});
    const bMas = el("button", {class: "m7-boton pv-mas", text: "⋯", title: "Más", "aria-label": "Más"});
    const bDatos = el("button", {class: "pv-datos-boton", text: "▸ Datos del vídeo"});
    const datos = el("div", {class: "pv-datos", hidden: true});
    const desc = el("div", {class: "pv-desc plegada"});
    const bDescMas = el("button", {class: "pv-desc-mas", text: "…más", hidden: true});
    const capitulos = el("div", {class: "pv-capitulos", hidden: true});
    const cajaTr = el("div", {class: "pv-transcripcion"});
    const cajaCom = el("div", {class: "pv-comentarios"});
    const info = el("div", {class: "pv-info"},
      titulo, resumen,
      el("div", {class: "pv-fila"},
        el("div", {class: "pv-canal"}, avatar, el("div", {class: "pv-canal-texto"}, canalNombre, canalSubs), bSuscribir, bFulminar),
        el("div", {class: "pv-botones"}, bMeGusta, bNoMeGusta, bCompartir, bDespues, bGuardar, bDescargar, bCine, bMas)),
      el("div", {class: "pv-caja"}, bDatos, datos, desc, bDescMas),
      capitulos, cajaTr, cajaCom);
    const auto = el("input", {type: "checkbox", class: "pv-automatica"});
    const colaTitulo = el("div", {class: "pv-cola-titulo"});
    const colaLista = el("ol", {class: "pv-cola-lista", tabindex: "0"});
    const cola = el("div", {class: "pv-cola", hidden: true}, colaTitulo, colaLista);
    const listaRel = el("div", {class: "pv-rel"});
    const lado = el("aside", {class: "pv-lado"},
      el("div", {class: "pv-lado-cab"}, el("h2", {text: "A continuación"}),
        el("label", {class: "m7-casilla pv-auto"}, auto, el("span", {text: "Reproducción automática"}))),
      cola, listaRel);
    raiz.append(ambiente, zona, info, lado);
    cont.append(raiz);

    const rep = M7.rep();
    // 22/10/2026: una canción importada («cancion:…») cambia de dirección al encontrar su vídeo; antes la página creía que
    // sonaba otra cosa y lo mandaba a la ventanita, con el hueco del vídeo en negro (visto en la tele)
    const dirs = (x) => [x.url, x.cancion].filter(Boolean);   // la de YouTube y, si fue una canción importada, la «cancion:»
    const esActual = () => !!(rep && rep.actual && dirs(rep.actual).some((u) => dirs(e).includes(u)));
    const tiempo = () => (esActual() && rep.estado && rep.estado.t) || 0;
    const saltar = (s, ev) => {
      if (ev && (ev.button === 1 || ev.ctrlKey)) return M7.abrirVideo(e, {t: s, nueva: true});
      if (esActual()) { rep.ir_a(s); M7.pausar(rep, false); } else rep.reproducir(e, s);
      mostrarCartel();
    };

    // ---- vídeo: la capa del reproductor se pone sobre la zona; si suena otro, el cartel con la portada
    function mostrarCartel() {
      const suena = esActual();
      cartel.hidden = suena;
      cartel.querySelector("img").src = e.miniatura || "";
      if (M7.capa && pagina.visible) { if (suena) M7.capa.ponerEn(zona, "video"); else if (rep && rep.actual) M7.capa.mini(); }
    }
    // con pestañas (M4) la página sigue viva al cambiar de pestaña: se mira si se ve
    function revisarVisible() {
      const v = raiz.isConnected && raiz.getClientRects().length > 0;
      if (v && !pagina.visible) pagina.mostrar();
      else if (!v && pagina.visible) pagina.ocultar();
    }
    function reproducirAqui() { if (rep) rep.reproducir(e, op.t); mostrarCartel(); }

    // ---- ficha
    async function cargar(nuevo, t) {
      e = U.elemento(nuevo);
      cargando = e.url;
      ficha = completo = null;
      titulo.textContent = e.titulo || "Cargando…";
      resumen.textContent = "";
      canalNombre.textContent = e.autor || "";
      pintarBotones();
      desc.textContent = ""; datos.textContent = ""; capitulos.hidden = true; listaRel.textContent = "";
      if (comentarios) comentarios.destruir();
      if (transcripcion) transcripcion.destruir();
      comentarios = M7.comentarios ? M7.comentarios(cajaCom, e.url, {saltar}) : null;
      transcripcion = M7.transcripcion ? M7.transcripcion(cajaTr, e.url, {saltar, tiempo}) : null;
      if (op.sonar && rep && !esActual()) rep.reproducir(e, t);
      mostrarCartel();
      pintarCola();
      ponerAmbiente(e.miniatura);
      let f;
      try { f = await M7.api("/api/video/ficha?url=" + encodeURIComponent(e.url), undefined, "GET", ctl.signal); }
      catch (err) { return; }
      if (cargando !== e.url) return;   // respuesta tardía de otro vídeo
      if (!f.ok) { titulo.textContent = e.titulo || "No he podido cargar el vídeo"; M7.fallo(f, "No he podido cargar la ficha"); return; }
      ficha = f;
      if (String(e.url || "").startsWith("cancion:") && f.url) {   // 22/10/2026: la canción importada ya es su vídeo (Me gusta, listas…)
        e.cancion = e.url;
        cargando = e.url = f.url;
        mostrarCartel();
      }
      if (!e.titulo) { e = Object.assign(e, {titulo: f.titulo, autor: f.autor, autorUrl: f.autorUrl, miniatura: f.miniatura || e.miniatura});
        M7.api("/api/visto", {e}); }
      if (!e.autorUrl) e.autorUrl = f.autorUrl;
      pintarFicha();
      M7.api(`/api/video/completo?url=${encodeURIComponent(e.url)}&dur=${e.duracion > 0 ? e.duracion : -1}`, undefined, "GET", ctl.signal)
        .then((c) => { if (cargando === e.url && c.ok) { completo = c; pintarResumen(); } }).catch(() => {});
    }
    function pintarFicha() {
      const f = ficha;
      titulo.textContent = f.titulo || e.titulo;
      pagina.titulo = f.titulo || e.titulo;
      if (typeof ctx.titulo === "function") ctx.titulo(pagina.titulo); else document.title = pagina.titulo + " · Cat-ode";
      pintarResumen();
      avatar.textContent = "";
      if (f.avatar) avatar.append(el("img", {src: f.avatar, alt: "", loading: "lazy", decoding: "async"}));
      else avatar.textContent = (f.autor || "?").trim().charAt(0).toUpperCase();
      canalNombre.textContent = f.autor || e.autor || "";
      canalSubs.textContent = f.canalSuscriptores || "";
      desc.textContent = "";
      const d = f.descripcionHtml ? U.limpiarHtml(f.descripcionHtml, saltar) : U.enlazar(f.descripcion || "", saltar);
      if (d) desc.append(d);
      desc.classList.add("plegada");
      bDescMas.textContent = "…más";
      requestAnimationFrame(() => { bDescMas.hidden = desc.scrollHeight <= desc.clientHeight + 2; });
      pintarCapitulos();
      pintarBotones();
      rel = f.relacionados || [];
      pintarRelacionados();
    }
    function pintarResumen() {
      const f = ficha || {}, x = (completo && completo.extra) || {};
      const vistas = x.vistas >= 0 && x.vistas !== undefined ? `${U.miles(x.vistas)} visualizaciones` : (f.vistas || "");
      const fecha = x.textoFecha || f.textoFecha || "";
      resumen.textContent = [vistas, fecha && (fecha + (f.fechaRelativa ? ` (${f.fechaRelativa})` : ""))].filter(Boolean).join(" · ");
      if (completo && completo.htmlDatos) { datos.textContent = ""; const n = U.limpiarHtml(completo.htmlDatos); if (n) datos.append(n); }
      pintarBotones();
    }
    function pintarBotones() {
      const f = ficha || {}, v = (completo && completo.votos) || {};
      bMeGusta.textContent = "👍" + (v.meGusta >= 0 && v.meGusta !== undefined ? " " + U.corto(v.meGusta) : "");
      bNoMeGusta.textContent = "👎" + (v.noMeGusta >= 0 && v.noMeGusta !== undefined ? " ≈" + U.corto(v.noMeGusta) : "");
      bMeGusta.classList.toggle("activo", !!f.megusta);
      bNoMeGusta.classList.toggle("activo", !!f.nomegusta);
      bDespues.classList.toggle("activo", !!f.despues);
      bDespues.textContent = f.despues ? "🕒 En Ver más tarde" : "🕒 Ver más tarde";
      bGuardar.classList.toggle("activo", !!(f.enListas && f.enListas.length));
      bSuscribir.textContent = f.suscrito ? "Suscrito" : "Suscribirse";
      bSuscribir.classList.toggle("suscrito", !!f.suscrito);
      bSuscribir.disabled = !(f.autorUrl || e.autorUrl);
      bCine.classList.toggle("activo", cine);
    }
    function pintarCapitulos() {
      const caps = (ficha && ficha.capitulos) || [];
      const g = window.Reproductor && window.Reproductor.gestor;   // al reproductor: marcas en la barra y nombre del capítulo
      if (g && typeof g.poner_capitulos === "function") g.poner_capitulos(e.url, caps);
      capitulos.textContent = "";
      capitulos.hidden = !caps.length;
      if (!caps.length) return;
      capitulos.append(el("h3", {text: `Capítulos (${caps.length})`}));
      const fila = el("div", {class: "pv-capitulos-fila"});
      caps.forEach(([s, nombre]) => fila.append(el("button", {class: "pv-capitulo", "data-s": s, title: nombre,
        onclick: (ev) => saltar(s, ev), onauxclick: (ev) => { if (ev.button === 1) { ev.preventDefault(); saltar(s, ev); } }},
        el("span", {class: "pv-capitulo-t", text: U.tiempo(s)}), el("span", {class: "pv-capitulo-n", text: nombre}))));
      capitulos.append(fila);
    }
    let capActual = -1;
    function alTiempo(t) {
      const caps = (ficha && ficha.capitulos) || [];
      let k = -1;
      for (let i = 0; i < caps.length; i++) if (t >= caps[i][0]) k = i;
      if (k !== capActual) {
        capActual = k;
        capitulos.querySelectorAll(".pv-capitulo").forEach((b, i) => b.classList.toggle("actual", i === k));
      }
      if (transcripcion) transcripcion.alTiempo(t);
    }

    // ---- A continuación: la cola (si hay ≥2) y los relacionados en filas
    function fila(x, i) {
      const r = el("div", {class: "pv-rel-fila", tabindex: "0", role: "link", "data-url": x.url},
        el("div", {class: "pv-rel-mini"}, x.miniatura ? el("img", {src: x.miniatura, alt: "", loading: "lazy", decoding: "async"}) : null,
          x.duracion > 0 ? el("span", {class: "pv-rel-dur", text: U.tiempo(x.duracion)}) : null,
          x.visto > 0 ? el("span", {class: "pv-rel-visto", style: `width:${Math.min(100, x.visto)}%`}) : null),
        el("div", {class: "pv-rel-texto"}, el("div", {class: "pv-rel-titulo", text: x.titulo}),
          el("div", {class: "pv-rel-autor m7-gris", text: x.autor}), el("div", {class: "pv-rel-detalle m7-gris", text: x.detalle || ""})),
        el("button", {class: "pv-rel-menu", text: "⋮", title: "Más", "aria-label": "Más", onclick: (ev) => { ev.stopPropagation();
          M7.menuVideo(x, ev.clientX, ev.clientY, ficha || {}); }}));
      r.addEventListener("click", (ev) => M7.abrirVideo(x, {nueva: ev.ctrlKey}));
      r.addEventListener("auxclick", (ev) => { if (ev.button === 1) { ev.preventDefault(); M7.abrirVideo(x, {nueva: true}); } });
      r.addEventListener("keydown", (ev) => { if (ev.key === "Enter") M7.abrirVideo(x); });
      r.addEventListener("contextmenu", (ev) => { ev.preventDefault(); M7.menuVideo(x, ev.clientX, ev.clientY, ficha || {}); });
      return r;
    }
    // 06/10/2026 · «A continuación» no se acaba («la lista de vídeos a ver es cortísima, tiene que autogenerarse al ir
    // haciendo scroll»): al llegar al final se piden los relacionados de un vídeo de la propia lista que aún no se haya
    // usado como semilla (en orden) y se añaden sin repetir. Tres tandas vacías seguidas = se acabó para este vídeo.
    let relSemilla = 0, relPidiendo = false, relVacias = 0, relObs = null;
    const relFin = el("div", {class: "pv-rel-fin m7-gris"});
    async function masRelacionados() {
      if (relPidiendo || !ficha || relVacias >= 3 || !rel.length || relSemilla >= rel.length) return;
      const para = cargando, semilla = rel[relSemilla++];
      relPidiendo = true;
      relFin.textContent = "Cargando más…";
      let nuevos = [];
      try {
        const r = await M7.api("/api/video/relacionados?url=" + encodeURIComponent(semilla.url));
        if (cargando !== para) return;
        const ya = new Set(rel.map((x) => x.url));
        ya.add(e.url);
        for (const x of (r.ok && r.elementos) || []) {
          if (!x || !x.url || ya.has(x.url) || (x.tipo && x.tipo !== "VIDEO")) continue;
          ya.add(x.url);
          nuevos.push(x);
        }
        if (nuevos.length) {
          relVacias = 0;
          const f = document.createDocumentFragment();
          nuevos.forEach((x) => { rel.push(x); f.append(fila(x, rel.length - 1)); });
          listaRel.insertBefore(f, relFin);
        } else relVacias++;
      } catch (err) { relVacias++; } finally {
        relPidiendo = false;
        relFin.textContent = "";
      }
      if (!nuevos.length && cargando === para) masRelacionados();   // el final sigue a la vista: otra semilla
    }
    function pintarRelacionados() {
      listaRel.textContent = "";
      relSemilla = 0; relVacias = 0;
      if (!rel.length) { listaRel.append(el("div", {class: "m7-gris pv-vacio", text: ficha ? "Sin relacionados" : "Cargando…"})); return; }
      const f = document.createDocumentFragment();
      rel.forEach((x, i) => f.append(fila(x, i)));
      listaRel.append(f);
      listaRel.append(relFin);
      if (!relObs && typeof IntersectionObserver === "function") {
        relObs = new IntersectionObserver((es) => { if (es.some((x) => x.isIntersecting)) masRelacionados(); }, {rootMargin: "200px"});
        relObs.observe(relFin);
        limpiar.push(() => { try { relObs.disconnect(); } catch (err) {} });
      }
    }
    let arrastrando = -1;
    function pintarCola() {
      const c = (rep && rep.cola) || [];
      cola.hidden = c.length < 2;
      if (c.length < 2) return;
      colaTitulo.textContent = `Cola · ${rep.i + 1} de ${c.length}`;
      colaLista.textContent = "";
      c.forEach((x, i) => {
        const li = el("li", {class: "pv-cola-item" + (i === rep.i ? " actual" : ""), draggable: "true", "data-i": i, tabindex: "-1",
          text: (i === rep.i ? "▶ " : `${i + 1}. `) + (x.titulo || x.url)});
        li.addEventListener("click", () => rep.saltar_a(i));
        li.addEventListener("auxclick", (ev) => { if (ev.button === 1) { ev.preventDefault(); M7.abrirVideo(x, {nueva: true}); } });
        li.addEventListener("contextmenu", (ev) => { ev.preventDefault(); M7.menu([
          {texto: "Quitar de la cola", inactivo: i === rep.i, hacer: () => quitarDeCola(i)},
          {texto: "Abrir en pestaña nueva", hacer: () => M7.abrirVideo(x, {nueva: true})}], ev.clientX, ev.clientY); });
        li.addEventListener("dragstart", (ev) => { arrastrando = i; ev.dataTransfer.effectAllowed = "move"; ev.dataTransfer.setData("text/plain", String(i)); li.classList.add("arrastrando"); });
        li.addEventListener("dragend", () => { arrastrando = -1; li.classList.remove("arrastrando"); });
        li.addEventListener("dragover", (ev) => { if (arrastrando >= 0) { ev.preventDefault(); li.classList.add("encima"); } });
        li.addEventListener("dragleave", () => li.classList.remove("encima"));
        li.addEventListener("drop", (ev) => { ev.preventDefault(); li.classList.remove("encima"); if (arrastrando >= 0 && arrastrando !== i) reordenar(arrastrando, i); });
        colaLista.append(li);
      });
    }
    function quitarDeCola(i) {
      if (!rep || i === rep.i) return;
      M7.quitarDeCola(rep, i);
      pintarCola();
    }
    function reordenar(de, a) {   // _cola_reordenada: reescribe la cola y el índice del que suena
      M7.moverEnCola(rep, de, a);
      pintarCola();
    }
    colaLista.addEventListener("keydown", (ev) => {
      if (ev.key !== "Delete") return;
      const li = document.activeElement && document.activeElement.closest(".pv-cola-item");
      if (li) quitarDeCola(Number(li.dataset.i));
    });

    // ---- botones
    bMeGusta.addEventListener("click", async () => { const p = await M7.alternar("megusta", e); if (p === null || !ficha) return;
      ficha.megusta = p; if (p) ficha.nomegusta = false; pintarBotones(); });
    bNoMeGusta.addEventListener("click", async () => { const p = await M7.alternar("nomegusta", e); if (p === null || !ficha) return;
      ficha.nomegusta = p; if (p) ficha.megusta = false; pintarBotones(); });
    bDespues.addEventListener("click", async () => { const p = await M7.alternar("despues", e); if (p !== null && ficha) { ficha.despues = p; pintarBotones(); } });
    bCompartir.addEventListener("click", (ev) => { const r = bCompartir.getBoundingClientRect(); M7.menuCompartir(e, r.left, r.bottom + 4, tiempo()); });
    bGuardar.addEventListener("click", () => { const r = bGuardar.getBoundingClientRect(); const f = ficha || {};
      M7.menuListas(e, f.listas, f.enListas, r.left, r.bottom + 4, (clave, dentro, nombre) => {
        f.enListas = (f.enListas || []).filter((c) => c !== clave); if (dentro) f.enListas.push(clave);
        if (nombre && f.listas && !f.listas.some(([c]) => c === clave)) f.listas.push([clave, nombre]);
        pintarBotones(); }); });
    bDescargar.addEventListener("click", () => { const r = bDescargar.getBoundingClientRect(); M7.menuDescargar(e, r.left, r.bottom + 4); });
    bMas.addEventListener("click", () => { const r = bMas.getBoundingClientRect(); M7.menuVideo(e, r.left, r.bottom + 4, ficha || {}); });
    bCine.addEventListener("click", () => M7.alternarCine());
    bSuscribir.addEventListener("click", async () => {
      const f = ficha || {}, url = f.autorUrl || e.autorUrl;
      if (!url) return;
      const r = f.suscrito ? await M7.api("/api/datos", {accion: "anular", url})
        : await M7.api("/api/datos", {accion: "suscribir", e: {tipo: "CANAL", url, titulo: f.autor || e.autor, autor: f.autor || e.autor, miniatura: f.avatar || ""}});
      if (!r.ok) return M7.fallo(r);
      if (ficha) ficha.suscrito = !f.suscrito;
      M7.avisar(f.suscrito ? `Suscrito a ${f.autor || e.autor}` : `Ya no sigues a ${f.autor || e.autor}`);
      pintarBotones();
    });
    bFulminar.addEventListener("click", async () => {   // _fulminar: para, fulminar, volver
      const f = ficha || {}, url = f.autorUrl || e.autorUrl, nombre = f.autor || e.autor;
      const ok = await M7.dialogo({titulo: `¿Fulminar «${nombre}»?`, texto: "No volverás a ver nada de este canal en ningún Cat-ode.",
        botones: [{texto: "Cancelar", valor: null}, {texto: "Fulminar", valor: "si", principal: true}]});
      if (!ok || ok.boton !== "si") return;
      if (esActual()) rep.parar();
      M7.atras();
      M7.fulminar(url, nombre);
    });
    const irCanal = (ev) => { ev.preventDefault(); M7.irCanal((ficha && ficha.autorUrl) || e.autorUrl, ev.ctrlKey || ev.button === 1); };
    canalNombre.addEventListener("click", irCanal);
    canalNombre.addEventListener("auxclick", (ev) => { if (ev.button === 1) irCanal(ev); });
    avatar.addEventListener("click", irCanal);
    bDatos.addEventListener("click", () => {   // al abrir los datos se oculta la descripción (fichas.PanelDatos)
      datos.hidden = !datos.hidden;
      bDatos.textContent = (datos.hidden ? "▸" : "▾") + " Datos del vídeo";
      desc.hidden = !datos.hidden; bDescMas.hidden = !datos.hidden || desc.scrollHeight <= desc.clientHeight + 2;
      if (!datos.hidden && !datos.childNodes.length) datos.textContent = completo ? "Sin datos" : "Cargando los datos…";
    });
    bDescMas.addEventListener("click", () => {
      const plegada = desc.classList.toggle("plegada");
      bDescMas.textContent = plegada ? "…más" : "Mostrar menos";
    });
    desc.addEventListener("click", (ev) => { if (desc.classList.contains("plegada") && !ev.target.closest("a")) { desc.classList.remove("plegada"); bDescMas.textContent = "Mostrar menos"; } });

    // ---- reproducción automática (ajustes.automatica, la misma casilla que en Ajustes)
    M7.ajustes().then((aj) => { auto.checked = aj.automatica !== false; const c = !!aj.cine; if (c !== cine) ponerCine(c); });
    auto.addEventListener("change", () => M7.ponerAjuste("automatica", auto.checked));
    limpiar.push(M7.alAjuste((clave, valor) => { if (clave === "automatica") auto.checked = !!valor; if (clave === "cine") ponerCine(!!valor); }));

    // ---- oyentes del reproductor
    if (rep && rep.on) {
      limpiar.push(M7.oir(rep, "estado", (st) => { if (esActual() && st && st.t !== null && st.t !== undefined) alTiempo(st.t); }));
      limpiar.push(M7.oir(rep, "cola", () => pintarCola()));
      limpiar.push(M7.oir(rep, "empieza", (x) => {   // _empieza 3928: la automática o la cola cambian el vídeo → se recarga
        pintarCola();
        if (x && !dirs(x).some((u) => dirs(e).includes(u)) && pagina.visible) { op.sonar = false; cargar(x); }
        else mostrarCartel();
      }));
      limpiar.push(M7.oir(rep, "pide_mas", () => {   // _automatica 3949: el primer relacionado no visto
        if (!esActual() && !(rep.actual === null && cargando === e.url)) return;
        if (!auto.checked) return;
        const sig = rel.find((x) => x.tipo === "VIDEO" && !(x.visto >= 90));
        if (sig) { rep.encolar(sig); rep.siguiente("reproducción automática"); }
      }));
      limpiar.push(M7.oir(rep, "para", () => mostrarCartel()));
    }
    limpiar.push(M7.alVetar(async () => {   // _repintar_vetos: los relacionados sin lo fulminado
      if (!ficha) return;
      const r = await M7.api("/api/video/relacionados?url=" + encodeURIComponent(e.url));
      if (r.ok && cargando === e.url) { rel = r.elementos || []; pintarRelacionados(); }
    }));

    // ---- Ctrl+F busca en la transcripción si está abierta
    const tecla = (ev) => {
      if (!pagina.visible) return;
      if (ev.ctrlKey && (ev.key === "f" || ev.key === "F") && transcripcion && transcripcion.abierta()) { ev.preventDefault(); transcripcion.enfocar(); }
    };
    document.addEventListener("keydown", tecla);
    limpiar.push(() => document.removeEventListener("keydown", tecla));

    function ponerCine(c) {
      cine = c;
      raiz.classList.toggle("cine", c);
      bCine.classList.toggle("activo", c);
      if (M7.capa) M7.capa.recolocar();
    }
    function ponerAmbiente(src) {
      ambiente.style.background = "";
      M7.ambiente(src).then((par) => {
        if (!par || cargando !== e.url) return;
        ambiente.style.background = `linear-gradient(90deg, ${par[0]}, ${par[1]})`;
      });
    }

    limpiar.push(M7.on("pestana:cambia", () => setTimeout(revisarVisible, 0)));
    const pagina = {
      url: () => e.url, titulo: e.titulo || "Vídeo", visible: true, raiz,
      ficha: () => ficha, recargar: () => cargar(e),
      buscar() { if (!transcripcion || !transcripcion.abierta()) return false; transcripcion.enfocar(); return true; },
      cine: ponerCine,
      salir() {   // deja el vídeo en el mini si sigue sonando (_a_flotante)
        pagina.visible = false;
        ctl.abort();
        for (const f of limpiar) try { f && f(); } catch (err) { /* nada */ }
        if (comentarios) comentarios.destruir();
        if (transcripcion) transcripcion.destruir();
        if (M7.capa && M7.capa.sitio === zona) { if (rep && rep.actual) M7.capa.mini(); else M7.capa.ocultar(); }
        if (M7._paginaVideo === pagina) { M7._paginaVideo = null; document.body.classList.remove("en-video"); }
        raiz.remove();
      },
      mostrar() { pagina.visible = true; M7._paginaVideo = pagina; document.body.classList.add("en-video"); mostrarCartel(); },
      ocultar() {
        pagina.visible = false;
        if (M7._paginaVideo === pagina) document.body.classList.remove("en-video");
        if (M7.capa && M7.capa.sitio === zona) { if (rep && rep.actual) M7.capa.mini(); else M7.capa.ocultar(); }
      },
    };
    pagina.destruir = pagina.salir;   // contrato de app.js (M4)
    M7._paginaVideo = pagina;
    document.body.classList.add("en-video");
    cargar(e, op.t);
    return pagina;
  }
  M7.paginas.video = PaginaVideo;
  M7.alternarCine = function () {
    const c = !M7.ajuste("cine", false);
    M7.ponerAjuste("cine", c);
    if (M7._paginaVideo) M7._paginaVideo.cine(c);
  };

  // registro en el espacio de nombres común cuando ya han cargado todos los <script>
  // nombres de las páginas en el marco de M4 (los de interfaz.py) → las de aquí
  const NOMBRES_M4 = {video: "_mostrar_video", shorts: "shorts", ajustes: "ajustes_pagina"};
  function registrar() {
    const c = window.catode = window.catode || {};
    c.paginas = c.paginas || {};
    const cp = window.catodePaginas = window.catodePaginas || {};
    for (const [k, v] of Object.entries(M7.paginas)) {
      if (!c.paginas[k]) c.paginas[k] = v;
      const n = NOMBRES_M4[k] || k;
      if (!cp[n]) cp[n] = v;
      if (window.app && typeof window.app.registrar === "function" && window.app.paginas && window.app.paginas[n] !== v) window.app.registrar(n, v);
    }
    c.m7 = M7;
    // ganchos del marco que son de M7 (atajos.js y mandos.js los llaman)
    const app = window.app;
    if (app) {
      app.ganchos = app.ganchos || {};
      if (!app.ganchos._m7) {
        app.ganchos._m7 = true;
        app.ganchos.completa = () => { if (M7.pantallaCompleta) M7.pantallaCompleta(); };
        app.ganchos.escape = () => (M7.escape ? M7.escape() : false);
        app.ganchos.buscarEnPagina = () => !!(M7._paginaVideo && M7._paginaVideo.visible && M7._paginaVideo.buscar && M7._paginaVideo.buscar());
      }
    }
  }
  M7.registrar = registrar;   // shorts.js y ajustes.js lo llaman al cargar (app.js carga los módulos después del DOM)
  registrar();
  document.addEventListener("DOMContentLoaded", registrar);
})();
