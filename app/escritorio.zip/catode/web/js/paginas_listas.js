// Cat-ode escritorio · interfaz web · módulo M5 (DISENO_WEB.md §3), 06/10/2026.
// paginas_listas.js: la plantilla de página de lista (PaginaRejilla, interfaz.py 285-400: cabecera con «←», título y
// botones, cabecera extra, chips, aviso y rejilla; «Cargando…»; turno que invalida respuestas tardías; sin red, aviso y
// reintento solo a los 15 s; tanda siguiente al llegar al final) y las páginas de lista del MAPA con sus chips, filtros
// y botones: inicio, shorts_rejilla, suscripciones (+ _gestionar), explorar, historial, despues, megusta (_coleccion),
// listas, _lista_propia, _lista_yt, descargas, nut, _canal (vídeos/shorts/directos/listas/acerca de) y _resultados.
//
// Contrato con el marco (M4): cada página se registra con app.registrar(nombre, fn) y se llama fn(raiz, a, ctx):
//   raiz = el elemento donde pintar (si falta, se crea y se devuelve en .nodo); a = la lista de argumentos, con el
//   mismo formato que las pestañas guardadas de la Qt ({f, a, t}, interfaz.py 2636); ctx = {signal} opcional.
// Devuelve {nodo, titulo, rejilla, destruir()}; la Promise del primer pintado queda en .listo.
"use strict";
(function () {
  const M5 = window.M5, Menu = window.Menu, Rejilla = window.Rejilla;
  const REINTENTO_MS = 15000;
  const q = encodeURIComponent;

  // ------------------------------------------------------------------------------------------------ PaginaRejilla
  function crearBoton(b) {
    if (b instanceof Node) return b;
    const n = document.createElement("button");
    n.className = "pr-btn" + (b.principal ? " principal" : "");
    n.textContent = b.texto;
    if (b.titulo) n.title = b.titulo;
    n.addEventListener("click", (ev) => b.accion(ev, n));
    return n;
  }

  /**
   * cfg = {f, a, titulo, atras, botones:[{texto, accion, principal}|Node], chips:[…], activo, alChip(c), fila, vertical,
   *        anchoImg, quitar(e, rejilla), vacio, recargarCon:[col…]}
   */
  function Pagina(raiz, cfg, ctx) {
    const p = this;
    p.cfg = cfg;
    p.turno = 0;
    p.vivo = true;
    p.reloj = 0;
    p.ctrl = null;
    p.ctx = ctx || {};
    p.senal = p.ctx.senal || p.ctx.signal;
    // El que hace scroll es la raíz que da el marco (M4: un div .pagina por navegación, con su scroll; así sus «sitios»
    // guardan el scroll bueno). Sin raíz, una propia. La cabecera y los chips se quedan arriba (sticky).
    if (!raiz) { raiz = document.createElement("div"); raiz.className = "pr-raiz"; }
    p.raiz = raiz;
    p.scroll = raiz;
    p.nodo = document.createElement("section");
    p.nodo.className = "pr";
    p.nodo.dataset.pagina = cfg.f;
    p.nodo.innerHTML = '<div class="pr-cabeza"><div class="pr-cab"></div><div class="pr-chips" role="tablist"></div></div>' +
      '<div class="pr-extra"></div><div class="pr-aviso" role="status"></div>';
    p.cab = p.nodo.querySelector(".pr-cab");
    p.chipsNodo = p.nodo.querySelector(".pr-chips");
    p.extra = p.nodo.querySelector(".pr-extra");
    p.avisoNodo = p.nodo.querySelector(".pr-aviso");
    if (cfg.atras) {
      const b = crearBoton({texto: "←", titulo: "Volver", accion: () => M5.volver()});
      b.classList.add("pr-atras");
      p.cab.appendChild(b);
    }
    p.tituloNodo = document.createElement("h1");
    p.tituloNodo.className = "pr-tit";
    p.cab.appendChild(p.tituloNodo);
    p.botonesNodo = document.createElement("div");
    p.botonesNodo.className = "pr-bot";
    p.cab.appendChild(p.botonesNodo);
    p.ponerTitulo(cfg.titulo || "");
    p.ponerBotones(cfg.botones || []);
    p.ponerChips(cfg.chips || [], cfg.activo, cfg.alChip);
    p.rejilla = new Rejilla(p.scroll, {fila: !!cfg.fila, vertical: !!cfg.vertical, anchoImg: cfg.anchoImg || 246,
      quitar: cfg.quitar || null, vacio: cfg.vacio, tapa: () => p.nodo.querySelector(".pr-cabeza").offsetHeight});
    p.rejilla.montar(p.nodo);
    // la rueda sobre los chips los mueve en horizontal (FilaFichas)
    p.chipsNodo.addEventListener("wheel", (ev) => {
      if (Math.abs(ev.deltaY) > Math.abs(ev.deltaX)) { p.chipsNodo.scrollLeft += ev.deltaY; ev.preventDefault(); }
    }, {passive: false});
    p._alDatos = (ev) => {
      const col = ev.detail && ev.detail.col;
      if (col && (cfg.recargarCon || []).includes(col) && p.recargar) p.recargar();
    };
    window.addEventListener("catode:datos", p._alDatos);
    raiz.appendChild(p.nodo);
  }
  Pagina.prototype.ponerTitulo = function (t) {
    this.titulo = t || "";
    this.tituloNodo.textContent = this.titulo;
    if (this.cfg.alTitulo) this.cfg.alTitulo(this.titulo);
    if (this.ctx && typeof this.ctx.titulo === "function") try { this.ctx.titulo(this.titulo || this.cfg.tituloPestana || ""); } catch (e) {}
  };
  Pagina.prototype.ponerBotones = function (bs) {
    this.botonesNodo.textContent = "";
    for (const b of bs) if (b) this.botonesNodo.appendChild(crearBoton(b));
  };
  Pagina.prototype.ponerChips = function (chips, activo, alChip) {
    this.chipsNodo.textContent = "";
    for (const c of chips || []) {
      const b = document.createElement("button");
      b.className = "pr-chip" + (c === activo ? " activo" : "");
      b.textContent = c;
      b.setAttribute("role", "tab");
      b.setAttribute("aria-selected", c === activo ? "true" : "false");
      b.addEventListener("click", () => { if (alChip) alChip(c); });
      this.chipsNodo.appendChild(b);
    }
    const act = this.chipsNodo.querySelector(".activo");
    if (act) requestAnimationFrame(() => { try { act.scrollIntoView({block: "nearest", inline: "nearest"}); } catch (e) {} });
  };
  Pagina.prototype.aviso = function (texto, clase) {
    this.avisoNodo.textContent = texto || "";
    this.avisoNodo.className = "pr-aviso" + (clase ? " " + clase : "");
  };
  /** preparar 338: un turno nuevo (lo anterior que llegue tarde se tira) y «Cargando…». */
  Pagina.prototype.preparar = function () {
    this.turno++;
    clearTimeout(this.reloj);
    if (this.ctrl) this.ctrl.abort();
    this.ctrl = new AbortController();
    if (this.senal) this.senal.addEventListener("abort", () => this.ctrl && this.ctrl.abort(), {once: true});
    this.aviso("Cargando…");
    return this.turno;
  };
  /** Pide ruta y pinta con alAcabar(r). Error: cartel por clase (§2.2); sin_red/servidor_autor → otra vez a los 15 s. */
  Pagina.prototype.cargar = async function (ruta, alAcabar, conservar) {
    const turno = this.preparar();
    if (!conservar) this.rejilla.poner([], {}, "");
    const r = await M5.api(ruta, undefined, {signal: this.ctrl.signal});
    if (!this.vivo || turno !== this.turno || r.abortada) return null;
    if (!r.ok) { this.fallo(r, turno); return null; }
    this.aviso("");
    this.ultima = r;
    alAcabar(r);
    return r;
  };
  Pagina.prototype.fallo = function (r, turno) {
    const clase = r.clase || "sin_red";
    if (clase === "bloqueo") return this.aviso("YouTube ha pedido comprobar que no eres un robot. Paro aquí y no lo vuelvo a intentar solo: pasará en un rato.", "bloqueo");
    if (clase === "imposible") return this.aviso(r.error || "Esto no se puede abrir (privado o borrado).", "error");
    this.aviso(`No he podido cargarlo (${r.error || clase}). Lo vuelvo a intentar solo en unos segundos…`, "error");
    clearTimeout(this.reloj);
    this.reloj = setTimeout(() => {   // _reintentar 3216: la misma página otra vez, sola, mientras sigas en ella
      if (this.vivo && turno === this.turno && this.nodo.isConnected && this.recargar) this.recargar();
    }, REINTENTO_MS);
  };
  /** Pinta la respuesta estándar {elementos, motivos, aviso, mas, cursor} y engancha la tanda siguiente. */
  Pagina.prototype.pintar = function (r, siguiente) {
    this.rejilla.poner(r.elementos || [], r.motivos || {}, r.aviso || "");
    this.enganchar(r, siguiente);
  };
  Pagina.prototype.enganchar = function (r, siguiente) {
    const g = this.rejilla;
    if (!(r.mas && r.cursor && siguiente)) { g.alFinal = null; return; }
    let cursor = r.cursor;
    const turno = this.turno;
    g.alFinal = async () => {
      const m = await M5.api(siguiente(cursor), undefined, {signal: this.ctrl && this.ctrl.signal});
      if (!this.vivo || turno !== this.turno) return;
      if (!m.ok) { g.pidiendo = false; g.alFinal = null; return M5.avisar("No he podido traer más: " + (m.error || "")); }
      cursor = m.cursor;
      if (!(m.mas && m.cursor)) g.alFinal = null;
      g.anadir(m.elementos || [], m.motivos || {});
    };
  };
  Pagina.prototype.elementos = function () { return this.rejilla.todos().slice(); };   // también lo que aún entra por tandas
  /** Para los «sitios» del marco (M4, _sitios 2893): cuántas tarjetas hay y volver al scroll guardado. */
  Pagina.prototype.cuantos = function () { return this.rejilla.todos().length; };
  Pagina.prototype.restaurar = function (sitio) {
    if (!sitio) return;
    const ir = () => { this.rejilla._pintar(this.rejilla._medir()); this.scroll.scrollTop = sitio.scroll || 0; this.rejilla.pedirPintura(); };
    Promise.resolve(this.listo).then(() => requestAnimationFrame(ir));
  };
  Pagina.prototype.destruir = function () {
    this.vivo = false;
    clearTimeout(this.reloj);
    if (this.ctrl) this.ctrl.abort();
    window.removeEventListener("catode:datos", this._alDatos);
    this.rejilla.destruir();
    if (window.Previa) window.Previa.salir();
  };
  window.PaginaRejilla = Pagina;

  /** Registra una página: fn(p, a, ctx) recibe la Pagina ya creada por plantilla(a) y la rellena. */
  function registrar(nombre, plantilla, rellenar) {
    const fn = function (raiz, a, ctx) {
      if (raiz && !(raiz instanceof Node)) { ctx = a; a = raiz; raiz = null; }   // también fn(a) sin raíz
      a = Array.isArray(a) ? a : (a == null ? [] : [a]);
      const p = new Pagina(raiz, Object.assign({f: nombre}, plantilla(a)), ctx);
      p.a = a;
      p.recargar = () => rellenar(p, a, ctx);
      p.listo = Promise.resolve(p.recargar()).catch((e) => { p.aviso("Algo ha fallado: " + e, "error"); });
      return p;
    };
    window.catodePaginas[nombre] = fn;
    window.app.registrar(nombre, fn);
    return fn;
  }
  M5.registrarPaginaLista = registrar;

  const todo = (p, barajar) => {
    const els = p.elementos().filter((e) => e.tipo === "VIDEO");
    if (!els.length) return M5.avisar("No hay vídeos que reproducir");
    return M5.rep("todo", els, !!barajar);
  };
  const botonTodo = (p) => ({texto: "▶  Reproducir todo", accion: () => todo(p, false)});
  const botonBarajar = (p) => ({texto: "🔀", titulo: "Reproducir todo en orden aleatorio", accion: () => todo(p, true)});

  // ------------------------------------------------------------------------------------------------ Inicio (3237-3293)
  registrar("inicio", (a) => ({titulo: "", tituloPestana: "Inicio"}), async (p, a) => {
    let recargar = !!a[1];
    const tema = a[0] || "Todo";
    if (window.app && window.app._inicioFresco) { window.app._inicioFresco = false; recargar = true; }   // Inicio pulsado estando en Inicio
    p.ponerBotones([botonTodo(p), botonBarajar(p), {texto: "⟳  Actualizar", accion: () => M5.reemplazar("inicio", [tema, true])}]);
    await p.cargar(`/api/pagina/inicio?tema=${q(tema)}&recargar=${recargar ? 1 : 0}`, (r) => {
      p.ponerChips(r.chips || r.temas || ["Todo"], r.activo || tema, (c) => M5.reemplazar("inicio", [c]));
      p.pintar(r, (cursor) => `/api/pagina/inicio_mas?tema=${q(tema)}&cursor=${cursor}`);   // 06/10/2026: el Inicio no se acaba
      if (r.aviso_vigilante) p.aviso(r.aviso_vigilante);
    });
    // 18/10/2026 · equipo nuevo (sin canales ni historial): la invitación «Trae tu YouTube», como en Android (cuenta.js)
    if (p.vivo && window.catode && window.catode.cuenta) window.catode.cuenta.invitar(p.extra);
  });

  // ------------------------------------------------------------------------------------------------ Shorts en rejilla
  // La página «shorts» (uno a uno, PaginaShorts) es de M7; esta es la cuadrícula vertical (la de antes del 03/10 y la
  // de la pestaña Shorts de un canal), útil para elegir uno.
  registrar("shorts_rejilla", () => ({titulo: "Shorts", vertical: true}), async (p) => {
    p.ponerBotones([botonTodo(p), botonBarajar(p)]);
    await p.cargar("/api/pagina/shorts", (r) => { p.pintar(r); });
  });

  // ------------------------------------------------------------------------------------------------ Suscripciones (3319-3369)
  registrar("suscripciones", (a) => ({titulo: "Suscripciones"}), async (p, a) => {
    const filtro = a[0] || "Todo", recargar = !!a[1];
    p.ponerBotones([{texto: "Gestionar", accion: () => M5.ir("_gestionar", [])}, botonTodo(p),
      {texto: "⟳", titulo: "Actualizar", accion: () => M5.reemplazar("suscripciones", [filtro, true])}]);
    p.ponerChips(["Todo", "Hoy", "Esta semana", "No vistos"], filtro, (c) => M5.reemplazar("suscripciones", [c]));
    await p.cargar(`/api/pagina/suscripciones?filtro=${q(filtro)}&recargar=${recargar ? 1 : 0}`, (r) => {
      if (r.chips && r.chips.length) p.ponerChips(r.chips, r.activo || filtro, (c) => M5.reemplazar("suscripciones", [c]));
      p.pintar(r);
    });
  });

  // ------------------------------------------------------------------------------------------------ Gestionar (_gestionar 3360)
  registrar("_gestionar", () => ({titulo: "Tus canales", atras: true, fila: true, anchoImg: 128,
    quitar: async (e, g) => {
      const r = await M5.datos("anular", {url: e.url});
      if (!r.ok) return M5.avisar("No he podido quitarlo");
      g.quitarElemento(e);
      M5.avisar(`Ya no sigues «${e.titulo}»`);
      M5.emitirDatos("suscripciones");
    }}), async (p) => {
    await p.cargar("/api/pagina/gestionar", (r) => { p.ponerTitulo(r.titulo || "Tus canales"); p.pintar(r); });
  });

  // ------------------------------------------------------------------------------------------------ Canales (13/10/2026)
  // Todos tus canales en rejilla, como los vídeos de Inicio o Suscripciones (cabecera «Suscripciones (n)» del menú).
  registrar("_canales", () => ({titulo: "Tus canales"}), async (p) => {
    p.ponerBotones([{texto: "Gestionar", accion: () => M5.ir("_gestionar", [])}]);
    await p.cargar("/api/pagina/gestionar", (r) => { p.ponerTitulo(r.titulo || "Tus canales"); p.pintar(r); });
  });

  // ------------------------------------------------------------------------------------------------ Explorar (3415)
  // 28/10/2026: canales que no sigues cerca de los tuyos (descubrir.py), con ⟳ y sin final (explorar_mas)
  registrar("explorar", () => ({titulo: "Explorar"}), async (p, a) => {
    const cat = a[0] || "", recargar = !!a[1];
    p.ponerBotones([{texto: "⟳  Actualizar", accion: () => M5.reemplazar("explorar", [cat, true])}]);
    await p.cargar("/api/pagina/explorar?" + (cat ? "categoria=" + q(cat) + "&" : "") + "recargar=" + (recargar ? 1 : 0), (r) => {
      p.ponerChips(r.chips || [], r.activo || cat, (c) => M5.reemplazar("explorar", [c]));
      const tema = r.activo || cat || "Todo";
      p.pintar(r, (cursor) => `/api/pagina/explorar_mas?tema=${q(tema)}&cursor=${cursor}`);
    });
  });

  // ------------------------------------------------------------------------------------------------ Historial (3422-3460)
  registrar("historial", () => ({titulo: "Historial", fila: true,
    quitar: async (e, g) => {
      const r = await M5.datos("quitar", {url: e.url, col: "historial", e: M5.limpio(e)});
      if (!r.ok) return M5.avisar("No he podido quitarlo del historial");
      g.quitarElemento(e);
    }}), async (p, a) => {
    const filtro = a[0] || "";
    const campo = document.createElement("input");
    campo.type = "search"; campo.className = "pr-campo"; campo.placeholder = "Buscar en el historial"; campo.value = filtro;
    campo.addEventListener("keydown", (ev) => { if (ev.key === "Enter") { ev.preventDefault(); M5.reemplazar("historial", [campo.value.trim()]); } });
    const pintarBotones = (pausado) => p.ponerBotones([campo,
      {texto: pausado ? "▶  Reanudar historial" : "⏸  Pausar historial", accion: async () => {
        const r = await M5.datos("historial", {que: "pausar"});
        if (!r.ok) return M5.avisar("No he podido cambiarlo");
        M5.avisar(r.pausado ? "Historial en pausa" : "Historial reanudado");
        pintarBotones(r.pausado);
        p.aviso(r.pausado ? "El historial está en pausa: lo que veas no se apunta." : "");
      }},
      {texto: "🗑  Borrar todo", accion: async () => {
        if (!(await Menu.confirmar("Borrar el historial", "¿Borrar todo el historial de Cat-ode? No se puede deshacer.", "Borrar todo"))) return;
        const r = await M5.datos("historial", {que: "borrar"});
        M5.avisar(r.ok ? "Historial borrado" : "No he podido borrarlo");
        p.recargar();
      }}]);
    pintarBotones(false);
    await p.cargar("/api/pagina/historial" + (filtro ? "?q=" + q(filtro) : ""), (r) => {
      pintarBotones(!!r.pausado);
      // por tandas de 150 (servicio.historial): la siguiente al acercarse al final
      p.pintar(r, (c) => "/api/pagina/historial?" + (filtro ? "q=" + q(filtro) + "&" : "") + "cursor=" + q(c));
      if (r.pausado) p.aviso("El historial está en pausa: lo que veas no se apunta.");
    });
  });

  // ------------------------------------------------------------------------------------------------ Ver más tarde y Me gusta (3462-3474)
  function coleccion(nombre, col, titulo) {
    registrar(nombre, () => ({titulo, fila: true, recargarCon: [col],
      quitar: async (e, g) => {
        const r = await M5.datos("quitar", {url: e.url, col});
        if (!r.ok) return M5.avisar("No he podido quitarlo");
        g.quitarElemento(e);
        p_titulo(g, titulo);
      }}), async (p) => {
      p.ponerBotones([botonTodo(p), botonBarajar(p)]);
      await p.cargar("/api/pagina/coleccion/" + col, (r) => { p.ponerTitulo(r.titulo || titulo); p.pintar(r); }, true);
    });
  }
  function p_titulo(g, titulo) {   // «X (n)» al quitar uno
    const pag = g.nodo.closest(".pr");
    const h = pag && pag.querySelector(".pr-tit");
    if (h) h.textContent = `${titulo} (${g.todos().length})`;
  }
  coleccion("despues", "despues", "Ver más tarde");
  coleccion("megusta", "megusta", "Vídeos que me gustan");
  // _coleccion(col, titulo, vacio) tal cual la guarda la Qt
  registrar("_coleccion", (a) => ({titulo: a[1] || "", fila: true, recargarCon: [a[0]],
    quitar: async (e, g) => { const r = await M5.datos("quitar", {url: e.url, col: a[0]}); if (r.ok) g.quitarElemento(e); }}), async (p, a) => {
    p.ponerBotones([botonTodo(p), botonBarajar(p)]);
    await p.cargar("/api/pagina/coleccion/" + q(a[0] || "despues"), (r) => { p.ponerTitulo(r.titulo || a[1] || ""); p.pintar(r); }, true);
  });

  // ------------------------------------------------------------------------------------------------ Listas (3476-3536)
  registrar("listas", () => ({titulo: "Listas", recargarCon: ["listas"]}), async (p) => {
    p.ponerBotones([{texto: "➕  Nueva lista", accion: async () => { if (await M5.nuevaLista()) p.recargar(); }}]);
    await p.cargar("/api/pagina/listas", (r) => p.pintar(r), true);
  });

  registrar("_lista_propia", () => ({titulo: "Lista", atras: true, fila: true, recargarCon: ["listas"],
    quitar: null}), async (p, a) => {
    const clave = a[0] || "";
    p.rejilla.o.quitar = async (e, g) => {
      const r = await M5.datos("lista", {que: "quitar", clave, e: M5.limpio(e)});
      if (!r.ok) return M5.avisar("No he podido quitarlo de la lista");
      g.quitarElemento(e);
    };
    p.ponerBotones([botonTodo(p), botonBarajar(p),
      {texto: "✏  Renombrar", accion: async () => {
        const nombre = await Menu.preguntar("Renombrar la lista", "Nombre nuevo:", p.titulo);
        if (!nombre) return;
        const r = await M5.datos("lista", {que: "renombrar", clave, nombre});
        if (r.ok) { p.ponerTitulo(nombre); M5.avisar("Lista renombrada"); }
      }},
      {texto: "🗑  Borrar lista", accion: async () => {
        if (!(await Menu.confirmar("Borrar la lista", `¿Borrar la lista «${p.titulo}»? Los vídeos no se borran de ningún otro sitio.`, "Borrar lista"))) return;
        const r = await M5.datos("lista", {que: "borrar", clave});
        if (!r.ok) return M5.avisar("No he podido borrarla");
        M5.avisar("Lista borrada");
        M5.emitirDatos("listas");
        M5.volver();
      }}]);
    await p.cargar("/api/pagina/lista_propia/" + q(clave), (r) => { p.ponerTitulo(r.titulo || "Lista"); p.pintar(r); }, true);
  });

  registrar("_lista_yt", (a) => ({titulo: a[1] || "Lista", atras: true, fila: true}), async (p, a) => {
    const url = a[0] || "", titulo = a[1] || "Lista";
    const guardar = (guardada) => ({texto: guardada ? "✓  Guardada" : "➕  Guardar lista", accion: async () => {
      const r = await M5.datos("lista", {que: "guardar_yt", url, titulo: p.titulo || titulo, elementos: p.elementos().slice(0, 1).map(M5.limpio)});
      if (!r.ok) return M5.avisar("No he podido guardarla");
      M5.avisar(r.guardada ? "Lista guardada en «Listas»" : "Lista quitada de «Listas»");
      p.ponerBotones([botonTodo(p), botonBarajar(p), guardar(r.guardada)]);
      M5.emitirDatos("listas");
    }});
    p.ponerBotones([botonTodo(p), botonBarajar(p), guardar(false)]);
    await p.cargar(`/api/pagina/lista_yt?url=${q(url)}&titulo=${q(titulo)}`, (r) => {
      p.ponerTitulo(r.titulo || titulo);
      p.ponerBotones([botonTodo(p), botonBarajar(p), guardar(!!r.guardada)]);
      p.pintar(r);
    });
  });

  // ------------------------------------------------------------------------------------------------ Música (22/10/2026)
  // Encargo de música: «quiero que cat-ode reemplace también a youtube music y que tenga una versión music viviendo dentro de
  // la aplicación». La biblioteca compartida (la hace el ProBook con su historial, sus «Me gusta», YouTube Music y su disco).
  const botonSonido = (p) => ({texto: "🎧  Solo el sonido", titulo: "Reproducir todo sin imagen (gasta menos)", accion: async () => {
    await todo(p, false);
    const r = window.Reproductor && window.Reproductor.gestor && window.Reproductor.gestor.vista && window.Reproductor.gestor.vista();
    if (r && typeof r.solo_sonido === "function") r.solo_sonido(true);
  }});
  // «Importar tu música» (22/10/2026, el autor: «quien use Catode redistributable debe poder importar en local su biblioteca de
  // spotify, amazon music y youtube music»): todo en este aparato (cuenta_servicio._importar_musica → importar_musica.py)
  const elegirRuta = (tipo, filtro) => new Promise((ok) => {
    const soltar = window.app.on("archivo", (d) => { if (d && d.para === "musica") { soltar(); ok(d.ruta || ""); } });
    M5.api("/api/ventana", {accion: "elegir_ruta", valor: {tipo, filtro, para: "musica"}}).catch(() => { soltar(); ok(""); });
  });
  const VIAS = [["youtube", "YouTube Music (con tu cuenta de Google)"],
    ["spotify_archivo", "Spotify: el archivo de «Descargar tus datos» (todo: listas, me gusta, álbumes)"],
    ["spotify_enlace", "Spotify: el enlace de una lista pública (hasta 100 canciones)"],
    ["carpeta", "Una carpeta con tu música (lo comprado en Amazon Music, tus discos…)"],
    ["csv", "Un CSV con tus canciones (Amazon Music por TuneMyMusic, u otro)"]];
  async function importar(p) {
    const M = window.Menu;
    const i = await M.elegir("Importar tu música", "¿De dónde la traigo? Se queda en este Cat-ode; las canciones se buscan en YouTube al sonar.",
      VIAS.map((v) => v[1]));
    if (i === null || i === undefined) return;
    const via = VIAS[i][0];
    let valor = "";
    if (via === "spotify_enlace") {
      valor = await M.preguntar("Lista de Spotify", "Pega el enlace (open.spotify.com/playlist/…):", "");
      if (!valor) return;
    } else if (via !== "youtube") {
      if (via === "spotify_archivo" && !(await M.confirmar("Spotify", "Pide tus datos en spotify.com → Cuenta → Privacidad → «Descargar tus datos». " +
          "Spotify te manda un correo en unos días con un ZIP: elígelo aquí.", "Elegir el ZIP"))) return;
      valor = await elegirRuta(via === "carpeta" ? "carpeta" : "archivo",
        via === "csv" ? "CSV (*.csv);;Todos (*.*)" : "Datos de Spotify (*.zip *.json);;Todos (*.*)");
      if (!valor) return;
    }
    p.aviso("Importando tu música…");
    const fin = await new Promise((ok) => {
      const soltar = window.app.on("cuenta", (d) => {
        if (d && d.fase === "musica" && d.texto && !d.hecho) p.aviso(d.texto);
        if (d && d.fase === "musica" && d.hecho) { soltar(); ok(d); }
      });
      M5.api("/api/cuenta", {accion: "importar_musica", via, valor}).then((r) => {
        if (!r || !r.ok || r.ocupado) { soltar(); ok({error: (r && r.error) || (r && r.ocupado ? "Ya estoy importando: espera a que acabe" : "No ha salido")}); }
      }).catch((err) => { soltar(); ok({error: String(err)}); });
    });
    if (fin.error) p.aviso(fin.error, "error");
    else { window.app.avisar(fin.resumen || "Música importada"); M5.reemplazar("musica", ["Todo"]); }
  }
  registrar("musica", () => ({titulo: "Música", recargarCon: ["biblioteca"]}), async (p, a) => {
    p.ponerBotones([{texto: "📥  Importar tu música", accion: () => importar(p)}]);
    const grupo = a[0] || "Todo";   // chips: Todo · YouTube Music · Spotify · Amazon Music · Álbumes · Artistas · Para ti · Descubrir
    await p.cargar("/api/pagina/musica?grupo=" + q(grupo), (r) => {
      p.ponerTitulo("Música");
      p.ponerChips(r.chips || [], r.activo || grupo, (c) => M5.reemplazar("musica", [c]));
      p.pintar(r);
    }, true);
  });
  registrar("_lista_musica", (a) => ({titulo: a[1] || "Lista", atras: true, fila: true}), async (p, a) => {
    p.ponerBotones([botonTodo(p), botonBarajar(p), botonSonido(p)]);
    await p.cargar("/api/pagina/lista_musica/" + q(a[0] || ""), (r) => { p.ponerTitulo(r.titulo || a[1] || "Lista"); p.pintar(r); }, true);
  });

  // ------------------------------------------------------------------------------------------------ Descargas (3538-3560)
  registrar("descargas", () => ({titulo: "Descargas", fila: true, recargarCon: ["descargas"],
    quitar: async (e, g) => {
      if (!(await Menu.confirmar("Borrar la descarga", `¿Borrar «${e.titulo}» del disco?`, "Borrar"))) return;
      // servicio.datos_accion("borrar_descarga") borra el archivo (M8: talón sustituido por lo real)
      const r = await M5.datos("borrar_descarga", {url: e.url, e: M5.limpio(e)});
      if (!r.ok) return M5.avisar("No he podido borrarla: " + (r.error || ""));
      g.quitarElemento(e);
      M5.avisar("Descarga borrada");
    }}), async (p) => {
    p.ponerBotones([{texto: "📂  Abrir la carpeta", accion: () => M5.ventana("carpeta_descargas", p.ultima && p.ultima.carpeta)}]);
    await p.cargar("/api/pagina/descargas", (r) => p.pintar(r));
  });

  // ------------------------------------------------------------------------------------------------ Para Nut (3368-3413)
  registrar("nut", () => ({titulo: "Para Nut"}), async (p, a) => {
    const chip = a[0] || "";
    p.ponerBotones([{texto: "📺  Poner en la tele", accion: () => M5.ponerEnTele(p.elementos().find((e) => e.tipo === "VIDEO"))}]);
    await p.cargar("/api/pagina/nut" + (chip ? "?chip=" + q(chip) : ""), (r) => {
      p.ponerChips(r.chips || [], r.activo || chip, (c) => M5.reemplazar("nut", [c]));
      p.pintar(r);
    });
  });

  // ------------------------------------------------------------------------------------------------ Canal (3562-3622 + FichaCanal)
  const NOMBRES_CANAL = {videos: "Vídeos", shorts: "Shorts", streams: "Directos", playlists: "Listas", acerca: "Acerca de"};
  function fichaCanal(p, url, r) {
    const info = r.info || {};
    const f = document.createElement("div");
    f.className = "fc";
    f.innerHTML = '<div class="fc-banner"></div><div class="fc-fila"><img class="fc-avatar" alt="" decoding="async"><div>' +
      '<div class="fc-nombre"></div><div class="fc-datos"></div><div class="fc-desc"></div><div class="fc-acerca"></div>' +
      '<div class="fc-valoracion"></div></div></div>';
    const banner = f.querySelector(".fc-banner");
    if (info.banner) banner.style.backgroundImage = `url("${info.banner.replace(/"/g, "%22")}")`; else banner.classList.add("vacio");
    const av = f.querySelector(".fc-avatar");
    if (info.avatar || (r.cabecera && r.cabecera.miniatura)) av.src = info.avatar || r.cabecera.miniatura;
    f.querySelector(".fc-nombre").textContent = (info.nombre || (r.cabecera && r.cabecera.titulo) || "") + (info.verificado ? "  ✔" : "");
    f.querySelector(".fc-datos").textContent = [info.handle, info.suscriptores].filter(Boolean).join(" · ");
    const desc = f.querySelector(".fc-desc");
    desc.textContent = info.descripcion || "";
    desc.title = "Clic para ver entera";
    desc.addEventListener("click", () => desc.classList.toggle("abierta"));
    p.extra.textContent = "";
    p.extra.appendChild(f);
    p.ficha = {url, nodo: f, info};
    // acerca de y valoración, en segundo plano (md.acerca_de / md.valoracion)
    M5.api("/api/canal/acerca?url=" + q(url)).then((a) => {
      if (!a.ok || !p.vivo) return;
      p.acerca = a.acerca || {};
      const x = p.acerca;
      const partes = [];
      if (x.videos) partes.push(`${x.videos} vídeos`);
      if (x.vistas) partes.push(`${(window.CatodeM7 && CatodeM7.util ? CatodeM7.util.miles(x.vistas) : Number(x.vistas).toLocaleString("es-ES"))} visualizaciones`);
      if (x.alta) partes.push(`se unió el ${x.alta}`);
      if (x.pais) partes.push(x.pais);
      f.querySelector(".fc-acerca").textContent = partes.join(" · ");
    });
    M5.api("/api/canal/valoracion?url=" + q(url)).then((v) => {
      if (!v.ok || !p.vivo) return;
      const t = v.texto || v.valoracion || (v.pct != null ? `${v.pct} % de «me gusta»` : "");
      if (t && typeof t === "string") f.querySelector(".fc-valoracion").textContent = t;
    });
  }
  function acercaLargo(p, url) {
    const caja = document.createElement("div");
    caja.className = "fc fc-acerca-largo";
    const pintar = (x) => {
      const info = (p.ficha && p.ficha.info) || {};
      const lineas = [];
      if (info.descripcion) lineas.push(info.descripcion, "");
      if (x.handle || info.handle) lineas.push("Identificador: " + (x.handle || info.handle));
      if (x.suscriptores) lineas.push(x.suscriptores);
      if (x.videos) lineas.push(`${x.videos} vídeos`);
      if (x.vistas) lineas.push(`${(window.CatodeM7 && CatodeM7.util ? CatodeM7.util.miles(x.vistas) : Number(x.vistas).toLocaleString("es-ES"))} visualizaciones`);
      if (x.alta) lineas.push("Se unió el " + x.alta);
      if (x.pais) lineas.push("País: " + x.pais);
      caja.textContent = lineas.join("\n");
      for (const [nombre, enlace] of x.enlaces || []) {
        const d = document.createElement("div");
        const l = document.createElement("a");
        l.textContent = nombre + " · " + enlace;
        l.addEventListener("click", () => abrirEnlace(enlace));
        d.appendChild(l);
        caja.appendChild(d);
      }
    };
    M5.api("/api/canal/acerca?url=" + q(url)).then((a) => { if (p.vivo) pintar((a.ok && a.acerca) || {}); });
    return caja;
  }
  /** abrir_enlace 3722: un enlace de YouTube dentro de la app; lo demás, fuera (navegador). */
  async function abrirEnlace(url, nueva) {
    const a = M5.soloLocal ? null : window.app;
    if (a && typeof a.abrirEnlace === "function") return a.abrirEnlace(url, nueva);
    const r = await M5.api("/api/enlace?url=" + q(url));
    if (!r.ok || r.tipo === "fuera") return M5.abrirFuera(url);
    if (r.tipo === "canal") return M5.abrirCanal(r.url, nueva);
    if (r.tipo === "lista") return M5.ir("_lista_yt", [r.url, r.titulo || "Lista"]);
    if (r.tipo === "busqueda" || r.tipo === "hashtag") return M5.ir("_resultados", [r.titulo || r.url, {}]);
    return M5.abrir({tipo: "VIDEO", url: r.url, titulo: r.titulo || ""});
  }
  M5.abrirEnlace = abrirEnlace;

  registrar("_canal", (a) => ({titulo: "", atras: true, vertical: (a[1] || "videos") === "shorts"}), async (p, a) => {
    const url = a[0] || "", pestana = a[1] || "videos";
    let nombre = "", suscrito = false;
    const alChip = (n) => {
      const k = Object.keys(NOMBRES_CANAL).find((x) => NOMBRES_CANAL[x] === n) || "videos";
      M5.reemplazar("_canal", [url, k]);
    };
    const botones = () => p.ponerBotones([botonTodo(p), botonBarajar(p),
      {texto: suscrito ? "🔔  Suscrito" : "Suscribirse", principal: !suscrito, accion: async () => {
        const r = suscrito ? await M5.datos("anular", {url})
          : await M5.datos("suscribir", {e: {tipo: "CANAL", url, titulo: nombre || url, miniatura: (p.ficha && p.ficha.info.avatar) || ""}});
        if (!r.ok) return M5.avisar("No he podido cambiar la suscripción");
        suscrito = !!r.suscrito;
        M5.avisar(suscrito ? `Suscrito a «${nombre}»` : `Ya no sigues «${nombre}»`);
        botones();
        M5.emitirDatos("suscripciones");
      }},
      {texto: "⊘  Fulminar canal", accion: async () => {
        const hecho = await M5.fulminar({tipo: "CANAL", url, titulo: nombre || url});
        if (hecho !== false) M5.volver();
      }}]);
    botones();
    p.ponerChips(Object.values(NOMBRES_CANAL), NOMBRES_CANAL[pestana], alChip);
    const ruta = `/api/pagina/canal?url=${q(url)}&pestana=${q(pestana === "acerca" ? "videos" : pestana)}`;
    await p.cargar(ruta, (r) => {
      nombre = (r.info && r.info.nombre) || (r.cabecera && r.cabecera.titulo) || "";
      suscrito = !!r.suscrito;
      p.ponerTitulo(r.titulo || nombre);
      botones();
      fichaCanal(p, url, r);
      if (pestana === "acerca") {
        p.rejilla.poner([], {}, " ");
        p.extra.appendChild(acercaLargo(p, url));
        return;
      }
      p.pintar(Object.assign({}, r, {aviso: r.aviso || ((r.elementos || []).length ? "" : "Este canal no tiene nada aquí.")}),
        (c) => `${ruta}&cursor=${q(c)}`);
    });
  });

  // ------------------------------------------------------------------------------------------------ Resultados (3686-3720)
  const FILTROS = [["tipo", "Tipo"], ["fecha", "Fecha de subida"], ["duracion", "Duración"], ["orden", "Ordenar por"]];
  registrar("_resultados", (a) => ({titulo: `«${a[0] || ""}»`, fila: true, tituloPestana: a[0] || "Buscar"}), async (p, a) => {
    const texto = a[0] || "";
    const filtros = Object.assign({}, a[1] || {});
    const consulta = (cursor) => {
      const u = new URLSearchParams({q: texto});
      for (const [k] of FILTROS) if (filtros[k]) u.set(k, filtros[k]);
      if (cursor) u.set("cursor", cursor);
      return "/api/buscar?" + u.toString();
    };
    const combos = (opciones) => FILTROS.map(([clave, nombre]) => {
      const s = document.createElement("select");
      s.className = "pr-sel";
      s.dataset.filtro = clave;
      s.title = nombre;
      const o0 = document.createElement("option"); o0.value = ""; o0.textContent = nombre + ": cualquiera"; s.appendChild(o0);
      for (const k of (opciones && opciones[clave]) || []) { const o = document.createElement("option"); o.value = k; o.textContent = k; s.appendChild(o); }
      s.value = filtros[clave] || "";
      s.addEventListener("change", () => {   // _refiltrar 3713: reemplaza la entrada de la pila
        const f = Object.assign({}, filtros);
        if (s.value) f[clave] = s.value; else delete f[clave];
        M5.reemplazar("_resultados", [texto, f]);
      });
      return s;
    });
    p.ponerBotones(combos(p._opciones || null));
    if (texto) M5.datos("buscado", {q: texto});
    await p.cargar(consulta(), (r) => {
      if (r.filtros) { p._opciones = r.filtros; p.ponerBotones(combos(r.filtros)); }
      p.pintar(Object.assign({}, r, {aviso: r.aviso || ((r.elementos || []).length ? "" : "Sin resultados.")}), consulta);
    });
  });

  // ------------------------------------------------------------------------------------------------ alias
  // Nombres cortos del encargo (canal, resultados, lista) apuntando a las mismas funciones que la Qt.
  for (const [corto, largo] of [["canal", "_canal"], ["resultados", "_resultados"], ["lista", "_lista_yt"], ["gestionar", "_gestionar"],
    ["lista_propia", "_lista_propia"]]) {
    window.catodePaginas[corto] = window.catodePaginas[largo];
    window.app.registrar(corto, window.catodePaginas[largo]);
  }
})();
