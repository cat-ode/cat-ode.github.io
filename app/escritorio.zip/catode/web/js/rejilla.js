// Cat-ode escritorio · interfaz web · módulo M5 (DISENO_WEB.md §3 y §1.11), 06/10/2026.
// rejilla.js: la cuadrícula de tarjetas (tarjetas.py Rejilla 422-544), VIRTUALIZADA para el N100: solo existen los
// nodos de lo que se ve más un margen, nunca más de 150, y se reutilizan al hacer scroll (pool). Columnas = ancho //
// (300 + 16) (200 + 16 en vertical; una en filas). Un solo requestAnimationFrame por scroll. Las tarjetas llevan
// contain: strict (medidas fijas) y content-visibility. Al cambiar el ancho se recoloca a los 120 ms conservando el
// sitio; refiltrar (canal fulminado, tema filtrado) quita lo vetado sin perder el scroll. A < 600 px del final avisa
// (alFinal) para pedir la tanda siguiente.
"use strict";
(function () {
  const M5 = window.M5, Tarjeta = window.Tarjeta;
  const POOL_MAX = 150, HUECO_H = 16, MARGEN_FINAL = 600;
  // 06/10/2026 (N100): una lista grande entra por tandas de 48, con ≤ 8 ms de trabajo por tarea, cediendo entre tareas
  // (scheduler.yield si existe; si no, setTimeout 0): ningún cuadro carga con miles de elementos de golpe
  const TANDA = 48, SINCRONOS = 240, PRESUPUESTO_MS = 8;
  const ceder = () => (window.scheduler && typeof window.scheduler.yield === "function") ? window.scheduler.yield() :
    new Promise((ok) => setTimeout(ok, 0));

  // la hoja de estilos del módulo, si index.html (M4) no la enlaza ya
  if (!document.querySelector('link[href*="css/rejilla.css"]')) {
    const l = document.createElement("link");
    l.rel = "stylesheet";
    const v = (document.currentScript && /[?&]v=([^&]+)/.exec(document.currentScript.src || "")) || null;
    l.href = M5.base() + "/css/rejilla.css" + (v ? "?v=" + v[1] : "");
    document.head.appendChild(l);
  }

  // ------------------------------------------------------------------------------------------------ vetos (datos.vetado 122)
  const sin = (t) => (t || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "");
  const normUrl = (u) => (u || "").toLowerCase().split("?")[0].replace(/\/+$/, "").replace("://m.youtube", "://www.youtube");
  const escapar = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const BORDE_I = "(^|[^\\p{L}\\p{N}_])", BORDE_F = "($|[^\\p{L}\\p{N}_])";
  let vetos = {urls: new Set(), nombres: new Set(), temas: [], colab: []};
  function rehacerVetos(temas, fulminados) {
    const urls = new Set(), nombres = new Set(), pal = new Set();
    for (const [u, n] of fulminados || []) { if (u) urls.add(normUrl(u)); if (n) nombres.add(n.trim().toLowerCase()); }
    for (const [, palabras] of temas || []) for (const w of palabras || []) if (w.trim()) pal.add(sin(w.trim()));
    vetos = {urls, nombres,
      temas: [...pal].map((w) => patron(w.split("*").filter(Boolean), BORDE_I + w.split("*").map(escapar).join("[\\p{L}\\p{N}_]*") + BORDE_F)),
      colab: [...nombres].filter((n) => n.length > 3).map((n) => patron([n], BORDE_I + escapar(n) + BORDE_F))};
  }
  // 06/10/2026 (perfil de uso, N100): un veto solo puede casar si sus trozos literales están en el texto. Primero esa
  // comprobación barata (includes) y la expresión regular (con \p{L}, cara de compilar y de pasar) solo si hace falta, y
  // compilada la primera vez que se usa: con los 55 canales fulminados del autor, rehacer y pasar 55 expresiones por cada
  // tarjeta era lo más caro del arranque (≈ 90 ms en el ProBook, el triple en el N100) y del Historial
  function patron(trozos, fuente) {
    let re = null;
    return {test: (t) => trozos.every((x) => t.includes(x)) && (re || (re = new RegExp(fuente, "u"))).test(t)};
  }
  M5.vetado = function (e) {
    if (!(vetos.urls.size || vetos.nombres.size || vetos.temas.length)) return false;
    const canal = e.tipo === "CANAL";
    const url = normUrl(canal ? e.url : (e.autorUrl || ""));
    const nombre = ((canal ? e.titulo : e.autor) || "").trim().toLowerCase();
    if ((url && vetos.urls.has(url)) || (nombre && vetos.nombres.has(nombre)) || (nombre.length > 3 && vetos.colab.some((r) => r.test(nombre)))) return true;
    if (!vetos.temas.length) return false;   // sin temas filtrados, ni se normaliza el texto (NFD de cada tarjeta)
    const texto = sin(`${e.titulo || ""} ${e.autor || ""} ${e.detalle || ""}`);
    return vetos.temas.some((r) => r.test(texto));
  };
  /** Trae los vetos del servidor (GET /api/vetos) y refiltra todas las rejillas vivas. */
  // 06/10/2026 (N100): cada cambio de datos (la posición del vídeo que suena se guarda cada 5 s) manda un SSE «datos» que
  // relee los vetos; si no han cambiado, no se rehacen ni se refiltra (eran miles de elementos por rejilla viva en cada aviso)
  let firmaVetos = null;
  M5.recargarVetos = async function () {
    const r = await M5.api("/api/vetos");
    if (!r.ok) return false;
    const firma = JSON.stringify([r.temas || [], r.fulminados || []]);
    if (firma === firmaVetos) return true;
    firmaVetos = firma;
    rehacerVetos(r.temas, r.fulminados);
    Rejilla.vivas.forEach((g) => g.refiltrar());
    return true;
  };
  /** Un canal recién fulminado: fuera ya de todas las rejillas, sin esperar al servidor. */
  M5.vetarLocal = function (url, nombre) {
    if (url) vetos.urls.add(normUrl(url));
    if (nombre) {
      const n = nombre.trim().toLowerCase();
      vetos.nombres.add(n);
      if (n.length > 3) vetos.colab.push(patron([n], BORDE_I + escapar(n) + BORDE_F));
    }
    Rejilla.vivas.forEach((g) => g.refiltrar());
    return true;
  };
  // el SSE «datos» (cambio llegado de otro equipo o de otra pestaña) por el marco (M4: app.on) → catode:datos
  if (window.app && typeof window.app.on === "function") {
    try { window.app.on("datos", (d) => M5.emitirDatos(d && d.col, d && d.motivo)); } catch (e) { /* sin marco */ }
  }
  window.addEventListener("catode:datos", (ev) => {
    const col = ev.detail && ev.detail.col;
    if (!col || col === "ocultos" || col === "vetos") M5.recargarVetos();
  });

  // ------------------------------------------------------------------------------------------------ la rejilla
  /**
   * new Rejilla(scroller, o): scroller = el elemento con overflow que hace scroll (la rejilla va dentro de él);
   * o = {fila, vertical, anchoImg, quitar(e), vacio, alFinal(), menu(e, x, y, conTeclado)}.
   */
  class Rejilla {
    constructor(scroller, o) {
      this.o = Object.assign({fila: false, vertical: false, anchoImg: 246, quitar: null, vacio: "No hay nada que enseñar aquí todavía."}, o || {});
      this.scroller = scroller;
      // 06/10/2026: el hueco de la barra de scroll, reservado. En Windows la barra ocupa ~10 px: al llenarse la lista
      // aparecía, el ancho cambiaba, el ResizeObserver rehacía TODAS las tarjetas a mitad de scroll (52 ms de guion +
      // 68 de maquetado en el N100: el cuadro largo de la prueba de 3000 elementos). Con el hueco fijo el ancho no cambia
      if (scroller && scroller.style && !scroller.style.scrollbarGutter) scroller.style.scrollbarGutter = "stable";
      this.nodo = document.createElement("div");
      this.nodo.className = "rj";
      this.nodo.tabIndex = 0;
      this.nodo.setAttribute("role", "list");
      this.fin = document.createElement("div");
      this.fin.className = "rj-fin";
      this.elementos = [];
      this.motivos = {};
      this.vivos = new Map();     // índice → nodo
      this.libres = [];           // nodos del pool sin usar (ocultos)
      this.creados = 0;
      this.foco = -1;
      this.pidiendo = false;
      this.pendiente = 0;
      this.alFinal = this.o.alFinal || null;
      // 06/10/2026: lo que se mide UNA vez y se guarda (el cuadro del scroll no lee nada del maquetado): la posición del
      // scroll (la apunta el evento scroll), el alto visible (el ResizeObserver), dónde empieza la rejilla y el ancho
      this._st = scroller ? scroller.scrollTop : 0;
      this._H = 0;
      this._desf = null;
      this._disp = 0;
      this._alto = -1;
      this._cola = [];
      this._gen = 0;
      this._conMotivo = false;
      this._noCanal = false;
      this._medir(true);
      this._oyentes();
      Rejilla.vivas.add(this);
    }

    /** La rejilla en el documento: devuelve [nodo, fin] para meterlos donde toque. */
    montar(padre) { padre.appendChild(this.nodo); padre.appendChild(this.fin); return this; }

    // ---- datos
    poner(elementos, motivos, aviso) {
      Rejilla.previa().salir();
      this.elementos = [];
      this.motivos = {};
      this.foco = -1;
      this.pidiendo = false;
      this._cola = [];
      this._gen++;
      this._conMotivo = this._noCanal = false;
      for (const [i, n] of this.vivos) { this._soltar(n); this.vivos.delete(i); }
      this.scroller.scrollTop = 0;
      this._st = 0;
      this._desf = null;
      this._cortarRelleno();   // la lista cambió: lo que siga llegando del relleno, fuera (y la petición en curso, abortada)
      this._sinMargen = true;   // el primer cuadro, solo lo que se ve (las filas de margen, en el hueco siguiente)
      this.anadir(elementos || [], motivos, aviso);
    }
    anadir(elementos, motivos, aviso) {
      this.pidiendo = false;
      Object.assign(this.motivos, motivos || {});
      const lista = elementos || [];
      this._desf = null;   // la cabecera de encima pudo cambiar con la lista: se vuelve a medir una vez
      if (!this._cola.length && lista.length <= SINCRONOS) return this._meter(lista, aviso, true);
      // lista grande: lo primero ya (lo que se ve), el resto por tandas en tareas aparte
      const ya = this._cola.length ? [] : lista.slice(0, SINCRONOS);
      for (let k = ya.length; k < lista.length; k++) this._cola.push(lista[k]);
      this._avisoCola = aviso;
      if (ya.length) this._meter(ya, aviso, true);
      this._vaciarCola();
    }
    /** Mete elementos ya llegados (filtrando lo vetado) y pinta. releer = medir el ancho otra vez (no en las tandas). */
    _meter(lista, aviso, releer) {
      const nuevos = [];
      for (const e of lista) {
        if (M5.vetado(e)) continue;
        this.elementos.push(e); nuevos.push(e);
        if (!this._conMotivo && this.motivo(e)) this._conMotivo = true;
        if (e.tipo !== "CANAL") this._noCanal = true;
      }
      const f = this.elementos.length ? (aviso || "") : (aviso || this.o.vacio || "");
      if (this.fin._t !== f) { this.fin._t = f; this.fin.textContent = f; }
      this._pintar(this._medir(releer));
      this._mirarFinal();
      this._rellenar(nuevos);
    }
    async _vaciarCola() {
      if (this._vaciando) return;
      this._vaciando = true;
      const gen = this._gen;
      try {
        while (this._cola.length && !this._muerta && gen === this._gen) {
          await ceder();
          if (this._muerta || gen !== this._gen) break;
          const t0 = performance.now(), tanda = [];
          do { for (const e of this._cola.splice(0, TANDA)) tanda.push(e); } while (this._cola.length && performance.now() - t0 < PRESUPUESTO_MS);
          this._meter(tanda, this._avisoCola, false);
        }
      } finally { this._vaciando = false; }
      if (this._cola.length && !this._muerta && gen !== this._gen) this._vaciarCola();   // poner() nuevo durante la espera
    }
    /** M8 · fichas.Relleno (444-469): duración, visualizaciones y fecha que la lista no trajo (novedades del RSS,
     *  historial), por detrás: POST /api/completar en tandas de 48, hasta 300 por lista; repinta solo esas tarjetas.
     *  UNA sola cadena por rejilla (el scroll infinito añade a su cola, no abre otra), con AbortController: poner() (la
     *  lista cambió) y destruir() (se fue de la página) cortan la petición en curso y lo pendiente, como la Qt. */
    _cortarRelleno() {
      const r = this._relleno;
      if (r) { r.cola.length = 0; if (r.ctl) r.ctl.abort(); }
      this._relleno = null;
    }
    _rellenar(els) {
      if (M5.soloLocal || this._muerta) return;
      // el criterio de la Qt: sin duración, sin fecha o sin detalle (no «sin visualizaciones»: eran casi todas)
      const r = this._relleno = this._relleno || {cola: [], vistos: 0, ctl: null, corriendo: false};
      // 24/10/2026: un estreno que aún no ha empezado («Próximamente · …», motor.programado) no: salía «0 visualizaciones»
      const faltan = els.filter((e) => e && e.tipo === "VIDEO" && /^https?:/.test(String(e.url || "")) &&
        !/^Próximamente/.test(e.detalle || "") &&
        (!(e.duracion > 0) || !e.fecha || !e.detalle)).slice(0, Math.max(0, 300 - r.vistos));
      if (!faltan.length) return;
      r.vistos += faltan.length;
      r.cola.push(...faltan);
      if (r.corriendo) return;
      r.corriendo = true;
      const pedir = async () => {
        if (this._muerta || this._relleno !== r || !r.cola.length) { r.corriendo = false; return; }
        const trozo = r.cola.splice(0, 48);
        r.ctl = new AbortController();
        const x0 = await M5.api("/api/completar", {urls: trozo.map((e) => e.url)}, {signal: r.ctl.signal});
        r.ctl = null;
        if (this._muerta || this._relleno !== r) { r.corriendo = false; return; }
        if (!x0.ok) { r.cola.length = 0; r.corriendo = false; return; }   // sin red o bloqueo: no se insiste (regla 24)
        const d = x0.datos || {};
        let cambio = false;
        for (const e of trozo) {
          const x = d[e.url];
          if (!x) continue;
          if (!(e.duracion > 0) && x.duracion > 0) { e.duracion = x.duracion; cambio = true; }
          if (x.vistas && !/visualiz/.test(e.detalle || "")) { e.detalle = e.detalle ? x.vistas + " · " + e.detalle : x.vistas; cambio = true; }
          if (!e.fecha && x.fecha) { e.fecha = x.fecha; cambio = true; }
        }
        if (cambio) {
          const tocados = new Set(trozo);
          let visible = false;
          for (const n of this.vivos.values()) if (tocados.has(n._e)) { n._i = -1; n._forma = null; visible = true; }   // se vuelven a poner en _pintar
          // solo si alguna de las tocadas está a la vista (repinta esas, nada más). Ya, no en el cuadro siguiente: con el
          // N100 cargado un cuadro tarda más de 100 ms y la tarjeta enseñaba el dato viejo (prueba «relleno», 06/10/2026)
          if (visible) this._pintar(false);
        }
        pedir();
      };
      pedir();
    }
    motivo(e) { return this.motivos[e.url] || e.motivo || ""; }
    /** Toda la lista, también lo que aún espera su tanda (sin lo vetado). */
    todos() { return this._cola.length ? this.elementos.concat(this._cola.filter((e) => !M5.vetado(e))) : this.elementos; }
    /** Quita lo vetado ahora (refiltrar 478) conservando el scroll. */
    refiltrar(predicado) {
      const quita = predicado || M5.vetado;
      const quedan = this.elementos.filter((e) => !quita(e));
      if (quedan.length === this.elementos.length) return 0;
      this._reemplazar(quedan);
      return this.elementos.length;
    }
    /** «No me interesa», ✕: fuera un elemento sin perder el sitio. */
    quitarElemento(e) {
      if (this._cola.length) this._cola = this._cola.filter((x) => x !== e && x.url !== e.url);
      const quedan = this.elementos.filter((x) => x !== e && x.url !== e.url);
      if (quedan.length !== this.elementos.length) this._reemplazar(quedan);
    }
    _reemplazar(lista) {
      const pos = this.scroller.scrollTop;
      Rejilla.previa().salir();
      for (const [i, n] of this.vivos) { this._soltar(n); this.vivos.delete(i); }
      this.elementos = lista;
      this._conMotivo = lista.some((e) => this.motivo(e));
      this._noCanal = lista.some((e) => e.tipo !== "CANAL");
      if (this.foco >= lista.length) this.foco = lista.length - 1;
      if (!lista.length) { this.fin._t = this.o.vacio || ""; this.fin.textContent = this.fin._t; }
      this._desf = null;
      const c = this._medir(true);
      this.scroller.scrollTop = pos;   // el navegador lo recorta solo si la rejilla es ahora más corta
      this._st = pos;
      this._pintar(c);
    }

    // ---- medidas
    _medir(releer) {
      if (releer || !this._disp) {
        this._disp = Math.max(200, (this.nodo.clientWidth || (this.scroller.clientWidth - 48)) - 4);
        // dónde empieza, con el maquetado aún limpio de esta lectura (después de cambiar el alto, leerlo forzaba otro)
        if (this._desf === null && this.nodo.isConnected) this._desfase();
      }
      const disp = this._disp;
      let cols, ancho;
      if (this.o.fila) { cols = 1; ancho = disp; }
      else {
        const minimo = this.o.vertical ? 200 : 300;
        cols = Math.max(1, Math.floor(disp / (minimo + HUECO_H)));
        ancho = Math.floor((disp - (cols - 1) * HUECO_H) / cols);
      }
      const conMotivo = this._conMotivo;   // se llevan al meter elementos (antes: dos recorridos de toda la lista)
      const canales = !this.o.fila && this.elementos.length > 0 && !this._noCanal;
      const m = Tarjeta.medidas({fila: this.o.fila, vertical: this.o.vertical, anchoImg: this.o.anchoImg, conMotivo}, ancho);
      if (canales) { m.ih = Math.min(ancho, 160); m.alto = m.ih + 10 + 42 + 19 + 10; }
      const huecoV = this.o.fila ? 8 : 24;
      const cambio = !this.m || this.cols !== cols || this.m.ancho !== m.ancho || this.m.alto !== m.alto || this.m.ih !== m.ih;
      this.cols = cols; this.huecoV = huecoV; this.filaH = m.alto + huecoV; this.anchoCol = ancho + HUECO_H;
      if (cambio) this.m = m;
      const filas = Math.ceil(this.elementos.length / cols);
      const alto = Math.max(0, filas * this.filaH - huecoV);
      if (alto !== this._alto) { this._alto = alto; this.nodo.style.height = alto + "px"; }
      return cambio;
    }

    // ---- pintar lo visible (pool)
    /** Dónde empieza la rejilla dentro del contenido que hace scroll (la cabecera, la ficha del canal… van encima). */
    _desfase() {
      this._desf = this.nodo.getBoundingClientRect().top - this.scroller.getBoundingClientRect().top + this.scroller.scrollTop;
      return this._desf;
    }
    /** El mismo dato guardado (se mide al cambiar la lista o el ancho; nunca en el cuadro del scroll). */
    _desfaseG() { return this._desf === null ? this._desfase() : this._desf; }
    _alturaVista() { return this._H || (this._H = this.scroller.clientHeight || window.innerHeight); }
    _rango() {
      const H = this._alturaVista();
      const arriba = this._st - this._desfaseG();
      const filasVisibles = Math.ceil(H / this.filaH) + 1;
      const margen = this._sinMargen ? 0 : Math.max(0, Math.min(3, Math.floor((Math.floor(POOL_MAX / this.cols) - filasVisibles) / 2)));
      const total = Math.ceil(this.elementos.length / this.cols);
      let primera = Math.max(0, Math.floor(arriba / this.filaH) - margen);
      let ultima = Math.min(total - 1, Math.floor((arriba + H) / this.filaH) + margen);
      while ((ultima - primera + 1) * this.cols > POOL_MAX && ultima > primera) ultima--;
      return [primera * this.cols, Math.min(this.elementos.length, (ultima + 1) * this.cols)];
    }
    // 06/10/2026: el cuadro solo toca los nodos que cambian de sitio. Los que salen por un lado se reutilizan para los que
    // entran por el otro SIN ocultarlos antes (ocultar y volver a enseñar recalculaba sus estilos); los demás, ni se leen
    _pintar(cambio) {
      this.pendiente = 0;
      if (!this.nodo.isConnected) return;
      const [desde, hasta] = this.elementos.length ? this._rango() : [0, 0];
      const enfocado = document.activeElement;
      const sueltos = [];
      for (const [i, n] of this.vivos) {
        if (i < desde || i >= hasta) {
          if (n === enfocado) this.nodo.focus({preventScroll: true});
          this.vivos.delete(i); n._i = -1; sueltos.push(n);
        }
      }
      const opc = {fila: this.o.fila, vertical: this.o.vertical, quitar: !!this.o.quitar};
      for (let i = desde; i < hasta; i++) {
        let n = this.vivos.get(i);
        const e = this.elementos[i];
        if (!n) { n = sueltos.pop() || this._tomar(); if (!n) break; this.vivos.set(i, n); n._i = -1; }
        if (n._i !== i || n._e !== e || cambio) {
          opc.motivo = this.motivo(e);
          if (cambio) n._forma = null;
          Tarjeta.poner(n, e, this.m, opc);
          const x = (i % this.cols) * this.anchoCol, y = Math.floor(i / this.cols) * this.filaH;
          const tr = `translate(${x}px, ${y}px)`;
          if (n._tr !== tr) { n._tr = tr; n.style.transform = tr; }
          n._i = i;
          if (n._foco) { n._foco = false; n.classList.remove("foco"); }
        }
      }
      for (const n of sueltos) this._soltar(n);
      // 06/10/2026 (perfil de uso, N100): la página nueva enseña primero lo visible y crea las filas de margen (otras ~20
      // tarjetas) en el hueco siguiente: el cuadro de la primera pintada pesaba el doble
      if (this._sinMargen && this.elementos.length) {
        this._sinMargen = false;
        const f = () => { if (!this._muerta) this.pedirPintura(); };
        if (window.requestIdleCallback) requestIdleCallback(f, {timeout: 300}); else setTimeout(f, 60);
      }
      if (this.foco >= 0 && document.activeElement === this.nodo) {
        const f = this.vivos.get(this.foco);
        if (f) f.focus({preventScroll: true});
      }
    }
    _tomar() {
      let n = this.libres.pop();
      if (!n) {
        if (this.creados >= POOL_MAX) return null;
        n = Tarjeta.crear();
        this.creados++;
        this.nodo.appendChild(n);
      }
      if (n._oculto) { n._oculto = false; n.style.display = ""; }
      return n;
    }
    _soltar(n) { if (!n._oculto) { n._oculto = true; n.style.display = "none"; } n._i = -1; n._e = null; this.libres.push(n); }
    pedirPintura() { if (!this.pendiente) this.pendiente = requestAnimationFrame(() => this._pintar(false)); }

    _mirarFinal() {
      // sin leer scrollHeight (forzaba el maquetado en cada evento de scroll): el fondo sale de lo que ya se sabe
      if (this.pidiendo || !this.alFinal || !this.elementos.length || this._cola.length) return;
      const fondo = this._desfaseG() + Math.max(0, this._alto) + 24 + (this.fin._t ? 40 : 0);
      if (this._st + this._alturaVista() >= fondo - MARGEN_FINAL) {
        this.pidiendo = true;
        try { this.alFinal(); } catch (e) { this.pidiendo = false; }
      }
    }

    // ---- teclado y foco (keyPressEvent 333, _vecina 355)
    enfocar(i) {
      if (!this.elementos.length) return;
      i = Math.max(0, Math.min(this.elementos.length - 1, i));
      this.foco = i;
      const y = this._desfase() + Math.floor(i / this.cols) * this.filaH;
      const s = this.scroller;
      const tapa = this.o.tapa ? this.o.tapa() : 0;   // la cabecera fija (sticky) de la página tapa lo de arriba
      if (y < s.scrollTop + tapa + 8) s.scrollTop = Math.max(0, y - tapa - 8);
      else if (y + this.m.alto > s.scrollTop + s.clientHeight - 40) s.scrollTop = y + this.m.alto - s.clientHeight + 40;
      this._st = s.scrollTop;
      this._pintar(false);
      const n = this.vivos.get(i);
      if (n) n.focus({preventScroll: true});
    }
    primeraVisible() {
      const arriba = this.scroller.scrollTop - this._desfase();
      return Math.max(0, Math.min(this.elementos.length - 1, Math.ceil(Math.max(0, arriba) / this.filaH) * this.cols));
    }
    abrirMenu(e, x, y, conTeclado) {
      if (this.o.menu) return this.o.menu(e, x, y, conTeclado);
      return window.Menu.video(e, x, y, {conTeclado, quitarDeVista: (x2) => this.quitarElemento(x2)});
    }

    _oyentes() {
      const g = this.nodo;
      const tarjetaDe = (ev) => { const n = ev.target.closest && ev.target.closest(".tj"); return n && n._e ? n : null; };
      const ctx = {quitar: this.o.quitar ? (e) => this.o.quitar(e, this) : null, menu: (e, x, y) => this.abrirMenu(e, x, y, false)};
      g.addEventListener("click", (ev) => {
        const n = tarjetaDe(ev);
        if (!n) return;
        ev.preventDefault();
        this.foco = n._i;
        Rejilla.previa().salir();
        Tarjeta.pulsar(ev, n._e, Tarjeta.zona(ev.target), ctx);
      });
      g.addEventListener("mousedown", (ev) => { if (ev.button === 1 && tarjetaDe(ev)) ev.preventDefault(); });   // sin autoscroll
      g.addEventListener("auxclick", (ev) => {
        const n = tarjetaDe(ev);
        if (!n || ev.button !== 1) return;
        ev.preventDefault();
        Tarjeta.pulsar(ev, n._e, Tarjeta.zona(ev.target), ctx);
      });
      g.addEventListener("contextmenu", (ev) => {
        const n = tarjetaDe(ev);   // canal de un vídeo y tarjetas que no son vídeos: el menú general (app.js)
        if (n && n._e.tipo === "VIDEO" && Tarjeta.zona(ev.target) !== "autor") { ev.preventDefault(); this.abrirMenu(n._e, ev.clientX, ev.clientY, false); }
      });
      g.addEventListener("mousemove", (ev) => {
        const n = tarjetaDe(ev);
        if (n) Rejilla.previa().posar(n); else Rejilla.previa().salir();
      });
      g.addEventListener("mouseleave", () => Rejilla.previa().salir());
      g.addEventListener("focus", () => {   // Tab hasta la rejilla: a la última tarjeta con foco o la primera visible
        if (this.elementos.length) this.enfocar(this.foco >= 0 ? this.foco : this.primeraVisible());
      });
      g.addEventListener("focusin", (ev) => { const n = tarjetaDe(ev); if (n) this.foco = n._i; });
      g.addEventListener("keydown", (ev) => {
        const n = tarjetaDe(ev);
        if (!n) return;
        const e = n._e, k = ev.key;
        if (k === "Enter") { ev.preventDefault(); return (ev.ctrlKey || ev.metaKey) ? M5.nuevaPestana(e) : M5.abrir(e); }
        if (k === "Delete" && ctx.quitar) { ev.preventDefault(); return ctx.quitar(e); }
        if ((k === "ContextMenu" || (k === "F10" && ev.shiftKey)) && e.tipo === "VIDEO") {
          ev.preventDefault();
          const r = n.getBoundingClientRect();
          return this.abrirMenu(e, r.left + r.width / 2, r.top + r.height / 2, true);
        }
        if (ev.ctrlKey || ev.altKey || ev.metaKey || ev.shiftKey) return;
        const paso = {ArrowLeft: this.o.fila ? 0 : -1, ArrowRight: this.o.fila ? 0 : 1, ArrowUp: -this.cols, ArrowDown: this.cols}[k];
        if (paso === undefined) return;
        ev.preventDefault();
        const i = n._i + paso;
        if (paso && i >= 0 && i < this.elementos.length && (Math.abs(paso) === this.cols || Math.floor(i / this.cols) === Math.floor(n._i / this.cols))) this.enfocar(i);
      });
      // la única lectura del scroll: scrollTop en su evento (el cuadro de pintar usa lo apuntado)
      this._alScroll = () => { this._st = this.scroller.scrollTop; Rejilla.previa().salir(); this.pedirPintura(); this._mirarFinal(); };
      this.scroller.addEventListener("scroll", this._alScroll, {passive: true});
      let reloj = 0;
      this._ro = new ResizeObserver((entradas) => {   // sin leer nada aquí: el alto viene en la entrada
        const en = entradas[entradas.length - 1];
        if (en && en.contentRect && en.contentRect.height > 0) this._H = en.contentRect.height;
        clearTimeout(reloj);
        reloj = setTimeout(() => this._recolocar(), 120);
      });
      this._ro.observe(this.scroller);
    }
    /** _recolocar: el ancho ha cambiado; mismo primer elemento visible arriba. */
    // 06/10/2026: primero todas las lecturas (scroll, dónde empieza, ancho) y luego todas las escrituras: un solo maquetado
    _recolocar() {
      if (!this.nodo.isConnected) return;
      const st = this.scroller.scrollTop, d0 = this._desfase();
      const arriba = st - d0;
      const primero = Math.max(0, Math.min(this.elementos.length - 1, Math.ceil(Math.max(0, arriba) / this.filaH) * this.cols));
      const desfase = arriba - Math.floor(primero / this.cols) * this.filaH;
      this._st = st;
      if (!this._medir(true)) return this._pintar(false);
      if (st > d0) {   // el alto de la rejilla no mueve su borde de arriba: d0 sigue valiendo
        const nuevo = d0 + Math.floor(primero / this.cols) * this.filaH + Math.max(0, desfase);
        this.scroller.scrollTop = nuevo;
        this._st = nuevo;
      }
      this._pintar(true);
    }
    nodos() { return this.nodo.querySelectorAll(".tj").length; }
    destruir() {
      this._muerta = true;
      this._cortarRelleno();
      Rejilla.previa().salir();
      this.scroller.removeEventListener("scroll", this._alScroll);
      if (this._ro) this._ro.disconnect();
      if (this.pendiente) cancelAnimationFrame(this.pendiente);
      Rejilla.vivas.delete(this);
    }
  }
  Rejilla.vivas = new Set();
  Rejilla.POOL_MAX = POOL_MAX;
  Rejilla.previa = () => window.Previa || {posar() {}, salir() {}};
  window.Rejilla = Rejilla;
  M5.recargarVetos();
})();
