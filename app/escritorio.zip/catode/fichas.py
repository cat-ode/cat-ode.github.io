"""Cat-ode escritorio · las fichas completas (02/10/2026): la sección «Datos» de cada vídeo, la ficha de cada canal con
la valoración estimada de sus últimos vídeos, y el relleno de las listas (duración, visualizaciones y fecha) cuando
YouTube no las da. Lo mismo que enseña el móvil. Los datos salen de metadatos.py; aquí solo se pintan."""
import concurrent.futures as cf
import html
import threading
import urllib.parse

from PySide6.QtCore import Qt, QObject, Signal, QEvent
from PySide6.QtGui import QPainter, QColor
from PySide6.QtWidgets import QWidget, QLabel, QPushButton, QTextBrowser, QVBoxLayout, QHBoxLayout, QSizePolicy

from . import metadatos as md
from . import motor

VERDE, ROJO, GRIS = "#3BA55C", "#E5534B", "#9AA0AA"
NOTA_SUBS = "YouTube redondea los suscriptores a 3 cifras: es la cifra que da, no la exacta."
NOTA_RYD = "estimación de Return YouTube Dislike"



class _CentralEnlace(QObject):
    """05/10/2026: botón central sobre un enlace (descripción, comentarios, fichas) = pestaña nueva, como en el navegador;
    QLabel y QTextBrowser solo avisan del clic izquierdo."""
    def __init__(self, w, al_central):
        super().__init__(w)
        self.w, self.al_central, self.sobre = w, al_central, ""
        if isinstance(w, QTextBrowser):
            w.viewport().installEventFilter(self)
        else:
            w.linkHovered.connect(lambda u: setattr(self, "sobre", u))
            w.installEventFilter(self)

    def eventFilter(self, obj, ev):
        if ev.type() == QEvent.MouseButtonPress and ev.button() == Qt.MiddleButton:
            u = self.w.anchorAt(ev.position().toPoint()) if isinstance(self.w, QTextBrowser) else self.sobre
            if u:
                self.al_central(u)
                return True
        return False


def central_en_enlaces(w, al_central):
    return _CentralEnlace(w, al_central)

class _Aviso(QObject):
    """Pasa resultados de los hilos de trabajo a la ventana (Qt solo deja tocar la pantalla desde su hilo)."""
    senal = Signal(object, object)


_aviso = None


def preparar():
    """Crea el mensajero en el hilo de la ventana (si se creara en un hilo de trabajo, lo que entrega se ejecutaría
    allí y Qt se cae). Lo llaman los paneles al construirse."""
    global _aviso
    if _aviso is None:
        _aviso = _Aviso()
        _aviso.senal.connect(lambda f, d: f(d))


def en_ventana(cb, dato):
    _aviso.senal.emit(cb, dato)


def en_fondo(funcion, al_acabar, *args):
    """Hace «funcion» en otro hilo y entrega el resultado (o None si falla) en la ventana."""
    preparar()

    def trabajo():
        try:
            r = funcion(*args)
        except Exception:
            r = None
        en_ventana(al_acabar, r)
    threading.Thread(target=trabajo, daemon=True).start()


class BarraVotos(QWidget):
    """La proporción de «me gusta» (verde) y «no me gusta» (rojo)."""
    def __init__(self, ancho=160):
        super().__init__()
        self.setFixedSize(ancho, 6)
        self.si, self.no = 0, 0
        self.hide()

    def poner(self, si, no):
        self.si, self.no = max(si, 0), max(no, 0)
        self.setVisible(self.si + self.no > 0)
        self.update()

    def paintEvent(self, ev):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(ROJO))
        p.drawRoundedRect(0, 0, self.width(), self.height(), 3, 3)
        if self.si + self.no:
            p.setBrush(QColor(VERDE))
            p.drawRoundedRect(0, 0, int(self.width() * self.si / (self.si + self.no)), self.height(), 3, 3)
        p.end()


def _por_ciento(si, no):
    return f"{100 * si / (si + no):.1f} %".replace(".", ",") if si >= 0 and no >= 0 and si + no > 0 else ""


def _barra_html(si, no):
    if si < 0 or no < 0 or si + no <= 0:
        return ""
    a = max(1, min(99, round(100 * si / (si + no))))
    return (f'<table width="260" cellspacing="0" cellpadding="0"><tr><td width="{a}%" bgcolor="{VERDE}" style="font-size:3px">&nbsp;</td>'
            f'<td width="{100 - a}%" bgcolor="{ROJO}" style="font-size:3px">&nbsp;</td></tr></table>')


def _fila(clave, valor):
    return f'<tr><td valign="top" style="color:{GRIS}; padding:2px 14px 2px 0">{html.escape(clave)}</td><td style="padding:2px 0">{valor}</td></tr>'


def _e(t):
    return html.escape(str(t)) if t not in (None, "") else ""


def _enlace(url, texto=None):
    return f'<a href="{html.escape(url, quote=True)}">{html.escape(texto or url)}</a>'


def texto_emision(e):
    if not e:
        return ""
    ini, fin = md.fecha_hora(e["inicio"]), md.fecha_hora(e["fin"])
    if e["tipo"] == "directo":
        if e["programado"]:
            return f"Directo programado para el {ini}" if ini else "Directo programado"
        if e["ahora"]:
            return f"En directo ahora (empezó el {ini}, {md.hace(e['inicio'])})" if ini else "En directo ahora"
        dur = f", duró {md.duracion_larga((e['fin'] - e['inicio']) // 1000)}" if e["fin"] and e["inicio"] else ""
        return f"Directo emitido el {ini}" + (f" hasta el {fin}" if fin else "") + dur
    if e["programado"]:
        return f"Estreno programado para el {ini}" if ini else "Estreno programado"
    return f"Estreno el {ini}" + (f" (acabó a las {md.hora(e['fin'])})" if fin else "")


def comentarios(n):
    return "desactivados" if n == -2 else md.miles(n) if n >= 0 else "no disponible"


# ---------------------------------------------------------------- vídeo
def html_datos(f, c):
    """La sección «Datos» de un vídeo: «f» es la ficha (motor.ficha) y «c» lo de metadatos.completo (puede ser None
    mientras llega; entonces sale lo que ya hay)."""
    e = (c or {}).get("extra") or {}
    fo = (c or {}).get("formatos") or {}
    v = (c or {}).get("votos")
    vid = f.get("id") or md.id_video(f["url"])
    filas = []
    vistas = e.get("vistas", f.get("vistasExactas", -1))
    filas.append(_fila("Visualizaciones", md.miles(vistas) if vistas is not None and vistas >= 0 else _e(f.get("vistas"))))
    mg = e.get("meGusta", -1)
    filas.append(_fila("Me gusta", md.miles(mg) if mg >= 0 else ("…" if not c else "ocultos por el autor")))
    if v and v.get("noMeGusta", -1) >= 0:
        si = mg if mg >= 0 else v.get("meGusta", -1)
        filas.append(_fila("No me gusta", f"≈ {md.miles(v['noMeGusta'])} <span style='color:{GRIS}'>({NOTA_RYD})</span>"
                           f"<br>{_barra_html(si, v['noMeGusta'])}<span style='color:{GRIS}'>{_por_ciento(si, v['noMeGusta'])} de «me gusta»</span>"))
    if e:
        filas.append(_fila("Comentarios", comentarios(e.get("comentarios", -1))))
        pub = e.get("publicado", 0)
        filas.append(_fila("Publicado", f"{md.fecha_hora(pub)} · {md.hace(pub)}" + (f"<br><span style='color:{GRIS}'>YouTube: «{_e(e['textoFecha'])}»</span>" if e.get("textoFecha") else "")))
        filas.append(_fila("Duración", md.duracion(e.get("duracion", -1)) or "en directo"))
        filas.append(_fila("Categoría", _e(e.get("categoria"))))
        filas.append(_fila("Etiquetas", " · ".join(_e(t) for t in e.get("etiquetas", [])) or "ninguna"))
        filas.append(_fila("Licencia", _e(e.get("licencia"))))
        filas.append(_fila("Para niños", "Sí" if e.get("paraNinos") else "No"))
        filas.append(_fila("Restricción de edad", "Sí (mayores de 18)" if e.get("edad") else "No"))
        filas.append(_fila("Tipo", _e(texto_emision(e.get("emision"))) or "Vídeo"))
        filas.append(_fila("Visibilidad", "Privado" if e.get("privado") else "Oculto (no listado)" if e.get("oculto") else "Público"))
        for k, t in e.get("filas", []):
            filas.append(_fila(k, _e(t)))
        caps = e.get("capitulos") or []
        if caps:
            filas.append(_fila(f"Capítulos ({len(caps)})", "<br>".join(
                f'{_enlace(f"https://www.youtube.com/watch?v={vid}&t={s}s", md.tiempo(s))} {_e(t)}' for s, t in caps)))
        else:
            filas.append(_fila("Capítulos", "ninguno"))
    elif not c:
        filas.append(_fila("", f"<span style='color:{GRIS}'>Cargando el resto de datos…</span>"))
    if fo:
        filas.append(_fila("Idiomas de audio", " · ".join(_e(a) for a in fo.get("audios", [])) or "una sola pista"))
        subs = []
        if fo.get("subtitulos"):
            subs.append("Manuales: " + ", ".join(_e(s) for s in fo["subtitulos"]))
        if fo.get("subtitulosAuto"):
            subs.append("Automáticos: " + ", ".join(_e(s) for s in fo["subtitulosAuto"]))
        filas.append(_fila("Subtítulos", "<br>".join(subs) or "ninguno"))
        vis, mas = md.formatos_visibles(fo.get("formatos", []))
        if vis:
            lineas = [f"<b>{_e(x['clase'].capitalize())}</b> · {_e(md.linea_formato(x))}" for x in vis]
            if mas:
                lineas.append(f"<span style='color:{GRIS}'>Las mismas calidades de audio en {mas} idiomas más.</span>")
            filas.append(_fila(f"Formatos ({len(vis)})", "<br>".join(lineas)))
        else:
            filas.append(_fila("Formatos", f"<span style='color:{GRIS}'>YouTube no los da ({_e(fo.get('motivo'))})</span>"))
    filas.append(_fila("Id del vídeo", _e(vid)))
    filas.append(_fila("Enlace", _enlace(f"https://www.youtube.com/watch?v={vid}")))
    canal_id = e.get("canalId") or md.id_canal(f.get("autorUrl", ""))
    subs = e.get("canalSuscriptores") or f.get("canalSuscriptores", "")
    verif = e.get("canalVerificado", "")
    filas.append(_fila("Canal", (_enlace(f"https://www.youtube.com/channel/{canal_id}", f.get("autor") or e.get("canal", "")) if canal_id else _e(f.get("autor")))
                       + (f" · {_e(subs)}" if subs else "") + (f" · ✔ {_e(verif)}" if verif else "")
                       + (f"<br><span style='color:{GRIS}'>{NOTA_SUBS}</span>" if subs else "")))
    filas.append(_fila("Id del canal", _e(canal_id)))
    filas.append(_fila("Descripción", f.get("descripcionHtml") or "sin descripción"))
    return f"<table cellspacing='0' cellpadding='0'>{''.join(filas)}</table>"


class PanelDatos(QWidget):
    """Bajo el título del vídeo: una línea con visualizaciones, fecha y votos, y la sección «Datos» desplegable."""
    def __init__(self, al_pulsar_enlace, al_desplegar=None):
        super().__init__()
        preparar()
        self.al_desplegar = al_desplegar
        v = QVBoxLayout(self)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(4)
        self.linea = QLabel()
        self.linea.setObjectName("gris")
        self.linea.setWordWrap(True)
        fila = QHBoxLayout()
        self.votos = QLabel()
        self.votos.setObjectName("gris")
        self.barra = BarraVotos()
        fila.addWidget(self.votos)
        fila.addWidget(self.barra)
        fila.addStretch()
        self.boton = QPushButton("▸  Datos")
        self.boton.setToolTip("Todos los datos del vídeo: votos, fechas, formatos, subtítulos, etiquetas…")
        self.boton.setStyleSheet("text-align: left; padding: 4px 10px;")
        self.boton.clicked.connect(self.alternar)
        fila.addWidget(self.boton)
        v.addWidget(self.linea)
        v.addLayout(fila)
        self.navegador = QTextBrowser()
        self.navegador.setOpenLinks(False)
        self.navegador.anchorClicked.connect(lambda u: al_pulsar_enlace(u.toString()))
        central_en_enlaces(self.navegador, lambda u: al_pulsar_enlace(u, nueva=True))
        self.navegador.setMinimumHeight(220)
        self.navegador.setMaximumHeight(380)
        self.navegador.setStyleSheet("QTextBrowser { background: #1C1C1E; border: none; border-radius: 16px; padding: 12px; }")
        self.navegador.document().setDefaultStyleSheet("a { color: #FFB067; text-decoration: none; }")
        self.navegador.hide()
        v.addWidget(self.navegador)
        self.ficha, self.completo = None, None

    def alternar(self):
        abierto = not self.navegador.isVisible()
        self.navegador.setVisible(abierto)
        self.boton.setText(("▾" if abierto else "▸") + "  Datos")
        if self.al_desplegar:
            self.al_desplegar(abierto)

    def limpiar(self):
        self.ficha, self.completo = None, None
        self.linea.setText("")
        self.votos.setText("")
        self.barra.poner(0, 0)
        self.navegador.setHtml("")

    def poner_ficha(self, f):
        self.ficha = f
        self._pintar()

    def poner_completo(self, c):
        self.completo = c
        self._pintar()

    def _pintar(self):
        f, c = self.ficha, self.completo
        if not f:
            return
        e = (c or {}).get("extra") or {}
        v = (c or {}).get("votos")
        vistas = e.get("vistas", f.get("vistasExactas", -1))
        partes = [f"{md.miles(vistas)} visualizaciones" if vistas is not None and vistas >= 0 else f.get("vistas", "")]
        if e.get("publicado"):
            partes.append(f"{md.fecha_hora(e['publicado'])} ({md.hace(e['publicado'])})")
        elif f.get("textoFecha"):
            partes.append(f["textoFecha"] + (f" ({f['fechaRelativa']})" if f.get("fechaRelativa") else ""))
        self.linea.setText(" · ".join(p for p in partes if p))
        mg = e.get("meGusta", -1)
        if v and v.get("noMeGusta", -1) >= 0:
            si = mg if mg >= 0 else v.get("meGusta", -1)
            self.votos.setText(f"Me gusta {md.miles(si) if si >= 0 else '—'}  ·  No me gusta ≈ {md.miles(v['noMeGusta'])}  ({NOTA_RYD})")
            self.barra.poner(si, v["noMeGusta"])
        else:
            self.votos.setText(f"Me gusta {md.miles(mg)}" if mg >= 0 else "")
            self.barra.poner(0, 0)
        barra = self.navegador.verticalScrollBar().value()
        self.navegador.setHtml(html_datos(f, c))
        self.navegador.verticalScrollBar().setValue(barra)


# ---------------------------------------------------------------- canal
class FichaCanal(QWidget):
    """Encima de los vídeos del canal: banner, suscriptores (con su nota), visualizaciones totales, vídeos, alta,
    país, valoración estimada de sus últimos vídeos y, desplegable, descripción, enlaces, etiquetas e ids."""
    def __init__(self, ventana, al_pulsar_enlace):
        super().__init__()
        preparar()
        self.ventana = ventana
        v = QVBoxLayout(self)
        v.setContentsMargins(0, 4, 0, 4)
        v.setSpacing(4)
        self.banner = QLabel()
        self.banner.setFixedHeight(96)
        self.banner.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Fixed)
        self.banner.setAlignment(Qt.AlignCenter)
        v.addWidget(self.banner)
        fila = QHBoxLayout()
        self.avatar = QLabel()
        self.avatar.setFixedSize(64, 64)
        fila.addWidget(self.avatar)
        t = QVBoxLayout()
        self.subs = QLabel()
        self.subs.setWordWrap(True)
        self.nota = QLabel(NOTA_SUBS)
        self.nota.setStyleSheet(f"color: {GRIS}; font-size: 11px;")
        self.hechos = QLabel()
        self.hechos.setObjectName("gris")
        self.hechos.setWordWrap(True)
        for w in (self.subs, self.nota, self.hechos):
            t.addWidget(w)
        fila.addLayout(t, 1)
        v.addLayout(fila)
        fv = QHBoxLayout()
        self.valoracion = QLabel()
        self.valoracion.setWordWrap(True)
        self.barra = BarraVotos(200)
        fv.addWidget(self.valoracion, 1)
        fv.addWidget(self.barra)
        v.addLayout(fv)
        self.boton = QPushButton("▸  Más datos del canal")
        self.boton.setStyleSheet("text-align: left; padding: 4px 10px;")
        self.boton.clicked.connect(self._alternar)
        v.addWidget(self.boton, 0, Qt.AlignLeft)
        self.navegador = QTextBrowser()
        self.navegador.setOpenLinks(False)
        self.navegador.anchorClicked.connect(lambda u: al_pulsar_enlace(u.toString()))
        central_en_enlaces(self.navegador, lambda u: al_pulsar_enlace(u, nueva=True))
        self.navegador.setMaximumHeight(260)
        self.navegador.setStyleSheet("QTextBrowser { background: #1C1C1E; border: none; border-radius: 16px; padding: 12px; }")
        self.navegador.document().setDefaultStyleSheet("a { color: #FFB067; text-decoration: none; }")
        self.navegador.hide()
        v.addWidget(self.navegador)
        self.url, self.info, self.acerca, self.val = None, None, None, None

    def _alternar(self):
        abierto = not self.navegador.isVisible()
        self.navegador.setVisible(abierto)
        self.boton.setText(("▾" if abierto else "▸") + "  Más datos del canal")

    def empezar(self, url):
        self.url, self.info, self.acerca, self.val = url, None, None, None
        self.banner.clear()
        self.banner.hide()
        self.avatar.clear()
        self.subs.setText("Cargando el canal…")
        self.nota.hide()
        self.hechos.setText("")
        self.valoracion.setText("")
        self.barra.poner(0, 0)
        self.navegador.setHtml("")

    def poner_info(self, info):
        self.info = info or {}
        if self.info.get("banner"):
            self.banner.show()
            self.ventana.imagenes.poner(self.info["banner"], self.banner, max(600, self.banner.width()), 96)
        if self.info.get("avatar"):
            self.ventana.imagenes.poner(self.info["avatar"], self.avatar, 64, 64, redonda=True)
        self._pintar()

    def poner_acerca(self, a):
        self.acerca = a
        self._pintar()

    def poner_valoracion(self, v):
        self.val = v
        self._pintar()

    def _pintar(self):
        i, a, v = self.info or {}, self.acerca or {}, self.val
        subs = a.get("suscriptores") or i.get("suscriptores") or ""
        cab = [x for x in (i.get("handle") or a.get("handle"), f"<b>{_e(subs)}</b>" if subs else "",
                           f"✔ {_e(i['verificado'])}" if i.get("verificado") else "") if x]
        self.subs.setText(" · ".join(cab) or "")
        self.nota.setVisible(bool(subs))
        hechos = [f"{md.miles(a['visualizaciones'])} visualizaciones" if a.get("visualizaciones", -1) >= 0 else "",
                  a.get("videos") or i.get("videos", ""), f"se unió el {a['alta']}" if a.get("alta") else "", a.get("pais", "")]
        self.hechos.setText(" · ".join(x for x in hechos if x) or ("" if self.acerca is None else "YouTube no da más datos de este canal"))
        if v is None:
            self.valoracion.setText("<b>Valoración de sus últimos vídeos (estimación):</b> calculando…")
        elif v.get("conVotos", 0) == 0:
            self.valoracion.setText("<b>Valoración de sus últimos vídeos (estimación):</b> " +
                                    ("calculando…" if v["hechos"] < v["total"] else "Return YouTube Dislike no responde ahora"))
            self.barra.poner(0, 0)
        else:
            si, no = v["mediaMeGusta"], v["mediaNoMeGusta"]
            falta = f" · calculando {v['hechos']}/{v['total']}" if v["hechos"] < v["total"] else ""
            self.valoracion.setText(f"<b>Valoración de sus últimos vídeos (estimación):</b> me gusta {md.miles(si)} · no me gusta {md.miles(no)} de media "
                                    f"({_por_ciento(si, no)} positivos, {v['conVotos']} vídeos){falta}"
                                    f"<br><span style='color:{GRIS}; font-size:11px'>{NOTA_RYD}</span>")
            self.barra.poner(si, no)
        filas = []
        desc = a.get("descripcion") or i.get("descripcion") or ""
        filas.append(_fila("Descripción", _texto_con_enlaces(desc) if desc else "sin descripción"))
        if a.get("enlaces"):
            filas.append(_fila("Enlaces", "<br>".join(f"{_e(t)}: {_enlace(u)}" for t, u in a["enlaces"])))
        filas.append(_fila("Etiquetas", " · ".join(_e(t) for t in i.get("etiquetas", [])) or "ninguna"))
        filas.append(_fila("Handle", _e(i.get("handle") or a.get("handle")) or "—"))
        cid = i.get("id") or a.get("canalId") or md.id_canal(self.url or "")
        filas.append(_fila("Id del canal", _e(cid)))
        filas.append(_fila("Enlace", _enlace(f"https://www.youtube.com/channel/{cid}") if cid else "—"))
        filas.append(_fila("Verificado", f"Sí ({_e(i['verificado'])})" if i.get("verificado") else "No"))
        if i.get("banner"):
            filas.append(_fila("Banner", _enlace(i["banner"], "abrir la imagen")))
        if cid:
            filas.append(_fila("RSS", _enlace(f"https://www.youtube.com/feeds/videos.xml?channel_id={cid}")))
        self.navegador.setHtml(f"<table cellspacing='0' cellpadding='0'>{''.join(filas)}</table>")


def _texto_con_enlaces(t):
    """Texto plano con las direcciones convertidas en enlaces que se pueden pulsar."""
    import re
    partes, pos = [], 0
    for m in re.finditer(r"https?://[^\s<>()]+", t):
        partes.append(html.escape(t[pos:m.start()]))
        partes.append(_enlace(m.group(0)))
        pos = m.end()
    partes.append(html.escape(t[pos:]))
    return "".join(partes).replace("\n", "<br>")


# ---------------------------------------------------------------- listas
class Relleno:
    """Completa las filas de una lista con duración, visualizaciones y fecha cuando YouTube no las da (las novedades
    del RSS no traen la duración; el historial, a veces, nada). 4 peticiones a la vez, con caché de 3 días."""
    def __init__(self):
        preparar()
        self.tanda = 0
        self.ex = cf.ThreadPoolExecutor(4)

    def empezar(self, filas):
        self.tanda += 1
        tanda = self.tanda
        faltan = [f for f in filas if f.e.tipo == "VIDEO" and not motor.programado(f.e)   # 24/10/2026: un estreno, nada que pedir
                  and (f.e.duracion is None or f.e.duracion < 0 or not f.e.fecha or not f.e.detalle)]
        for f in faltan[:300]:
            r = md.resumen_en_cache(f.e.url)
            if r:
                f.completar(r)
            else:
                self.ex.submit(self._uno, tanda, f)

    def _uno(self, tanda, f):
        if tanda != self.tanda:      # la lista ya cambió: no se pide
            return
        r = md.resumen(f.e.url)
        if r:
            en_ventana(lambda d: tanda == self.tanda and _seguro(f.completar, d), r)


def _seguro(funcion, *a):
    try:
        funcion(*a)
    except RuntimeError:     # la fila ya no existe
        pass


def abrir_fuera(url):
    # 19/10/2026: al navegador de verdad (el del sistema es Cat-ode para los enlaces de YouTube)
    from . import compartir
    compartir.abrir_fuera(url)


def hashtag(url):
    p = urllib.parse.urlparse(url)
    return p.path.split("/hashtag/", 1)[1].strip("/") if "/hashtag/" in p.path else ""
