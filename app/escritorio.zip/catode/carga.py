"""Cat-ode · carga del equipo para las pruebas de fluidez (06/10/2026).

medir(segundos) → {"cpu": % de todo el equipo ocupado, "propia": % de este proceso y sus descendientes (WebView2 o el
Chromium de Playwright cuelgan de él), "ajena": la diferencia (Syncthing, servicios de Intel, la app del autor…),
"nucleos": n}. Porcentajes sobre el total de núcleos (100 = todos llenos). Sin psutil: /proc en Linux y la API de
Windows por ctypes. Solo lee; nunca toca otros procesos. Si algo falla, devuelve {"error": …}."""
import os
import time


def _linux_total():
    with open("/proc/stat", encoding="ascii") as f:
        campos = [int(x) for x in f.readline().split()[1:]]
    ocio = campos[3] + (campos[4] if len(campos) > 4 else 0)
    return sum(campos), ocio


def _linux_propia(raiz):
    hijos, tiempos = {}, {}
    for d in os.listdir("/proc"):
        if not d.isdigit():
            continue
        try:
            with open(f"/proc/{d}/stat", encoding="utf-8", errors="replace") as f:
                x = f.read()
            resto = x[x.rindex(")") + 2:].split()
            pid, ppid = int(d), int(resto[1])
            hijos.setdefault(ppid, []).append(pid)
            tiempos[pid] = int(resto[11]) + int(resto[12])   # utime + stime (en jiffies, como /proc/stat)
        except (OSError, ValueError, IndexError):
            continue
    total, pila, vistos = 0, [raiz], set()
    while pila:
        p = pila.pop()
        if p in vistos:
            continue
        vistos.add(p)
        total += tiempos.get(p, 0)
        pila.extend(hijos.get(p, []))
    return total


def _win():
    import ctypes
    from ctypes import wintypes as w
    k = ctypes.WinDLL("kernel32", use_last_error=True)

    class FT(ctypes.Structure):
        _fields_ = [("lo", w.DWORD), ("hi", w.DWORD)]

    def n(ft):
        return (ft.hi << 32) | ft.lo

    class PE(ctypes.Structure):
        _fields_ = [("dwSize", w.DWORD), ("cntUsage", w.DWORD), ("th32ProcessID", w.DWORD),
                    ("th32DefaultHeapID", ctypes.c_void_p), ("th32ModuleID", w.DWORD), ("cntThreads", w.DWORD),
                    ("th32ParentProcessID", w.DWORD), ("pcPriClassBase", ctypes.c_long), ("dwFlags", w.DWORD),
                    ("szExeFile", ctypes.c_char * 260)]

    k.CreateToolhelp32Snapshot.restype = w.HANDLE
    k.OpenProcess.restype = w.HANDLE

    def total():
        i, kk, u = FT(), FT(), FT()
        k.GetSystemTimes(ctypes.byref(i), ctypes.byref(kk), ctypes.byref(u))
        return n(kk) + n(u), n(i)   # el tiempo de núcleo ya incluye el ocioso

    def propia(raiz):
        snap = k.CreateToolhelp32Snapshot(0x2, 0)
        hijos = {}
        try:
            e = PE(); e.dwSize = ctypes.sizeof(PE)
            ok = k.Process32First(snap, ctypes.byref(e))
            while ok:
                hijos.setdefault(e.th32ParentProcessID, []).append(e.th32ProcessID)
                ok = k.Process32Next(snap, ctypes.byref(e))
        finally:
            k.CloseHandle(snap)
        suma, pila, vistos = 0, [raiz], set()
        while pila:
            p = pila.pop()
            if p in vistos or p == 0:
                continue
            vistos.add(p)
            pila.extend(hijos.get(p, []))
            h = k.OpenProcess(0x1000, False, p)   # PROCESS_QUERY_LIMITED_INFORMATION
            if not h:
                continue
            try:
                c, s, kk, u = FT(), FT(), FT(), FT()
                if k.GetProcessTimes(h, ctypes.byref(c), ctypes.byref(s), ctypes.byref(kk), ctypes.byref(u)):
                    suma += n(kk) + n(u)
            finally:
                k.CloseHandle(h)
        return suma
    return total, propia


def medir(segundos=1.0):
    try:
        raiz = os.getpid()
        if os.name == "nt":
            total, propia = _win()
        else:
            total, propia = _linux_total, _linux_propia
        t0, o0 = total()
        p0 = propia(raiz)
        time.sleep(max(0.2, min(5.0, float(segundos))))
        t1, o1 = total()
        p1 = propia(raiz)
        dt = max(1, t1 - t0)
        cpu = 100.0 * (dt - (o1 - o0)) / dt
        mia = min(cpu, max(0.0, 100.0 * (p1 - p0) / dt))
        return {"cpu": round(cpu), "propia": round(mia), "ajena": round(max(0.0, cpu - mia)), "nucleos": os.cpu_count() or 1}
    except Exception as error:   # noqa: BLE001
        return {"error": repr(error)[:120]}


if __name__ == "__main__":
    print(medir(1.0))
