"""Cat-ode escritorio · la cara de sorpresa en las miniaturas, para el filtro «Sin clickbait» (21/11/2026).

Orden del autor (literal en ~/Cat-ode/ENCARGO_catode_21nov_filtros.md): quitar «youtubers sorprendidos con cara de sorpresa».
Cómo: la miniatura pequeña del vídeo (i.ytimg.com/vi/<id>/mqdefault.jpg, 320×180) → YuNet encuentra las caras y sus cinco
puntos (ojos, nariz, boca) → cada cara grande (al menos el 3,5 % de la imagen y confianza 0,8) se endereza a 112×112 → FER
MobileFaceNet da sus 7 expresiones → «s» = sorpresa + miedo de la más sorprendida. filtros.cara_de_sorpresa decide con
filtros.json («caras»): con 0,90, fuera; con 0,75, si el título ya suma 2 puntos de clickbait. Medido el 21/11 con 2.500
miniaturas suyas: el 4,3 % pasa de 0,90, y a ojo todas son caras de susto o cejas arriba de miniatura gancho.
Los modelos (caras.bin, hecho por vigia/caras_modelos.py) se ejecutan con este motor propio en numpy, el mismo que Caras.kt
del móvil. Comparado con OpenCV el 22/11/2026 en 800 miniaturas suyas (pesos en float32 allí, float16 aquí): el mismo número
de caras en todas, «s» como mucho 0,018 distinta y una sola decisión cambiada de 800 con 0,90 (ninguna con 0,75); Caras.kt
da lo mismo que este motor en las 10 miniaturas de CarasTest.kt (las rehace pruebas/caras_esperado.py). Sin numpy
(Windows), se instala con pip la primera vez que se enciende el filtro; si no se puede, el filtro sigue con los títulos (y lo
apunta en el registro).
"""
# COMPROBACIONES (~/.claude/COMPROBACIONES.md)
# C1 datos y red: solo con «Sin clickbait» encendido: una miniatura de 320×180 (unos 15 KB, i.ytimg.com) por vídeo que se enseña, una vez (el resultado se guarda); nunca peticiones a YouTube; numpy por pip una sola vez si falta.
# C2 su presencia: nada que se vea ni suene; un hilo en segundo plano con prioridad baja (nice 19 en Linux), de uno en uno.
# C3 fallo y bucle: cola con tope (300, primero lo último que se pidió); una miniatura que falla se apunta y no se repite; el hilo no se cae por un error.
# C4 aviso: los fallos van al registro de Cat-ode; sin numpy o sin modelos, el filtro sigue con los títulos y lo apunta una vez.
# C5 irreversible: nada; no borra ni envía; los resultados van a filtros_aprendidos.json (caché del aparato).
# C6 gasto: sin tokens, sin API y sin dinero; todo local.
# C7 recursos: unos 120 ms de un hilo por miniatura (medido en el Dell el 22/11, a nice 19) y 30 MB de memoria con los modelos cargados; solo con el filtro encendido.
# C8 cambios de contexto: sin red no baja nada (lo deja para cuando vuelva); fuera de casa igual.
# C9 equipos y prueba: dentro de Cat-ode en Windows y Linux; comparado con OpenCV el 22/11 (800 miniaturas) y con Caras.kt en CarasTest.kt.
# C10 lo que ya existe: usa filtros.py (umbral, aprendidos, aviso a las interfaces) y el patrón de pip de actualizar.py.
import json
import os
import struct
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request

AQUI = os.path.dirname(os.path.abspath(__file__))
MODELOS = os.path.join(AQUI, "caras.bin")
EXPRESIONES = ("enfado", "asco", "miedo", "alegría", "neutra", "tristeza", "sorpresa")   # el orden de FER (RAF-DB)
UMBRAL_DETECCION = 0.6
NMS = 0.3
TOPE_CARAS = 50
PUNTOS_ESTANDAR = ((38.2946, 51.6963), (73.5318, 51.5014), (56.0252, 71.7366), (41.5493, 92.3655), (70.7299, 92.2041))

np = None
_motor = None
_estado = {"listo": False, "fallo": "", "preparando": False}
_cola = []                 # [(vid, url, puntos del título)], lo último al final
_pedidos = set()
_cerrojo = threading.Condition()
_hilo = None
TOPE_COLA = 300


def _registro(texto):
    try:
        from .resolutor import registro
        registro(texto)
    except Exception:   # noqa: BLE001
        pass


def _cargar_numpy():
    """numpy; si falta, con pip (como actualizar._curl hace con curl_cffi), una vez."""
    global np
    if np is not None:
        return np
    puestos = []
    if "numpy" not in sys.modules:
        # 22/11/2026, medido en el Dell: con un hilo va 4 veces más deprisa que con cuatro (las matrices son pequeñas) y no
        # le quita núcleos a nada. Solo mientras se carga numpy (OpenBLAS lo lee al cargarse): no pasa a otros programas.
        for k in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"):
            if k not in os.environ:
                os.environ[k] = "1"
                puestos.append(k)
    try:
        _importar_numpy()
    finally:
        for k in puestos:
            os.environ.pop(k, None)
    return np


def _importar_numpy():
    global np
    try:
        import numpy
    except ImportError:
        from .actualizar import _pip_usuario, SIN_VENTANA
        r = subprocess.run([sys.executable, "-m", "pip", "install", "-q", "--disable-pip-version-check", "numpy"] + _pip_usuario(),
                           capture_output=True, text=True, timeout=900, creationflags=SIN_VENTANA)
        if r.returncode:
            raise RuntimeError(f"pip numpy: {(r.stderr or r.stdout or '').strip()[-200:]}")
        import importlib
        import site
        importlib.invalidate_caches()
        try:
            import numpy
        except ImportError:
            site.addsitedir(site.getusersitepackages())
            import numpy
    np = numpy


# ------------------------------------------------------------------------------------------------ el motor
class Modelo:
    """Un grafo de caras.bin: nodos en orden (Conv, Relu, PRelu, Sigmoid, MaxPool, Resize, Add, Transpose, Reshape, Flatten,
    Gemm) sobre tensores sin la dimensión del lote ((C, H, W) o vectores)."""

    def __init__(self, cab, blob):
        self.entrada, self.salidas, self.nodos = cab["entrada"], cab["salidas"], cab["nodos"]
        self.w = {}
        for nombre, t in cab["tensores"].items():
            n = 1
            for d in t["forma"]:
                n *= d
            a = np.frombuffer(blob, dtype="<f2", count=n, offset=2 * t["ini"]).astype(np.float32)
            self.w[nombre] = a.reshape(t["forma"])

    def __call__(self, x):
        v = {self.entrada: x}
        for nd in self.nodos:
            op, a = nd["op"], v[nd["i"][0]]
            if op == "Conv":
                r = self._conv(a, nd)
            elif op == "Relu":
                r = np.maximum(a, 0)
            elif op == "PRelu":
                s = self.w[nd["i"][1]].reshape(-1, 1, 1)
                r = np.where(a >= 0, a, a * s)
            elif op == "Sigmoid":
                r = 1.0 / (1.0 + np.exp(-a))
            elif op == "MaxPool":
                kh, kw = nd["k"]
                sh, sw = nd["s"]
                c, h, w = a.shape
                ho, wo = (h - kh) // sh + 1, (w - kw) // sw + 1
                r = None
                for dy in range(kh):
                    for dx in range(kw):
                        t = a[:, dy:dy + sh * (ho - 1) + 1:sh, dx:dx + sw * (wo - 1) + 1:sw]
                        r = t if r is None else np.maximum(r, t)
            elif op == "Resize":
                f = nd["f"]
                r = a.repeat(f, axis=1).repeat(f, axis=2)
            elif op == "Add":
                r = a + v[nd["i"][1]]
            elif op == "Transpose":
                r = a.transpose([p - 1 for p in nd["perm"][1:]])
            elif op == "Reshape":
                r = a.reshape(nd["forma"][1:])
            elif op == "Flatten":
                r = a.reshape(-1)
            elif op == "Gemm":
                wt = self.w[nd["i"][1]]
                r = (a @ wt.T if nd.get("tb") else a @ wt) + self.w[nd["i"][2]]
            else:
                raise ValueError(op)
            v[nd["o"][0]] = r.astype(np.float32, copy=False)
        return {k: v[k] for k in self.salidas}

    def _conv(self, x, nd):
        w = self.w[nd["i"][1]]
        b = self.w[nd["i"][2]] if nd["i"][2] else None
        co, cig, kh, kw = w.shape
        g, (sh, sw), (pt, pl, pb, pr) = nd["g"], nd["s"], nd["p"]
        c = x.shape[0]
        if pt or pl or pb or pr:
            x = np.pad(x, ((0, 0), (pt, pb), (pl, pr)))
        hp, wp = x.shape[1], x.shape[2]
        ho, wo = (hp - kh) // sh + 1, (wp - kw) // sw + 1
        if g == 1:
            if kh == kw == 1 and sh == sw == 1:
                r = w.reshape(co, cig) @ x.reshape(c, -1)
            else:
                cols = np.empty((c, kh, kw, ho, wo), np.float32)
                for dy in range(kh):
                    for dx in range(kw):
                        cols[:, dy, dx] = x[:, dy:dy + sh * (ho - 1) + 1:sh, dx:dx + sw * (wo - 1) + 1:sw]
                r = w.reshape(co, -1) @ cols.reshape(c * kh * kw, -1)
            r = r.reshape(co, ho, wo)
        elif g == c == co and cig == 1:
            r = np.zeros((c, ho, wo), np.float32)
            for dy in range(kh):
                for dx in range(kw):
                    r += w[:, 0, dy, dx][:, None, None] * x[:, dy:dy + sh * (ho - 1) + 1:sh, dx:dx + sw * (wo - 1) + 1:sw]
        else:
            raise ValueError(f"convolución por grupos que el motor no sabe hacer: {w.shape} g={g}")
        if b is not None:
            r += b[:, None, None]
        return r


class Motor:
    def __init__(self, ruta=MODELOS):
        with open(ruta, "rb") as f:
            b = f.read()
        if b[:8] != b"CATCARA1":
            raise ValueError("caras.bin no es de Cat-ode")
        n = struct.unpack_from("<I", b, 8)[0]
        cab = json.loads(b[12:12 + n].decode("utf-8"))
        blob = b[12 + n:]
        self.yunet = Modelo(cab["modelos"]["yunet"], blob)
        self.fer = Modelo(cab["modelos"]["fer"], blob)

    def caras(self, bgr):
        """Las caras de una imagen BGR (alto, ancho, 3) de uint8: [(confianza, x, y, ancho, alto, [(x, y) × 5])], como
        cv.FaceDetectorYN (rellena hasta múltiplos de 32 con negro, cls·obj, NMS 0,3 con cajas enteras)."""
        h, w = bgr.shape[:2]
        pw, ph = ((w - 1) // 32 + 1) * 32, ((h - 1) // 32 + 1) * 32
        x = np.zeros((3, ph, pw), np.float32)
        x[:, :h, :w] = bgr.transpose(2, 0, 1)
        out = self.yunet(x)
        todas = []
        for s in (8, 16, 32):
            cols = pw // s
            cls = np.clip(out[f"cls_{s}"].reshape(-1), 0, 1)
            obj = np.clip(out[f"obj_{s}"].reshape(-1), 0, 1)
            bb = out[f"bbox_{s}"].reshape(-1, 4)
            kp = out[f"kps_{s}"].reshape(-1, 10)
            score = np.sqrt(cls * obj)
            for j in np.nonzero(score >= UMBRAL_DETECCION)[0]:
                r, c = divmod(int(j), cols)
                cx, cy = (c + bb[j, 0]) * s, (r + bb[j, 1]) * s
                ww, hh = float(np.exp(bb[j, 2]) * s), float(np.exp(bb[j, 3]) * s)
                pts = [(float((kp[j, 2 * k] + c) * s), float((kp[j, 2 * k + 1] + r) * s)) for k in range(5)]
                todas.append((float(score[j]), float(cx - ww / 2), float(cy - hh / 2), ww, hh, pts))
        return _nms(todas)

    def expresion(self, bgr, puntos):
        """Las 7 probabilidades de FER para la cara de esos cinco puntos."""
        cara = _enderezar(bgr, puntos)
        x = (cara[:, :, ::-1].astype(np.float32) / 255.0 - 0.5) / 0.5
        logit = self.fer(np.ascontiguousarray(x.transpose(2, 0, 1)))["label"]
        e = np.exp(logit - logit.max())
        return e / e.sum()

    def analizar(self, bgr, confianza=0.8, area_minima=0.035):
        """{"s": sorpresa+miedo de la cara grande más sorprendida, "a": su área, "n": caras grandes} (s = 0 si no hay)."""
        h, w = bgr.shape[:2]
        mejor, n = {"s": 0.0, "a": 0.0}, 0
        for conf, x, y, ww, hh, pts in self.caras(bgr):
            area = ww * hh / float(w * h)
            if conf < confianza or area < area_minima:
                continue
            n += 1
            p = self.expresion(bgr, pts)
            s = float(p[6] + p[2])
            if s > mejor["s"]:
                mejor = {"s": s, "a": area}
        return {"s": round(mejor["s"], 4), "a": round(mejor["a"], 4), "n": n}


def _nms(caras):
    """cv.dnn.NMSBoxes como lo usa FaceDetectorYN: con una sola cara, tal cual; si no, las 50 de más puntuación (por encima
    del umbral, orden estable) y fuera la que solape más de 0,3 con una ya elegida (cajas enteras, como Rect2i)."""
    if len(caras) <= 1:
        return caras
    orden = sorted((i for i in range(len(caras)) if caras[i][0] > UMBRAL_DETECCION), key=lambda i: -caras[i][0])[:TOPE_CARAS]
    elegidas = []
    for i in orden:
        x1, y1, w1, h1 = (int(v) for v in caras[i][1:5])
        bien = True
        for j in elegidas:
            x2, y2, w2, h2 = (int(v) for v in caras[j][1:5])
            ix = max(0, min(x1 + w1, x2 + w2) - max(x1, x2))
            iy = max(0, min(y1 + h1, y2 + h2) - max(y1, y2))
            inter = ix * iy
            union = w1 * h1 + w2 * h2 - inter
            if union <= 0 or inter / union > NMS:
                bien = False
                break
        if bien:
            elegidas.append(i)
    return [caras[i] for i in elegidas]


def similitud(puntos):
    """(sc, ss, tx, ty) de la semejanza (sin reflejo) que lleva los puntos estándar de 112×112 a los de la imagen, por
    mínimos cuadrados (lo mismo que FaceAlignment de OpenCV Zoo): u = sc·x + ss·y + tx, v = -ss·x + sc·y + ty."""
    filas, ladob = [], []
    for (x, y), (u, v) in zip(PUNTOS_ESTANDAR, puntos):
        filas.append((x, y, 1.0, 0.0))
        ladob.append(u)
    for (x, y), (u, v) in zip(PUNTOS_ESTANDAR, puntos):
        filas.append((y, -x, 0.0, 1.0))
        ladob.append(v)
    a = np.array(filas, np.float64)
    b = np.array(ladob, np.float64)
    r = np.linalg.solve(a.T @ a, a.T @ b)
    return float(r[0]), float(r[1]), float(r[2]), float(r[3])


def _enderezar(bgr, puntos):
    """La cara a 112×112 (bilineal, fuera de la imagen negro), como cv.warpAffine con la semejanza."""
    sc, ss, tx, ty = similitud(puntos)
    ys, xs = np.mgrid[0:112, 0:112].astype(np.float64)
    u = sc * xs + ss * ys + tx
    v = -ss * xs + sc * ys + ty
    h, w = bgr.shape[:2]
    x0, y0 = np.floor(u).astype(np.int64), np.floor(v).astype(np.int64)
    fx, fy = (u - x0)[..., None], (v - y0)[..., None]
    img = bgr.astype(np.float32)

    def pix(yy, xx):
        dentro = (xx >= 0) & (xx < w) & (yy >= 0) & (yy < h)
        r = np.zeros((112, 112, 3), np.float32)
        r[dentro] = img[yy[dentro], xx[dentro]]
        return r

    r = (pix(y0, x0) * (1 - fx) * (1 - fy) + pix(y0, x0 + 1) * fx * (1 - fy)
         + pix(y0 + 1, x0) * (1 - fx) * fy + pix(y0 + 1, x0 + 1) * fx * fy)
    return np.clip(np.rint(r), 0, 255).astype(np.uint8)


# ------------------------------------------------------------------------------------------------ las miniaturas
def leer_imagen(datos, ancho=320, alto=180):
    """JPEG/PNG/WebP → BGR (alto, ancho, 3) de uint8 con QImage (va en todos los Cat-ode de escritorio; no hace falta
    ventana). Si no es 16:9, se recorta el centro a 16:9 (las hqdefault traen bandas negras)."""
    from PySide6.QtCore import Qt, QRect
    from PySide6.QtGui import QImage
    img = QImage()
    if not img.loadFromData(datos):
        raise ValueError("imagen que no se puede leer")
    w, h = img.width(), img.height()
    if abs(w * 9 - h * 16) > 16:
        nh = w * 9 // 16
        if nh <= h:
            img = img.copy(QRect(0, (h - nh) // 2, w, nh))
    img = img.convertToFormat(QImage.Format.Format_RGB888).scaled(ancho, alto, Qt.AspectRatioMode.IgnoreAspectRatio,
                                                                  Qt.TransformationMode.SmoothTransformation)
    fila = img.bytesPerLine()
    a = np.frombuffer(img.constBits(), np.uint8, count=fila * img.height()).reshape(img.height(), fila)
    return np.ascontiguousarray(a[:, :img.width() * 3].reshape(img.height(), img.width(), 3)[:, :, ::-1])


def bajar_miniatura(vid):
    url = f"https://i.ytimg.com/vi/{vid}/mqdefault.jpg"
    q = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0 Safari/537.36"})
    with urllib.request.urlopen(q, timeout=8) as r:
        return r.read(400_000)


def _fixture(vid):
    """En las pruebas sin red (CATODE_PRUEBA_INTERFAZ, el motor falso) nunca se baja nada: la miniatura de la carpeta
    CATODE_FIXTURES_CARAS (<id>.jpg) o, si no está, ninguna (b""). Fuera de las pruebas, None (se baja de i.ytimg.com)."""
    d = os.environ.get("CATODE_FIXTURES_CARAS")
    if not d and not os.environ.get("CATODE_PRUEBA_INTERFAZ"):
        return None
    p = os.path.join(d or "", f"{vid}.jpg")
    if d and os.path.exists(p):
        with open(p, "rb") as f:
            return f.read()
    return b""


# ------------------------------------------------------------------------------------------------ la cola
def preparar():
    """Al encender «Sin clickbait»: numpy, los modelos y el hilo (una vez; en segundo plano)."""
    global _hilo
    with _cerrojo:
        if _estado["listo"] or _estado["preparando"] or _estado["fallo"]:
            return
        _estado["preparando"] = True
    try:
        global _motor
        _cargar_numpy()
        _motor = Motor()
        _estado["listo"] = True
    except Exception as ex:   # noqa: BLE001
        _estado["fallo"] = repr(ex)[:200]
        _registro(f"caras: el filtro sigue solo con los títulos: {_estado['fallo']}")
    finally:
        _estado["preparando"] = False
    if _estado["listo"] and _hilo is None:
        _hilo = threading.Thread(target=_trabajar, daemon=True, name="caras")
        _hilo.start()
        with _cerrojo:
            _cerrojo.notify_all()


def pedir(vid, url, puntos=0):
    """Que se mire la miniatura de ese vídeo (si no está ya mirada o pedida); «puntos», los de clickbait de su título (con 2
    o más, basta una cara algo menos clara: filtros.cara_de_sorpresa)."""
    if not vid or _estado["fallo"]:
        return
    with _cerrojo:
        if vid in _pedidos:
            return
        _pedidos.add(vid)
        _cola.append((vid, url, puntos))
        if len(_cola) > TOPE_COLA:
            viejo = _cola.pop(0)[0]
            _pedidos.discard(viejo)
        _cerrojo.notify()
    if not _estado["listo"] and not _estado["preparando"]:
        threading.Thread(target=preparar, daemon=True, name="caras-preparar").start()


def _trabajar():
    if os.name != "nt":
        try:
            os.setpriority(os.PRIO_PROCESS, threading.get_native_id(), 19)
        except Exception:   # noqa: BLE001
            pass
    from . import filtros
    fallos_seguidos = 0
    while True:
        with _cerrojo:
            while not _cola:
                _cerrojo.wait(60)
            vid, url, puntos = _cola.pop()   # lo último que se pidió es lo que se está viendo
        try:
            if not filtros.estado["cebo"]:
                with _cerrojo:
                    _pedidos.discard(vid)
                continue
            if filtros.aprendidos().cara(vid) is not None:
                continue
            datos = _fixture(vid)
            if datos is None:
                try:
                    datos = bajar_miniatura(vid)
                except urllib.error.HTTPError as ex:
                    if ex.code not in (404, 410):
                        raise
                    filtros.aprendidos().poner_cara(vid, {"s": 0.0, "a": 0.0, "n": 0, "x": ex.code}, False)   # sin miniatura: no se repite
                    continue
            if not datos:
                continue
            t = time.time()
            r = _motor.analizar(leer_imagen(datos), filtros.reglas().caras.get("confianza_cara", 0.8),
                                filtros.reglas().caras.get("area_minima", 0.035))
            r["ms"] = int((time.time() - t) * 1000)
            positiva = filtros.cara_de_sorpresa(r, puntos)
            filtros.aprendidos().poner_cara(vid, r, positiva)
            if positiva:   # fuera ya de lo que se ve (la web y la Qt lo quitan sin volver a pedir la página)
                filtros.avisar_cambio([url])
            fallos_seguidos = 0
        except Exception as ex:   # noqa: BLE001
            fallos_seguidos += 1
            with _cerrojo:
                _pedidos.discard(vid)
            if fallos_seguidos in (1, 20):
                _registro(f"caras: {vid}: {ex!r}"[:300])
            time.sleep(min(30, fallos_seguidos))   # sin red: espera y sigue con lo siguiente


def estado():
    return {"listo": _estado["listo"], "fallo": _estado["fallo"], "en_cola": len(_cola)}
