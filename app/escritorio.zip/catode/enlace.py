"""Cat-ode · el «navegador» del sistema para los enlaces (03/10/2026, el autor: «que los enlaces en todos los sistemas
abran Cat-ode»). Los de vídeos, Shorts, listas y canales de YouTube van a Cat-ode; todo lo demás, al navegador de
siempre (guardado en navegador.json al instalarlo). Nunca llama a xdg-open ni al navegador «por defecto» (que es él).
19/10/2026 («catode tiene que abrir los enlaces a youtube en los que haces clic en todos los sistemas en los que se
instala y en los míos»): lo usan también el anfitrión de la extensión de Chrome y compartir.py; en Linux arranca Cat-ode
con el entorno de ~/bin/catode (sin él, con Cat-ode cerrado, no encontraba libmpv); un enlace con «catode=navegador» va
siempre al navegador; CATODE_ENLACE_PRUEBA=<archivo> apunta lo que haría, sin abrir nada (pruebas)."""
import json
import os
import re
import subprocess
import sys

AQUI = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))   # la carpeta de catode.pyw
YT = re.compile(r"^https?://(?:(?:www|m|music)\.)?(?:youtube\.com/(?:watch|shorts/|live/|playlist|@|channel/|c/|user/)"
                r"|youtu\.be/)", re.I)
EDGE = (r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe", r"C:\Program Files\Microsoft\Edge\Application\msedge.exe")


def carpeta():
    # 18/10/2026: CATODE_CARPETA (instalación aislada de prueba) manda; se lee aquí sin importar datos (módulo suelto)
    d = os.environ.get("CATODE_CARPETA", "").strip()
    return os.path.abspath(os.path.expanduser(d)) if d else os.path.join(os.environ["LOCALAPPDATA"], "Cat-ode") if os.name == "nt" else os.path.expanduser("~/.config/catode")


def _conf():
    try:
        with open(os.path.join(carpeta(), "navegador.json"), encoding="utf-8-sig") as f:
            return json.load(f)
    except Exception:   # noqa: BLE001
        return {}


def _prueba(que, url):
    with open(os.environ["CATODE_ENLACE_PRUEBA"], "a", encoding="utf-8") as f:
        f.write(f"{que} {url}\n")
    return True


def _lanzar(orden, **kw):
    try:
        return subprocess.Popen(orden, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                start_new_session=True, **kw)
    except OSError:
        return None


def al_navegador(url):
    """El navegador de antes (no Cat-ode). Devuelve el proceso, o None si no hay ninguno conocido."""
    if os.environ.get("CATODE_ENLACE_PRUEBA"):
        return _prueba("navegador", url)
    c = _conf()
    orden = c.get("orden")   # lista con «{url}»
    if orden and (os.name != "nt" or os.path.exists(orden[0])):
        p = _lanzar([url if x == "{url}" else x for x in orden])
        if p:
            return p
    if os.name == "nt":
        for exe in EDGE:   # sin navegador guardado (o ya no está): Edge, que siempre viene con Windows
            if os.path.exists(exe):
                return _lanzar([exe, url])
        return None
    if c.get("desktop"):   # Linux: el .desktop del navegador de antes
        for base in (os.path.expanduser("~/.local/share/applications"), "/usr/local/share/applications",
                     "/usr/share/applications", "/var/lib/snapd/desktop/applications", "/var/lib/flatpak/exports/share/applications"):
            ruta = os.path.join(base, c["desktop"])
            if os.path.exists(ruta):
                p = _lanzar(["gio", "launch", ruta, url])
                if p:
                    return p
    for n in ("google-chrome", "firefox", "chromium", "chromium-browser"):
        p = _lanzar([n, url])
        if p:
            return p
    return None


def a_catode(url, prefijo=()):
    """Abre el enlace en Cat-ode (si ya está abierto, en su ventana: instancia única). «prefijo» va delante de la orden
    (31/10/2026: el servicio de Chromium lo arranca en su propio scope con systemd-run, fuera del grupo del servicio)."""
    if os.environ.get("CATODE_ENLACE_PRUEBA"):
        return _prueba("catode", url)
    python = sys.executable
    entorno = dict(os.environ)
    if os.name == "nt":
        if python.lower().endswith("python.exe"):
            python = python[:-10] + "pythonw.exe"
    else:   # lo mismo que ~/bin/catode
        lib = os.path.expanduser("~/.local/share/catode/lib")
        if os.path.isdir(lib):
            entorno["LD_LIBRARY_PATH"] = lib + (":" + entorno["LD_LIBRARY_PATH"] if entorno.get("LD_LIBRARY_PATH") else "")
        entorno.update(QT_QPA_PLATFORM="xcb", RESOURCE_NAME="catode", LC_NUMERIC="C")
        nvm = os.path.expanduser("~/.nvm/versions/node")
        if os.path.isdir(nvm):
            ult = sorted(os.listdir(nvm))
            if ult:
                entorno["PATH"] = os.path.join(nvm, ult[-1], "bin") + os.pathsep + entorno.get("PATH", "")
    return _lanzar([*prefijo, python, os.path.join(AQUI, "catode.pyw"), url], cwd=AQUI, env=entorno)


def abrir(url):
    if url.startswith("catode:"):   # catode://www.youtube.com/watch?v=… (el protocolo propio)
        url = "https://" + url.split(":", 1)[1].lstrip("/")
    if YT.match(url) and "catode=navegador" not in url:
        return a_catode(url)
    if url:
        return al_navegador(url)
    return None


def main():
    abrir(sys.argv[1] if len(sys.argv) > 1 else "")


if __name__ == "__main__":
    main()
