"""Cat-ode escritorio · el servicio sin Qt para la interfaz web (06/10/2026, DISENO_WEB.md §1.7, §2 y módulo M1).

Todo lo que las páginas Qt piden hoy a motor/datos/metadatos, en Python puro y con la misma lógica (las referencias de
línea son de interfaz.py): cada función BLOQUEA (red) y devuelve un dict serializable a JSON con el formato del contrato
§2.3; el servidor (servidor_web.py) las llama desde sus hilos. Una instancia por proceso (Servicio.instancia()).

Errores: se lanza ErrorCat(texto, clase) con clase ∈ sin_red · bloqueo · imposible · servidor_autor (§2.2); cualquier
otra excepción la clasifica clasificar(). Los eventos para la página (§2.4) salen por self.emitir(tipo, datos), que pone
el servidor."""
import os
import platform
import re
import threading
import time
import uuid

from . import cancion, motor, musica, roto, VERSION
from . import ajustes as aj
from .datos import Datos
from .resolutor import Resolutor, definitivo, registro


# ---------------------------------------------------------------- errores (§2.2)
class ErrorCat(Exception):
    def __init__(self, texto, clase="sin_red", reintentar=None):
        super().__init__(texto)
        self.clase = clase
        self.reintentar = (15 if clase == "sin_red" else 0) if reintentar is None else reintentar


# 18/10/2026: «confirm you» y «sign in to confirm» casaban con «Sign in to confirm your age» (restricción de edad, que es de
# ese vídeo y definitiva): se tomaba por bloqueo de la IP. La lista y el orden (edad primero) viven ahora en roto.py.
BLOQUEOS = roto.BLOQUEOS + roto.BLOQUEO_FLOJO


def clasificar(error):
    """(clase, texto en español, segundos para reintentar) de cualquier excepción."""
    if isinstance(error, ErrorCat):
        return error.clase, str(error), error.reintentar
    t = str(error)
    tl = t.lower()
    if roto.clasificar(error) == "bloqueo":
        return "bloqueo", "YouTube pide comprobar que no eres un robot: no insisto (se reintenta más tarde, a mano)", 0
    aviso = definitivo(error)
    if aviso:
        return "imposible", aviso, 0
    import socket
    import urllib.error
    if isinstance(error, (urllib.error.URLError, ConnectionError, socket.timeout, TimeoutError, OSError)) or "sin conexión" in tl:
        return "sin_red", "Sin conexión: lo vuelvo a intentar solo en unos segundos…", 15
    return "imposible", f"No he podido hacerlo ({error.__class__.__name__}: {t[:160]})", 0


def marcar_bloqueo():
    """Regla 24: YouTube ha marcado la IP; la marca del guardián (~/.cache/guardia/youtube_bloqueado), sin reintentar."""
    try:
        g = os.path.join(os.path.expanduser("~"), ".cache", "guardia")
        os.makedirs(g, exist_ok=True)
        with open(os.path.join(g, "youtube_bloqueado"), "w") as f:
            f.write(str(int(time.time())))
    except OSError:
        pass


def _vtt_a_lineas(texto):
    """De un WebVTT a [(segundos, frase)], sin etiquetas ni repeticiones (copia de interfaz.py 1503)."""
    lineas, ultimo = [], ""
    bloque_t = None
    for cruda in texto.splitlines():
        linea = cruda.strip()
        m = re.match(r"(\d+):(\d\d):(\d\d)[.,](\d{3})\s+-->", linea) or re.match(r"(\d\d):(\d\d)[.,](\d{3})\s+-->", linea)
        if m:
            g = m.groups()
            bloque_t = (int(g[0]) * 3600 + int(g[1]) * 60 + int(g[2]) + int(g[3]) / 1000) if len(g) == 4 else (int(g[0]) * 60 + int(g[1]) + int(g[2]) / 1000)
            continue
        if not linea or linea.startswith(("WEBVTT", "Kind:", "Language:", "NOTE")) or linea.isdigit() or bloque_t is None:
            continue
        frase = re.sub(r"<[^>]+>", "", linea).replace("&nbsp;", " ").replace("&amp;", "&").replace("&gt;", ">").replace("&lt;", "<").strip()
        if not frase or frase == ultimo:
            continue
        lineas.append((bloque_t, frase))
        ultimo = frase
    return lineas


def _hashtag(url):
    """El hashtag de un enlace de YouTube (/hashtag/<x>), o None (como fichas.hashtag, sin Qt)."""
    m = re.search(r"youtube\.com/hashtag/([^/?#&]+)", url or "")
    if not m:
        return None
    import urllib.parse
    return urllib.parse.unquote(m.group(1))


NUT = {"Juegos para gatos": "cat games for cats to watch", "TV para gatos": "cat tv birds squirrels for cats to watch",
       "Música para gatos": "relaxing music for cats"}
CANAL_PESTANAS = {"videos": "Vídeos", "shorts": "Shorts", "streams": "Directos", "playlists": "Listas"}
MENU = [["inicio", "🏠  Inicio"], ["shorts", "⚡  Shorts"], ["suscripciones", "📺  Suscripciones"], ["explorar", "🧭  Explorar"],
        ["historial", "🕘  Historial"], ["despues", "🕒  Ver más tarde"], ["megusta", "👍  Vídeos que me gustan"],
        ["listas", "☰  Listas"], ["descargas", "⬇  Descargas"], ["nut", "🐾  Para Nut"], ["ajustes", "⚙  Ajustes"]]


class Servicio:
    _unico = None

    @classmethod
    def instancia(cls, **kw):
        if cls._unico is None:
            cls._unico = cls(**kw)
        return cls._unico

    def __init__(self, fixtures=None, ajustes=None):
        self.fixtures = bool(os.environ.get("CATODE_PRUEBA_INTERFAZ")) if fixtures is None else bool(fixtures)
        if self.fixtures:
            from . import motor_falso
            motor_falso.activar()
        self.ajustes = ajustes if ajustes is not None else aj.leer()
        self.datos = Datos()
        self.datos.pausar_historial = self.ajustes.get("pausar_historial", False)
        self.resolutor = Resolutor(self.ajustes)
        musica.al_resolver = lambda c, i: musica.apuntar(self.datos, c, i)   # 22/10/2026: lo encontrado, a la biblioteca
        self.emitir = lambda tipo, datos: None      # lo pone el servidor (SSE)
        self.servir_archivo = lambda ruta: ruta     # lo pone el servidor: ruta local → URL /<id>
        self.al_reiniciar = None                    # lo pone VentanaWeb (actualizar.py → reiniciar cuando no suene nada)
        self.aviso_vigilante = ""
        self.estado_actualizacion = ""
        self._sonados = []   # 22/10/2026 (3.8): lo que ha sonado en esta sesión (para no repetir la misma canción)
        self._parati = None
        self._vistos_inicio = None
        self._novedades = None
        self._hist_yt = None
        self._locales = {}
        self._canales = {}          # url → (cabecera, vídeos, info) del último canal abierto (acerca y valoración)
        self._nuevos = []
        self._descargas = {}
        self._cerrojo = threading.RLock()
        self.datos.oyentes.append(lambda: self.emitir("datos", {"col": "", "motivo": "cambio"}))
        # 22/10/2026 (cuenta única): los ajustes compartidos entre equipos, como en interfaz.py
        self.datos.al_ajustes.append(self._ajustes_de_fuera)
        self._ajustes_de_fuera(self.datos.ajustes_comunes(), avisar=False)
        self.datos.sembrar_ajustes(self.ajustes)

    # ---------------------------------------------------------------- utilidades
    def guardar_ajustes(self, compartir=True):
        aj.guardar(self.ajustes)
        if compartir and getattr(self, "datos", None) is not None:   # 22/10/2026: los compartidos, a los otros equipos
            self.datos.poner_ajustes(self.ajustes)

    def _ajustes_de_fuera(self, d, avisar=True):
        """22/10/2026 (cuenta única) · ajustes cambiados en otro equipo: aquí y en la página (evento «ajustes»)."""
        cambia = {k: v for k, v in (d or {}).items() if self.ajustes.get(k) != v}
        if not cambia:
            return
        self.ajustes.update(cambia)
        if "pausar_historial" in cambia:
            self.datos.pausar_historial = bool(cambia["pausar_historial"])
        self.guardar_ajustes(compartir=False)
        registro(f"web: ajustes de otro equipo: {cambia}")
        self.emitir("ajustes", {"ajustes": cambia, "avisar": avisar})

    def reiniciar_cuando_libre(self):   # actualizar.py (con la web, lo hace la ventana)
        if self.al_reiniciar:
            self.al_reiniciar()

    def _d(self, e, motivos=None):
        d = e.dict() if hasattr(e, "dict") else dict(e)
        s, dur = self.datos.posicion(d.get("url", ""))
        d["visto"] = int(100 * s / dur) if dur else 0
        d["motivo"] = (motivos or {}).get(d.get("url", ""), "")
        return d

    def _lista(self, elementos, motivos=None, filtrar=True):
        ocultos = self.datos.ocultos() if filtrar else set()
        r = []
        for e in elementos:
            if isinstance(e, dict):
                e = motor.elemento_de_dict(e)
            if filtrar and (e.url in ocultos or self.datos.vetado(e)):
                continue
            r.append(self._d(e, motivos))
        return r

    def _mas_inicio(self, tema):
        from .mezcla import mas_para_ti
        if getattr(self, "_inicio_ya", None) is None:
            self._inicio_ya = set()
        if self._vistos_inicio is None:
            self._vistos_inicio = {motor.id_video(e.url) for e in self.datos.historial(3000)}
        return mas_para_ti(self.datos, self._inicio_ya, tema, (self._parati or {}).get("videos", []), self._vistos_inicio)

    def inicio_mas(self, tema="Todo", cursor=1):
        """06/10/2026 · el Inicio no se acaba: al llegar al final, otra tanda alrededor de lo suyo (mezcla.mas_para_ti).
        Si una tanda no trae nada nuevo se prueba con otras semillas; a la tercera vacía, se acabó por esta visita."""
        tema = tema or "Todo"
        elementos, motivos = [], {}
        for _ in range(3):
            elementos, motivos = self._mas_inicio(tema)
            if elementos:
                break
        return self._pagina("", elementos, motivos, mas=bool(elementos), cursor=int(cursor or 1) + 1)

    def _pagina(self, titulo, elementos, motivos=None, aviso="", chips=None, activo=None, filtrar=True, **mas):
        lista = self._lista(elementos, motivos, filtrar)
        return {"titulo": titulo, "elementos": lista, "motivos": {k: v for k, v in (motivos or {}).items() if v},
                "aviso": aviso, "mas": bool(mas.pop("mas", False)), "cursor": mas.pop("cursor", None),
                "chips": list(chips or []), "activo": activo, **mas}

    @staticmethod
    def _e(x):
        """Un Elemento de lo que manda la página (dict) o de una url."""
        if isinstance(x, motor.Elemento):
            return x
        if isinstance(x, str):
            return motor.Elemento("VIDEO", x, "")
        return motor.elemento_de_dict(x or {})

    # ---------------------------------------------------------------- estado y ajustes
    def estado(self):
        return {"version": VERSION, "so": os.name, "ajustes": self.ajustes,
                "pestanas": self.ajustes.get("pestanas") or [{"f": "inicio", "a": [], "t": "Inicio"}],
                "pestana_activa": int(self.ajustes.get("pestana_activa", 0) or 0), "sincro": self.datos.estado_sincro,
                "nodo": platform.node(), "remoto": bool(self.ajustes.get("apagar_remoto")), "actualizacion": self.estado_actualizacion,
                "fixtures": self.fixtures, "menu": MENU, "canales": self._lista(self.datos.suscripciones(), filtrar=False),
                "novedades": len(self._nuevos), "aviso_vigilante": self.aviso_vigilante, "hay_musica": self.hay_musica(),
                "novedades_version": self.novedades_version()}

    def novedades_version(self):
        """22/10/2026 · lo nuevo de esta versión que aún no se ha visto en este aparato ({version, puntos}), o None."""
        if self.fixtures:   # en las pruebas automáticas no: el diálogo se quedaría con su teclado (lo midió «buscar: Intro»)
            return None
        from . import novedades_version
        p = novedades_version.pendientes(self.ajustes.get("novedades_vista"), VERSION, self.hay_musica())
        return {"version": VERSION, "puntos": p} if p else None

    def novedades_vistas(self):
        self.ajustes["novedades_vista"] = VERSION
        self.guardar_ajustes()
        return {}

    def ajustes_leer(self):
        return {"ajustes": self.ajustes}

    def ajustes_guardar(self, nuevos):
        if not isinstance(nuevos, dict):
            raise ErrorCat("Ajustes no válidos", "imposible")
        nuevos = nuevos.get("ajustes", nuevos) if isinstance(nuevos.get("ajustes"), dict) else nuevos
        self.ajustes.update(nuevos)
        if "pausar_historial" in nuevos:
            self.datos.pausar_historial = bool(nuevos["pausar_historial"])
        self.guardar_ajustes()
        return {"ajustes": self.ajustes}

    # ---------------------------------------------------------------- páginas
    def _dsc(self):
        """28/10/2026 · Inicio, Suscripciones, Explorar y la campana se calculan aquí (descubrir.py), sin el servidor de casa
        (orden del autor: «que la app funcione bien para cualquiera, en local y sin servicios … en segundo plano»)."""
        with self._cerrojo:
            if getattr(self, "_descubrir", None) is None:
                from .descubrir import Descubrir, Almacen
                almacen = None
                if self.fixtures:   # las pruebas sin red: nunca el almacén del autor
                    from . import motor_falso
                    almacen = Almacen(os.path.join(motor_falso.DATOS, "descubrir.json"))
                self._descubrir = Descubrir(self.datos, almacen, estilo=self.ajustes.get("estilo", True))
            return self._descubrir

    def inicio(self, tema="Todo", recargar=False):
        """interfaz.py: la portada (descubrir.py: semillas que rotan, lo nuevo de tus canales y lo descubierto), «Continuar
        viendo» y los temas. 06/10/2026 («el feed no puede ser siempre el mismo y fijo»): cada visita «de nuevas» (al abrir,
        con Actualizar, al pulsar Inicio estando en Inicio, o pasados 10 min) es una portada nueva; dentro de esos 10 min no
        cambia (volver atrás la encuentra como estaba). 28/10/2026: ya no se pide la lista del servidor (parati.json): la
        portada se calcula aquí, y lo que estaba arriba la vez anterior no vuelve arriba."""
        tema = tema or "Todo"
        import time as _t
        from .mezcla import Ensenado
        ahora = _t.time()
        if getattr(self, "_ensenado", None) is None:
            self._ensenado = Ensenado()
        fresca = recargar or not self._parati or ahora - getattr(self, "_mezcla_t", 0) > 600
        nueva = False
        if fresca:
            lista, temas = self._dsc().inicio(self._ensenado.veces(), self._ensenado.cansados())
            if lista:
                self._parati = {"videos": [dict(e.dict(), motivo=m) for e, m in lista], "temas": temas}
                self._parati_t = ahora
                self._mezcla, self._mezcla_t, nueva = self._parati["videos"], ahora, True
                self._vistos_inicio = None
                self._inicio_ya = {motor.id_video(x.get("url", "")) for x in self._mezcla}   # lo ya mostrado: las tandas de más no lo repiten
            elif not self._parati:
                raise ErrorCat("Sin conexión con YouTube: lo vuelvo a intentar solo…", "sin_red")
        p = self._parati
        temas = ["Todo"] + [t for t in (p.get("temas") or []) if not self.datos.vetado(motor.Elemento("CANAL", "", t))][:14] \
            + ["Novedades de tus canales", "Ya vistos"]
        ocultos = self.datos.ocultos()
        if recargar or self._vistos_inicio is None:
            self._vistos_inicio = {motor.id_video(e.url) for e in self.datos.historial(3000)}
            self._cansados_inicio = self._ensenado.cansados()   # 24/10/2026: lo enseñado 3 veces sin abrirlo (mezcla.Ensenado)
        vistos = self._vistos_inicio
        cansados = getattr(self, "_cansados_inicio", set())
        self._inicio_ya |= cansados   # las tandas de más (inicio_mas) tampoco lo traen
        videos = [x for x in self._mezcla if x.get("url") not in ocultos and not motor.programado(x)]
        if tema == "Ya vistos":
            lista = [x.dict() for x in self.datos.historial(200)]
        elif tema == "Novedades de tus canales":
            lista = [x for x in videos if "suscri" in (x.get("motivo") or "").lower()]
        else:
            lista = [x for x in videos if motor.id_video(x.get("url", "")) not in vistos]
            if tema != "Todo":
                lista = [x for x in lista if x.get("autor") == tema or tema.lower() in (x.get("motivo") or "").lower()]
            lista = self._ensenado.apartar(lista, cansados, lambda x: motor.id_video(x.get("url", "")))
            if nueva and tema == "Todo":
                self._ensenado.apuntar([motor.id_video(x.get("url", "")) for x in lista[:Ensenado.PRIMEROS]])
        motivos = {x["url"]: x.get("motivo", "") for x in lista if x.get("motivo")}
        elementos = [motor.elemento_de_dict(x) for x in lista]
        if tema not in ("Todo", "Ya vistos") and len(elementos) < 12:   # un tema con casi nada: se rellena ya (06/10/2026)
            mas, m2 = self._mas_inicio(tema)
            elementos += mas
            motivos.update(m2)
        if tema == "Todo":   # «Continuar viendo» primero, como YouTube (06/10/2026: 4, no 8: eran fila y media siempre iguales)
            seguir = self.datos.continuar_viendo(4)
            urls = {e.url for e, _, _ in seguir}
            for e, s, d in seguir:
                motivos[e.url] = f"Continuar viendo · {int(100 * s / d)} % visto"
            elementos = [e for e, _, _ in seguir] + [e for e in elementos if e.url not in urls]
        r = self._pagina("", elementos, motivos, self.aviso_vigilante, temas, tema,
                         mas=tema != "Ya vistos", cursor=1)   # 06/10/2026: al llegar al final, más (inicio_mas)
        r["temas"] = temas
        return r

    def shorts(self):
        """interfaz.py 3295-3317: los Shorts de tus canales (sin ocultos ni vetados)."""
        subs = self.datos.suscripciones()
        if not subs:
            return self._pagina("Shorts", [], aviso="Los Shorts salen de los canales que sigues: suscríbete a alguno.")
        r = motor.shorts(subs)
        if not r:
            raise ErrorCat("No he podido cargar los Shorts", "sin_red")
        p = self._pagina("Shorts", r)
        p["aviso"] = f"{len(p['elementos'])} Shorts de tus canales · rueda o ↑ ↓ para pasar"
        return p

    def suscripciones(self, filtro="Todo", recargar=False):
        """interfaz.py: lo nuevo de TODOS tus canales (descubrir.py: el RSS de cada canal, guardado 30 min; ⟳ lo vuelve a
        pedir de verdad; 28/10/2026, antes la lista del servidor de hasta 6 h), 2 min en memoria para los filtros."""
        filtro = filtro or "Todo"
        chips = ("Todo", "Hoy", "Esta semana", "No vistos")
        subs = self.datos.suscripciones()
        if not subs:
            return self._pagina("Suscripciones", [], aviso="Aún no sigues ningún canal: búscalo y pulsa «Suscribirse».", chips=chips, activo=filtro)
        if recargar or not (self._novedades and time.time() - self._novedades[0] < 120):
            r = self._dsc().suscripciones(forzar=bool(recargar))
            if not r:
                self._novedades = None
                raise ErrorCat("Sin conexión: no he podido mirar lo nuevo de tus canales. Lo vuelvo a intentar solo…", "sin_red")
            self._novedades = (time.time(), r)
        r = self._novedades[1]
        ahora = time.time() * 1000
        lista = r
        if filtro == "Hoy":
            lista = [e for e in r if e.fecha and ahora - e.fecha < 86_400_000]
        elif filtro == "Esta semana":
            lista = [e for e in r if e.fecha and ahora - e.fecha < 7 * 86_400_000]
        elif filtro == "No vistos":
            vistos = {motor.id_video(e.url) for e in self.datos.historial(3000)}
            lista = [e for e in r if motor.id_video(e.url) not in vistos]
        return self._pagina("Suscripciones", lista, aviso="" if lista else "Nada nuevo con este filtro.", chips=chips, activo=filtro)

    def gestionar(self):
        subs = self.datos.suscripciones()
        return self._pagina(f"Tus canales ({len(subs)})", subs, filtrar=False)

    def explorar(self, categoria=None, recargar=False):
        """28/10/2026 («explorar me pone vídeos populares de mierda y nada relacionado con las temáticas de mis canales pero
        distintos, para ampliar mi catálogo de intereses y canales»): canales que no sigues cerca de los tuyos, con su
        porqué (descubrir.py); al bajar hasta el final, más (explorar_mas). Sin canales ni «me gusta», o con una de las
        categorías de antes, lo de antes (los canales de tema de YouTube)."""
        cats = list(motor.EXPLORAR)
        if categoria in motor.EXPLORAR:
            return self._pagina("Explorar", motor.explorar(categoria), chips=cats, activo=categoria)
        self._explorar_ya = set()
        r = self._dsc().explorar(categoria or "Todo", forzar=bool(recargar), ya=self._explorar_ya)
        if r is None:
            p = self._pagina("Explorar", motor.explorar(cats[0]), chips=cats, activo=cats[0])
            p["aviso"] = "Sigue algún canal o dale a «Me gusta» a algún vídeo y aquí saldrán canales nuevos cerca de los tuyos."
            return p
        return self._pagina("Explorar", r["elementos"], r["motivos"], r["aviso"], r["chips"], r["activo"],
                            mas=bool(r["elementos"]), cursor=1)

    def explorar_mas(self, tema="Todo", cursor=1):
        """La tanda siguiente de Explorar al llegar al final: otros canales (los ya enseñados en esta visita no se repiten)."""
        if not hasattr(self, "_explorar_ya"):
            self._explorar_ya = set()
        r = self._dsc().explorar(tema or "Todo", mas=True, ya=self._explorar_ya) or {}
        els = r.get("elementos", [])
        return self._pagina("", els, r.get("motivos"), mas=bool(els), cursor=int(cursor or 1) + 1)

    TANDA_HISTORIAL = 150

    def historial(self, q="", cursor=None):
        """interfaz.py 3422-3460: lo visto aquí + el historial de la cuenta de YouTube (/app/historial.json, por detrás).
        06/10/2026 (perfil de uso): por tandas de 150 (cursor = desde dónde). Entero eran 5000 vídeos y 1,8 MB de JSON en
        cada visita: ≈ 0,8 s hasta ver las tarjetas en el N100; la rejilla pide la tanda siguiente al acercarse al final."""
        h = self.datos.historial(20000)
        if self._hist_yt is None:
            self._hist_yt = []

            def traer():
                r = self.datos.del_servidor("/app/historial.json") or {}
                if r.get("videos"):
                    self._hist_yt = [motor.elemento_de_dict(x) for x in r["videos"]]
                    self.emitir("datos", {"col": "historial", "motivo": "historial de YouTube"})
            threading.Thread(target=traer, daemon=True, name="historial-yt").start()
        ya = {motor.id_video(e.url) for e in h} | {motor.id_video(u) for u in self.datos.ocultos()}
        if not self.datos.borrado:
            h = h + [e for e in self._hist_yt if motor.id_video(e.url) not in ya]
        if q:
            f = q.lower()
            h = [e for e in h if f in e.titulo.lower() or f in (e.autor or "").lower()]
        pausado = self.datos.pausar_historial
        try:
            desde = max(0, int(cursor or 0))
        except (TypeError, ValueError):
            desde = 0
        hasta = desde + self.TANDA_HISTORIAL
        mas = hasta < len(h)
        r = self._pagina("Historial", h[desde:hasta], aviso="El historial está en pausa: lo que veas no se apunta." if pausado else ("" if h else "Nada en el historial."),
                         filtrar=False, mas=mas, cursor=str(hasta) if mas else None)
        r["pausado"], r["q"], r["total"] = pausado, q, len(h)
        return r

    def coleccion(self, col):
        titulos = {"despues": ("Ver más tarde", "Nada guardado. En el menú «⋮» de cada vídeo: «Guardar para ver más tarde»."),
                   "megusta": ("Vídeos que me gustan", "Aún no has marcado ninguno con «Me gusta».")}
        if col not in titulos:
            raise ErrorCat(f"Colección desconocida: {col}", "imposible")
        titulo, vacio = titulos[col]
        lista = self.datos.coleccion(col)
        return self._pagina(f"{titulo} ({len(lista)})", lista, aviso="" if lista else vacio, filtrar=False)

    def listas(self):
        elementos = []
        for clave, x in self.datos.listas_propias():
            vids = x.get("videos", [])
            if x.get("yt"):
                elementos.append(motor.Elemento("LISTA", x["yt"], x.get("nombre", "Lista"), x.get("autor", ""), "",
                                                x.get("miniatura", ""), detalle="de YouTube"))
            else:
                elementos.append(motor.Elemento("LISTA", clave, x.get("nombre", "Lista"), "", "",
                                                vids[0].get("miniatura", "") if vids else "", detalle=f"{len(vids)} vídeos"))
        return self._pagina("Listas", elementos, filtrar=False,
                            aviso="" if elementos else "Aún no tienes listas. Crea una aquí o desde el menú «⋮» de un vídeo.")

    # ---------------------------------------------------------------- música (22/10/2026, encargo de música, M3: musica.py)
    def musica(self, grupo="Todo"):
        elementos, chips = musica.pagina(self.datos, grupo)
        return self._pagina("Música", elementos, filtrar=False, chips=chips, activo=grupo,
                            aviso="" if elementos else "Aún no tienes música aquí: pulsa «📥 Importar tu música» (YouTube Music, Spotify, Amazon Music…).")

    def lista_musica(self, clave):
        nombre, cs = musica.lista(self.datos, clave)
        r = self._pagina(nombre, cs, aviso="" if cs else "Esta lista no tiene canciones aquí.", filtrar=False)
        r["clave"] = clave
        return r

    def musica_mezcla(self, grupo="Todo"):
        """09/11/2026 · «🔀 Aleatorio» de la sección Música: hasta 400 canciones al azar de todas las listas del grupo."""
        cs = musica.mezcla(self.datos, grupo)
        return self._pagina("Música aleatoria", cs, aviso="" if cs else "Aún no hay canciones en tu música.", filtrar=False)

    def hay_musica(self):
        return musica.hay(self.datos)

    def lista_propia(self, clave):
        x = self.datos.extra("listas", clave) or {}
        vids = [motor.elemento_de_dict(v) for v in x.get("videos", [])]
        r = self._pagina(x.get("nombre", "Lista"), vids, aviso="" if vids else "Lista vacía.", filtrar=False)
        r["clave"] = clave
        return r

    def lista_yt(self, url, titulo="Lista"):
        cab, elementos = motor.lista(url)
        nombre = cab if isinstance(cab, str) else getattr(cab, "titulo", "")
        r = self._pagina(nombre or titulo or "Lista", elementos)
        r["guardada"] = any(x.get("yt") == url for _, x in self.datos.listas_propias())
        r["url"] = url
        return r

    def descargas(self):
        self._locales = {}
        elementos = []
        for ruta, titulo, vid in motor.descargados():
            try:
                mb = os.path.getsize(ruta) / 1e6
            except OSError:
                mb = 0
            e = motor.Elemento("VIDEO", motor.url_video(vid) if vid else "file:" + ruta, titulo, "", "",
                               motor.miniatura(vid) if vid else "",
                               detalle=("Solo sonido · " if ruta.lower().endswith((".m4a", ".mp3", ".opus")) else "") + f"{mb:.0f} MB")
            self._locales[e.url] = ruta
            elementos.append(e)
        r = self._pagina("Descargas", elementos, filtrar=False,
                         aviso="" if elementos else "Nada descargado. En el menú «⋮» de cada vídeo: «Descargar».")
        r["carpeta"] = motor.carpeta_descargas()
        return r

    def nut(self, chip=None):
        que = chip if chip in NUT else next(iter(NUT))
        r = [x for x in motor.buscar(NUT[que]) if x.tipo == "VIDEO"][:40]
        self.datos.sin_historial = getattr(self.datos, "sin_historial", set()) | {x.url for x in r}
        return self._pagina("Para Nut", r, chips=list(NUT), activo=que)

    def canal(self, url, pestana="videos"):
        """interfaz.py 3562-3622: ficha del canal + pestañas Vídeos, Shorts, Directos y Listas."""
        pestana = pestana if pestana in CANAL_PESTANAS else "videos"
        if pestana == "videos" or url not in self._canales:
            cab, videos, info = motor.canal_completo(url)
            with self._cerrojo:
                if len(self._canales) > 20:
                    self._canales.clear()
                self._canales[url] = (cab, videos, info)
        cab, videos, info = self._canales[url]
        elementos = videos if pestana == "videos" else motor.canal_pestana(url, pestana)
        info_pub = {k: info.get(k) for k in ("nombre", "avatar", "suscriptores", "banner", "verificado", "handle", "descripcion", "etiquetas", "id")}
        r = self._pagina(cab.titulo + ("  ✔" if info.get("verificado") else ""), elementos,
                         aviso="" if elementos else "Este canal no tiene nada aquí.",
                         chips=list(CANAL_PESTANAS.values()), activo=CANAL_PESTANAS[pestana])
        r.update({"cabecera": self._d(cab), "info": info_pub, "suscrito": self.datos.suscrito(url), "pestana": pestana,
                  "pestanas": CANAL_PESTANAS, "vertical": pestana == "shorts", "url": url})
        return r

    def canal_acerca(self, url):
        from . import metadatos as md
        info = (self._canales.get(url) or (None, None, {}))[2]
        return {"acerca": md.acerca_de(url, info.get("cabecera"))}

    def canal_valoracion(self, url):
        from . import metadatos as md
        if url not in self._canales:
            self._canales[url] = motor.canal_completo(url)
        urls = [e.url for e in self._canales[url][1] if e.tipo == "VIDEO"]
        try:
            v = md.valoracion(urls)
        except Exception:   # noqa: BLE001
            v = {"hechos": 0, "total": 0, "conVotos": 0, "mediaMeGusta": -1, "mediaNoMeGusta": -1}
        return {"valoracion": v}

    # ---------------------------------------------------------------- buscar
    def buscar(self, q, tipo=None, fecha=None, duracion=None, orden=None, cursor=None):
        q = (q or "").removeprefix("⟲  ").strip()
        if not q:
            return {"elementos": [], "cursor": None, "filtros": {k: list(v) for k, v in motor.FILTROS.items()}}
        if re.search(r"(youtube\.com|youtu\.be)/", q):   # un enlace pegado: se abre
            return {"elementos": [], "cursor": None, "enlace": self.enlace(q), "filtros": {k: list(v) for k, v in motor.FILTROS.items()}}
        filtros = {k: v for k, v in (("tipo", tipo), ("fecha", fecha), ("duracion", duracion), ("orden", orden)) if v}
        if not cursor:
            self.datos.buscado(q)
        elementos, token = motor.buscar_filtrada(q, filtros or None, cursor or None)
        r = self._pagina(f"«{q}»", elementos, aviso="" if elementos else "Sin resultados.")
        r.update({"cursor": token, "mas": bool(token), "filtros": {k: list(v) for k, v in motor.FILTROS.items()}, "elegidos": filtros})
        return r

    def sugerencias(self, q=""):
        previas = [b for b in self.datos.busquedas(40) if q.lower() in b.lower()][:5] if q else self.datos.busquedas(10)
        yt = []
        if q.strip():
            try:
                yt = [x for x in motor.sugerencias(q) if x not in previas]
            except Exception:   # noqa: BLE001
                yt = []
        return {"propias": previas, "youtube": yt}

    def enlace(self, url):
        """El clasificador de abrir_enlace (interfaz.py 3730-3768): {tipo, url, t, titulo}."""
        url = (url or "").strip()
        if url.startswith("/"):
            url = "https://www.youtube.com" + url
        es_yt = re.search(r"https?://(www\.|m\.|music\.)?(youtube\.com|youtu\.be)/", url) is not None or url.startswith(("youtube.com", "youtu.be", "www.youtube"))
        if es_yt and not url.startswith("http"):
            url = "https://" + url
        t = re.search(r"[?&#]t=(\d+)", url)
        t = int(t.group(1)) if t else None
        if es_yt and re.search(r"(youtube\.com/(watch|shorts/|live/)|youtu\.be/)", url):
            vid = motor.id_video(url)
            return {"tipo": "video", "url": motor.url_video(vid), "t": t, "titulo": "", "miniatura": motor.miniatura(vid)}
        h = _hashtag(url)
        if es_yt and h:
            return {"tipo": "hashtag", "url": "#" + h, "t": None, "titulo": "#" + h}
        if es_yt and re.search(r"youtube\.com/(channel/|@|c/|user/)", url):
            return {"tipo": "canal", "url": url, "t": None, "titulo": ""}
        if es_yt and "list=" in url:
            return {"tipo": "lista", "url": url, "t": None, "titulo": "Lista"}
        if es_yt and "/results?" in url:
            m = re.search(r"search_query=([^&]+)", url)
            if m:
                import urllib.parse
                q = urllib.parse.unquote_plus(m.group(1))
                return {"tipo": "busqueda", "url": q, "t": None, "titulo": q}
        return {"tipo": "fuera", "url": url, "t": None, "titulo": ""}

    # ---------------------------------------------------------------- vídeo
    def ficha(self, url):
        """motor.ficha + estado de las colecciones (interfaz.py 811-885 y _botones 963)."""
        f = dict(motor.ficha(url))
        d = self.datos
        u = f.get("url") or url
        ocultos = d.ocultos()
        rel = [r for r in (f.get("relacionados") or []) if r.url not in ocultos and not d.vetado(r)]
        # 22/10/2026 (3.8): «la primera que sugiere es la misma que has buscado»: la misma canción, al final
        rel = cancion.ordenar(rel, {"url": u, "titulo": f.get("titulo", ""), "autor": f.get("autor", "")}, self._sonados)
        f["relacionados"] = [self._d(r) for r in rel]
        f["capitulos"] = [[s, n] for s, n in (f.get("capitulos") or [])]
        enlistas = [clave for clave, x in d.listas_propias() if any(v.get("url") == u for v in x.get("videos", []))]
        s, dur = d.posicion(u)
        f.update({"megusta": d.contiene("megusta", u), "nomegusta": d.contiene("nomegusta", u), "despues": d.contiene("despues", u),
                  "suscrito": bool(f.get("autorUrl")) and d.suscrito(f["autorUrl"]), "enListas": enlistas, "posicion": [s, dur],
                  "listas": [[clave, x.get("nombre", "Lista")] for clave, x in d.listas_propias() if not x.get("yt")]})
        return f

    def completo(self, url, dur=-1):
        from . import metadatos as md
        c = md.completo(url, int(dur or -1)) or {}
        try:
            from . import fichas   # html_datos no tiene Qt dentro, pero fichas importa Qt: solo si está
            c["htmlDatos"] = fichas.html_datos(self.ficha(url), c)
        except Exception:   # noqa: BLE001
            c["htmlDatos"] = ""
        return {"extra": c.get("extra"), "formatos": c.get("formatos"), "votos": c.get("votos"), "htmlDatos": c.get("htmlDatos", "")}

    def comentarios(self, url, cursor=None):
        lista, token = motor.comentarios(url, cursor or None)
        return {"comentarios": lista, "cursor": token}

    def _subs(self, url):
        x = self.resolutor.guardado(url, 1080) or self.resolutor.resolver(url, 1080)
        return x.get("subs") or []

    def transcripcion(self, url):
        """interfaz.py 980-1027: la pista española sin traducir, si no la original; el VTT a líneas."""
        subs = self._subs(url)
        sub = next((u for u, n, l in subs if l == "es" and "tlang=" not in u), None) or \
            next((u for u, n, l in subs if "tlang=" not in u), None) or (subs[0][0] if subs else None)
        if not sub:
            return {"lineas": [], "aviso": "Este vídeo no tiene subtítulos: no hay transcripción."}
        texto = self._leer_vtt(sub)
        lineas = [[s, t] for s, t in _vtt_a_lineas(texto or "")]
        return {"lineas": lineas, "aviso": "" if lineas else "No he podido leer los subtítulos de este vídeo."}

    def _leer_vtt(self, sub):
        if self.fixtures or not sub.startswith("http"):
            from . import motor_falso
            ruta = motor_falso.ruta_local(sub)
            try:
                with open(ruta, encoding="utf-8", errors="replace") as f:
                    return f.read()
            except OSError:
                return ""
        from . import anuncios   # 15/10/2026: como Chrome (YouTube niega con 429 lo que no parece un navegador)
        return anuncios.bajar_subtitulos(sub, motor.AGENTE, forzar=True)

    def tramos(self, url, dur=0, vtt=None):
        """reproductor.py 312-325: los tramos de SponsorBlock y, si nadie marcó un patrocinio, los anuncios del creador
        (anuncios.detectar por capítulos, descripción y subtítulos del idioma original)."""
        t = [list(x) for x in (motor.patrocinios(url) or [])]
        if not any(x[2] == "sponsor" for x in t):
            try:
                from . import anuncios
                f = motor.ficha(url)
                if vtt and not str(vtt).startswith("http"):
                    vtt = None
                t += [list(x) for x in anuncios.detectar(f.get("descripcion", ""), f.get("capitulos") or [],
                                                          float(dur or 0) or f.get("duracion") or 0, vtt)]
            except Exception as error:   # noqa: BLE001
                registro(f"anuncios: {error!r}"[:200])
        return {"tramos": t}

    def completar(self, urls, seguir=None):
        """fichas.Relleno (444-469): duración, visualizaciones y fecha de las filas que no las traen (novedades del RSS,
        historial). Caché de 3 días primero; lo que falte, 4 a la vez. Un bloqueo de YouTube corta la tanda (regla 24):
        md.resumen(avisar_bloqueo=True) lanza el 429 / «not a bot» / LOGIN_REQUIRED en vez de devolver None, y lo que
        quede ya no se pide. seguir(): False si la página ya no lo quiere (petición abortada) → no se pide nada más."""
        import concurrent.futures as cf
        from . import metadatos as md
        urls = [u for u in (urls or []) if isinstance(u, str) and u.startswith("http")][:48]
        datos, faltan = {}, []
        for u in urls:
            r = md.resumen_en_cache(u)
            (datos.__setitem__(u, r) if r else faltan.append(u))
        errores, cortado = [], threading.Event()

        def uno(u):
            if cortado.is_set():
                return u, None
            if seguir is not None and not seguir():
                cortado.set()
                return u, None
            try:
                return u, md.resumen(u, avisar_bloqueo=True)
            except Exception as error:   # noqa: BLE001
                if re.search(r"not a bot|LOGIN_REQUIRED|429|Too Many", str(error), re.I):
                    cortado.set()   # bloqueo: lo que quede de la tanda no se pide
                errores.append(error)
                return u, None
        if faltan:
            with cf.ThreadPoolExecutor(4) as ex:
                for u, r in ex.map(uno, faltan):
                    if r:
                        datos[u] = r
        for error in errores:   # «not a bot», 429…: que el servidor lo clasifique como bloqueo y no se insista
            if re.search(r"not a bot|LOGIN_REQUIRED|429|Too Many", str(error), re.I):
                raise error
        salida = {}
        for u, r in datos.items():
            x = {}
            if (r.get("duracion") or -1) > 0:
                x["duracion"] = int(r["duracion"])
            if isinstance(r.get("vistas"), int) and r["vistas"] >= 0:
                x["vistas"] = f"{md.miles(r['vistas'])} visualizaciones"
            f = r.get("publicado") or r.get("fecha") or 0
            if isinstance(f, (int, float)) and f > 0:
                x["fecha"] = int(f)
            if x:
                salida[u] = x
        return {"datos": salida}

    def relacionados(self, url, automatica=False):
        ocultos = self.datos.ocultos()
        rel = [r for r in (motor.relacionados(url) or []) if r.url not in ocultos and not self.datos.vetado(r)]
        # 22/10/2026 (encargo 3.8): la misma canción (de este vídeo o de lo ya sonado en la sesión) al final, y «siguiente»
        # para la reproducción automática: otra canción, no vista antes si se puede (cancion.py)
        actual = next((s for s in reversed(self._sonados) if motor.id_video(s.url) == motor.id_video(url)), None) or {"url": url}
        rel = cancion.ordenar(rel, actual, self._sonados)
        vistos = {motor.id_video(e.url) for e in self.datos.historial(300)}
        sig = cancion.siguiente(rel, actual, self._sonados, vistos=vistos, ocultos=ocultos)
        if sig is None and automatica and cancion.es_cancion(actual):   # una canción y ninguna otra suelta: el Mix de YouTube
            registro(f"web: automática sin otra canción suelta entre los relacionados de {url}: el Mix")
            sig = cancion.mezcla(actual, self._sonados, vistos, ocultos, lambda u: motor.lista(u)[1])
        return {"elementos": [self._d(r) for r in rel], "siguiente": self._d(sig) if sig else None}

    def resolver(self, url, alto=1080, fondo=False):
        """Lo que reproduce el iframe (§2.3): HLS de YouTube o un archivo servido por /<id>."""
        if url.startswith(musica.PREFIJO):   # 22/10/2026: canción importada (Spotify, Amazon): su vídeo de YouTube, ahora
            real = musica.resolver_cancion(url)
            return {**self.resolver(real, alto, fondo), "url": real}
        alto = int(alto or 1080)
        reanudar = None
        if self.ajustes.get("reanudar", True):
            s, d = self.datos.posicion(url)
            if s and d and s < d - 20:
                reanudar = {"seg": s, "dur": d}
        local = self._locales.get(url) or (url[5:] if url.startswith("file:") else None)
        if local:
            return {"tipo": "archivo", "fuente": self.servir_archivo(local), "titulo": os.path.basename(local), "duracion": 0,
                    "directo": False, "subs": [], "storyboard": None, "tramos": [], "reanudar": reanudar}
        from concurrent.futures import ThreadPoolExecutor
        ex = ThreadPoolExecutor(1)
        tramos_f = ex.submit(motor.patrocinios, url) if (self.ajustes.get("patrocinios", True) and not fondo) else None
        try:
            x = self.resolutor.resolver(url, alto, fondo)
        except Exception as error:   # noqa: BLE001
            roto.apuntar_video(url, error)   # 18/10/2026: la página no avisa a /api/fallo de esto: se cuenta aquí
            raise
        finally:
            ex.shutdown(wait=False)
        fuente = x.get("hls") or x.get("ruta")
        tipo = "hls" if x.get("hls") else "archivo"
        if tipo == "archivo" and fuente and os.path.exists(str(fuente)):
            fuente = self.servir_archivo(fuente)   # un archivo local (vídeo de prueba)
        tramos = []
        if tramos_f is not None:
            try:
                tramos = [[a, b, c] for a, b, c in (tramos_f.result(timeout=1.5) or [])]
            except Exception:   # noqa: BLE001
                tramos = []
        return {"tipo": tipo, "fuente": fuente, "titulo": x.get("titulo", ""), "duracion": x.get("duracion", 0),
                "directo": bool(x.get("directo")), "subs": [{"url": u, "nombre": n, "lengua": l} for u, n, l in (x.get("subs") or [])],
                "storyboard": x.get("storyboard"), "tramos": tramos, "reanudar": reanudar, "alto": x.get("alto")}

    def sonando(self):
        """24/10/2026: un directo no guarda posición, pero suena: la actualización espera igual (al publicar la 1.2.18 se
        reinició la tele a mitad del «24/7 LIVE CAT TV» que tenía puesto para Nut, porque solo contaba /api/posicion)."""
        self._ultima_pos = time.time()
        return {}

    def posicion(self, url, seg, dur):
        self._ultima_pos = time.time()   # algo suena: la actualización espera (VentanaWeb.reiniciar_cuando_libre)
        self.datos.guardar_posicion(url, float(seg or 0), float(dur or 0))
        return {}

    def visto(self, e):
        el = self._e(e)
        self.datos.visto(el)
        self._sonados = (self._sonados + [el])[-30:]   # 22/10/2026 (3.8)
        return {}

    def fallo(self, url, error):
        """Como _rep.al_fallar (interfaz.py 2044-2049): al servidor del autor (el arreglador del ProBook)."""
        registro(f"web: fallo de {url}: {str(error)[:200]}")
        roto.apuntar_video(url, error)   # 18/10/2026: ¿YouTube se ha roto? (2 vídeos distintos en 15 min → busca el arreglo YA)
        if self.datos.conf and not self.fixtures:
            import json
            from .datos import pedir
            cuerpo = json.dumps({"app": "escritorio-web-" + os.name, "version": VERSION, "url": url, "error": str(error)[:300]}).encode()
            threading.Thread(target=lambda: pedir(self.datos.conf, self.datos.conf["servidores"][0], "POST", "/fallo", cuerpo), daemon=True).start()
        return {}

    # ---------------------------------------------------------------- cambios en los datos (POST /api/datos)
    def datos_accion(self, accion, **k):
        d = self.datos
        if accion == "alternar":
            col = k.get("col")
            if col not in ("despues", "megusta", "nomegusta"):
                raise ErrorCat(f"Colección no válida: {col}", "imposible")
            return {"puesto": d.alternar(col, self._e(k.get("e")))}
        if accion == "quitar":
            d.quitar(k["url"], k.get("col") or "suscripciones")
            if k.get("col") == "historial" and k.get("e"):   # como en Historial: además, oculto
                d.poner("ocultos", k["url"], self._e(k["e"]))
            return {}
        if accion == "ocultar":
            e = self._e(k.get("e"))
            d.poner("ocultos", e.url, e)
            return {}
        if accion == "suscribir":
            e = self._e(k.get("e"))
            if e.tipo != "CANAL":
                e = motor.Elemento("CANAL", e.autorUrl or e.url, e.autor or e.titulo, miniatura=e.miniatura if e.tipo == "CANAL" else "")
            d.suscribir(e)
            return {"suscrito": True}
        if accion == "anular":
            d.quitar(k["url"])
            return {"suscrito": False}
        if accion == "fulminar":
            return self.fulminar(k.get("url", ""), k.get("nombre", ""))
        if accion == "fulminar_lote":
            for x in k.get("urls") or []:
                u, n = (x.get("url"), x.get("nombre")) if isinstance(x, dict) else (x, x)
                d.fulminar(u, n)
            return {"n": len(k.get("urls") or [])}
        if accion == "indultar":
            d.indultar(k["url"])
            return {}
        if accion == "tema":
            pal = k.get("palabras") or []
            d.poner_tema(k.get("nombre", ""), pal.split(",") if isinstance(pal, str) else pal)
            return {"temas": d.temas()}
        if accion == "quitar_tema":
            d.quitar_tema(k.get("nombre", ""))
            return {"temas": d.temas()}
        if accion == "vetos":
            return {"temas": d.temas(), "fulminados": d.fulminados()}
        if accion == "lista":
            return self._lista_accion(**k)
        if accion == "historial":
            if k.get("que", k.get("accion2")) == "borrar" or k.get("hacer") == "borrar":
                d.borrar_historial()
            else:
                d.pausar_historial = not d.pausar_historial
                self.ajustes["pausar_historial"] = d.pausar_historial
                self.guardar_ajustes()
            return {"pausado": d.pausar_historial}
        if accion == "buscado":
            d.buscado(k.get("q", ""))
            return {}
        if accion == "quitar_busqueda":
            d.poner("busquedas", (k.get("q") or "").strip().lower(), None, None, activo=False)
            return {}
        if accion == "sincronizar":
            self.sincronizar()
            return {"sincro": d.estado_sincro}
        if accion == "borrar_descarga":   # interfaz.py 3553 _borrar_descarga (la página ya ha preguntado)
            url = k.get("url") or (k.get("e") or {}).get("url", "")
            if url not in getattr(self, "_locales", {}):
                self.descargas()
            ruta = self._locales.get(url)
            if not ruta:
                raise ErrorCat("Esa descarga ya no está en el disco", "imposible")
            try:
                os.remove(ruta)
            except OSError as error:
                raise ErrorCat(f"No he podido borrarla: {error}", "imposible") from error
            self._locales.pop(url, None)
            return {"borrada": ruta}
        raise ErrorCat(f"Acción desconocida: {accion}", "imposible")

    def _lista_accion(self, que=None, clave=None, nombre=None, e=None, elementos=None, url=None, titulo=None, **k):
        """lista(accion: nueva|poner|quitar|renombrar|borrar|guardar_yt|guardar_cola). La subacción llega en «que»
        (o en «sub»): «accion» ya es «lista»."""
        d = self.datos
        que = que or k.get("sub") or k.get("hacer")
        if que == "nueva":
            clave = d.nueva_lista((nombre or "Lista").strip())
            if e:
                d.lista_poner(clave, self._e(e))
            for x in elementos or []:
                d.lista_poner(clave, self._e(x))
            return {"clave": clave}
        if que == "poner":
            d.lista_poner(clave, self._e(e))
            return {"clave": clave}
        if que == "quitar":
            d.lista_poner(clave, self._e(e), False)
            return {"clave": clave}
        if que == "renombrar":
            x = dict(d.extra("listas", clave) or {})
            if (nombre or "").strip():
                x["nombre"] = nombre.strip()
                d.poner("listas", clave, None, x)
            return {"clave": clave}
        if que == "borrar":
            d.borrar_lista(clave)
            return {}
        if que == "guardar_yt":
            for c, x in d.listas_propias():
                if x.get("yt") == url:
                    d.borrar_lista(c)
                    return {"guardada": False}
            primero = self._e(elementos[0]) if elementos else None
            d.poner("listas", f"yt:{url}", None, {"nombre": titulo or nombre or "Lista", "yt": url,
                                                  "miniatura": primero.miniatura if primero else "", "autor": primero.autor if primero else ""})
            return {"guardada": True}
        if que == "guardar_cola":
            clave = d.nueva_lista((nombre or "Cola").strip())
            for x in elementos or []:
                d.lista_poner(clave, self._e(x))
            return {"clave": clave}
        raise ErrorCat(f"Acción de lista desconocida: {que}", "imposible")

    def fulminar(self, url, nombre):
        """interfaz.py 3068-3130: fuera el canal y, después, su entorno (canales de su burbuja, ≥35 % marcados)."""
        d = self.datos
        if not (url or nombre):
            raise ErrorCat("Falta el canal", "imposible")
        d.fulminar(url, nombre)
        if not url:
            return {"entorno": []}
        import concurrent.futures as cf

        def rel(canal, n):
            try:
                vids = [v for v in motor.canal(canal)[1] if v.tipo == "VIDEO"][:n]
            except Exception:   # noqa: BLE001
                return []
            with cf.ThreadPoolExecutor(4) as ex:
                return [r for lista in ex.map(motor.relacionados, [v.url for v in vids]) for r in (lista or [])]
        cuenta = {}
        for r in rel(url, 6):
            if r.tipo == "VIDEO" and r.autorUrl and r.autorUrl != url and not d.vetado(r):
                n0 = cuenta.get(r.autorUrl, (r.autor, 0))
                cuenta[r.autorUrl] = (r.autor, n0[1] + 1)
        cand = sorted(((u, a, n) for u, (a, n) in cuenta.items() if n >= 2), key=lambda x: -x[2])[:15]
        grupo = {u for u, _, _ in cand} | {url}

        def burbuja(c):
            rs = [r for r in rel(c[0], 3) if r.tipo == "VIDEO" and r.autorUrl != c[0]]
            dentro = sum(1 for r in rs if r.autorUrl in grupo or d.vetado(r))
            return (c[0], c[1], c[2], dentro * 100 // len(rs) if rs else 0)
        with cf.ThreadPoolExecutor(4) as ex:
            res = sorted(ex.map(burbuja, cand), key=lambda x: -x[3])
        return {"entorno": [{"url": u, "nombre": a, "pct": pct, "marcado": pct >= 35 and not d.suscrito(u)} for u, a, n, pct in res]}

    def importar(self, texto):
        return {"n": self.datos.importar_takeout(texto or "")}

    # ---------------------------------------------------------------- descargas (progreso por SSE)
    def descargar(self, e, solo_audio=False, alto=720):
        e = self._e(e)
        ident = uuid.uuid4().hex[:12]
        self._descargas[ident] = {"fraccion": 0.0, "hecho": False}

        def progreso(x, texto=""):
            self._descargas[ident]["fraccion"] = float(x)
            self.emitir("descarga", {"id": ident, "fraccion": float(x), "texto": texto or e.titulo, "hecho": False, "ruta": None})

        def trabajo():
            ruta, error = None, None
            try:
                ruta = motor.descargar(e, bool(solo_audio), int(alto or 720), progreso)
            except Exception as err:   # noqa: BLE001
                error = err
            self._descargas[ident].update({"hecho": True, "ruta": ruta})
            self.emitir("descarga", {"id": ident, "fraccion": 1.0 if ruta else self._descargas[ident]["fraccion"],
                                     "texto": f"No he podido descargarlo: {error}" if error else f"Descargado: {e.titulo}",
                                     "hecho": True, "ruta": ruta, "error": bool(error)})
        threading.Thread(target=trabajo, daemon=True, name="descarga").start()
        return {"id": ident}

    # ---------------------------------------------------------------- tele, remoto, miembros
    def teles(self):
        from . import tele
        return {"teles": [{"nombre": n, "app": a} for n, a in tele.buscar()]}

    def tele_poner(self, tele, url):
        from . import tele as t
        app = tele.get("app") if isinstance(tele, dict) else tele
        return {"puesto": bool(t.poner(app, url))}

    def remoto(self, apagar):
        from . import remoto
        texto = remoto.apagar(bool(apagar), self.ajustes, aj.guardar)
        self.emitir("remoto", {"apagado": bool(apagar)})
        return {"texto": texto, "apagado": bool(apagar)}

    def miembros_cuentas(self):
        from . import miembros
        return {"cuentas": [{"navegador": c[0], "nombre": c[1], "au": c[2], "pagina": c[3], "cuenta": c[4]} for c in miembros.cuentas()]}

    # ---------------------------------------------------------------- sincronización, novedades y arranque
    def sincronizar(self):
        try:
            self.datos.sincronizar()
        except Exception as error:   # noqa: BLE001
            self.emitir("sincro", {"estado": f"falla: {error}"[:120], "hora": time.strftime("%H:%M")})
            raise ErrorCat("El servidor de sincronización no responde", "servidor_autor")
        if self.datos.conf and self.datos.estado_sincro.startswith("Sin conexión"):
            self.emitir("sincro", {"estado": self.datos.estado_sincro, "hora": time.strftime("%H:%M")})
            raise ErrorCat("Sin conexión con tu servidor: lo de los otros equipos llegará cuando vuelva", "servidor_autor")
        self.emitir("sincro", {"estado": self.datos.estado_sincro, "hora": time.strftime("%H:%M")})

    def mirar_novedades(self):
        """interfaz.py: lo nuevo de tus canales que no se había visto (cuenta en la campana). 28/10/2026: de descubrir.py
        (cada 15 min mira los 10 canales que más publican), no del servidor de casa."""
        subs = {s.url for s in self.datos.suscripciones()}
        if not subs:
            return
        lista = self._dsc().campana()
        if not lista:
            return
        conocidos = set(self.ajustes.get("avisados") or [])
        ids = [motor.id_video(e.url) for e in lista]
        if not conocidos:   # la primera vez no se avisa de nada
            self.ajustes["avisados"] = ids[:600]
            return self.guardar_ajustes()
        vistos = {motor.id_video(e.url) for e in self.datos.historial(400)}
        nuevos = [e for e, i in zip(lista, ids) if i not in conocidos and i not in vistos]
        self.ajustes["avisados"] = (ids + [i for i in conocidos if i not in ids])[:600]
        self.guardar_ajustes()
        if nuevos:
            self._nuevos = nuevos + [e for e in self._nuevos if e.url not in {n.url for n in nuevos}]
            self.emitir("novedades", {"n": len(self._nuevos), "ids": [motor.id_video(e.url) for e in self._nuevos][:50]})
            if getattr(self, "al_novedades", None):   # M8: el aviso del sistema de la ventana (bandeja), si está en Ajustes
                self.al_novedades(nuevos)

    def novedades(self):
        """La campana: los nuevos (y se vacía)."""
        r = self._lista(self._nuevos, filtrar=False)
        self._nuevos = []
        return {"elementos": r}

    def arrancar(self):
        """Los hilos de siempre: sincronizar al empezar y cada 3 min, escuchar al servidor y mirar novedades cada 15 min."""
        def sincro_bucle():
            while True:
                try:
                    self.sincronizar()
                except Exception:   # noqa: BLE001
                    pass
                time.sleep(180)

        def novedades_bucle():
            time.sleep(20)
            while True:
                try:
                    self.mirar_novedades()
                except Exception:   # noqa: BLE001
                    pass
                time.sleep(900)
        threading.Thread(target=sincro_bucle, daemon=True, name="sincro").start()
        threading.Thread(target=novedades_bucle, daemon=True, name="novedades").start()
        self.datos.escuchar(lambda: self.emitir("datos", {"col": "", "motivo": "otro equipo"}))

    def cerrar(self):
        """Al cerrar: ajustes, sincronizar (en hilo) y esperar el guardado de los datos."""
        self.guardar_ajustes()
        threading.Thread(target=self.datos.sincronizar, daemon=True).start()
        self.datos.esperar_guardado()
