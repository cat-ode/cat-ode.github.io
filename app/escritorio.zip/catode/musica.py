"""Cat-ode escritorio · el modo Música (22/10/2026, encargo de música M3 y orden «termina el modo Music y que tire de la biblioteca
de youtube music»). Lo comparten la interfaz web (servicio.py) y la ventana Qt (interfaz.py), para que enseñen lo mismo.
La biblioteca es la colección compartida «biblioteca» (la hace el ProBook: recomendador/ytmusic.py + biblioteca.py): listas
{nombre, origen, canciones} y artistas {nombre, id, miniatura} que sigue en YouTube Music."""
import os
import threading

from . import motor
from .datos import ORIGENES_MUSICA


def canciones(x):
    """Las canciones de una lista de la biblioteca como vídeos: las de YouTube por su id; las del D: del mini PC, solo donde
    está el archivo (la tele), como archivo local."""
    out = []
    for c in x.get("canciones") or []:
        if c.get("id"):
            out.append(motor.Elemento("VIDEO", motor.url_video(c["id"]), c.get("titulo", ""), c.get("autor", ""), "",
                                      f"https://i.ytimg.com/vi/{c['id']}/mqdefault.jpg", int(c.get("dur") or -1)))
        elif c.get("ruta") and os.path.exists(c["ruta"]):
            out.append(motor.Elemento("VIDEO", "file:" + c["ruta"], c.get("titulo", ""), c.get("autor", ""), "", "",
                                      int(c.get("dur") or -1)))
        elif c.get("titulo") and not c.get("ruta"):   # importada de Spotify o Amazon: se busca en YouTube al ir a sonar
            out.append(motor.Elemento("VIDEO", url_cancion(c), c.get("titulo", ""), c.get("autor", ""), "", "",
                                      int(c.get("dur") or -1)))
    return out


def pagina(datos, grupo="Todo"):
    """(elementos, chips) de la sección: YouTube Music primero (listas, canciones, álbumes y los artistas, que abren su canal),
    luego las hechas con lo suyo, para descubrir y su disco; un chip por grupo («Todo» y los que haya)."""
    elementos, grupos = [], []
    for clave, x in datos.biblioteca():
        g = ORIGENES_MUSICA.get(x.get("origen"), "Para ti")
        if x.get("origen") == "youtube music · artista":
            if not x.get("id"):
                continue
            e = motor.Elemento("CANAL", "https://www.youtube.com/channel/" + x["id"], x.get("nombre", ""),
                               miniatura=x.get("miniatura", ""), detalle=x.get("detalle") or "Artista")
        else:
            cs = canciones(x)
            if not cs:
                continue
            mini = next((c.miniatura for c in cs if c.miniatura), "")   # 22/10/2026: las de Spotify empiezan sin vídeo (tarjeta gris)
            e = motor.Elemento("LISTA", "biblioteca:" + clave, x.get("nombre", "Lista"), "", "", mini,
                               detalle=f"{len(cs)} canciones")
        if g not in grupos:
            grupos.append(g)
        if grupo in ("Todo", g):
            elementos.append(e)
    return elementos, (["Todo"] + grupos if len(grupos) > 1 else [])


def lista(datos, clave):
    """(nombre, canciones) de una lista de la biblioteca."""
    x = dict(datos.biblioteca()).get(clave) or {}
    return x.get("nombre", "Lista"), canciones(x)


def hay(datos):
    """¿Hay biblioteca en este Cat-ode? (para avisar de lo suyo en las novedades; la sección Música sale siempre desde que se
    puede importar: orden del 22/10 para la redistribuible)."""
    return any(x.get("canciones") or x.get("id") for _, x in datos.biblioteca())


# ---------------------------------------------------------------- canciones sin vídeo (Spotify, Amazon Music; 22/10/2026)
# Orden del autor: «quien use Catode redistributable debe poder importar en local su biblioteca de spotify, amazon music y
# youtube music … Quiero poder usarlo todo desde catode». Lo importado de Spotify y Amazon trae título, artista, álbum y
# duración, no el vídeo: se busca UNA vez en YouTube (una búsqueda por canción) y se queda guardado.
_FEO = ("karaoke", "cover", "8d audio", "slowed", "sped up", "reverb", "nightcore", "instrumental", "remix", "live", "en directo",
        "directo", "acoustic", "acústic", "tutorial", "reaction", "reacción", "lyrics video maker")


def _palabras(t):
    import re
    import unicodedata
    t = unicodedata.normalize("NFKD", (t or "").lower())
    return set(re.findall(r"[a-z0-9]+", "".join(c for c in t if not unicodedata.combining(c))))


def elegir(c, resultados):
    """El vídeo que mejor encaja con la canción c = {titulo, artista, dur} entre los resultados de una búsqueda (Elementos),
    o None si ninguno se parece lo bastante (mejor nada que otra canción)."""
    tit, art = _palabras(c.get("titulo")), _palabras(c.get("artista") or c.get("autor"))
    dur = int(c.get("dur") or -1)
    mejor, nota_mejor = None, 0.0
    for e in resultados:
        if getattr(e, "tipo", "") != "VIDEO":
            continue
        pal = _palabras(f"{e.titulo} {e.autor}")
        if not tit or len(tit & pal) / len(tit) < 0.6:
            continue
        nota = len(tit & pal) / len(tit) + (0.6 * len(art & pal) / len(art) if art else 0)
        if "topic" in _palabras(e.autor) or "vevo" in (e.autor or "").lower():
            nota += 0.3   # «Artista - Topic» es el audio oficial (lo de YouTube Music)
        crudo = (e.titulo or "").lower()
        nota -= sum(0.5 for f in _FEO if f in crudo and f not in (c.get("titulo") or "").lower())
        if dur > 0 and (e.duracion or 0) > 0:
            d = abs(e.duracion - dur)
            nota += 0.4 if d <= 5 else 0.2 if d <= 15 else -0.3 if d <= 60 else -1.0
        if nota > nota_mejor:
            mejor, nota_mejor = e, nota
    return mejor if nota_mejor >= 1.2 else None


def buscar_cancion(c):
    """Busca la canción en YouTube (una petición) y devuelve el id del vídeo elegido, o "" si no hay uno que encaje."""
    q = " ".join(x for x in (c.get("artista") or c.get("autor") or "", c.get("titulo") or "") if x)
    e = elegir(c, motor.buscar(q, 10))
    return motor.id_video(e.url) if e else ""


# ---------------------------------------------------------------- la canción sin vídeo, al ir a sonar
PREFIJO = "cancion:"
_resueltas = {}          # url «cancion:…» → id de YouTube (o "" si no hay), en esta sesión
_cerrojos, _cerrojos_lock = {}, threading.Lock()
al_resolver = None       # fn(canción, id): lo pone la ventana o el servicio para apuntarlo en la biblioteca (todos los aparatos)


def url_cancion(c):
    """La «dirección» de una canción importada sin vídeo: cancion:{titulo, autor, dur} (se busca al ir a sonar)."""
    import json
    import urllib.parse
    return PREFIJO + urllib.parse.quote(json.dumps({"t": c.get("titulo", ""), "a": c.get("autor") or c.get("artista") or "",
                                                     "d": int(c.get("dur") or -1)}, ensure_ascii=False))


def de_url(url):
    import json
    import urllib.parse
    d = json.loads(urllib.parse.unquote(url[len(PREFIJO):]))
    return {"titulo": d.get("t", ""), "artista": d.get("a", ""), "dur": int(d.get("d") or -1)}


def resolver_cancion(url):
    """La dirección de YouTube de una canción importada (una búsqueda la primera vez; luego, de memoria). ValueError si
    YouTube no tiene ninguna que encaje (mejor saltarla que poner otra canción)."""
    # 22/10/2026: la ficha de la página y el reproductor la piden a la vez: un cerrojo por canción para buscarla UNA vez
    with _cerrojos_lock:
        cerrojo = _cerrojos.setdefault(url, threading.Lock())
    with cerrojo:
        if url in _resueltas:
            i = _resueltas[url]
        else:
            c = de_url(url)
            i = _resueltas[url] = buscar_cancion(c)
            if al_resolver:
                try:
                    al_resolver(c, i)
                except Exception:   # noqa: BLE001 (apuntarlo es un extra: la canción suena igual)
                    pass
    if not i:
        raise ValueError("No encuentro esta canción en YouTube")
    return motor.url_video(i)


def apuntar(datos, c, i):
    """Lo encontrado, en todas las listas de la biblioteca donde está esa canción sin vídeo (y, con cuenta compartida, en
    todos sus aparatos): así no se vuelve a buscar. Si no se encontró, no se apunta nada (se puede volver a intentar)."""
    if not i:
        return
    t, a = (c.get("titulo") or "").strip().lower(), (c.get("artista") or "").strip().lower()
    for clave, x in datos.biblioteca():
        cs = x.get("canciones") or []
        if any(not s.get("id") and (s.get("titulo") or "").strip().lower() == t and (s.get("autor") or "").strip().lower() == a for s in cs):
            nuevas = [dict(s, id=i) if (not s.get("id") and (s.get("titulo") or "").strip().lower() == t and
                                        (s.get("autor") or "").strip().lower() == a) else s for s in cs]
            datos.poner("biblioteca", clave, None, dict(x, canciones=nuevas))
