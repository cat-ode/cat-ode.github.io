"""Claroscuro · contador de descargas y aperturas · cliente en Python, solo biblioteca estándar (19/10/2026).

Orden del autor: «Haz un contador de descargas y usos integrado en las versiones que se usan y añádelo a mi contador de
Dos Gatos, hazlo también para Rosbel's Delight.»

Para Cat-ode de escritorio (Windows y Linux) y para el servidor de Rosbel's Delight en el ProBook. Cada apertura se apunta
en un archivo (recuento.json) y se manda en un hilo aparte a https://dosgatos.pages.dev/api/cuenta (Cloudflare; si no
contesta, al relevo del ProBook, 23/10/2026): la app nunca espera
ni falla por esto. Sin red, las aperturas se quedan en cola y salen en el siguiente intento (al minuto, a los 5, a los 30
y en la siguiente apertura). Cada envío lleva un número al azar («n»): si se repite porque se perdió la respuesta, el
contador no lo cuenta dos veces.
Lo único que sale: la app, la plataforma, la versión, un número al azar de esta instalación (inventado aquí la primera
vez) y las fechas de las aperturas. Nada del usuario. Ni una petición a YouTube.

Uso:
    from recuento_cliente import Contador
    c = Contador("catode", "windows", "1.2.2", carpeta_config())
    c.apertura()                 # al arrancar la app (vuelve al momento)
    c.enviar_pendientes()        # opcional, desde un reloj que ya exista (también vuelve al momento)
Pruebas: CLAROSCURO_RECUENTO_URL cambia la dirección; CLAROSCURO_SIN_RECUENTO=1 lo apaga del todo.
"""
import datetime
import json
import os
import secrets
import threading
import time
import urllib.error
import urllib.request

# 23/10/2026 · el contador vivía en Cloudflare con el relevo del ProBook. 02/11/2026 · sin contador fuera (orden del autor:
# «web propia separada de mi alojamiento»; «para no exponer mi cuenta»): la versión que se reparte ya no lleva dentro su
# alojamiento ni la dirección de su ProBook; solo manda a CLAROSCURO_RECUENTO_URL (pruebas). Lo que se cuenta ahora son las
# descargas de su web (GitHub).
MAX_COLA = 60            # lo que acepta el contador en un envío
MAX_GUARDADAS = 300      # aperturas en cola como mucho (las más viejas se pierden; el contador no apunta más de 45 días)
ESPERAS = (60, 300, 1800)   # reintentos si no hay red (segundos)


class Contador:
    def __init__(self, app, plataforma, version, carpeta, nombre="recuento.json", url=None):
        self.app, self.plataforma, self.version = app, plataforma, (str(version or "").split() or [""])[0][:24]
        self.ruta = os.path.join(carpeta, nombre)
        self.url = url or os.environ.get("CLAROSCURO_RECUENTO_URL") or ""
        self.apagado = not self.url or os.environ.get("CLAROSCURO_SIN_RECUENTO", "").strip() not in ("", "0")
        self._cerrojo = threading.Lock()
        self._hilo = None

    # ---- estado en disco: {"id": 32 hex, "pendientes": [fechas], "envio": {"n": …, "f": [...]} o null}
    def _leer(self):
        try:
            with open(self.ruta, encoding="utf-8") as f:
                e = json.load(f)
        except (OSError, ValueError):
            e = {}
        if not (isinstance(e.get("id"), str) and len(e["id"]) == 32 and all(c in "0123456789abcdef" for c in e["id"])):
            e["id"] = secrets.token_hex(16)
        e["pendientes"] = [f for f in e.get("pendientes", []) if isinstance(f, str)][-MAX_GUARDADAS:]
        if not (isinstance(e.get("envio"), dict) and e["envio"].get("n") and e["envio"].get("f")):
            e["envio"] = None
        return e

    def _guardar(self, e):
        os.makedirs(os.path.dirname(self.ruta) or ".", exist_ok=True)
        tmp = self.ruta + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(e, f)
        os.replace(tmp, self.ruta)

    # ---- lo que usa la app
    def apertura(self):
        """Una apertura más (hoy, en la hora de este equipo) y a mandarla, sin esperar: hasta apuntarla en disco va en otro
        hilo (22/10/2026: con el ProBook a carga 40, escribir el archivo en el hilo de la app tardaba hasta 143 ms)."""
        if self.apagado:
            return
        hoy, previo = datetime.date.today().isoformat(), self._hilo

        def todo():
            try:
                with self._cerrojo:
                    e = self._leer()
                    e["pendientes"].append(hoy)
                    self._guardar(e)
            except OSError:
                return
            if previo is not None and previo.is_alive():
                return   # el que ya está mandando la recoge en su siguiente intento
            self._trabajo()
        self._hilo = threading.Thread(target=todo, daemon=True, name="recuento")
        self._hilo.start()

    def enviar_pendientes(self):
        """Manda lo que haya en cola en un hilo aparte (uno a la vez); vuelve al momento."""
        if self.apagado or (self._hilo and self._hilo.is_alive()):
            return
        self._hilo = threading.Thread(target=self._trabajo, daemon=True, name="recuento")
        self._hilo.start()

    # ---- por dentro
    def _trabajo(self):
        for espera in (0,) + ESPERAS:
            if espera:
                time.sleep(espera)
            if self._vaciar():
                return

    def _vaciar(self):
        """True si no queda nada por mandar; False si falta la red o el contador no contesta."""
        for _ in range(8):
            with self._cerrojo:
                try:
                    e = self._leer()
                except OSError:
                    return False
                if not e["envio"]:
                    if not e["pendientes"]:
                        return True
                    e["envio"] = {"n": secrets.token_hex(8), "f": e["pendientes"][:MAX_COLA]}
                    e["pendientes"] = e["pendientes"][MAX_COLA:]
                    self._guardar(e)
                envio, ident = e["envio"], e["id"]
            codigo = self._mandar({"app": self.app, "p": self.plataforma, "id": ident, "v": self.version,
                                   "f": envio["f"], "n": envio["n"]})
            if codigo is None or not 200 <= codigo < 300:
                # se queda en cola, igual (mismo «n»). También con 4xx: mientras siga publicada la 1.ª versión del
                # contador (solo entiende a Dos Gatos), un envío nuevo da 400 y no se puede perder.
                return False
            with self._cerrojo:                                  # 2xx: contado
                e = self._leer()
                if e["envio"] and e["envio"]["n"] == envio["n"]:
                    e["envio"] = None
                    self._guardar(e)
        return False

    def _mandar(self, cuerpo):
        """El código de la primera dirección que lo acepte (2xx); si ninguna, el de la última que contestó, o None."""
        datos = json.dumps(cuerpo, separators=(",", ":")).encode("utf-8")
        codigo = None
        for url in [self.url]:
            q = urllib.request.Request(url, data=datos, method="POST",
                                       headers={"Content-Type": "text/plain;charset=UTF-8", "User-Agent": f"Claroscuro-recuento/{self.app}"})
            try:
                with urllib.request.urlopen(q, timeout=10) as r:
                    return r.status
            except urllib.error.HTTPError as err:
                codigo = err.code
                if 200 <= err.code < 300:
                    return err.code
            except (OSError, ValueError):
                pass
        return codigo
