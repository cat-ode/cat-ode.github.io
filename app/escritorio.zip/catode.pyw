"""Cat-ode de escritorio · arranque. En Linux va por XWayland (QT_QPA_PLATFORM=xcb) para que mpv pinte dentro de la ventana."""
import os
import sys
import time
os.environ.setdefault("CATODE_T0", str(time.time()))   # para medir el arranque (--medir)
try:   # trabajar siempre en una carpeta propia y escribible, la abra quien la abra (acceso directo, tarea, enlace)
    import tempfile
    os.chdir(tempfile.gettempdir())
except OSError:
    pass

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
if os.name != "nt":
    os.environ.setdefault("QT_QPA_PLATFORM", "xcb")
else:
    import ctypes   # el mismo id que llevan sus accesos: así la ventana abierta va sobre el icono anclado de la barra de tareas
    ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("es.catode.app")
    try:   # la gráfica, primero para Cat-ode (por delante del escritorio remoto); «alta», no «tiempo real»
        ctypes.windll.kernel32.OpenProcess.restype = ctypes.c_void_p
        _h = ctypes.windll.kernel32.OpenProcess(0x0200 | 0x0400, False, os.getpid())
        ctypes.windll.gdi32.D3DKMTSetProcessSchedulingPriorityClass.argtypes = [ctypes.c_void_p, ctypes.c_int]
        # 04/10/2026: con el motor de Edge el vídeo lo pinta otro proceso (msedgewebview2): Cat-ode, normal, para no quitarle la gráfica
        _prio = int(os.environ.get("CATODE_PRIORIDAD_GPU", "4" if os.environ.get("CATODE_MOTOR") == "mpv" else "2"))
        _r = ctypes.windll.gdi32.D3DKMTSetProcessSchedulingPriorityClass(_h, _prio)
        if _r:
            print(f"Cat-ode: prioridad de gráfica {_prio}: NTSTATUS {_r & 0xFFFFFFFF:#x}", file=sys.stderr, flush=True)
    except Exception:   # noqa: BLE001
        pass
    os.environ.setdefault("QT_QPA_PLATFORM", "windows:darkmode=2")   # menús y diálogos del sistema, en oscuro

from PySide6.QtNetwork import QLocalServer, QLocalSocket  # noqa: E402
if os.environ.get("CATODE_PRUEBA_INTERFAZ"):   # 05/10/2026: prueba de interfaz SIN RED: ni una petición a YouTube
    from PySide6.QtNetwork import QNetworkProxy
    QNetworkProxy.setApplicationProxy(QNetworkProxy(QNetworkProxy.HttpProxy, "127.0.0.1", 9))
from PySide6.QtWidgets import QApplication  # noqa: E402


def _tramo(nombre):   # 06/10/2026: los tramos del arranque en frío (el perfil de prueba_web.py los imprime)
    os.environ["CATODE_TRAMOS"] = os.environ.get("CATODE_TRAMOS", "") + f"{nombre}={time.time():.3f};"


_tramo("qt_importado")
# 06/10/2026 (perfil en el mini PC: 2,7 s del proceso a la ventana, de ellos ~0,7 s importando yt_dlp a través de la
# interfaz): la QApplication y la instancia única van ANTES de importar la interfaz, y en Windows el entorno de Edge se pide
# en cuanto hay QApplication, así msedgewebview2 arranca mientras Python sigue importando
app = QApplication(sys.argv)
app.setApplicationName("Cat-ode")
app.setDesktopFileName("es.catode.app")
from PySide6.QtGui import QIcon  # noqa: E402
app.setWindowIcon(QIcon(os.path.join(os.path.dirname(os.path.abspath(__file__)), "catode.ico" if os.name == "nt" else "catode.svg")))
_tramo("qapplication")
# 30/10/2026 · cerrada a usuarios nuevos (catode/acceso.py): el aviso y fuera, sin abrir nada; ante cualquier error, se abre
try:
    from catode import acceso as _acceso
    _cerrada = not _acceso.permitido()
except Exception as _error:   # noqa: BLE001
    _cerrada = False
    print(f"Cat-ode: acceso sin comprobar ({_error!r})"[:200], file=sys.stderr, flush=True)
if _cerrada:
    try:
        _acceso.cerrada(app)
    except Exception as _error:   # noqa: BLE001
        print(f"Cat-ode: sin aviso de cerrada ({_error!r})"[:200], file=sys.stderr, flush=True)
    sys.exit(0)
# una sola ventana: si ya está abierta, se trae al frente (y abre el enlace de YouTube que se le pase, si lo hay)
enlaces = [a for a in sys.argv[1:] if not a.startswith("--")]
nombre = "catode-" + os.environ.get("USER", os.environ.get("USERNAME", ""))
if os.environ.get("CATODE_CARPETA", "").strip():   # 18/10/2026: una instalación aislada (CATODE_CARPETA) no se confunde con la del autor
    import hashlib as _h
    nombre += "-" + _h.sha1(os.path.abspath(os.path.expanduser(os.environ["CATODE_CARPETA"].strip())).encode("utf-8")).hexdigest()[:10]
if "--prueba" in sys.argv:   # la prueba, aparte: con el Cat-ode del autor abierto solo lo traía al frente y salía (03/10/2026)
    nombre += "-prueba-" + (os.environ.get("CATODE_PRUEBA_NOMBRE") or str(os.getpid()))   # 06/10/2026: único por ejecución: un proceso de prueba zombi retenía el nombre y las nuevas salían al instante
s = QLocalSocket()
if "--reinicio" in sys.argv:   # tras actualizarse: espera a que la ventana vieja termine de cerrarse
    import time as _t
    for _ in range(40):
        s.connectToServer(nombre)
        if not s.waitForConnected(150):
            break
        s.disconnectFromServer(); _t.sleep(0.25)


def _fantasma(enchufe):
    """06/10/2026: una instancia anterior que se quedó atascada al cerrar (proceso vivo, SIN ventana) retenía el nombre de
    instancia única y la app «no abría». Si quien escucha no tiene ninguna ventana visible en 4 s (una que está arrancando
    la tiene antes), es un fantasma: se termina y esta arranca normal. Devuelve el PID terminado, o 0."""
    if os.name != "nt":
        return 0
    try:
        import ctypes
        import time as _t
        from ctypes import wintypes
        k, u = ctypes.windll.kernel32, ctypes.windll.user32
        pid = wintypes.ULONG(0)
        k.GetNamedPipeServerProcessId.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.ULONG)]
        if not k.GetNamedPipeServerProcessId(wintypes.HANDLE(int(enchufe.socketDescriptor())), ctypes.byref(pid)) or not pid.value:
            return 0
        if pid.value == os.getpid():
            return 0

        def con_ventana():
            hay = [False]

            @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
            def cada(h, _):
                p = wintypes.DWORD(0)
                u.GetWindowThreadProcessId(h, ctypes.byref(p))
                if p.value == pid.value and u.IsWindowVisible(h):
                    hay[0] = True
                    return False
                return True
            u.EnumWindows(cada, 0)
            return hay[0]
        for _ in range(8):
            if con_ventana():
                return 0
            _t.sleep(0.5)
        k.OpenProcess.restype = wintypes.HANDLE
        k.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        k.TerminateProcess.argtypes = [wintypes.HANDLE, wintypes.UINT]
        h = k.OpenProcess(0x0001, False, pid.value)   # PROCESS_TERMINATE
        if not h:
            return 0
        bien = k.TerminateProcess(h, 0)
        k.CloseHandle.argtypes = [wintypes.HANDLE]
        k.CloseHandle(h)
        _t.sleep(0.5)
        return pid.value if bien else 0
    except Exception:   # noqa: BLE001
        return 0


FANTASMA = 0
s.connectToServer(nombre)
if s.waitForConnected(300):
    FANTASMA = _fantasma(s)
    if not FANTASMA:
        s.write(("abrir " + enlaces[0]).encode() if enlaces else b"frente"); s.flush(); s.waitForBytesWritten(300)
        sys.exit(0)
    s.abort()
QLocalServer.removeServer(nombre)
servidor = QLocalServer()
servidor.listen(nombre)
if (os.name == "nt" and "--clasica" not in sys.argv and os.environ.get("CATODE_INTERFAZ", "").strip().lower() != "qt"
        and os.environ.get("CATODE_MOTOR") != "mpv" and not os.environ.get("CATODE_WEBVIEW2_FALLA")):
    try:
        from catode import motor_web as _mw
        _mw.precalentar(lambda t: print("Cat-ode:", t, file=sys.stderr, flush=True))
    except Exception as _error:   # noqa: BLE001 (sin WebView2: lo dirá interfaz_web.activa y se abre la Qt)
        print(f"Cat-ode: Edge sin precalentar ({_error!r})"[:200], file=sys.stderr, flush=True)
_tramo("edge_pedido")
from catode import interfaz, interfaz_web  # noqa: E402
_tramo("interfaz_importada")
try:   # 22/10/2026: una apertura para el panel de Claroscuro (anónima, en otro hilo, con cola sin red; nunca frena ni falla)
    from catode import recuento
    recuento.al_arrancar()
except Exception:   # noqa: BLE001
    pass
try:   # 22/10/2026: en Windows, los accesos directos con el icono de ahora (en otro hilo, al minuto; nunca frena ni falla)
    from catode import accesos
    accesos.al_arrancar()
except Exception:   # noqa: BLE001
    pass
if FANTASMA:
    from catode.resolutor import registro as _registro
    _registro(f"instancia anterior atascada sin ventana (pid {FANTASMA}): terminada; se arranca normal")
interfaz.tema(app)
sys.setswitchinterval(0.002)   # 04/10/2026: con varios hilos de Python cargando vídeos, la ventana esperaba su turno segundos en el N100
# 06/10/2026 · interfaz web (DISENO_WEB.md): solo en Windows y si está pedida (ajustes «interfaz»: «web» o CATODE_INTERFAZ=web);
# --clasica / CATODE_INTERFAZ=qt, la de siempre. Si la web no arranca, ella misma vuelve a la Qt (interfaz_web.viva)
WEB = interfaz_web.activa()
v = interfaz_web.VentanaWeb() if WEB else interfaz.Ventana()
v._soltar_instancia = servidor.close   # 06/10/2026: al cerrar se suelta el nombre de instancia única (una vieja atascada no impide abrir otra)


def _vigia_cuelgues():
    """Si la ventana deja de responder 6 s, escribe qué hace cada hilo en catode_cuelgues.log (03/10/2026: Windows se
    colgaba con 3-4 pestañas con vídeo y no había forma de saber dónde)."""
    import faulthandler
    import threading
    from PySide6.QtCore import QTimer
    from catode.datos import carpeta_datos
    latido = [time.time()]
    ruta = os.path.join(carpeta_datos(), "catode_cuelgues.log")
    # además, el de bajo nivel: escribe aunque el bloqueo retenga a todo Python (una llamada nativa de Qt o de mpv)
    fichero = open(ruta, "a", encoding="utf-8")

    def latir():
        latido[0] = time.time()
        faulthandler.dump_traceback_later(12, repeat=False, file=fichero)
    reloj = QTimer(app, interval=500)
    reloj.timeout.connect(latir)
    reloj.start()
    saliendo = [False]

    def al_salir():   # al cerrar la app no es un cuelgue: el vigía se calla
        saliendo[0] = True
        faulthandler.cancel_dump_traceback_later()
    app.aboutToQuit.connect(al_salir)

    def mirar():
        apuntado = False
        while True:
            time.sleep(1)
            parado = time.time() - latido[0]
            if saliendo[0]:
                return
            if parado > 6 and not apuntado:
                apuntado = True
                try:
                    with open(ruta, "a", encoding="utf-8") as f:
                        f.write(time.strftime("\n=== %d/%m %H:%M:%S ") + f"la ventana no responde desde hace {parado:.0f} s\n")
                        f.flush()
                        faulthandler.dump_traceback(file=f, all_threads=True)
                except Exception:   # noqa: BLE001
                    pass
            elif parado < 2:
                apuntado = False
    threading.Thread(target=mirar, daemon=True, name="vigia-cuelgues").start()


_vigia_cuelgues()
if os.name == "nt":   # barra de título oscura (Windows la ponía clara sobre una app oscura)
    try:
        import ctypes
        _oscuro = ctypes.c_int(1)
        ctypes.windll.dwmapi.DwmSetWindowAttribute(int(v.winId()), 20, ctypes.byref(_oscuro), ctypes.sizeof(_oscuro))
    except Exception:
        pass


def _llamada():
    c = servidor.nextPendingConnection()
    def leer():
        texto = bytes(c.readAll()).decode(errors="replace")
        w = interfaz_web.viva(v)   # la Qt si la web volvió atrás
        w.showNormal(); w.raise_(); w.activateWindow()
        if texto.startswith("abrir "):
            # 05/10/2026: con un vídeo sonando, el enlace que llega de fuera va a una pestaña nueva (antes lo pisaba)
            w.abrir_enlace(texto[6:], nueva=w.rep.actual is not None)
    c.readyRead.connect(leer)


servidor.newConnection.connect(_llamada)
if enlaces:   # 05/10/2026: con pestañas reabiertas de la última vez, el enlace va en una nueva y no pisa ninguna
    v.abrir_enlace(enlaces[0], nueva=len(v.pestanas) > 1 or bool(v.pila and v.pila[-1][0] != v.inicio))
if not WEB and not enlaces:   # 22/10/2026: el logo animado al abrir (la web, en su página: js/arranque.js); con un enlace, no
    try:
        from catode import arranque
        _capa_arranque = arranque.mostrar(v)
    except Exception as _error:   # noqa: BLE001 (sin logo, la app arranca igual)
        print("Cat-ode: sin logo de arranque:", _error, file=sys.stderr, flush=True)
if not WEB and "--prueba" not in sys.argv and "--medir" not in sys.argv:   # 22/10/2026: novedades de la versión, tras el logo
    from PySide6.QtCore import QTimer   # 22/10 18:0x: sin esto Linux se cerraba al abrir (NameError; las pruebas no pasan por aquí)
    QTimer.singleShot(0, lambda: v.novedades_version(globals().get("_capa_arranque")))
if "--medir" in sys.argv and not WEB:   # uso real: tiempos de arranque y de cada vídeo, y si aguanta sonando
    from catode import medir
    medir.empezar(app, v)
if "--prueba" in sys.argv and not WEB:   # prueba sin mirar la pantalla (con la web: VentanaWeb → prueba_web al llegar «lista»)
    from catode import prueba
    prueba.empezar(app, v)
codigo = app.exec()
if os.name == "nt":
    if WEB:   # 06/10/2026: con WebView2 (pythonnet/CLR) cargado, ExitProcess se quedaba colgado en la descarga de las DLL
        # 06/10/2026 tarde: con pythonw (como la abre el autor) sys.stdout es None; el flush fallaba, saltaba al except y
        # NO se llegaba a TerminateProcess: quedaba os._exit, que se cuelga → proceso atascado y la app no volvía a abrir
        try:
            if sys.stderr is not None:
                print(f"Cat-ode: salida {codigo}", file=sys.stderr, flush=True)
            if sys.stdout is not None:
                sys.stdout.flush()
        except Exception:   # noqa: BLE001
            pass
        try:
            if os.environ.get("CATODE_CIERRE_VIEJO"):   # solo para pruebas/windows_cierre.sh: reproduce el fallo (sin TerminateProcess)
                raise RuntimeError("cierre viejo")
            import ctypes
            from ctypes import wintypes
            k = ctypes.windll.kernel32
            k.GetCurrentProcess.restype = wintypes.HANDLE   # sin esto el seudoasa -1 llega truncada y no termina nada
            k.TerminateProcess.argtypes = [wintypes.HANDLE, wintypes.UINT]
            k.TerminateProcess(k.GetCurrentProcess(), int(codigo) & 0xFFFFFFFF)
        except Exception:   # noqa: BLE001
            pass
    os._exit(codigo)   # sin pasar por los finalizadores: mpv sigue vivo y al liberarlo con la ventana ya cerrada revienta
sys.exit(codigo)
